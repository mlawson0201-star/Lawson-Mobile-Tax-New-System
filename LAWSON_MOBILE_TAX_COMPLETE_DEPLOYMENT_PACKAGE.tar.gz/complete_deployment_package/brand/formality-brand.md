
# Formality Tax - White-Label Brand Guidelines

## Brand Overview

**Brand Name:** Formality Tax  
**Tagline:** "Professional Tax Solutions, Your Brand"  
**Mission:** To empower tax professionals with white-label technology that enhances their practice  
**Vision:** To be the leading white-label tax platform for modern tax professionals  
**Values:** Partnership, Flexibility, Excellence, Innovation, Support  

---

## Brand Personality

### Primary Traits
- **Professional:** Sophisticated and credible for B2B audience
- **Flexible:** Adaptable to partner brands and requirements
- **Supportive:** Dedicated to partner success and growth
- **Innovative:** Cutting-edge technology for competitive advantage
- **Reliable:** Dependable platform partners can trust

### Voice & Tone
- **Professional:** Business-appropriate while remaining approachable
- **Knowledgeable:** Demonstrate deep industry expertise
- **Collaborative:** Partner-focused, not vendor-focused
- **Solution-Oriented:** Focus on solving business challenges
- **Confident:** Assured in our platform capabilities

### Communication Style
- Use "partner" instead of "client" or "customer"
- Focus on business outcomes and ROI
- Provide specific metrics and case studies
- Emphasize customization and flexibility
- Always position as a partnership, not a service

---

## Color Palette

### Primary Colors

**Formality Purple**
- Hex: #7C3AED
- RGB: 124, 58, 237
- CMYK: 48, 75, 0, 7
- Usage: Primary brand color, premium positioning

**Formality Indigo**
- Hex: #4F46E5
- RGB: 79, 70, 229
- CMYK: 66, 69, 0, 10
- Usage: Secondary brand color, technology emphasis

### Secondary Colors

**Success Emerald**
- Hex: #059669
- RGB: 5, 150, 105
- CMYK: 97, 0, 30, 41
- Usage: Success metrics, growth indicators

**Premium Gold**
- Hex: #D97706
- RGB: 217, 119, 6
- CMYK: 0, 45, 97, 15
- Usage: Premium features, highlights

**Alert Coral**
- Hex: #DC2626
- RGB: 220, 38, 38
- CMYK: 0, 83, 83, 14
- Usage: Important notices, urgent items

### Neutral Colors

**Slate Dark**
- Hex: #1E293B
- RGB: 30, 41, 59
- CMYK: 49, 31, 0, 77
- Usage: Primary text, professional headings

**Slate Medium**
- Hex: #64748B
- RGB: 100, 116, 139
- CMYK: 28, 17, 0, 45
- Usage: Secondary text, descriptions

**Slate Light**
- Hex: #F1F5F9
- RGB: 241, 245, 249
- CMYK: 3, 2, 0, 2
- Usage: Backgrounds, subtle dividers

**Pure White**
- Hex: #FFFFFF
- RGB: 255, 255, 255
- CMYK: 0, 0, 0, 0
- Usage: Clean backgrounds, contrast

---

## Typography

### Primary Typeface: Poppins
**Usage:** Headlines, branding, premium applications
**Characteristics:** Modern, professional, distinctive
**Weights Available:** Light (300), Regular (400), Medium (500), Semibold (600), Bold (700)

**Brand Headlines:** Poppins Semibold (600) or Bold (700)
**Section Headers:** Poppins Medium (500)
**Emphasis Text:** Poppins Medium (500)

### Secondary Typeface: Inter
**Usage:** Body text, UI elements, technical content
**Characteristics:** Highly legible, professional, versatile
**Weights Available:** Regular (400), Medium (500), Semibold (600)

**Body Text:** Inter Regular (400)
**UI Elements:** Inter Medium (500)
**Captions:** Inter Regular (400)

### Typography Scale
- **H1:** 56px / 3.5rem (Desktop), 40px / 2.5rem (Mobile)
- **H2:** 40px / 2.5rem (Desktop), 32px / 2rem (Mobile)
- **H3:** 32px / 2rem (Desktop), 28px / 1.75rem (Mobile)
- **H4:** 28px / 1.75rem (Desktop), 24px / 1.5rem (Mobile)
- **Body Large:** 20px / 1.25rem
- **Body Regular:** 18px / 1.125rem
- **Body Small:** 16px / 1rem
- **Caption:** 14px / 0.875rem

---

## Logo Guidelines

### Primary Logo
**Format:** Horizontal lockup with geometric icon and wordmark
**Minimum Size:** 140px width (digital), 1.25 inches width (print)
**Clear Space:** Minimum 1.5x the height of the "F" in Formality on all sides

### Logo Variations
1. **Full Color on White:** Primary usage
2. **Full Color on Dark:** For dark backgrounds
3. **White on Color:** For colored backgrounds
4. **Monochrome:** Single color applications
5. **Icon Only:** When space is extremely limited (minimum 40px)

### White-Label Considerations
- Logo can be completely replaced with partner branding
- Color scheme can be customized to partner brand
- Typography can be adjusted to match partner style
- All UI elements are customizable

---

## White-Label Customization

### Brand Flexibility
- **Complete Rebranding:** Partners can use their own logo, colors, fonts
- **Partial Customization:** Mix partner branding with Formality elements
- **Co-Branding:** "Powered by Formality" options available
- **Domain Customization:** Custom subdomains or full domains

### Customizable Elements
- Logo and brand marks
- Color palette (primary, secondary, accent colors)
- Typography (within technical constraints)
- Custom domain/subdomain
- Email templates and communications
- Marketing materials and templates
- User interface themes

### Technical Specifications
- **Logo Formats:** SVG (preferred), PNG, PDF
- **Color Formats:** Hex, RGB, CMYK values required
- **Font Requirements:** Web-safe fonts or custom font licensing
- **Image Specifications:** High-resolution assets for all applications

---

## Partner Portal Design

### Design Principles
1. **Professional:** Clean, sophisticated interface
2. **Intuitive:** Easy navigation for tax professionals
3. **Customizable:** Flexible branding options
4. **Efficient:** Streamlined workflows for productivity
5. **Scalable:** Grows with partner business needs

### Interface Elements
- **Dashboard:** Clean metrics and KPI displays
- **Navigation:** Consistent, logical menu structure
- **Forms:** Professional styling with clear validation
- **Tables:** Easy-to-scan data presentation
- **Charts:** Clear data visualization

---

## Marketing Materials

### Partner-Focused Messaging
- **ROI-Driven:** Focus on business benefits and returns
- **Competitive Advantage:** How platform differentiates partners
- **Scalability:** Growth potential and expansion opportunities
- **Support:** Comprehensive training and ongoing assistance
- **Technology:** Advanced features and capabilities

### Collateral Types
- **Sales Sheets:** One-page partner benefits overview
- **Case Studies:** Success stories with metrics
- **White Papers:** Industry insights and thought leadership
- **Webinar Materials:** Educational content for partners
- **Proposal Templates:** Customizable partner proposals

---

## Revenue Sharing Model

### Transparent Pricing
- **30% Platform Fee:** Clear, consistent revenue share
- **No Hidden Costs:** Transparent fee structure
- **Volume Discounts:** Incentives for high-volume partners
- **Custom Pricing:** Available for enterprise partners

### Value Proposition
- **Technology Investment:** Continuous platform improvements
- **Support Services:** Dedicated partner success team
- **Marketing Support:** Co-marketing opportunities
- **Training Programs:** Comprehensive partner education

---

## Partner Success Framework

### Onboarding Process
1. **Discovery Call:** Understand partner needs and goals
2. **Platform Demo:** Customized demonstration
3. **Branding Setup:** Custom theme and domain configuration
4. **Training Program:** Comprehensive platform education
5. **Launch Support:** Dedicated assistance during rollout

### Ongoing Support
- **Dedicated Success Manager:** Single point of contact
- **Regular Check-ins:** Quarterly business reviews
- **Training Updates:** Ongoing education and certification
- **Marketing Support:** Co-marketing opportunities
- **Technical Support:** Priority platform assistance

---

## Competitive Positioning

### vs. Drake Software
- **Modern Technology:** Cloud-based vs. desktop-bound
- **Mobile Experience:** Full mobile capability
- **White-Label Options:** Complete customization available

### vs. Intuit ProConnect
- **Revenue Sharing:** Partner-friendly economics
- **Customization:** Full white-label capabilities
- **Support Model:** Dedicated partner success focus

### vs. TaxSlayer Pro
- **Technology Stack:** Modern, API-first architecture
- **Partner Focus:** Built specifically for partnerships
- **Scalability:** Enterprise-grade infrastructure

---

## Brand Voice Examples

### Headlines
✅ "Grow Your Practice with White-Label Tax Technology"
✅ "Your Brand, Our Platform, Unlimited Potential"
✅ "Professional Tax Solutions That Scale with You"

❌ "Revolutionary Tax Software for Modern Professionals"
❌ "Advanced Tax Technology Solutions"
❌ "Comprehensive Tax Platform Services"

### Body Copy
✅ "We understand that your brand is your most valuable asset. That's why our platform is completely customizable to match your firm's identity while providing the advanced technology your clients expect."

❌ "Our sophisticated tax preparation platform leverages cutting-edge algorithms to optimize the user experience through streamlined workflows and enhanced functionality."

### Call-to-Actions
✅ "Schedule Your Demo"
✅ "Explore Partnership Options"
✅ "See Your Custom Platform"

❌ "Request Information"
❌ "Learn More About Solutions"
❌ "Access Platform Features"

---

## Success Metrics

### Partner KPIs
- **Revenue Growth:** Year-over-year partner revenue increase
- **Client Retention:** Partner client retention rates
- **Platform Adoption:** Feature usage and engagement
- **Support Satisfaction:** Partner support ratings
- **Time to Value:** Speed of partner onboarding and success

### Platform Metrics
- **Uptime:** 99.9% platform availability
- **Performance:** Sub-2-second page load times
- **Security:** Zero data breaches, SOC 2 compliance
- **Accuracy:** 99.7% tax calculation accuracy
- **Processing Speed:** 24-hour average turnaround

---

## Legal and Compliance

### Partnership Agreement
- **Revenue Sharing Terms:** Clear percentage and payment schedule
- **Intellectual Property:** Rights and usage guidelines
- **Data Protection:** GLBA compliance and security standards
- **Termination Clauses:** Fair and reasonable exit terms
- **Support Obligations:** Defined service levels

### Compliance Standards
- **IRS Regulations:** Full compliance with tax preparation rules
- **State Requirements:** Licensed in all 50 states
- **Data Security:** SOC 2 Type II certification
- **Privacy Protection:** GLBA and state privacy law compliance
- **Professional Standards:** AICPA and NATP guidelines

---

## Contact Information

**Partner Success:** partners@formalitytax.com  
**Sales Inquiries:** sales@formalitytax.com  
**Technical Support:** support@formalitytax.com  
**Brand Assets:** assets@formalitytax.com  

**Phone:** 1-800-FORMALITY  
**Address:** [Business Address]  

---

*Brand Guidelines Version 1.0*  
*Last Updated: August 22, 2025*  
*© 2025 Formality Tax. All rights reserved.*
