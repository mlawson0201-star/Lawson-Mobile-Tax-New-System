
// Lawson Mobile Tax - Social Media Automation Platform JavaScript

class SocialMediaApp {
    constructor() {
        this.apiBase = '/api';
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadDashboardData();
    }

    bindEvents() {
        // Post creation form
        const postForm = document.getElementById('postForm');
        if (postForm) {
            postForm.addEventListener('submit', (e) => this.handlePostSubmit(e));
        }

        // Campaign creation form
        const campaignForm = document.getElementById('campaignForm');
        if (campaignForm) {
            campaignForm.addEventListener('submit', (e) => this.handleCampaignSubmit(e));
        }

        // Template creation form
        const templateForm = document.getElementById('templateForm');
        if (templateForm) {
            templateForm.addEventListener('submit', (e) => this.handleTemplateSubmit(e));
        }

        // Account creation form
        const accountForm = document.getElementById('accountForm');
        if (accountForm) {
            accountForm.addEventListener('submit', (e) => this.handleAccountSubmit(e));
        }

        // Generate content button
        const generateBtn = document.getElementById('generateContent');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => this.generateContent());
        }

        // Modal controls
        this.bindModalEvents();

        // Platform selection
        this.bindPlatformEvents();

        // Analytics refresh
        const refreshAnalytics = document.getElementById('refreshAnalytics');
        if (refreshAnalytics) {
            refreshAnalytics.addEventListener('click', () => this.loadAnalytics());
        }
    }

    bindModalEvents() {
        // Open modals
        document.querySelectorAll('[data-modal]').forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                const modalId = trigger.getAttribute('data-modal');
                this.openModal(modalId);
            });
        });

        // Close modals
        document.querySelectorAll('.close, .modal-close').forEach(closeBtn => {
            closeBtn.addEventListener('click', () => this.closeModals());
        });

        // Close modal on outside click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModals();
                }
            });
        });
    }

    bindPlatformEvents() {
        // Platform selection checkboxes
        document.querySelectorAll('input[name="platforms"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => this.updatePlatformSelection());
        });

        // Platform-specific settings
        document.querySelectorAll('.platform-settings').forEach(setting => {
            setting.addEventListener('change', () => this.updatePlatformSettings());
        });
    }

    async loadDashboardData() {
        try {
            // Load recent posts
            const postsResponse = await fetch(`${this.apiBase}/posts?limit=5`);
            const postsData = await postsResponse.json();
            
            if (postsData.success) {
                this.updateRecentPosts(postsData.posts);
            }

            // Load platform status
            const platformsResponse = await fetch(`${this.apiBase}/platforms`);
            const platformsData = await platformsResponse.json();
            
            if (platformsData.success) {
                this.updatePlatformStatus(platformsData.platforms);
            }

            // Load accounts
            const accountsResponse = await fetch(`${this.apiBase}/accounts`);
            const accountsData = await accountsResponse.json();
            
            if (accountsData.success) {
                this.updateAccountStatus(accountsData.accounts);
            }

        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.showNotification('Error loading dashboard data', 'error');
        }
    }

    async handlePostSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const selectedPlatforms = Array.from(document.querySelectorAll('input[name="platforms"]:checked'))
            .map(cb => cb.value);
        
        if (selectedPlatforms.length === 0) {
            this.showNotification('Please select at least one platform', 'warning');
            return;
        }

        const postData = {
            content: formData.get('content'),
            platforms: selectedPlatforms,
            hashtags: formData.get('hashtags') ? formData.get('hashtags').split(',').map(h => h.trim()) : [],
            media_urls: formData.get('media_urls') ? formData.get('media_urls').split(',').map(u => u.trim()) : [],
            scheduled_time: formData.get('scheduled_time') || null,
            metadata: {}
        };

        try {
            this.showLoading('Creating post...');
            
            const response = await fetch(`${this.apiBase}/posts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(postData)
            });

            const result = await response.json();
            
            if (result.success) {
                this.showNotification('Post created successfully!', 'success');
                this.closeModals();
                e.target.reset();
                this.loadDashboardData();
            } else {
                this.showNotification('Error creating post: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error creating post:', error);
            this.showNotification('Error creating post', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async handleCampaignSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const selectedPlatforms = Array.from(document.querySelectorAll('input[name="campaign_platforms"]:checked'))
            .map(cb => cb.value);
        
        const campaignData = {
            name: formData.get('name'),
            description: formData.get('description'),
            start_date: formData.get('start_date'),
            end_date: formData.get('end_date') || null,
            platforms: selectedPlatforms,
            content_templates: [],
            posting_schedule: {
                frequency: formData.get('frequency'),
                times: formData.get('posting_times') ? formData.get('posting_times').split(',').map(t => t.trim()) : ['09:00'],
                days_of_week: [0, 1, 2, 3, 4] // Mon-Fri default
            }
        };

        try {
            this.showLoading('Creating campaign...');
            
            const response = await fetch(`${this.apiBase}/campaigns`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(campaignData)
            });

            const result = await response.json();
            
            if (result.success) {
                this.showNotification(`Campaign created with ${result.scheduled_jobs} scheduled posts!`, 'success');
                this.closeModals();
                e.target.reset();
                this.loadCampaigns();
            } else {
                this.showNotification('Error creating campaign: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error creating campaign:', error);
            this.showNotification('Error creating campaign', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async handleTemplateSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const selectedPlatforms = Array.from(document.querySelectorAll('input[name="template_platforms"]:checked'))
            .map(cb => cb.value);
        
        const templateData = {
            name: formData.get('name'),
            category: formData.get('category'),
            template_text: formData.get('template_text'),
            platforms: selectedPlatforms,
            hashtags: {},
            media_requirements: {}
        };

        try {
            this.showLoading('Creating template...');
            
            const response = await fetch(`${this.apiBase}/templates`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(templateData)
            });

            const result = await response.json();
            
            if (result.success) {
                this.showNotification('Template created successfully!', 'success');
                this.closeModals();
                e.target.reset();
                this.loadTemplates();
            } else {
                this.showNotification('Error creating template: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error creating template:', error);
            this.showNotification('Error creating template', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async handleAccountSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        
        const accountData = {
            platform: formData.get('platform'),
            account_name: formData.get('account_name'),
            account_id: formData.get('account_id'),
            access_token: formData.get('access_token'),
            refresh_token: formData.get('refresh_token') || null
        };

        try {
            this.showLoading('Adding account...');
            
            const response = await fetch(`${this.apiBase}/accounts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(accountData)
            });

            const result = await response.json();
            
            if (result.success) {
                const message = result.authenticated ? 
                    'Account added and authenticated successfully!' : 
                    'Account added but authentication failed. Please check credentials.';
                const type = result.authenticated ? 'success' : 'warning';
                
                this.showNotification(message, type);
                this.closeModals();
                e.target.reset();
                this.loadDashboardData();
            } else {
                this.showNotification('Error adding account: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error adding account:', error);
            this.showNotification('Error adding account', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async generateContent() {
        const templateSelect = document.getElementById('templateSelect');
        const platformSelect = document.getElementById('platformSelect');
        const contentTextarea = document.getElementById('content');
        const hashtagsInput = document.getElementById('hashtags');

        if (!templateSelect || !platformSelect) {
            this.showNotification('Template and platform selection required', 'warning');
            return;
        }

        const templateId = templateSelect.value;
        const platform = platformSelect.value;

        if (!templateId || !platform) {
            this.showNotification('Please select a template and platform', 'warning');
            return;
        }

        try {
            this.showLoading('Generating content...');
            
            const response = await fetch(`${this.apiBase}/generate-content`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    template_id: parseInt(templateId),
                    platform: platform,
                    context: {}
                })
            });

            const result = await response.json();
            
            if (result.success) {
                if (contentTextarea) {
                    contentTextarea.value = result.content;
                }
                if (hashtagsInput && result.hashtags) {
                    hashtagsInput.value = result.hashtags.join(', ');
                }
                this.showNotification('Content generated successfully!', 'success');
            } else {
                this.showNotification('Error generating content: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error generating content:', error);
            this.showNotification('Error generating content', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async loadAnalytics() {
        try {
            this.showLoading('Loading analytics...');
            
            const response = await fetch(`${this.apiBase}/analytics/report?days=30`);
            const result = await response.json();
            
            if (result.success) {
                this.updateAnalyticsDisplay(result.report);
                this.showNotification('Analytics updated', 'success');
            } else {
                this.showNotification('Error loading analytics: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error loading analytics:', error);
            this.showNotification('Error loading analytics', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async deletePost(postId) {
        if (!confirm('Are you sure you want to delete this post?')) {
            return;
        }

        try {
            this.showLoading('Deleting post...');
            
            const response = await fetch(`${this.apiBase}/posts/${postId}`, {
                method: 'DELETE'
            });

            const result = await response.json();
            
            if (result.success) {
                this.showNotification('Post deleted successfully', 'success');
                this.loadDashboardData();
            } else {
                this.showNotification('Error deleting post: ' + (result.error || 'Unknown error'), 'error');
            }

        } catch (error) {
            console.error('Error deleting post:', error);
            this.showNotification('Error deleting post', 'error');
        } finally {
            this.hideLoading();
        }
    }

    updateRecentPosts(posts) {
        const container = document.getElementById('recentPosts');
        if (!container) return;

        if (posts.length === 0) {
            container.innerHTML = '<p class="text-center">No recent posts</p>';
            return;
        }

        const postsHtml = posts.map(post => `
            <div class="post-item">
                <div class="post-header">
                    <span class="platform-badge ${post.platform}">${post.platform}</span>
                    <span class="status-badge ${post.status}">${post.status}</span>
                </div>
                <div class="post-content">
                    ${post.content.substring(0, 100)}${post.content.length > 100 ? '...' : ''}
                </div>
                <div class="post-meta">
                    <small>${new Date(post.created_at).toLocaleDateString()}</small>
                    <button class="btn btn-sm btn-danger" onclick="app.deletePost(${post.id})">Delete</button>
                </div>
            </div>
        `).join('');

        container.innerHTML = postsHtml;
    }

    updatePlatformStatus(platforms) {
        const container = document.getElementById('platformStatus');
        if (!container) return;

        const platformsHtml = Object.entries(platforms).map(([key, config]) => `
            <div class="platform-item ${config.enabled ? 'enabled' : 'disabled'}">
                <div class="platform-icon ${key}">
                    ${config.name.charAt(0)}
                </div>
                <div class="platform-info">
                    <div class="platform-name">${config.name}</div>
                    <div class="platform-status">${config.enabled ? 'Connected' : 'Not Connected'}</div>
                </div>
            </div>
        `).join('');

        container.innerHTML = platformsHtml;
    }

    updateAccountStatus(accounts) {
        // Update account-related UI elements
        const accountCount = document.getElementById('accountCount');
        if (accountCount) {
            accountCount.textContent = accounts.filter(acc => acc.is_active).length;
        }
    }

    updateAnalyticsDisplay(report) {
        // Update analytics charts and data
        const overview = report.overview || {};
        
        // Update overview stats
        const totalEngagement = document.getElementById('totalEngagement');
        if (totalEngagement) {
            totalEngagement.textContent = overview.total_engagement || 0;
        }

        const totalReach = document.getElementById('totalReach');
        if (totalReach) {
            totalReach.textContent = overview.total_reach || 0;
        }

        const avgEngagement = document.getElementById('avgEngagement');
        if (avgEngagement) {
            avgEngagement.textContent = Math.round(overview.average_engagement_rate || 0);
        }

        // Update platform breakdown
        this.updatePlatformBreakdown(report.platform_breakdown || {});

        // Update top posts
        this.updateTopPosts(report.top_performing_posts || []);
    }

    updatePlatformBreakdown(breakdown) {
        const container = document.getElementById('platformBreakdown');
        if (!container) return;

        const breakdownHtml = Object.entries(breakdown).map(([platform, data]) => `
            <div class="platform-stat">
                <div class="platform-name">${platform}</div>
                <div class="platform-metrics">
                    <div class="metric">
                        <span class="metric-label">Posts:</span>
                        <span class="metric-value">${data.post_count}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Engagement:</span>
                        <span class="metric-value">${data.total_engagement}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Avg Reach:</span>
                        <span class="metric-value">${Math.round(data.average_reach)}</span>
                    </div>
                </div>
            </div>
        `).join('');

        container.innerHTML = breakdownHtml;
    }

    updateTopPosts(topPosts) {
        const container = document.getElementById('topPosts');
        if (!container) return;

        if (topPosts.length === 0) {
            container.innerHTML = '<p class="text-center">No posts data available</p>';
            return;
        }

        const postsHtml = topPosts.slice(0, 5).map(post => `
            <div class="top-post-item">
                <div class="post-platform">${post.platform}</div>
                <div class="post-content">${post.content}</div>
                <div class="post-engagement">${post.engagement} engagements</div>
            </div>
        `).join('');

        container.innerHTML = postsHtml;
    }

    updatePlatformSelection() {
        const selectedPlatforms = Array.from(document.querySelectorAll('input[name="platforms"]:checked'))
            .map(cb => cb.value);
        
        // Update character count based on selected platforms
        this.updateCharacterCount(selectedPlatforms);
    }

    updateCharacterCount(platforms) {
        const contentTextarea = document.getElementById('content');
        const charCount = document.getElementById('charCount');
        
        if (!contentTextarea || !charCount) return;

        const content = contentTextarea.value;
        const minLimit = Math.min(...platforms.map(p => this.getPlatformCharLimit(p)));
        
        charCount.textContent = `${content.length}/${minLimit}`;
        charCount.className = content.length > minLimit ? 'char-count over-limit' : 'char-count';
    }

    getPlatformCharLimit(platform) {
        const limits = {
            'facebook': 2200,
            'instagram': 2200,
            'twitter': 280,
            'linkedin': 3000,
            'tiktok': 2200,
            'youtube': 5000,
            'pinterest': 500,
            'reddit': 10000
        };
        return limits[platform] || 2000;
    }

    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }

    closeModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        document.body.style.overflow = 'auto';
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span>${message}</span>
            <button class="notification-close">&times;</button>
        `;

        // Add to page
        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);

        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        });
    }

    showLoading(message = 'Loading...') {
        const loading = document.getElementById('loadingOverlay') || this.createLoadingOverlay();
        const loadingText = loading.querySelector('.loading-text');
        if (loadingText) {
            loadingText.textContent = message;
        }
        loading.style.display = 'flex';
    }

    hideLoading() {
        const loading = document.getElementById('loadingOverlay');
        if (loading) {
            loading.style.display = 'none';
        }
    }

    createLoadingOverlay() {
        const overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="loading-content">
                <div class="spinner"></div>
                <div class="loading-text">Loading...</div>
            </div>
        `;
        document.body.appendChild(overlay);
        return overlay;
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new SocialMediaApp();
});

// Add notification styles
const notificationStyles = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 5px;
        color: white;
        font-weight: 600;
        z-index: 1001;
        display: flex;
        align-items: center;
        gap: 1rem;
        min-width: 300px;
        animation: slideIn 0.3s ease-out;
    }
    
    .notification-success { background-color: #27ae60; }
    .notification-error { background-color: #e74c3c; }
    .notification-warning { background-color: #f39c12; }
    .notification-info { background-color: #3498db; }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        margin-left: auto;
    }
    
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 1002;
    }
    
    .loading-content {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        text-align: center;
    }
    
    .loading-text {
        margin-top: 1rem;
        font-weight: 600;
        color: #2c3e50;
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;

// Add styles to head
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);
