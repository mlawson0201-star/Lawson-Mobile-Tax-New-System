
"""
Ecosystem Integrations
Financial services and third-party platform integrations
"""

from .financial_aggregation import FinancialDataAggregator
from .investment_analyzer import InvestmentPortfolioAnalyzer
from .crypto_processor import CryptocurrencyProcessor
from .real_estate_tracker import RealEstateTracker
from .expense_categorizer import BusinessExpenseCategorizer
from .payroll_integrator import PayrollSystemIntegrator
from .accounting_sync import AccountingSoftwareSync
from .insurance_tracker import InsurancePolicyTracker
from .retirement_optimizer import RetirementAccountOptimizer
from .marketplace_connector import MarketplaceConnector

__version__ = "1.0.0"
__all__ = [
    "FinancialDataAggregator",
    "InvestmentPortfolioAnalyzer",
    "CryptocurrencyProcessor",
    "RealEstateTracker", 
    "BusinessExpenseCategorizer",
    "PayrollSystemIntegrator",
    "AccountingSoftwareSync",
    "InsurancePolicyTracker",
    "RetirementAccountOptimizer",
    "MarketplaceConnector"
]
