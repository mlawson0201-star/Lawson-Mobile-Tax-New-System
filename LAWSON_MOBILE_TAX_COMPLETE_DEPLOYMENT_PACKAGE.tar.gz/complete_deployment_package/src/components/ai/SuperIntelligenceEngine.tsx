"use client";

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Brain, 
  FileText, 
  TrendingUp, 
  Shield, 
  Zap, 
  MessageSquare,
  Eye,
  AlertTriangle,
  BookOpen,
  Target,
  Sparkles,
  CheckCircle,
  Clock,
  DollarSign
} from 'lucide-react';

interface AIInsight {
  id: string;
  type: 'optimization' | 'risk' | 'recommendation' | 'warning';
  title: string;
  description: string;
  confidence: number;
  potential_savings?: number;
  action_required?: boolean;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

interface DocumentAnalysis {
  document_type: string;
  extracted_data: Record<string, any>;
  confidence_scores: Record<string, number>;
  validation_status: 'valid' | 'needs_review' | 'invalid';
  anomalies: string[];
}

interface TaxOptimization {
  strategy: string;
  estimated_savings: number;
  implementation_steps: string[];
  timeline: string;
  risk_level: 'low' | 'medium' | 'high';
}

export default function SuperIntelligenceEngine() {
  const [activeTab, setActiveTab] = useState('overview');
  const [query, setQuery] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [documentAnalyses, setDocumentAnalyses] = useState<DocumentAnalysis[]>([]);
  const [optimizations, setOptimizations] = useState<TaxOptimization[]>([]);
  const [auditRisk, setAuditRisk] = useState(0.15);
  const [confidenceScore, setConfidenceScore] = useState(0.92);

  useEffect(() => {
    // Initialize with sample data
    setInsights([
      {
        id: '1',
        type: 'optimization',
        title: 'Home Office Deduction Opportunity',
        description: 'Based on your work patterns, you may qualify for a $3,200 home office deduction.',
        confidence: 0.89,
        potential_savings: 3200,
        action_required: true,
        priority: 'high'
      },
      {
        id: '2',
        type: 'risk',
        title: 'Business Meal Documentation',
        description: 'Some business meal expenses lack proper documentation. This could trigger audit scrutiny.',
        confidence: 0.76,
        action_required: true,
        priority: 'medium'
      },
      {
        id: '3',
        type: 'recommendation',
        title: 'Retirement Contribution Optimization',
        description: 'Increasing your 401(k) contribution by $2,000 could save $500 in taxes.',
        confidence: 0.94,
        potential_savings: 500,
        action_required: false,
        priority: 'medium'
      }
    ]);

    setDocumentAnalyses([
      {
        document_type: 'W-2',
        extracted_data: {
          employer: 'Tech Corp Inc.',
          wages: 125000,
          federal_withholding: 18750,
          state_withholding: 6250
        },
        confidence_scores: {
          employer: 0.98,
          wages: 0.95,
          federal_withholding: 0.92,
          state_withholding: 0.89
        },
        validation_status: 'valid',
        anomalies: []
      },
      {
        document_type: '1099-NEC',
        extracted_data: {
          payer: 'Consulting LLC',
          nonemployee_compensation: 15000
        },
        confidence_scores: {
          payer: 0.87,
          nonemployee_compensation: 0.91
        },
        validation_status: 'needs_review',
        anomalies: ['Unusual payment amount for this payer']
      }
    ]);

    setOptimizations([
      {
        strategy: 'Tax Loss Harvesting',
        estimated_savings: 1200,
        implementation_steps: [
          'Review investment portfolio for unrealized losses',
          'Sell losing positions before year-end',
          'Reinvest in similar but not identical securities'
        ],
        timeline: '2-3 weeks',
        risk_level: 'low'
      },
      {
        strategy: 'Business Equipment Purchase',
        estimated_savings: 2800,
        implementation_steps: [
          'Purchase qualifying business equipment before Dec 31',
          'Ensure equipment is used >50% for business',
          'Apply Section 179 deduction'
        ],
        timeline: '1 week',
        risk_level: 'medium'
      }
    ]);
  }, []);

  const handleAnalyzeQuery = async () => {
    if (!query.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Add a new insight based on the query
    const newInsight: AIInsight = {
      id: Date.now().toString(),
      type: 'recommendation',
      title: 'AI Analysis Result',
      description: `Based on your query "${query}", I recommend reviewing your quarterly estimated tax payments to avoid penalties.`,
      confidence: 0.85,
      potential_savings: Math.floor(Math.random() * 1000) + 200,
      action_required: true,
      priority: 'medium'
    };
    
    setInsights(prev => [newInsight, ...prev]);
    setQuery('');
    setIsAnalyzing(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'optimization': return <TrendingUp className="h-4 w-4" />;
      case 'risk': return <AlertTriangle className="h-4 w-4" />;
      case 'recommendation': return <Target className="h-4 w-4" />;
      case 'warning': return <Shield className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="h-8 w-8 text-purple-600" />
            AI Superintelligence Engine
          </h1>
          <p className="text-muted-foreground mt-1">
            Advanced neural tax reasoning with GPT-4o integration
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Confidence Score</div>
            <div className="text-2xl font-bold text-green-600">
              {(confidenceScore * 100).toFixed(1)}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Audit Risk</div>
            <div className="text-2xl font-bold text-orange-600">
              {(auditRisk * 100).toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* Natural Language Query */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Ask the AI Tax Expert
          </CardTitle>
          <CardDescription>
            Ask any tax question in natural language and get personalized insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Textarea
              placeholder="e.g., 'Can I deduct my home office expenses?' or 'What's the best way to minimize my tax liability?'"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="min-h-[60px]"
            />
            <Button 
              onClick={handleAnalyzeQuery}
              disabled={isAnalyzing || !query.trim()}
              className="px-6"
            >
              {isAnalyzing ? (
                <>
                  <Sparkles className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4 mr-2" />
                  Analyze
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Potential Savings
                    </p>
                    <p className="text-2xl font-bold text-green-600">
                      ${insights.reduce((sum, insight) => sum + (insight.potential_savings || 0), 0).toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Documents Processed
                    </p>
                    <p className="text-2xl font-bold">
                      {documentAnalyses.length}
                    </p>
                  </div>
                  <FileText className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Active Insights
                    </p>
                    <p className="text-2xl font-bold">
                      {insights.filter(i => i.action_required).length}
                    </p>
                  </div>
                  <Brain className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Optimization Score
                    </p>
                    <p className="text-2xl font-bold text-orange-600">
                      A+
                    </p>
                  </div>
                  <Target className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Recent AI Insights</CardTitle>
              <CardDescription>
                Latest recommendations and findings from the AI engine
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {insights.slice(0, 3).map((insight) => (
                  <div key={insight.id} className="flex items-start gap-3 p-4 border rounded-lg">
                    <div className="flex-shrink-0">
                      {getTypeIcon(insight.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{insight.title}</h4>
                        <Badge className={`${getPriorityColor(insight.priority)} text-white`}>
                          {insight.priority}
                        </Badge>
                        {insight.potential_savings && (
                          <Badge variant="outline" className="text-green-600">
                            ${insight.potential_savings.toLocaleString()} savings
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {insight.description}
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Confidence: {(insight.confidence * 100).toFixed(0)}%</span>
                        {insight.action_required && (
                          <span className="flex items-center gap-1 text-orange-600">
                            <Clock className="h-3 w-3" />
                            Action Required
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Multi-Modal Document Analysis
              </CardTitle>
              <CardDescription>
                AI-powered document processing with OCR and validation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {documentAnalyses.map((analysis, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">{analysis.document_type}</h4>
                      <Badge 
                        variant={analysis.validation_status === 'valid' ? 'default' : 'destructive'}
                      >
                        {analysis.validation_status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <h5 className="text-sm font-medium mb-2">Extracted Data</h5>
                        <div className="space-y-1">
                          {Object.entries(analysis.extracted_data).map(([key, value]) => (
                            <div key={key} className="flex justify-between text-sm">
                              <span className="text-muted-foreground capitalize">
                                {key.replace('_', ' ')}:
                              </span>
                              <span>{typeof value === 'number' ? value.toLocaleString() : value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h5 className="text-sm font-medium mb-2">Confidence Scores</h5>
                        <div className="space-y-2">
                          {Object.entries(analysis.confidence_scores).map(([key, score]) => (
                            <div key={key} className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="capitalize">{key.replace('_', ' ')}</span>
                                <span>{(score * 100).toFixed(0)}%</span>
                              </div>
                              <Progress value={score * 100} className="h-2" />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    {analysis.anomalies.length > 0 && (
                      <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Anomalies detected:</strong> {analysis.anomalies.join(', ')}
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Tax Optimization Strategies
              </CardTitle>
              <CardDescription>
                AI-recommended strategies to minimize your tax liability
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {optimizations.map((optimization, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">{optimization.strategy}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-green-600">
                          ${optimization.estimated_savings.toLocaleString()} savings
                        </Badge>
                        <Badge 
                          variant={optimization.risk_level === 'low' ? 'default' : 'destructive'}
                        >
                          {optimization.risk_level} risk
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h5 className="text-sm font-medium mb-2">Implementation Steps</h5>
                        <ol className="text-sm space-y-1">
                          {optimization.implementation_steps.map((step, stepIndex) => (
                            <li key={stepIndex} className="flex items-start gap-2">
                              <span className="text-muted-foreground">{stepIndex + 1}.</span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>
                      
                      <div>
                        <h5 className="text-sm font-medium mb-2">Timeline</h5>
                        <p className="text-sm text-muted-foreground mb-3">
                          {optimization.timeline}
                        </p>
                        
                        <Button size="sm" className="w-full">
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Implement Strategy
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Audit Risk Assessment
              </CardTitle>
              <CardDescription>
                Real-time analysis of potential audit triggers and mitigation strategies
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Overall Risk Score */}
                <div className="text-center p-6 border rounded-lg">
                  <div className="text-4xl font-bold text-orange-600 mb-2">
                    {(auditRisk * 100).toFixed(1)}%
                  </div>
                  <div className="text-lg font-medium mb-1">Overall Audit Risk</div>
                  <div className="text-sm text-muted-foreground">
                    Below average risk level
                  </div>
                </div>

                {/* Risk Categories */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { category: 'Income Verification', risk: 0.12, status: 'Low' },
                    { category: 'Deduction Scrutiny', risk: 0.18, status: 'Medium' },
                    { category: 'Business Expenses', risk: 0.22, status: 'Medium' },
                    { category: 'Investment Reporting', risk: 0.08, status: 'Low' }
                  ].map((item, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">{item.category}</h4>
                        <Badge 
                          variant={item.risk < 0.15 ? 'default' : 'destructive'}
                        >
                          {item.status}
                        </Badge>
                      </div>
                      <Progress value={item.risk * 100} className="mb-2" />
                      <div className="text-sm text-muted-foreground">
                        {(item.risk * 100).toFixed(1)}% risk level
                      </div>
                    </div>
                  ))}
                </div>

                {/* Mitigation Recommendations */}
                <div>
                  <h4 className="font-medium mb-3">Risk Mitigation Recommendations</h4>
                  <div className="space-y-2">
                    {[
                      'Ensure all business meal receipts include business purpose documentation',
                      'Maintain detailed mileage logs for vehicle deductions',
                      'Keep contemporaneous records for all charitable contributions',
                      'Document home office usage with photos and measurements'
                    ].map((recommendation, index) => (
                      <div key={index} className="flex items-start gap-2 p-3 bg-muted rounded-lg">
                        <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                All AI Insights
              </CardTitle>
              <CardDescription>
                Complete list of AI-generated insights and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {insights.map((insight) => (
                  <div key={insight.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(insight.type)}
                        <h4 className="font-medium">{insight.title}</h4>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`${getPriorityColor(insight.priority)} text-white`}>
                          {insight.priority}
                        </Badge>
                        {insight.potential_savings && (
                          <Badge variant="outline" className="text-green-600">
                            ${insight.potential_savings.toLocaleString()}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3">
                      {insight.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Confidence: {(insight.confidence * 100).toFixed(0)}%</span>
                        <span>Type: {insight.type}</span>
                      </div>
                      
                      {insight.action_required && (
                        <Button size="sm" variant="outline">
                          Take Action
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
