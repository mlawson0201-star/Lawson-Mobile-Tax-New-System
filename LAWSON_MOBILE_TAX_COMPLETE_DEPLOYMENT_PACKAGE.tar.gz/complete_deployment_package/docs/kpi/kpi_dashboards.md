
# KPI Dashboards & Analytics
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. KPI Dashboard Overview

### 1.1 Dashboard Architecture
The Lawson Mobile Tax platform provides comprehensive analytics through a multi-tiered dashboard system designed for different user roles and business needs.

### 1.2 Dashboard Hierarchy

```mermaid
graph TB
    subgraph "Executive Dashboard"
        EXEC[Executive Overview]
        REVENUE[Revenue Analytics]
        GROWTH[Growth Metrics]
    end
    
    subgraph "Operational Dashboard"
        OPS[Operations Overview]
        QUALITY[Quality Metrics]
        EFFICIENCY[Efficiency Metrics]
    end
    
    subgraph "Marketing Dashboard"
        MARKETING[Marketing Performance]
        ACQUISITION[Customer Acquisition]
        CAMPAIGNS[Campaign Analytics]
    end
    
    subgraph "White-Label Dashboard"
        TENANT[Tenant Performance]
        RESELLER[Reseller Analytics]
        PAYOUT[Revenue Sharing]
    end
    
    subgraph "Technical Dashboard"
        TECH[System Performance]
        AI[AI Metrics]
        SECURITY[Security Monitoring]
    end
    
    EXEC --> OPS
    EXEC --> MARKETING
    EXEC --> TENANT
    OPS --> TECH
    MARKETING --> CAMPAIGNS
    TENANT --> RESELLER
```

---

## 2. Core KPI Metrics (12 Tiles)

### 2.1 Tile 1: Lead Generation & Conversion

```typescript
interface LeadMetrics {
  totalLeads: number;
  leadSources: {
    organic: number;
    paid: number;
    referral: number;
    direct: number;
  };
  leadToIntakeRate: number;
  intakeToCompleteRate: number;
  paidConversionRate: number;
  trends: {
    period: string;
    change: number;
    direction: 'up' | 'down' | 'stable';
  };
}

class LeadMetricsCalculator {
  async calculateLeadMetrics(dateRange: DateRange, tenantId?: string): Promise<LeadMetrics> {
    const query = `
      WITH lead_funnel AS (
        SELECT 
          l.id as lead_id,
          l.source,
          l.created_at,
          CASE WHEN c.id IS NOT NULL THEN 1 ELSE 0 END as converted_to_client,
          CASE WHEN tr.id IS NOT NULL THEN 1 ELSE 0 END as started_return,
          CASE WHEN p.status = 'succeeded' THEN 1 ELSE 0 END as paid
        FROM leads l
        LEFT JOIN clients c ON l.email = c.email AND l.tenant_id = c.tenant_id
        LEFT JOIN tax_returns tr ON c.id = tr.client_id
        LEFT JOIN payments p ON tr.id = p.tax_return_id
        WHERE l.created_at BETWEEN $1 AND $2
        ${tenantId ? 'AND l.tenant_id = $3' : ''}
      )
      SELECT 
        COUNT(*) as total_leads,
        COUNT(*) FILTER (WHERE source = 'organic') as organic_leads,
        COUNT(*) FILTER (WHERE source = 'paid') as paid_leads,
        COUNT(*) FILTER (WHERE source = 'referral') as referral_leads,
        COUNT(*) FILTER (WHERE source = 'direct') as direct_leads,
        AVG(converted_to_client::float) as lead_to_intake_rate,
        AVG(CASE WHEN converted_to_client = 1 THEN started_return::float END) as intake_to_complete_rate,
        AVG(CASE WHEN started_return = 1 THEN paid::float END) as paid_conversion_rate
      FROM lead_funnel
    `;
    
    const result = await this.database.query(query, [
      dateRange.start, 
      dateRange.end,
      ...(tenantId ? [tenantId] : [])
    ]);
    
    const trends = await this.calculateTrends('leads', dateRange, tenantId);
    
    return {
      totalLeads: result.rows[0].total_leads,
      leadSources: {
        organic: result.rows[0].organic_leads,
        paid: result.rows[0].paid_leads,
        referral: result.rows[0].referral_leads,
        direct: result.rows[0].direct_leads
      },
      leadToIntakeRate: result.rows[0].lead_to_intake_rate,
      intakeToCompleteRate: result.rows[0].intake_to_complete_rate,
      paidConversionRate: result.rows[0].paid_conversion_rate,
      trends
    };
  }
}
```

### 2.2 Tile 2: Revenue Metrics

```typescript
interface RevenueMetrics {
  totalRevenue: number;
  monthlyRecurringRevenue: number;
  averageOrderValue: number;
  revenuePerUser: number;
  revenueByService: {
    taxPreparation: number;
    bankProducts: number;
    bookkeeping: number;
    taxPlanning: number;
    auditDefense: number;
  };
  growthRate: number;
  trends: TrendData;
}

class RevenueMetricsCalculator {
  async calculateRevenueMetrics(dateRange: DateRange, tenantId?: string): Promise<RevenueMetrics> {
    // Total Revenue
    const revenueQuery = `
      SELECT 
        SUM(amount) as total_revenue,
        AVG(amount) as average_order_value,
        COUNT(DISTINCT client_id) as unique_customers,
        SUM(amount) / COUNT(DISTINCT client_id) as revenue_per_user
      FROM payments 
      WHERE status = 'succeeded' 
        AND created_at BETWEEN $1 AND $2
        ${tenantId ? 'AND tenant_id = $3' : ''}
    `;
    
    // Revenue by Service
    const serviceRevenueQuery = `
      SELECT 
        i.service_type,
        SUM(i.amount) as service_revenue
      FROM invoice_line_items i
      JOIN invoices inv ON i.invoice_id = inv.id
      JOIN payments p ON inv.id = p.invoice_id
      WHERE p.status = 'succeeded'
        AND p.created_at BETWEEN $1 AND $2
        ${tenantId ? 'AND p.tenant_id = $3' : ''}
      GROUP BY i.service_type
    `;
    
    // Monthly Recurring Revenue (for subscriptions)
    const mrrQuery = `
      SELECT SUM(monthly_fee) as mrr
      FROM subscriptions 
      WHERE status = 'active'
        ${tenantId ? 'AND tenant_id = $1' : ''}
    `;
    
    const [revenueResult, serviceResult, mrrResult] = await Promise.all([
      this.database.query(revenueQuery, [dateRange.start, dateRange.end, ...(tenantId ? [tenantId] : [])]),
      this.database.query(serviceRevenueQuery, [dateRange.start, dateRange.end, ...(tenantId ? [tenantId] : [])]),
      this.database.query(mrrQuery, tenantId ? [tenantId] : [])
    ]);
    
    const revenueByService = this.mapServiceRevenue(serviceResult.rows);
    const trends = await this.calculateRevenueTrends(dateRange, tenantId);
    
    return {
      totalRevenue: revenueResult.rows[0].total_revenue || 0,
      monthlyRecurringRevenue: mrrResult.rows[0].mrr || 0,
      averageOrderValue: revenueResult.rows[0].average_order_value || 0,
      revenuePerUser: revenueResult.rows[0].revenue_per_user || 0,
      revenueByService,
      growthRate: trends.growthRate,
      trends
    };
  }
}
```

### 2.3 Tile 3: E-Filing Performance

```typescript
interface EFilingMetrics {
  totalSubmissions: number;
  acceptanceRate: number;
  rejectionRate: number;
  averageTurnaroundTime: number;
  rejectionReasons: {
    reason: string;
    count: number;
    percentage: number;
  }[];
  correctionCycleTime: number;
  trends: TrendData;
}

class EFilingMetricsCalculator {
  async calculateEFilingMetrics(dateRange: DateRange, tenantId?: string): Promise
