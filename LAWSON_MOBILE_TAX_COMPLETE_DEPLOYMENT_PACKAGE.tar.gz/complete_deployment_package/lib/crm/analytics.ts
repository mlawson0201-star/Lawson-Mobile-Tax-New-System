
import { prisma } from '@/lib/prisma';
import { LeadStatus, LeadSource } from '@prisma/client';

export interface CRMAnalytics {
  overview: {
    totalLeads: number;
    newLeads: number;
    qualifiedLeads: number;
    convertedLeads: number;
    lostLeads: number;
    conversionRate: number;
    averageDealSize: number;
    totalPipelineValue: number;
  };
  leadSources: {
    source: LeadSource;
    count: number;
    percentage: number;
    conversionRate: number;
  }[];
  pipelineStages: {
    stageId: string;
    stageName: string;
    count: number;
    value: number;
    averageTimeInStage: number;
  }[];
  userPerformance: {
    userId: string;
    userName: string;
    leadsAssigned: number;
    leadsConverted: number;
    conversionRate: number;
    totalValue: number;
  }[];
  trends: {
    date: string;
    newLeads: number;
    convertedLeads: number;
    lostLeads: number;
    pipelineValue: number;
  }[];
  topPerformers: {
    bestConverter: { userId: string; userName: string; rate: number };
    highestValue: { userId: string; userName: string; value: number };
    mostActive: { userId: string; userName: string; activities: number };
  };
}

export interface LeadConversionFunnel {
  stage: string;
  count: number;
  percentage: number;
  dropOffRate: number;
}

export interface SalesMetrics {
  totalRevenue: number;
  averageDealSize: number;
  salesCycleLength: number;
  winRate: number;
  pipelineVelocity: number;
  forecastedRevenue: number;
}

export class CRMAnalyticsService {
  private tenantId: string;

  constructor(tenantId: string) {
    this.tenantId = tenantId;
  }

  async getAnalytics(startDate?: Date, endDate?: Date): Promise<CRMAnalytics> {
    const dateFilter = this.buildDateFilter(startDate, endDate);

    const [
      overview,
      leadSources,
      pipelineStages,
      userPerformance,
      trends,
      topPerformers,
    ] = await Promise.all([
      this.getOverviewMetrics(dateFilter),
      this.getLeadSourceAnalytics(dateFilter),
      this.getPipelineStageAnalytics(dateFilter),
      this.getUserPerformanceAnalytics(dateFilter),
      this.getTrendAnalytics(startDate, endDate),
      this.getTopPerformers(dateFilter),
    ]);

    return {
      overview,
      leadSources,
      pipelineStages,
      userPerformance,
      trends,
      topPerformers,
    };
  }

  private async getOverviewMetrics(dateFilter: any): Promise<CRMAnalytics['overview']> {
    const leads = await prisma.crm_leads.findMany({
      where: {
        tenant_id: this.tenantId,
        ...dateFilter,
      },
      select: {
        status: true,
        estimated_value: true,
        created_at: true,
      },
    });

    const totalLeads = leads.length;
    const newLeads = leads.filter(l => l.status === LeadStatus.NEW).length;
    const qualifiedLeads = leads.filter(l => l.status === LeadStatus.QUALIFIED).length;
    const convertedLeads = leads.filter(l => l.status === LeadStatus.WON).length;
    const lostLeads = leads.filter(l => l.status === LeadStatus.LOST).length;

    const conversionRate = totalLeads > 0 ? (convertedLeads / totalLeads) * 100 : 0;
    
    const totalPipelineValue = leads
      .filter(l => l.status !== LeadStatus.LOST && l.status !== LeadStatus.WON)
      .reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);

    const convertedValue = leads
      .filter(l => l.status === LeadStatus.WON)
      .reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);

    const averageDealSize = convertedLeads > 0 ? convertedValue / convertedLeads : 0;

    return {
      totalLeads,
      newLeads,
      qualifiedLeads,
      convertedLeads,
      lostLeads,
      conversionRate,
      averageDealSize,
      totalPipelineValue,
    };
  }

  private async getLeadSourceAnalytics(dateFilter: any): Promise<CRMAnalytics['leadSources']> {
    const sourceStats = await prisma.crm_leads.groupBy({
      by: ['source'],
      where: {
        tenant_id: this.tenantId,
        ...dateFilter,
      },
      _count: {
        id: true,
      },
    });

    const totalLeads = sourceStats.reduce((sum, s) => sum + s._count.id, 0);

    const sourceAnalytics = await Promise.all(
      sourceStats.map(async (stat) => {
        const convertedCount = await prisma.crm_leads.count({
          where: {
            tenant_id: this.tenantId,
            source: stat.source,
            status: LeadStatus.WON,
            ...dateFilter,
          },
        });

        return {
          source: stat.source,
          count: stat._count.id,
          percentage: totalLeads > 0 ? (stat._count.id / totalLeads) * 100 : 0,
          conversionRate: stat._count.id > 0 ? (convertedCount / stat._count.id) * 100 : 0,
        };
      })
    );

    return sourceAnalytics.sort((a, b) => b.count - a.count);
  }

  private async getPipelineStageAnalytics(dateFilter: any): Promise<CRMAnalytics['pipelineStages']> {
    const stages = await prisma.crm_pipeline_stages.findMany({
      where: {
        tenant_id: this.tenantId,
        is_active: true,
      },
      orderBy: { order_index: 'asc' },
    });

    const stageAnalytics = await Promise.all(
      stages.map(async (stage) => {
        const leads = await prisma.crm_leads.findMany({
          where: {
            tenant_id: this.tenantId,
            pipeline_stage_id: stage.id,
            ...dateFilter,
          },
          select: {
            estimated_value: true,
            created_at: true,
            updated_at: true,
          },
        });

        const count = leads.length;
        const value = leads.reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);
        
        // Calculate average time in stage (simplified)
        const averageTimeInStage = leads.length > 0 
          ? leads.reduce((sum, l) => {
              const timeInStage = l.updated_at.getTime() - l.created_at.getTime();
              return sum + timeInStage;
            }, 0) / leads.length / (1000 * 60 * 60 * 24) // Convert to days
          : 0;

        return {
          stageId: stage.id,
          stageName: stage.name,
          count,
          value,
          averageTimeInStage: Math.round(averageTimeInStage),
        };
      })
    );

    return stageAnalytics;
  }

  private async getUserPerformanceAnalytics(dateFilter: any): Promise<CRMAnalytics['userPerformance']> {
    const userStats = await prisma.crm_leads.groupBy({
      by: ['assigned_to'],
      where: {
        tenant_id: this.tenantId,
        assigned_to: { not: null },
        ...dateFilter,
      },
      _count: {
        id: true,
      },
    });

    const userPerformance = await Promise.all(
      userStats.map(async (stat) => {
        if (!stat.assigned_to) return null;

        const user = await prisma.user.findUnique({
          where: { id: stat.assigned_to },
          select: { firstName: true, lastName: true },
        });

        const convertedLeads = await prisma.crm_leads.findMany({
          where: {
            tenant_id: this.tenantId,
            assigned_to: stat.assigned_to,
            status: LeadStatus.WON,
            ...dateFilter,
          },
          select: { estimated_value: true },
        });

        const leadsAssigned = stat._count.id;
        const leadsConverted = convertedLeads.length;
        const conversionRate = leadsAssigned > 0 ? (leadsConverted / leadsAssigned) * 100 : 0;
        const totalValue = convertedLeads.reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);

        return {
          userId: stat.assigned_to,
          userName: user ? `${user.firstName} ${user.lastName}` : 'Unknown User',
          leadsAssigned,
          leadsConverted,
          conversionRate,
          totalValue,
        };
      })
    );

    return userPerformance.filter(Boolean) as CRMAnalytics['userPerformance'];
  }

  private async getTrendAnalytics(startDate?: Date, endDate?: Date): Promise<CRMAnalytics['trends']> {
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
    const end = endDate || new Date();

    // Generate date range
    const dates: string[] = [];
    const currentDate = new Date(start);
    while (currentDate <= end) {
      dates.push(currentDate.toISOString().split('T')[0]);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    const trends = await Promise.all(
      dates.map(async (date) => {
        const dayStart = new Date(date);
        const dayEnd = new Date(date);
        dayEnd.setDate(dayEnd.getDate() + 1);

        const [newLeads, convertedLeads, lostLeads, pipelineLeads] = await Promise.all([
          prisma.crm_leads.count({
            where: {
              tenant_id: this.tenantId,
              created_at: { gte: dayStart, lt: dayEnd },
            },
          }),
          prisma.crm_leads.count({
            where: {
              tenant_id: this.tenantId,
              status: LeadStatus.WON,
              updated_at: { gte: dayStart, lt: dayEnd },
            },
          }),
          prisma.crm_leads.count({
            where: {
              tenant_id: this.tenantId,
              status: LeadStatus.LOST,
              updated_at: { gte: dayStart, lt: dayEnd },
            },
          }),
          prisma.crm_leads.findMany({
            where: {
              tenant_id: this.tenantId,
              status: { notIn: [LeadStatus.WON, LeadStatus.LOST] },
              created_at: { lte: dayEnd },
            },
            select: { estimated_value: true },
          }),
        ]);

        const pipelineValue = pipelineLeads.reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);

        return {
          date,
          newLeads,
          convertedLeads,
          lostLeads,
          pipelineValue,
        };
      })
    );

    return trends;
  }

  private async getTopPerformers(dateFilter: any): Promise<CRMAnalytics['topPerformers']> {
    const userPerformance = await this.getUserPerformanceAnalytics(dateFilter);

    // Get activity counts
    const activityCounts = await prisma.crm_communication_logs.groupBy({
      by: ['user_id'],
      where: {
        tenant_id: this.tenantId,
        user_id: { not: null },
        ...dateFilter,
      },
      _count: { id: true },
    });

    const bestConverter = userPerformance.reduce((best, user) => 
      user.conversionRate > best.rate 
        ? { userId: user.userId, userName: user.userName, rate: user.conversionRate }
        : best
    , { userId: '', userName: '', rate: 0 });

    const highestValue = userPerformance.reduce((best, user) => 
      user.totalValue > best.value 
        ? { userId: user.userId, userName: user.userName, value: user.totalValue }
        : best
    , { userId: '', userName: '', value: 0 });

    const mostActiveUser = activityCounts.reduce((best, activity) => {
      if (!activity.user_id) return best;
      return activity._count.id > best.activities 
        ? { userId: activity.user_id, activities: activity._count.id }
        : best;
    }, { userId: '', activities: 0 });

    const mostActiveUserName = mostActiveUser.userId 
      ? (await prisma.user.findUnique({
          where: { id: mostActiveUser.userId },
          select: { firstName: true, lastName: true },
        }))
      : null;

    const mostActive = {
      userId: mostActiveUser.userId,
      userName: mostActiveUserName ? `${mostActiveUserName.firstName} ${mostActiveUserName.lastName}` : '',
      activities: mostActiveUser.activities,
    };

    return {
      bestConverter,
      highestValue,
      mostActive,
    };
  }

  async getConversionFunnel(): Promise<LeadConversionFunnel[]> {
    const stages = await prisma.crm_pipeline_stages.findMany({
      where: {
        tenant_id: this.tenantId,
        is_active: true,
      },
      orderBy: { order_index: 'asc' },
    });

    const totalLeads = await prisma.crm_leads.count({
      where: { tenant_id: this.tenantId },
    });

    let previousCount = totalLeads;
    const funnel: LeadConversionFunnel[] = [];

    for (const stage of stages) {
      const count = await prisma.crm_leads.count({
        where: {
          tenant_id: this.tenantId,
          pipeline_stage_id: stage.id,
        },
      });

      const percentage = totalLeads > 0 ? (count / totalLeads) * 100 : 0;
      const dropOffRate = previousCount > 0 ? ((previousCount - count) / previousCount) * 100 : 0;

      funnel.push({
        stage: stage.name,
        count,
        percentage,
        dropOffRate,
      });

      previousCount = count;
    }

    return funnel;
  }

  async getSalesMetrics(startDate?: Date, endDate?: Date): Promise<SalesMetrics> {
    const dateFilter = this.buildDateFilter(startDate, endDate);

    const wonLeads = await prisma.crm_leads.findMany({
      where: {
        tenant_id: this.tenantId,
        status: LeadStatus.WON,
        ...dateFilter,
      },
      select: {
        estimated_value: true,
        created_at: true,
        updated_at: true,
      },
    });

    const totalLeads = await prisma.crm_leads.count({
      where: {
        tenant_id: this.tenantId,
        ...dateFilter,
      },
    });

    const totalRevenue = wonLeads.reduce((sum, l) => sum + (Number(l.estimated_value) || 0), 0);
    const averageDealSize = wonLeads.length > 0 ? totalRevenue / wonLeads.length : 0;
    
    const salesCycleLength = wonLeads.length > 0 
      ? wonLeads.reduce((sum, l) => {
          const cycleTime = l.updated_at.getTime() - l.created_at.getTime();
          return sum + cycleTime;
        }, 0) / wonLeads.length / (1000 * 60 * 60 * 24) // Convert to days
      : 0;

    const winRate = totalLeads > 0 ? (wonLeads.length / totalLeads) * 100 : 0;

    // Pipeline velocity (deals per day)
    const daysDiff = startDate && endDate 
      ? (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
      : 30;
    const pipelineVelocity = wonLeads.length / daysDiff;

    // Forecasted revenue (pipeline value * average probability)
    const pipelineLeads = await prisma.crm_leads.findMany({
      where: {
        tenant_id: this.tenantId,
        status: { notIn: [LeadStatus.WON, LeadStatus.LOST] },
      },
      include: {
        pipeline_stage: true,
      },
    });

    const forecastedRevenue = pipelineLeads.reduce((sum, l) => {
      const value = Number(l.estimated_value) || 0;
      const probability = l.pipeline_stage ? Number(l.pipeline_stage.probability) / 100 : 0.5;
      return sum + (value * probability);
    }, 0);

    return {
      totalRevenue,
      averageDealSize,
      salesCycleLength: Math.round(salesCycleLength),
      winRate,
      pipelineVelocity,
      forecastedRevenue,
    };
  }

  async generateAnalyticsSnapshot(): Promise<void> {
    const today = new Date();
    const analytics = await this.getAnalytics();

    await prisma.crm_analytics_snapshots.create({
      data: {
        tenant_id: this.tenantId,
        snapshot_date: today,
        total_leads: analytics.overview.totalLeads,
        new_leads: analytics.overview.newLeads,
        qualified_leads: analytics.overview.qualifiedLeads,
        converted_leads: analytics.overview.convertedLeads,
        lost_leads: analytics.overview.lostLeads,
        total_pipeline_value: analytics.overview.totalPipelineValue,
        average_deal_size: analytics.overview.averageDealSize,
        conversion_rate: analytics.overview.conversionRate,
        lead_sources: analytics.leadSources,
        stage_distribution: analytics.pipelineStages,
        user_performance: analytics.userPerformance,
      },
    });
  }

  private buildDateFilter(startDate?: Date, endDate?: Date): any {
    if (!startDate && !endDate) return {};
    
    const filter: any = {};
    if (startDate) filter.gte = startDate;
    if (endDate) filter.lte = endDate;
    
    return { created_at: filter };
  }
}

export function createAnalyticsService(tenantId: string): CRMAnalyticsService {
  return new CRMAnalyticsService(tenantId);
}
