
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { createSyncService } from '@/lib/gohighlevel/sync';
import { triggerLeadStatusChanged } from '@/lib/crm/automation';
import { LeadStatus } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;
  const leadId = req.query.id as string;

  switch (req.method) {
    case 'GET':
      return handleGetLead(req, res, tenantId, leadId);
    case 'PUT':
      return handleUpdateLead(req, res, tenantId, leadId);
    case 'DELETE':
      return handleDeleteLead(req, res, tenantId, leadId);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetLead(req: NextApiRequest, res: NextApiResponse, tenantId: string, leadId: string) {
  try {
    const lead = await prisma.crm_leads.findFirst({
      where: { id: leadId, tenant_id: tenantId },
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        pipeline_stage: {
          select: { id: true, name: true, color: true, probability: true },
        },
        communication_logs: {
          orderBy: { created_at: 'desc' },
          take: 10,
          include: {
            user: {
              select: { id: true, firstName: true, lastName: true },
            },
          },
        },
        tasks: {
          where: { status: { not: 'COMPLETED' } },
          orderBy: { due_date: 'asc' },
          take: 5,
          include: {
            assigned_user: {
              select: { id: true, firstName: true, lastName: true },
            },
          },
        },
        appointments: {
          where: { start_time: { gte: new Date() } },
          orderBy: { start_time: 'asc' },
          take: 5,
        },
      },
    });

    if (!lead) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.status(200).json({ lead });
  } catch (error) {
    console.error('Error fetching lead:', error);
    res.status(500).json({ error: 'Failed to fetch lead' });
  }
}

async function handleUpdateLead(req: NextApiRequest, res: NextApiResponse, tenantId: string, leadId: string) {
  try {
    const existingLead = await prisma.crm_leads.findFirst({
      where: { id: leadId, tenant_id: tenantId },
    });

    if (!existingLead) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    const {
      firstName,
      lastName,
      email,
      phone,
      company,
      jobTitle,
      status,
      source,
      leadScore,
      estimatedValue,
      expectedCloseDate,
      assignedTo,
      pipelineStageId,
      tags,
      customFields,
      notes,
      syncToGoHighLevel = true,
    } = req.body;

    const updateData: any = {};
    
    if (firstName !== undefined) updateData.first_name = firstName;
    if (lastName !== undefined) updateData.last_name = lastName;
    if (email !== undefined) updateData.email = email;
    if (phone !== undefined) updateData.phone = phone;
    if (company !== undefined) updateData.company = company;
    if (jobTitle !== undefined) updateData.job_title = jobTitle;
    if (status !== undefined) updateData.status = status;
    if (source !== undefined) updateData.source = source;
    if (leadScore !== undefined) updateData.lead_score = leadScore;
    if (estimatedValue !== undefined) updateData.estimated_value = parseFloat(estimatedValue);
    if (expectedCloseDate !== undefined) updateData.expected_close_date = new Date(expectedCloseDate);
    if (assignedTo !== undefined) updateData.assigned_to = assignedTo;
    if (pipelineStageId !== undefined) updateData.pipeline_stage_id = pipelineStageId;
    if (tags !== undefined) updateData.tags = tags;
    if (customFields !== undefined) updateData.custom_fields = customFields;
    if (notes !== undefined) updateData.notes = notes;

    updateData.updated_at = new Date();

    const updatedLead = await prisma.crm_leads.update({
      where: { id: leadId },
      data: updateData,
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        pipeline_stage: {
          select: { id: true, name: true, color: true, probability: true },
        },
      },
    });

    // Sync to GoHighLevel if enabled
    if (syncToGoHighLevel) {
      try {
        const syncService = createSyncService(tenantId);
        await syncService.updateGoHighLevelContact(leadId);
      } catch (error) {
        console.error('Error syncing lead update to GoHighLevel:', error);
      }
    }

    // Trigger automation if status changed
    if (status && status !== existingLead.status) {
      try {
        await triggerLeadStatusChanged(tenantId, leadId, existingLead.status, status);
      } catch (error) {
        console.error('Error triggering lead status changed automation:', error);
      }
    }

    res.status(200).json({ lead: updatedLead });
  } catch (error) {
    console.error('Error updating lead:', error);
    res.status(500).json({ error: 'Failed to update lead' });
  }
}

async function handleDeleteLead(req: NextApiRequest, res: NextApiResponse, tenantId: string, leadId: string) {
  try {
    const lead = await prisma.crm_leads.findFirst({
      where: { id: leadId, tenant_id: tenantId },
    });

    if (!lead) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    // Delete from GoHighLevel if synced
    if (lead.gohighlevel_contact_id) {
      try {
        const { createGoHighLevelClient } = await import('@/lib/gohighlevel/client');
        const client = await createGoHighLevelClient(tenantId);
        if (client) {
          await client.deleteContact(lead.gohighlevel_contact_id);
        }
      } catch (error) {
        console.error('Error deleting contact from GoHighLevel:', error);
      }
    }

    // Delete lead and related records (cascade will handle most)
    await prisma.crm_leads.delete({
      where: { id: leadId },
    });

    res.status(200).json({ message: 'Lead deleted successfully' });
  } catch (error) {
    console.error('Error deleting lead:', error);
    res.status(500).json({ error: 'Failed to delete lead' });
  }
}
