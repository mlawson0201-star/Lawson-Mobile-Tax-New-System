
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import { createAnalyticsService } from '@/lib/crm/analytics';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { startDate, endDate, type = 'overview' } = req.query;

    const analyticsService = createAnalyticsService(tenantId);
    
    const start = startDate ? new Date(startDate as string) : undefined;
    const end = endDate ? new Date(endDate as string) : undefined;

    switch (type) {
      case 'overview':
        const analytics = await analyticsService.getAnalytics(start, end);
        return res.status(200).json(analytics);

      case 'funnel':
        const funnel = await analyticsService.getConversionFunnel();
        return res.status(200).json({ funnel });

      case 'sales':
        const salesMetrics = await analyticsService.getSalesMetrics(start, end);
        return res.status(200).json({ salesMetrics });

      default:
        return res.status(400).json({ error: 'Invalid analytics type' });
    }
  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
}
