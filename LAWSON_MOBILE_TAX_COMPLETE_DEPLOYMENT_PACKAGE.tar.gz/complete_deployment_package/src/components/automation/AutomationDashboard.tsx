
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Area, AreaChart
} from 'recharts';
import { 
  Brain, 
  Shield, 
  Mic, 
  GitBranch, 
  Building, 
  RefreshCw, 
  FileText, 
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  Zap,
  Target,
  Activity
} from 'lucide-react';

interface AutomationMetrics {
  deductionEngine: {
    totalPredictions: number;
    averageConfidence: number;
    potentialSavings: number;
    processingTime: number;
  };
  auditDefense: {
    activeCases: number;
    averageRiskScore: number;
    resolutionRate: number;
    preventedAudits: number;
  };
  voiceProcessing: {
    totalJobs: number;
    averageAccuracy: number;
    processingTime: number;
    automatedActions: number;
  };
  workflowRouting: {
    totalRules: number;
    executionRate: number;
    automationLevel: number;
    timesSaved: number;
  };
  taxStrategy: {
    activeStrategies: number;
    projectedSavings: number;
    implementationRate: number;
    complexityScore: number;
  };
  businessFormation: {
    totalFormations: number;
    automationRate: number;
    averageTime: number;
    complianceRate: number;
  };
  taxUpdates: {
    updatesProcessed: number;
    automatedAdjustments: number;
    impactedReturns: number;
    processingSpeed: number;
  };
  complexReturns: {
    totalProcessed: number;
    automationLevel: number;
    qualityScore: number;
    timeReduction: number;
  };
  riskAssessment: {
    totalAssessments: number;
    averageRiskScore: number;
    highRiskReturns: number;
    preventionRate: number;
  };
}

interface AutomationAlert {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: string;
  module: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function AutomationDashboard() {
  const [metrics, setMetrics] = useState<AutomationMetrics | null>(null);
  const [alerts, setAlerts] = useState<AutomationAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboardData();
    const interval = setInterval(loadDashboardData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      setRefreshing(true);
      
      // Load automation metrics
      const metricsResponse = await fetch('/api/automation/dashboard/metrics');
      const metricsData = await metricsResponse.json();
      setMetrics(metricsData);

      // Load alerts
      const alertsResponse = await fetch('/api/automation/dashboard/alerts');
      const alertsData = await alertsResponse.json();
      setAlerts(alertsData.alerts || []);

    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    loadDashboardData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading automation dashboard...</p>
        </div>
      </div>
    );
  }

  if (!metrics) {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load automation metrics. Please try again.
        </AlertDescription>
      </Alert>
    );
  }

  const overviewData = [
    {
      name: 'Deduction Engine',
      value: metrics.deductionEngine.averageConfidence * 100,
      savings: metrics.deductionEngine.potentialSavings,
      icon: Brain,
      color: '#0088FE'
    },
    {
      name: 'Audit Defense',
      value: (1 - metrics.auditDefense.averageRiskScore) * 100,
      savings: metrics.auditDefense.preventedAudits * 5000,
      icon: Shield,
      color: '#00C49F'
    },
    {
      name: 'Voice Processing',
      value: metrics.voiceProcessing.averageAccuracy * 100,
      savings: metrics.voiceProcessing.automatedActions * 50,
      icon: Mic,
      color: '#FFBB28'
    },
    {
      name: 'Workflow Routing',
      value: metrics.workflowRouting.automationLevel * 100,
      savings: metrics.workflowRouting.timesSaved * 25,
      icon: GitBranch,
      color: '#FF8042'
    },
  ];

  const performanceData = [
    { name: 'Jan', deductions: 85, audits: 92, voice: 88, workflow: 90 },
    { name: 'Feb', deductions: 87, audits: 89, voice: 91, workflow: 93 },
    { name: 'Mar', deductions: 90, audits: 94, voice: 89, workflow: 95 },
    { name: 'Apr', deductions: 92, audits: 91, voice: 93, workflow: 97 },
    { name: 'May', deductions: 89, audits: 96, voice: 95, workflow: 94 },
    { name: 'Jun', deductions: 94, audits: 93, voice: 92, workflow: 98 },
  ];

  const riskDistribution = [
    { name: 'Low Risk', value: 65, color: '#00C49F' },
    { name: 'Medium Risk', value: 25, color: '#FFBB28' },
    { name: 'High Risk', value: 8, color: '#FF8042' },
    { name: 'Critical Risk', value: 2, color: '#FF0000' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Automation Dashboard</h1>
          <p className="text-muted-foreground">
            Real-time monitoring of AI-powered tax automation systems
          </p>
        </div>
        <Button onClick={handleRefresh} disabled={refreshing}>
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.slice(0, 3).map((alert) => (
            <Alert key={alert.id} className={
              alert.type === 'error' ? 'border-red-200 bg-red-50' :
              alert.type === 'warning' ? 'border-yellow-200 bg-yellow-50' :
              alert.type === 'success' ? 'border-green-200 bg-green-50' :
              'border-blue-200 bg-blue-50'
            }>
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>{alert.title}</AlertTitle>
              <AlertDescription>
                {alert.message}
                <span className="text-xs text-muted-foreground ml-2">
                  {alert.module} • {new Date(alert.timestamp).toLocaleTimeString()}
                </span>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="modules">Modules</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {overviewData.map((item) => {
              const Icon = item.icon;
              return (
                <Card key={item.name}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{item.name}</CardTitle>
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{item.value.toFixed(1)}%</div>
                    <p className="text-xs text-muted-foreground">
                      ${item.savings.toLocaleString()} saved
                    </p>
                    <Progress value={item.value} className="mt-2" />
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Performance Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Automation Performance Trends</CardTitle>
                <CardDescription>
                  Monthly performance across all automation modules
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="deductions" stroke="#0088FE" strokeWidth={2} />
                    <Line type="monotone" dataKey="audits" stroke="#00C49F" strokeWidth={2} />
                    <Line type="monotone" dataKey="voice" stroke="#FFBB28" strokeWidth={2} />
                    <Line type="monotone" dataKey="workflow" stroke="#FF8042" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Distribution</CardTitle>
                <CardDescription>
                  Current risk assessment across all tax returns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
              <CardDescription>
                Real-time status of all automation modules
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>All systems operational</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-blue-500" />
                  <span>Processing {metrics.voiceProcessing.totalJobs} jobs</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  <span>99.8% uptime this month</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Performance Metrics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Processing Speed</CardTitle>
                <CardDescription>
                  Average processing times across modules
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Deduction Analysis</span>
                    <Badge variant="secondary">{metrics.deductionEngine.processingTime}s</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Voice Processing</span>
                    <Badge variant="secondary">{metrics.voiceProcessing.processingTime}s</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Risk Assessment</span>
                    <Badge variant="secondary">2.3s</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Complex Returns</span>
                    <Badge variant="secondary">45s</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Accuracy Metrics</CardTitle>
                <CardDescription>
                  Current accuracy rates for AI models
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span>Deduction Predictions</span>
                      <span>{(metrics.deductionEngine.averageConfidence * 100).toFixed(1)}%</span>
                    </div>
                    <Progress value={metrics.deductionEngine.averageConfidence * 100} />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span>Voice Recognition</span>
                      <span>{(metrics.voiceProcessing.averageAccuracy * 100).toFixed(1)}%</span>
                    </div>
                    <Progress value={metrics.voiceProcessing.averageAccuracy * 100} />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span>Risk Assessment</span>
                      <span>94.2%</span>
                    </div>
                    <Progress value={94.2} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Performance Analysis</CardTitle>
              <CardDescription>
                Comprehensive view of automation performance over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="deductions" stackId="1" stroke="#0088FE" fill="#0088FE" />
                  <Area type="monotone" dataKey="audits" stackId="1" stroke="#00C49F" fill="#00C49F" />
                  <Area type="monotone" dataKey="voice" stackId="1" stroke="#FFBB28" fill="#FFBB28" />
                  <Area type="monotone" dataKey="workflow" stackId="1" stroke="#FF8042" fill="#FF8042" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="modules" className="space-y-6">
          {/* Module Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5" />
                  <span>Deduction Engine</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Predictions</span>
                    <Badge>{metrics.deductionEngine.totalPredictions}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Potential Savings</span>
                    <Badge variant="secondary">${metrics.deductionEngine.potentialSavings.toLocaleString()}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Confidence</span>
                    <Badge variant="outline">{(metrics.deductionEngine.averageConfidence * 100).toFixed(1)}%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5" />
                  <span>Audit Defense</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Active Cases</span>
                    <Badge>{metrics.auditDefense.activeCases}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Resolution Rate</span>
                    <Badge variant="secondary">{(metrics.auditDefense.resolutionRate * 100).toFixed(1)}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Prevented Audits</span>
                    <Badge variant="outline">{metrics.auditDefense.preventedAudits}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mic className="h-5 w-5" />
                  <span>Voice Processing</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Jobs</span>
                    <Badge>{metrics.voiceProcessing.totalJobs}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Accuracy</span>
                    <Badge variant="secondary">{(metrics.voiceProcessing.averageAccuracy * 100).toFixed(1)}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Automated Actions</span>
                    <Badge variant="outline">{metrics.voiceProcessing.automatedActions}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>Business Formation</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Formations</span>
                    <Badge>{metrics.businessFormation.totalFormations}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Automation Rate</span>
                    <Badge variant="secondary">{(metrics.businessFormation.automationRate * 100).toFixed(1)}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg Time</span>
                    <Badge variant="outline">{metrics.businessFormation.averageTime} days</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <RefreshCw className="h-5 w-5" />
                  <span>Tax Updates</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Updates Processed</span>
                    <Badge>{metrics.taxUpdates.updatesProcessed}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Auto Adjustments</span>
                    <Badge variant="secondary">{metrics.taxUpdates.automatedAdjustments}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Impacted Returns</span>
                    <Badge variant="outline">{metrics.taxUpdates.impactedReturns}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Complex Returns</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Processed</span>
                    <Badge>{metrics.complexReturns.totalProcessed}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Automation Level</span>
                    <Badge variant="secondary">{(metrics.complexReturns.automationLevel * 100).toFixed(1)}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Quality Score</span>
                    <Badge variant="outline">{(metrics.complexReturns.qualityScore * 100).toFixed(1)}%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* Analytics Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>ROI Analysis</CardTitle>
                <CardDescription>
                  Return on investment from automation systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-3xl font-bold text-green-600">
                    ${(metrics.deductionEngine.potentialSavings + metrics.auditDefense.preventedAudits * 5000).toLocaleString()}
                  </div>
                  <p className="text-sm text-muted-foreground">Total savings this month</p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Deduction Savings</span>
                      <span>${metrics.deductionEngine.potentialSavings.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Audit Prevention</span>
                      <span>${(metrics.auditDefense.preventedAudits * 5000).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time Savings</span>
                      <span>${(metrics.workflowRouting.timesSaved * 25).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Efficiency Gains</CardTitle>
                <CardDescription>
                  Time and cost savings from automation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-3xl font-bold text-blue-600">
                    {metrics.workflowRouting.timesSaved} hours
                  </div>
                  <p className="text-sm text-muted-foreground">Time saved this month</p>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={[
                      { name: 'Manual', time: 120 },
                      { name: 'Automated', time: 25 },
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="time" fill="#0088FE" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          {/* Settings Content */}
          <Card>
            <CardHeader>
              <CardTitle>Automation Settings</CardTitle>
              <CardDescription>
                Configure automation thresholds and preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Auto-approve deductions</h4>
                    <p className="text-sm text-muted-foreground">
                      Automatically approve deductions above confidence threshold
                    </p>
                  </div>
                  <Badge variant="outline">85%</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Risk monitoring</h4>
                    <p className="text-sm text-muted-foreground">
                      Continuous monitoring of audit risk factors
                    </p>
                  </div>
                  <Badge variant="secondary">Enabled</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Voice processing</h4>
                    <p className="text-sm text-muted-foreground">
                      Automatic transcription and data extraction
                    </p>
                  </div>
                  <Badge variant="secondary">Enabled</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
