
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get performance metrics from the database
    const metrics = await prisma.performanceMetrics.findMany({
      where: {
        tenantId: session.user.tenantId,
        recordedAt: {
          gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
        },
      },
      orderBy: { recordedAt: 'desc' },
    });

    // Calculate aggregated metrics
    const aggregatedMetrics = {
      totalProcessed: 1247, // Mock data - would calculate from actual processing records
      averageConfidence: 0.87,
      potentialSavings: 45230,
      processingTime: 12.5, // seconds
      accuracy: 0.92,
      trendsData: [
        { date: '2024-01', accuracy: 0.85, volume: 203 },
        { date: '2024-02', accuracy: 0.88, volume: 287 },
        { date: '2024-03', accuracy: 0.91, volume: 342 },
        { date: '2024-04', accuracy: 0.92, volume: 415 },
      ],
    };

    return NextResponse.json({
      success: true,
      metrics: aggregatedMetrics,
      rawMetrics: metrics,
    });
  } catch (error: any) {
    console.error('Get performance metrics error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve performance metrics', details: error?.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      metricType,
      metricCategory,
      metricName,
      metricValue,
      targetValue,
      dimensions,
      measurementPeriod,
    } = await request.json();

    const metric = await prisma.performanceMetrics.create({
      data: {
        tenantId: session.user.tenantId,
        metricType,
        metricCategory,
        metricName,
        metricValue,
        targetValue,
        dimensions,
        measurementPeriod,
        aggregationType: 'point', // single point measurement
      },
    });

    return NextResponse.json({
      success: true,
      metric,
    });
  } catch (error: any) {
    console.error('Create performance metric error:', error);
    return NextResponse.json(
      { error: 'Failed to create performance metric', details: error?.message },
      { status: 500 }
    );
  }
}
