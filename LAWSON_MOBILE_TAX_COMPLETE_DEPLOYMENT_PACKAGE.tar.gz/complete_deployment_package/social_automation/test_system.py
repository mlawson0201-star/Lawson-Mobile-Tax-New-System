#!/usr/bin/env python3
"""
Quick test to verify the social media automation system is working
"""
import asyncio
import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from platform_adapters import PlatformAdapterFactory
from ai_content import AIContentGenerator
from analytics import AnalyticsCollector
from scheduler import SocialMediaScheduler

async def test_system():
    """Test basic system functionality"""
    print("🚀 Testing Lawson Mobile Tax Social Media Automation System")
    print("=" * 60)
    
    # Test platform adapters
    print("✅ Testing Platform Adapters...")
    supported_platforms = PlatformAdapterFactory.get_supported_platforms()
    print(f"   Supported platforms: {', '.join(supported_platforms)}")
    
    # Test AI content generator
    print("✅ Testing AI Content Generator...")
    ai_generator = AIContentGenerator()
    print("   AI Content Generator initialized successfully")
    
    # Test analytics collector
    print("✅ Testing Analytics Collector...")
    analytics = AnalyticsCollector()
    print("   Analytics Collector initialized successfully")
    
    # Test scheduler
    print("✅ Testing Scheduler...")
    scheduler = SocialMediaScheduler()
    print("   Scheduler initialized successfully")
    
    print("\n🎉 All core components initialized successfully!")
    print("\n📋 System Features:")
    print("   • 10 Social Media Platforms Supported")
    print("   • AI-Powered Content Generation")
    print("   • Advanced Scheduling & Automation")
    print("   • Comprehensive Analytics & Reporting")
    print("   • Multi-Platform Campaign Management")
    print("   • Real-time Engagement Tracking")
    
    print("\n🌐 Web Interface Available at: http://localhost:8000")
    print("📚 API Documentation: http://localhost:8000/docs")
    
    return True

if __name__ == "__main__":
    asyncio.run(test_system())
