
'use client';

import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Calculator, Video, TrendingUp } from 'lucide-react';

// Import our new components
import PersonalizedLearningHub from '@/components/education/learning-paths/personalized-learning-hub';
import InteractiveTaxCalculator from '@/components/education/calculators/interactive-tax-calculator';

// Mock data
const mockClientProfile = {
  id: '1',
  userId: 'user123',
  persona: {
    id: '1',
    type: 'small_business' as const,
    name: 'Small Business Owner',
    description: 'Entrepreneurs needing comprehensive business tax solutions',
    painPoints: ['Complex deductions', 'Quarterly taxes', 'Business/personal separation'],
    preferences: {
      communicationChannel: 'phone' as const,
      complexity: 'advanced' as const,
      timing: 'scheduled' as const
    },
    demographics: {
      ageRange: '30-55',
      incomeRange: '$60K-$200K',
      location: 'Mixed'
    }
  },
  financialGoals: ['Minimize tax liability', 'Business growth', 'Retirement planning'],
  riskTolerance: 'moderate' as const,
  lifeStage: 'family' as const,
  taxComplexity: 'complex' as const,
  preferredCommunication: 'email' as const,
  communicationFrequency: 'monthly' as const,
  timezone: 'America/New_York',
  lastUpdated: new Date(),
  completionScore: 75
};

const mockLearningPaths = [
  {
    id: '1',
    title: 'Business Tax Fundamentals',
    description: 'Master the basics of business taxation and deductions',
    targetPersona: 'small_business',
    difficulty: 'intermediate' as const,
    estimatedTime: 180,
    modules: [
      {
        id: 'm1',
        title: 'Business Entity Types',
        description: 'Understanding different business structures and their tax implications',
        type: 'video' as const,
        content: 'Learn about LLCs, S-Corps, C-Corps, and sole proprietorships',
        videoUrl: 'https://example.com/video1',
        duration: 25,
        order: 1,
        isCompleted: false
      },
      {
        id: 'm2',
        title: 'Business Deductions Overview',
        description: 'Common business deductions and how to claim them',
        type: 'interactive' as const,
        content: 'Interactive guide to business deductions',
        duration: 30,
        order: 2,
        isCompleted: false
      },
      {
        id: 'm3',
        title: 'Quarterly Tax Planning',
        description: 'How to calculate and pay quarterly estimated taxes',
        type: 'article' as const,
        content: 'Step-by-step guide to quarterly tax payments',
        duration: 20,
        order: 3,
        isCompleted: false
      }
    ],
    prerequisites: [],
    completionRate: 78,
    isPublished: true
  },
  {
    id: '2',
    title: 'Advanced Investment Strategies',
    description: 'Optimize your investment taxes with advanced strategies',
    targetPersona: 'investor',
    difficulty: 'advanced' as const,
    estimatedTime: 240,
    modules: [
      {
        id: 'm4',
        title: 'Tax Loss Harvesting',
        description: 'Using losses to offset gains and reduce taxes',
        type: 'video' as const,
        content: 'Advanced tax loss harvesting strategies',
        duration: 35,
        order: 1,
        isCompleted: false
      },
      {
        id: 'm5',
        title: 'Asset Location Strategies',
        description: 'Placing investments in the right account types',
        type: 'interactive' as const,
        content: 'Interactive asset location optimizer',
        duration: 40,
        order: 2,
        isCompleted: false
      }
    ],
    prerequisites: ['Basic Investment Knowledge'],
    completionRate: 65,
    isPublished: true
  }
];

const mockUserProgress = {
  '1': {
    completedModules: ['m1'],
    currentModule: 'm2',
    completionPercentage: 33,
    timeSpent: 45,
    lastAccessed: new Date('2024-02-15')
  },
  '2': {
    completedModules: [],
    completionPercentage: 0,
    timeSpent: 0,
    lastAccessed: new Date('2024-02-10')
  }
};

const mockTaxCalculators = [
  {
    id: '1',
    name: 'Income Tax Calculator',
    description: 'Calculate your federal and state income tax liability',
    type: 'income_tax' as const,
    inputs: [
      {
        id: 'annual_income',
        label: 'Annual Income',
        type: 'number' as const,
        required: true,
        placeholder: 'Enter your annual income',
        helpText: 'Your total income before deductions'
      },
      {
        id: 'filing_status',
        label: 'Filing Status',
        type: 'select' as const,
        required: true,
        options: ['single', 'married_filing_jointly', 'married_filing_separately', 'head_of_household'],
        helpText: 'Your tax filing status'
      }
    ],
    formula: 'Progressive tax calculation based on 2024 tax brackets',
    resultFields: [],
    isActive: true,
    usageCount: 15420
  },
  {
    id: '2',
    name: 'Business Deduction Calculator',
    description: 'Maximize your business tax deductions',
    type: 'business_deduction' as const,
    inputs: [
      {
        id: 'business_revenue',
        label: 'Business Revenue',
        type: 'number' as const,
        required: true,
        placeholder: 'Enter your business revenue'
      },
      {
        id: 'home_office_expense',
        label: 'Home Office Expenses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter home office expenses'
      },
      {
        id: 'vehicle_expense',
        label: 'Vehicle Expenses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter vehicle expenses'
      },
      {
        id: 'equipment_expense',
        label: 'Equipment Expenses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter equipment expenses'
      },
      {
        id: 'travel_expense',
        label: 'Travel Expenses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter travel expenses'
      },
      {
        id: 'meal_expense',
        label: 'Meal Expenses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter meal expenses'
      }
    ],
    formula: 'Sum of eligible business deductions',
    resultFields: [],
    isActive: true,
    usageCount: 8930
  },
  {
    id: '3',
    name: 'Investment Tax Calculator',
    description: 'Calculate taxes on your investment gains and losses',
    type: 'investment' as const,
    inputs: [
      {
        id: 'short_term_gains',
        label: 'Short-Term Capital Gains',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter short-term gains'
      },
      {
        id: 'long_term_gains',
        label: 'Long-Term Capital Gains',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter long-term gains'
      },
      {
        id: 'dividends',
        label: 'Dividend Income',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter dividend income'
      },
      {
        id: 'capital_losses',
        label: 'Capital Losses',
        type: 'number' as const,
        required: false,
        placeholder: 'Enter capital losses'
      }
    ],
    formula: 'Capital gains tax calculation',
    resultFields: [],
    isActive: true,
    usageCount: 6750
  }
];

export default function EducationPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const handleStartPath = (pathId: string) => {
    console.log('Starting learning path:', pathId);
  };

  const handleCompleteModule = (pathId: string, moduleId: string) => {
    console.log('Completing module:', { pathId, moduleId });
  };

  const handleUpdateProgress = (pathId: string, progress: any) => {
    console.log('Updating progress:', { pathId, progress });
  };

  const handleSaveCalculation = (calculatorId: string, inputs: any, results: any) => {
    console.log('Saving calculation:', { calculatorId, inputs, results });
  };

  const handleShareCalculation = (calculatorId: string, results: any) => {
    console.log('Sharing calculation:', { calculatorId, results });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Tax Education Hub
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl">
          Empower yourself with comprehensive tax knowledge through personalized learning paths, 
          interactive calculators, and expert guidance tailored to your specific situation.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Learning Progress</p>
                <p className="text-2xl font-bold text-blue-600">75%</p>
                <p className="text-xs text-blue-600">Profile completion</p>
              </div>
              <BookOpen className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Modules Completed</p>
                <p className="text-2xl font-bold text-green-600">12</p>
                <p className="text-xs text-green-600">↑ 3 this month</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Calculator Uses</p>
                <p className="text-2xl font-bold text-purple-600">47</p>
                <p className="text-xs text-purple-600">↑ 8 this week</p>
              </div>
              <Calculator className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Video Watch Time</p>
                <p className="text-2xl font-bold text-orange-600">8.5h</p>
                <p className="text-xs text-orange-600">↑ 2.1h this month</p>
              </div>
              <Video className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="learning-paths">Learning Paths</TabsTrigger>
          <TabsTrigger value="calculators">Tax Calculators</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Learning Journey</CardTitle>
                <CardDescription>
                  Personalized recommendations based on your profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium">Business Tax Fundamentals</p>
                      <p className="text-sm text-gray-600">33% complete</p>
                    </div>
                    <Badge variant="outline">In Progress</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Quarterly Tax Planning</p>
                      <p className="text-sm text-gray-600">Recommended next</p>
                    </div>
                    <Badge variant="outline">Recommended</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Advanced Deduction Strategies</p>
                      <p className="text-sm text-gray-600">Perfect for your situation</p>
                    </div>
                    <Badge variant="outline">New</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  Your latest learning activities and achievements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <BookOpen className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Completed "Business Entity Types"</p>
                      <p className="text-sm text-gray-600">2 days ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Calculator className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Used Business Deduction Calculator</p>
                      <p className="text-sm text-gray-600">3 days ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <Video className="w-4 h-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Watched "Tax Planning Strategies"</p>
                      <p className="text-sm text-gray-600">1 week ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Access Tools */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Access Tools</CardTitle>
              <CardDescription>
                Frequently used calculators and resources
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                  <Calculator className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="font-medium">Income Tax Calculator</p>
                  <p className="text-sm text-gray-600">Quick tax estimate</p>
                </div>
                <div className="text-center p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                  <BookOpen className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="font-medium">Deduction Finder</p>
                  <p className="text-sm text-gray-600">Discover savings</p>
                </div>
                <div className="text-center p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                  <Video className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <p className="font-medium">Video Library</p>
                  <p className="text-sm text-gray-600">Expert tutorials</p>
                </div>
                <div className="text-center p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                  <TrendingUp className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <p className="font-medium">Tax Planner</p>
                  <p className="text-sm text-gray-600">Year-round planning</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="learning-paths">
          <PersonalizedLearningHub
            clientProfile={mockClientProfile}
            learningPaths={mockLearningPaths}
            userProgress={mockUserProgress}
            onStartPath={handleStartPath}
            onCompleteModule={handleCompleteModule}
            onUpdateProgress={handleUpdateProgress}
          />
        </TabsContent>

        <TabsContent value="calculators">
          <InteractiveTaxCalculator
            calculators={mockTaxCalculators}
            clientProfile={mockClientProfile}
            onSaveCalculation={handleSaveCalculation}
            onShareCalculation={handleShareCalculation}
          />
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Tax Forms & Documents</CardTitle>
                <CardDescription>
                  Essential tax forms and documentation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Form 1040 (Individual Tax Return)</p>
                      <p className="text-sm text-gray-600">2024 tax year</p>
                    </div>
                    <Badge variant="outline">PDF</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Schedule C (Business Income)</p>
                      <p className="text-sm text-gray-600">For sole proprietors</p>
                    </div>
                    <Badge variant="outline">PDF</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Form 1099-NEC (Contractor Income)</p>
                      <p className="text-sm text-gray-600">Non-employee compensation</p>
                    </div>
                    <Badge variant="outline">PDF</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tax Calendar</CardTitle>
                <CardDescription>
                  Important tax dates and deadlines
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div>
                      <p className="font-medium text-red-900">Q1 Estimated Taxes Due</p>
                      <p className="text-sm text-red-700">April 15, 2024</p>
                    </div>
                    <Badge className="bg-red-100 text-red-800">Upcoming</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div>
                      <p className="font-medium text-yellow-900">Tax Return Filing Deadline</p>
                      <p className="text-sm text-yellow-700">April 15, 2024</p>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">Important</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Q2 Estimated Taxes Due</p>
                      <p className="text-sm text-gray-600">June 17, 2024</p>
                    </div>
                    <Badge variant="outline">Future</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Expert Articles & Guides</CardTitle>
              <CardDescription>
                In-depth articles on tax strategies and planning
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h4 className="font-semibold mb-2">Year-End Tax Planning Strategies</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Essential moves to make before December 31st to minimize your tax liability.
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">Tax Planning</Badge>
                    <span className="text-xs text-gray-500">5 min read</span>
                  </div>
                </div>
                <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h4 className="font-semibold mb-2">Business Expense Deduction Guide</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Complete guide to claiming business expenses and maximizing deductions.
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">Business</Badge>
                    <span className="text-xs text-gray-500">8 min read</span>
                  </div>
                </div>
                <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h4 className="font-semibold mb-2">Investment Tax Optimization</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Advanced strategies for minimizing taxes on your investment portfolio.
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">Investments</Badge>
                    <span className="text-xs text-gray-500">12 min read</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
