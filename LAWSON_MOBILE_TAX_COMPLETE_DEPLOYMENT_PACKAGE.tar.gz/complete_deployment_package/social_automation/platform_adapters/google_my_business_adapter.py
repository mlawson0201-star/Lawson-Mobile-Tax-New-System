
"""
Google My Business adapter using Google My Business API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class GoogleMyBusinessAdapter(BasePlatformAdapter):
    """Adapter for Google My Business using Google My Business API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.client_id = credentials.get('client_id')
        self.client_secret = credentials.get('client_secret')
        self.location_id = credentials.get('location_id')  # GMB location ID
        self.base_url = "https://mybusinessbusinessinformation.googleapis.com/v1"
        self.posts_url = "https://mybusinessposts.googleapis.com/v1"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            # Get account information
            url = f"{self.base_url}/accounts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                accounts = result.get('accounts', [])
                if accounts:
                    account_name = accounts[0].get('name', 'Unknown')
                    logger.info(f"Authenticated for GMB account: {account_name}")
                    return True
                else:
                    logger.error("No GMB accounts found")
                    return False
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Create a Google My Business post"""
        try:
            if not self.location_id:
                return {"success": False, "error": "Location ID is required"}
            
            # Format content
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content}\n\n{hashtag_text}"
            
            # GMB posts have a 1500 character limit
            full_content = self.validate_content_length(full_content, 1500)
            
            url = f"{self.posts_url}/locations/{self.location_id}/localPosts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            # Determine post type
            post_type = kwargs.get('post_type', 'STANDARD')  # STANDARD, EVENT, OFFER, PRODUCT
            
            post_data = {
                'languageCode': kwargs.get('language_code', 'en'),
                'summary': full_content,
                'state': 'LIVE',
                'topicType': post_type
            }
            
            # Add call to action if specified
            cta_type = kwargs.get('call_to_action')
            if cta_type:
                post_data['callToAction'] = {
                    'actionType': cta_type,  # BOOK, ORDER, SHOP, LEARN_MORE, SIGN_UP, CALL
                    'url': kwargs.get('cta_url', '')
                }
            
            # Add media if provided
            if media_urls and len(media_urls) > 0:
                media_list = []
                for media_url in media_urls[:10]:  # GMB supports up to 10 media items
                    media_item = {
                        'mediaFormat': 'PHOTO',  # or VIDEO
                        'sourceUrl': media_url
                    }
                    media_list.append(media_item)
                
                post_data['media'] = media_list
            
            # Add event-specific fields if it's an event post
            if post_type == 'EVENT':
                event_title = kwargs.get('event_title', 'Event')
                start_date = kwargs.get('event_start_date')
                end_date = kwargs.get('event_end_date')
                
                if start_date:
                    post_data['event'] = {
                        'title': event_title,
                        'schedule': {
                            'startDate': {
                                'year': start_date.year,
                                'month': start_date.month,
                                'day': start_date.day
                            }
                        }
                    }
                    
                    if end_date:
                        post_data['event']['schedule']['endDate'] = {
                            'year': end_date.year,
                            'month': end_date.month,
                            'day': end_date.day
                        }
            
            # Add offer-specific fields if it's an offer post
            if post_type == 'OFFER':
                offer_title = kwargs.get('offer_title', 'Special Offer')
                coupon_code = kwargs.get('coupon_code')
                terms_conditions = kwargs.get('terms_conditions')
                
                post_data['offer'] = {
                    'title': offer_title
                }
                
                if coupon_code:
                    post_data['offer']['couponCode'] = coupon_code
                
                if terms_conditions:
                    post_data['offer']['termsConditions'] = terms_conditions
            
            response = requests.post(url, headers=headers, json=post_data)
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "post_id": result.get('name', '').split('/')[-1],
                    "post_name": result.get('name'),
                    "state": result.get('state'),
                    "platform_response": result
                }
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('error', {}).get('message', f'HTTP {response.status_code}')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            logger.error(f"Error creating GMB post: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a Google My Business post"""
        try:
            # GMB API doesn't support native scheduling
            # This would be handled by our internal scheduler
            
            return {
                "success": True,
                "message": "GMB post scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "GMB API doesn't support native scheduling"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a GMB post"""
        try:
            if not self.location_id:
                return {"success": False, "error": "Location ID is required"}
            
            # Get post insights
            url = f"{self.posts_url}/locations/{self.location_id}/localPosts/{post_id}/insights"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                insights = result.get('localPostInsights', [])
                
                analytics = {
                    "post_id": post_id,
                    "views": 0,
                    "actions": 0,
                    "photos_viewed": 0,
                    "period": "total"
                }
                
                # Process insights data
                for insight in insights:
                    metric_type = insight.get('metricType', '')
                    value = insight.get('value', 0)
                    
                    if metric_type == 'VIEWS':
                        analytics['views'] = value
                    elif metric_type == 'ACTIONS':
                        analytics['actions'] = value
                    elif metric_type == 'PHOTOS_VIEWED':
                        analytics['photos_viewed'] = value
                
                return {"success": True, "analytics": analytics}
            else:
                # If insights are not available, try to get basic post info
                post_info = await self._get_post_info(post_id)
                if post_info.get('success'):
                    return {
                        "success": True,
                        "analytics": {
                            "post_id": post_id,
                            "state": post_info.get('post_data', {}).get('state', 'UNKNOWN'),
                            "created_time": post_info.get('post_data', {}).get('createTime'),
                            "note": "Limited analytics available"
                        }
                    }
                else:
                    error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                    return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _get_post_info(self, post_id: str) -> Dict[str, Any]:
        """Get basic post information"""
        try:
            url = f"{self.posts_url}/locations/{self.location_id}/localPosts/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                return {"success": True, "post_data": result}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a GMB post"""
        try:
            if not self.location_id:
                return False
            
            url = f"{self.posts_url}/locations/{self.location_id}/localPosts/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.delete(url, headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            logger.error(f"Error deleting GMB post: {str(e)}")
            return False
    
    async def get_locations(self) -> Dict[str, Any]:
        """Get GMB locations"""
        try:
            url = f"{self.base_url}/accounts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            # First get accounts
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                accounts = result.get('accounts', [])
                
                all_locations = []
                
                for account in accounts:
                    account_name = account.get('name')
                    
                    # Get locations for this account
                    locations_url = f"{self.base_url}/{account_name}/locations"
                    locations_response = requests.get(locations_url, headers=headers)
                    
                    if locations_response.status_code == 200:
                        locations_data = locations_response.json()
                        locations = locations_data.get('locations', [])
                        
                        for location in locations:
                            all_locations.append({
                                'name': location.get('name'),
                                'title': location.get('title', ''),
                                'address': location.get('storefrontAddress', {}),
                                'phone': location.get('primaryPhone', ''),
                                'website': location.get('websiteUri', ''),
                                'category': location.get('primaryCategory', {}).get('displayName', ''),
                                'verification_state': location.get('metadata', {}).get('verificationState', '')
                            })
                
                return {"success": True, "locations": all_locations}
            else:
                error_msg = f"Failed to get locations: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def reply_to_review(self, review_id: str, reply_text: str) -> Dict[str, Any]:
        """Reply to a customer review"""
        try:
            if not self.location_id:
                return {"success": False, "error": "Location ID is required"}
            
            url = f"{self.base_url}/locations/{self.location_id}/reviews/{review_id}/reply"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            reply_data = {
                'comment': reply_text
            }
            
            response = requests.put(url, headers=headers, json=reply_data)
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "reply_id": result.get('name'),
                    "comment": result.get('comment'),
                    "platform_response": result
                }
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('error', {}).get('message', f'HTTP {response.status_code}')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
