
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { mlClient } from '@/lib/ml-client';
import { z } from 'zod';

const AuditDefenseRequestSchema = z.object({
  taxReturnId: z.string(),
  auditType: z.enum(['correspondence', 'office', 'field']),
  irsNoticeDate: z.string().optional(),
  responseDeadline: z.string().optional(),
  auditScope: z.array(z.string()).optional(),
  initialDocuments: z.array(z.string()).optional(),
});

const CorrespondenceRequestSchema = z.object({
  auditCaseId: z.string(),
  correspondenceType: z.enum(['notice', 'response', 'request']),
  direction: z.enum(['inbound', 'outbound']),
  subject: z.string(),
  content: z.string(),
  attachments: z.array(z.string()).optional(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;

    if (action === 'create_case') {
      return await createAuditDefenseCase(body);
    } else if (action === 'process_correspondence') {
      return await processCorrespondence(body);
    } else if (action === 'generate_response') {
      return await generateAutomatedResponse(body);
    } else if (action === 'assess_case_risk') {
      return await assessCaseRisk(body);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Audit Defense System Error:', error);
    return NextResponse.json(
      { error: 'Audit defense operation failed', details: error.message },
      { status: 500 }
    );
  }
}

async function createAuditDefenseCase(body: any) {
  const { taxReturnId, auditType, irsNoticeDate, responseDeadline, auditScope, initialDocuments } = 
    AuditDefenseRequestSchema.parse(body);

  // Get tax return and client information
  const taxReturn = await prisma.taxReturn.findUnique({
    where: { id: taxReturnId },
    include: {
      client: true,
      documents: true,
    }
  });

  if (!taxReturn) {
    return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
  }

  // Generate unique case number
  const caseNumber = `AUD-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;

  // Assess initial risk using ML
  const riskAssessment = await mlClient.assessAuditRisk({
    tax_return_id: taxReturnId,
    return_data: taxReturn.formData || {},
    client_profile: {
      previous_audits: 0, // Would get from client history
      years_as_client: 1,
      self_employed: taxReturn.formData?.selfEmployed || false,
      cash_business: taxReturn.formData?.cashBusiness || false,
      complexity_score: calculateComplexityScore(taxReturn.formData || {}),
    }
  });

  // Create audit defense case
  const auditCase = await prisma.auditDefenseCase.create({
    data: {
      tenantId: taxReturn.tenantId,
      taxReturnId: taxReturnId,
      clientId: taxReturn.clientId,
      caseNumber,
      auditType,
      irsNoticeDate: irsNoticeDate ? new Date(irsNoticeDate) : null,
      responseDeadline: responseDeadline ? new Date(responseDeadline) : null,
      caseStatus: 'active',
      riskLevel: riskAssessment.risk_category,
      defenseStrategy: {
        initialAssessment: riskAssessment,
        auditScope: auditScope || [],
        defenseApproach: generateDefenseStrategy(auditType, riskAssessment),
        keyDocuments: initialDocuments || [],
        timeline: generateDefenseTimeline(auditType, responseDeadline),
      },
      correspondenceLog: [],
    }
  });

  // Create initial correspondence record if IRS notice provided
  if (irsNoticeDate) {
    await prisma.irsCorrespondence.create({
      data: {
        auditCaseId: auditCase.id,
        correspondenceType: 'notice',
        direction: 'inbound',
        subject: `${auditType.toUpperCase()} Audit Notice`,
        content: 'Initial IRS audit notice received',
        aiProcessed: false,
        responseRequired: true,
        responseDeadline: responseDeadline ? new Date(responseDeadline) : null,
      }
    });
  }

  // Generate automated defense plan
  const defensePlan = await generateComprehensiveDefensePlan(auditCase, taxReturn, riskAssessment);

  return NextResponse.json({
    success: true,
    auditCase: {
      id: auditCase.id,
      caseNumber: auditCase.caseNumber,
      status: auditCase.caseStatus,
      riskLevel: auditCase.riskLevel,
    },
    defensePlan,
    nextSteps: generateImmediateNextSteps(auditType, responseDeadline),
  });
}

async function processCorrespondence(body: any) {
  const { auditCaseId, correspondenceType, direction, subject, content, attachments } = 
    CorrespondenceRequestSchema.parse(body);

  // Get audit case
  const auditCase = await prisma.auditDefenseCase.findUnique({
    where: { id: auditCaseId },
    include: {
      taxReturn: true,
      client: true,
    }
  });

  if (!auditCase) {
    return NextResponse.json({ error: 'Audit case not found' }, { status: 404 });
  }

  // Create correspondence record
  const correspondence = await prisma.irsCorrespondence.create({
    data: {
      auditCaseId,
      correspondenceType,
      direction,
      subject,
      content,
      attachments: attachments || [],
      aiProcessed: false,
      responseRequired: direction === 'inbound',
    }
  });

  // Process with AI if inbound correspondence
  let aiAnalysis = null;
  if (direction === 'inbound') {
    aiAnalysis = await analyzeIRSCorrespondence(content, subject, correspondenceType);
    
    // Update correspondence with AI analysis
    await prisma.irsCorrespondence.update({
      where: { id: correspondence.id },
      data: {
        aiProcessed: true,
        aiAnalysis,
        responseDeadline: aiAnalysis.extractedDeadline ? 
          new Date(aiAnalysis.extractedDeadline) : null,
      }
    });

    // Update case strategy if needed
    if (aiAnalysis.requiresStrategyUpdate) {
      await updateDefenseStrategy(auditCase, aiAnalysis);
    }
  }

  return NextResponse.json({
    success: true,
    correspondence: {
      id: correspondence.id,
      processed: direction === 'inbound',
      aiAnalysis,
    },
    recommendedActions: aiAnalysis?.recommendedActions || [],
  });
}

async function generateAutomatedResponse(body: any) {
  const { auditCaseId, correspondenceId, responseType } = body;

  // Get correspondence and case details
  const correspondence = await prisma.irsCorrespondence.findUnique({
    where: { id: correspondenceId },
    include: {
      auditCase: {
        include: {
          taxReturn: true,
          client: true,
        }
      }
    }
  });

  if (!correspondence) {
    return NextResponse.json({ error: 'Correspondence not found' }, { status: 404 });
  }

  // Generate response using AI
  const responseContent = await generateIRSResponse(
    correspondence,
    responseType,
    correspondence.auditCase
  );

  // Create draft response
  const draftResponse = await prisma.irsCorrespondence.create({
    data: {
      auditCaseId,
      correspondenceType: 'response',
      direction: 'outbound',
      subject: `Re: ${correspondence.subject}`,
      content: responseContent.content,
      attachments: responseContent.requiredAttachments || [],
      aiProcessed: true,
      aiAnalysis: {
        generatedResponse: true,
        responseType,
        confidence: responseContent.confidence,
        reviewRequired: responseContent.confidence < 0.9,
      },
      responseRequired: false,
    }
  });

  return NextResponse.json({
    success: true,
    draftResponse: {
      id: draftResponse.id,
      content: responseContent.content,
      confidence: responseContent.confidence,
      reviewRequired: responseContent.confidence < 0.9,
    },
    requiredAttachments: responseContent.requiredAttachments || [],
    legalReview: responseContent.confidence < 0.8,
  });
}

async function assessCaseRisk(body: any) {
  const { auditCaseId } = body;

  const auditCase = await prisma.auditDefenseCase.findUnique({
    where: { id: auditCaseId },
    include: {
      taxReturn: true,
      client: true,
      correspondence: true,
    }
  });

  if (!auditCase) {
    return NextResponse.json({ error: 'Audit case not found' }, { status: 404 });
  }

  // Reassess risk with current case information
  const updatedRiskAssessment = await mlClient.assessAuditRisk({
    tax_return_id: auditCase.taxReturnId,
    return_data: auditCase.taxReturn.formData || {},
    client_profile: {
      previous_audits: 1, // Current audit
      audit_history: auditCase.correspondence.map(c => ({
        type: c.correspondenceType,
        date: c.createdAt,
        content_summary: c.content.substring(0, 100),
      })),
    }
  });

  // Update case with new risk assessment
  await prisma.auditDefenseCase.update({
    where: { id: auditCaseId },
    data: {
      riskLevel: updatedRiskAssessment.risk_category,
      defenseStrategy: {
        ...auditCase.defenseStrategy,
        updatedRiskAssessment,
        lastAssessed: new Date().toISOString(),
      }
    }
  });

  return NextResponse.json({
    success: true,
    riskAssessment: updatedRiskAssessment,
    recommendedActions: generateRiskMitigationActions(updatedRiskAssessment),
  });
}

// Helper functions
function calculateComplexityScore(formData: any): number {
  let score = 1;
  
  if (formData.businessIncome > 0) score += 0.3;
  if (formData.rentalIncome > 0) score += 0.2;
  if (formData.investmentIncome > 0) score += 0.2;
  if (formData.foreignIncome > 0) score += 0.4;
  if (formData.totalDeductions > formData.income * 0.3) score += 0.3;
  
  return Math.min(score, 3.0);
}

function generateDefenseStrategy(auditType: string, riskAssessment: any): any {
  const baseStrategy = {
    approach: auditType === 'correspondence' ? 'documentation_focused' : 'comprehensive_defense',
    priority_areas: riskAssessment.risk_factors.map((f: any) => f.factor),
    documentation_requirements: [],
    communication_strategy: 'professional_cooperative',
  };

  switch (auditType) {
    case 'correspondence':
      baseStrategy.documentation_requirements = [
        'Gather all supporting documents for questioned items',
        'Prepare detailed explanations for each issue',
        'Organize documents chronologically',
      ];
      break;
    case 'office':
      baseStrategy.documentation_requirements = [
        'Prepare comprehensive document package',
        'Create timeline of events',
        'Prepare client for interview',
        'Organize evidence by audit issue',
      ];
      break;
    case 'field':
      baseStrategy.documentation_requirements = [
        'Secure all business records',
        'Prepare detailed business operations overview',
        'Organize multi-year documentation',
        'Prepare for on-site examination',
      ];
      break;
  }

  return baseStrategy;
}

function generateDefenseTimeline(auditType: string, responseDeadline?: string): any {
  const timeline = [];
  const deadlineDate = responseDeadline ? new Date(responseDeadline) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  
  // Calculate milestone dates
  const totalDays = Math.floor((deadlineDate.getTime() - Date.now()) / (24 * 60 * 60 * 1000));
  
  timeline.push({
    phase: 'Initial Assessment',
    deadline: new Date(Date.now() + Math.floor(totalDays * 0.1) * 24 * 60 * 60 * 1000),
    tasks: ['Review audit notice', 'Assess scope', 'Gather initial documents'],
  });
  
  timeline.push({
    phase: 'Document Preparation',
    deadline: new Date(Date.now() + Math.floor(totalDays * 0.6) * 24 * 60 * 60 * 1000),
    tasks: ['Collect all supporting documents', 'Organize evidence', 'Prepare explanations'],
  });
  
  timeline.push({
    phase: 'Response Preparation',
    deadline: new Date(Date.now() + Math.floor(totalDays * 0.9) * 24 * 60 * 60 * 1000),
    tasks: ['Draft response', 'Legal review', 'Client approval'],
  });
  
  timeline.push({
    phase: 'Submission',
    deadline: deadlineDate,
    tasks: ['Submit response', 'Confirm receipt', 'Schedule follow-up'],
  });

  return timeline;
}

async function generateComprehensiveDefensePlan(auditCase: any, taxReturn: any, riskAssessment: any): Promise<any> {
  return {
    executiveSummary: `Audit defense plan for ${auditCase.auditType} audit with ${riskAssessment.risk_category} risk level`,
    keyStrategies: [
      'Proactive documentation gathering',
      'Strategic communication with IRS',
      'Risk mitigation through comprehensive responses',
      'Timeline management for optimal outcomes',
    ],
    documentationPlan: {
      primaryDocuments: generateRequiredDocuments(taxReturn.formData, auditCase.auditType),
      secondaryDocuments: generateSupportingDocuments(riskAssessment.risk_factors),
      organizationStrategy: 'Chronological with cross-references',
    },
    communicationPlan: {
      tone: 'Professional and cooperative',
      responseStrategy: 'Comprehensive but concise',
      escalationProtocol: 'Involve legal counsel if penalties exceed $10,000',
    },
    riskMitigation: riskAssessment.prevention_recommendations,
    successMetrics: [
      'No additional tax liability',
      'No penalties assessed',
      'Case closed within 6 months',
      'Client satisfaction maintained',
    ],
  };
}

function generateImmediateNextSteps(auditType: string, responseDeadline?: string): string[] {
  const steps = [
    'Acknowledge receipt of audit notice',
    'Secure all relevant documents and records',
    'Begin document organization process',
  ];

  if (responseDeadline) {
    const daysUntilDeadline = Math.floor(
      (new Date(responseDeadline).getTime() - Date.now()) / (24 * 60 * 60 * 1000)
    );
    
    if (daysUntilDeadline < 15) {
      steps.unshift('URGENT: Request extension if needed');
    }
  }

  switch (auditType) {
    case 'correspondence':
      steps.push('Prepare written response to specific issues raised');
      break;
    case 'office':
      steps.push('Schedule appointment with IRS examiner');
      steps.push('Prepare client for in-person meeting');
      break;
    case 'field':
      steps.push('Prepare business premises for examination');
      steps.push('Notify all relevant personnel');
      break;
  }

  return steps;
}

async function analyzeIRSCorrespondence(content: string, subject: string, type: string): Promise<any> {
  // This would use advanced NLP to analyze IRS correspondence
  // For now, implementing basic analysis
  
  const analysis = {
    extractedDeadline: extractDeadlineFromContent(content),
    requestedDocuments: extractDocumentRequests(content),
    issuesRaised: extractIssues(content),
    tone: analyzeTone(content),
    urgency: assessUrgency(content, subject),
    requiresStrategyUpdate: false,
    recommendedActions: [],
  };

  // Generate recommended actions based on analysis
  if (analysis.extractedDeadline) {
    const daysUntilDeadline = Math.floor(
      (new Date(analysis.extractedDeadline).getTime() - Date.now()) / (24 * 60 * 60 * 1000)
    );
    
    if (daysUntilDeadline < 15) {
      analysis.recommendedActions.push('Consider requesting extension');
    }
  }

  if (analysis.requestedDocuments.length > 0) {
    analysis.recommendedActions.push('Begin gathering requested documents immediately');
  }

  if (analysis.urgency === 'high') {
    analysis.recommendedActions.push('Prioritize this case for immediate attention');
    analysis.requiresStrategyUpdate = true;
  }

  return analysis;
}

function extractDeadlineFromContent(content: string): string | null {
  // Simple regex to find dates - would be more sophisticated in production
  const dateRegex = /(\d{1,2}\/\d{1,2}\/\d{4}|\d{4}-\d{2}-\d{2})/g;
  const matches = content.match(dateRegex);
  
  if (matches && matches.length > 0) {
    // Return the latest date found
    return matches.sort().pop() || null;
  }
  
  return null;
}

function extractDocumentRequests(content: string): string[] {
  const documents = [];
  const commonDocs = [
    'bank statements', 'receipts', 'invoices', 'contracts', 'records',
    'w-2', '1099', 'schedule c', 'depreciation', 'mileage log'
  ];
  
  for (const doc of commonDocs) {
    if (content.toLowerCase().includes(doc)) {
      documents.push(doc);
    }
  }
  
  return documents;
}

function extractIssues(content: string): string[] {
  const issues = [];
  const commonIssues = [
    'business expenses', 'deductions', 'income reporting', 'depreciation',
    'home office', 'travel expenses', 'charitable contributions'
  ];
  
  for (const issue of commonIssues) {
    if (content.toLowerCase().includes(issue)) {
      issues.push(issue);
    }
  }
  
  return issues;
}

function analyzeTone(content: string): string {
  // Simple tone analysis - would use NLP in production
  const formalWords = ['pursuant', 'therefore', 'accordingly', 'hereby'];
  const urgentWords = ['immediately', 'urgent', 'deadline', 'final'];
  
  const formalCount = formalWords.filter(word => content.toLowerCase().includes(word)).length;
  const urgentCount = urgentWords.filter(word => content.toLowerCase().includes(word)).length;
  
  if (urgentCount > 1) return 'urgent';
  if (formalCount > 1) return 'formal';
  return 'standard';
}

function assessUrgency(content: string, subject: string): string {
  const urgentKeywords = ['final', 'immediate', 'deadline', 'penalty', 'enforcement'];
  const urgentCount = urgentKeywords.filter(keyword => 
    content.toLowerCase().includes(keyword) || subject.toLowerCase().includes(keyword)
  ).length;
  
  if (urgentCount >= 2) return 'high';
  if (urgentCount === 1) return 'medium';
  return 'low';
}

async function updateDefenseStrategy(auditCase: any, aiAnalysis: any): Promise<void> {
  const updatedStrategy = {
    ...auditCase.defenseStrategy,
    aiInsights: aiAnalysis,
    updatedPriorities: aiAnalysis.issuesRaised,
    lastUpdated: new Date().toISOString(),
  };

  await prisma.auditDefenseCase.update({
    where: { id: auditCase.id },
    data: { defenseStrategy: updatedStrategy }
  });
}

async function generateIRSResponse(correspondence: any, responseType: string, auditCase: any): Promise<any> {
  // This would use advanced AI to generate appropriate responses
  // For now, implementing template-based responses
  
  const templates = {
    document_request: `Dear IRS Examiner,

In response to your correspondence dated ${correspondence.createdAt.toDateString()}, please find the requested documentation attached.

We have provided the following items:
{document_list}

If you require any additional information or clarification, please do not hesitate to contact us.

Respectfully,
Tax Professional`,
    
    explanation_request: `Dear IRS Examiner,

Thank you for your inquiry regarding {subject_matter}. Please find our detailed explanation below:

{explanation_content}

We believe this information adequately addresses your concerns. Please let us know if you require any additional clarification.

Respectfully,
Tax Professional`,
    
    disagreement: `Dear IRS Examiner,

We respectfully disagree with the proposed adjustments outlined in your correspondence. Our position is based on the following:

{disagreement_points}

We request that you reconsider your position based on the information provided.

Respectfully,
Tax Professional`,
  };

  const template = templates[responseType as keyof typeof templates] || templates.document_request;
  
  return {
    content: template,
    confidence: 0.85,
    requiredAttachments: generateRequiredAttachments(responseType, auditCase),
  };
}

function generateRequiredDocuments(formData: any, auditType: string): string[] {
  const documents = ['Tax return as filed', 'All supporting schedules'];
  
  if (formData.businessIncome > 0) {
    documents.push('Business income records', 'Business expense receipts', 'Bank statements');
  }
  
  if (formData.charitableDeductions > 0) {
    documents.push('Charitable contribution receipts', 'Acknowledgment letters');
  }
  
  if (formData.homeOfficeDeduction > 0) {
    documents.push('Home office measurements', 'Utility bills', 'Home expenses');
  }
  
  return documents;
}

function generateSupportingDocuments(riskFactors: any[]): string[] {
  const documents = [];
  
  for (const factor of riskFactors) {
    switch (factor.factor) {
      case 'high_deductions':
        documents.push('Detailed deduction worksheets', 'Supporting receipts');
        break;
      case 'cash_business':
        documents.push('Daily cash receipts', 'Deposit records', 'Sales records');
        break;
      case 'business_expenses':
        documents.push('Business purpose documentation', 'Travel logs');
        break;
    }
  }
  
  return documents;
}

function generateRequiredAttachments(responseType: string, auditCase: any): string[] {
  const attachments = [];
  
  switch (responseType) {
    case 'document_request':
      attachments.push('Requested documents', 'Document index', 'Cover letter');
      break;
    case 'explanation_request':
      attachments.push('Supporting calculations', 'Legal authorities', 'Precedent cases');
      break;
    case 'disagreement':
      attachments.push('Counter-evidence', 'Legal brief', 'Expert opinions');
      break;
  }
  
  return attachments;
}

function generateRiskMitigationActions(riskAssessment: any): string[] {
  const actions = [];
  
  for (const factor of riskAssessment.risk_factors) {
    switch (factor.factor) {
      case 'high_deductions':
        actions.push('Prepare detailed substantiation for all large deductions');
        break;
      case 'cash_business':
        actions.push('Implement better cash tracking systems for future');
        break;
      case 'audit_history':
        actions.push('Address any recurring issues from previous audits');
        break;
    }
  }
  
  actions.push(...riskAssessment.prevention_recommendations);
  
  return [...new Set(actions)]; // Remove duplicates
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get('tenantId');
    const caseId = searchParams.get('caseId');
    const status = searchParams.get('status');

    if (!tenantId) {
      return NextResponse.json({ error: 'tenantId required' }, { status: 400 });
    }

    let whereClause: any = { tenantId };
    
    if (caseId) {
      whereClause.id = caseId;
    }
    
    if (status) {
      whereClause.caseStatus = status;
    }

    const auditCases = await prisma.auditDefenseCase.findMany({
      where: whereClause,
      include: {
        client: {
          select: { firstName: true, lastName: true, email: true }
        },
        taxReturn: {
          select: { taxYear: true, returnType: true }
        },
        correspondence: {
          orderBy: { createdAt: 'desc' },
          take: 5
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({
      auditCases,
      summary: {
        total: auditCases.length,
        active: auditCases.filter(c => c.caseStatus === 'active').length,
        resolved: auditCases.filter(c => c.caseStatus === 'resolved').length,
        highRisk: auditCases.filter(c => c.riskLevel === 'high' || c.riskLevel === 'critical').length,
      }
    });

  } catch (error) {
    console.error('Get Audit Cases Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve audit cases' },
      { status: 500 }
    );
  }
}
