
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { enqueueJob } from '@/lib/jobs/queue';
import { TaskStatus, TaskPriority } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'GET':
      return handleGetTasks(req, res, tenantId);
    case 'POST':
      return handleCreateTask(req, res, tenantId, session.user.id);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetTasks(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const {
      page = '1',
      limit = '20',
      status,
      priority,
      assignedTo,
      leadId,
      overdue,
      sortBy = 'due_date',
      sortOrder = 'asc',
    } = req.query;

    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    const where: any = { tenant_id: tenantId };
    
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (assignedTo) where.assigned_to = assignedTo;
    if (leadId) where.lead_id = leadId;
    
    if (overdue === 'true') {
      where.due_date = { lt: new Date() };
      where.status = { not: TaskStatus.COMPLETED };
    }

    const [tasks, total] = await Promise.all([
      prisma.crm_tasks.findMany({
        where,
        include: {
          assigned_user: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
          created_user: {
            select: { id: true, firstName: true, lastName: true },
          },
          lead: {
            select: { id: true, first_name: true, last_name: true, email: true },
          },
        },
        orderBy: { [sortBy as string]: sortOrder },
        skip: offset,
        take: limitNum,
      }),
      prisma.crm_tasks.count({ where }),
    ]);

    const totalPages = Math.ceil(total / limitNum);

    res.status(200).json({
      tasks,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1,
      },
    });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
}

async function handleCreateTask(req: NextApiRequest, res: NextApiResponse, tenantId: string, userId: string) {
  try {
    const {
      title,
      description,
      leadId,
      assignedTo,
      priority = TaskPriority.MEDIUM,
      dueDate,
      reminderAt,
      tags = [],
    } = req.body;

    if (!title) {
      return res.status(400).json({ error: 'Title is required' });
    }

    const task = await prisma.crm_tasks.create({
      data: {
        tenant_id: tenantId,
        title,
        description,
        lead_id: leadId,
        assigned_to: assignedTo || userId,
        created_by: userId,
        priority,
        due_date: dueDate ? new Date(dueDate) : null,
        reminder_at: reminderAt ? new Date(reminderAt) : null,
        tags,
        status: TaskStatus.PENDING,
      },
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        lead: {
          select: { id: true, first_name: true, last_name: true, email: true },
        },
      },
    });

    // Schedule reminder if specified
    if (reminderAt) {
      const reminderTime = new Date(reminderAt);
      const delay = reminderTime.getTime() - Date.now();
      
      if (delay > 0) {
        await enqueueJob('crm.task.reminder', { taskId: task.id }, {
          delay,
          tenantId,
        });
      }
    }

    res.status(201).json({ task });
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
}
