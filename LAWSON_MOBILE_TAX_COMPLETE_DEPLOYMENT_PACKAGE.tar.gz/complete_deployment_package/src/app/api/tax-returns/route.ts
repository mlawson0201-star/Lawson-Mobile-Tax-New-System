
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createTaxReturnSchema = z.object({
  clientId: z.string().uuid(),
  taxYear: z.number().int().min(2020).max(2024),
  filingStatus: z.enum(['SINGLE', 'MARRIED_FILING_JOINTLY', 'MARRIED_FILING_SEPARATELY', 'HEAD_OF_HOUSEHOLD', 'QUALIFYING_WIDOW']),
  returnType: z.enum(['INDIVIDUAL', 'BUSINESS', 'PARTNERSHIP', 'CORPORATION']),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.tenantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = createTaxReturnSchema.parse(body)

    // Verify client belongs to tenant
    const client = await prisma.client.findFirst({
      where: {
        id: validatedData.clientId,
        tenantId: session.user.tenantId,
      },
    })

    if (!client) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 })
    }

    const taxReturn = await prisma.taxReturn.create({
      data: {
        ...validatedData,
        tenantId: session.user.tenantId,
        status: 'INTAKE',
        preparerId: session.user.id,
      },
      include: {
        client: true,
        preparer: true,
      },
    })

    return NextResponse.json(taxReturn)
  } catch (error) {
    console.error('Error creating tax return:', error)
    return NextResponse.json(
      { error: 'Failed to create tax return' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.tenantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const status = searchParams.get('status')
    const taxYear = searchParams.get('taxYear')

    const where = {
      tenantId: session.user.tenantId,
      ...(status && { status }),
      ...(taxYear && { taxYear: parseInt(taxYear) }),
    }

    const [taxReturns, total] = await Promise.all([
      prisma.taxReturn.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          client: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          preparer: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
            },
          },
        },
      }),
      prisma.taxReturn.count({ where }),
    ])

    return NextResponse.json({
      taxReturns,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching tax returns:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tax returns' },
      { status: 500 }
    )
  }
}
