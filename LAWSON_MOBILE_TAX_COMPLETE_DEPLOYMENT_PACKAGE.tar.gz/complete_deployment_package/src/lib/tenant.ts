
'use server';

import { headers } from 'next/headers';
import { prisma } from '@/lib/prisma';

export interface TenantInfo {
  id: string;
  name: string;
  domain: string;
  brandingConfig: any;
  settings: any;
  subscriptionTier: string;
  revenueShareRate: number;
  active: boolean;
}

/**
 * Get tenant information from the current request
 */
export async function getCurrentTenant(): Promise<TenantInfo | null> {
  try {
    const headersList = headers();
    const host = headersList.get('host') || '';
    
    // Extract domain from host (remove port if present)
    const domain = host.split(':')[0];
    
    // For development, return default Lawson Mobile Tax configuration
    if (domain === 'localhost' || domain === '127.0.0.1') {
      return {
        id: 'lawson-mobile-tax',
        name: 'Lawson Mobile Tax',
        domain: 'lawsonmobiletax.com',
        brandingConfig: {
          primaryColor: '#6a0dad',
          logo: null
        },
        settings: {},
        subscriptionTier: 'premium',
        revenueShareRate: 0.15,
        active: true
      };
    }

    // Try to get from database for production
    try {
      const tenant = await prisma.tenant.findUnique({
        where: { 
          domain,
          active: true 
        }
      });

      if (!tenant) {
        // Return default configuration if no tenant found
        return {
          id: 'lawson-mobile-tax',
          name: 'Lawson Mobile Tax',
          domain: 'lawsonmobiletax.com',
          brandingConfig: {
            primaryColor: '#6a0dad',
            logo: null
          },
          settings: {},
          subscriptionTier: 'premium',
          revenueShareRate: 0.15,
          active: true
        };
      }

      return {
        id: tenant.id,
        name: tenant.name,
        domain: tenant.domain,
        brandingConfig: tenant.brandingConfig as any,
        settings: tenant.settings as any,
        subscriptionTier: tenant.subscriptionTier,
        revenueShareRate: Number(tenant.revenueShareRate),
        active: tenant.active
      };
    } catch (dbError) {
      console.error('Database error, using default tenant:', dbError);
      // Return default configuration if database is not available
      return {
        id: 'lawson-mobile-tax',
        name: 'Lawson Mobile Tax',
        domain: 'lawsonmobiletax.com',
        brandingConfig: {
          primaryColor: '#6a0dad',
          logo: null
        },
        settings: {},
        subscriptionTier: 'premium',
        revenueShareRate: 0.15,
        active: true
      };
    }
  } catch (error) {
    console.error('Error fetching tenant:', error);
    return {
      id: 'lawson-mobile-tax',
      name: 'Lawson Mobile Tax',
      domain: 'lawsonmobiletax.com',
      brandingConfig: {
        primaryColor: '#6a0dad',
        logo: null
      },
      settings: {},
      subscriptionTier: 'premium',
      revenueShareRate: 0.15,
      active: true
    };
  }
}

/**
 * Get tenant by domain
 */
export async function getTenantByDomain(domain: string): Promise<TenantInfo | null> {
  try {
    const tenant = await prisma.tenant.findUnique({
      where: { 
        domain,
        active: true 
      }
    });

    if (!tenant) {
      return null;
    }

    return {
      id: tenant.id,
      name: tenant.name,
      domain: tenant.domain,
      brandingConfig: tenant.brandingConfig as any,
      settings: tenant.settings as any,
      subscriptionTier: tenant.subscriptionTier,
      revenueShareRate: Number(tenant.revenueShareRate),
      active: tenant.active
    };
  } catch (error) {
    console.error('Error fetching tenant:', error);
    return null;
  }
}

/**
 * Set tenant context for Prisma queries
 */
export async function setTenantContext(tenantId: string) {
  // This would be used with Prisma's row-level security
  // For now, we'll handle tenant isolation in individual queries
  return tenantId;
}
