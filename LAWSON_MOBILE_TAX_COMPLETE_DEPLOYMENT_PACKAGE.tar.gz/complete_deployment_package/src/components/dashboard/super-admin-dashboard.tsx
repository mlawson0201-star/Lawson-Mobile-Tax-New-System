
'use client';

import { useEffect, useState } from 'react';
import { 
  Users, 
  Building2, 
  DollarSign, 
  TrendingUp, 
  FileText, 
  Shield,
  Activity,
  AlertCircle
} from 'lucide-react';
import { MetricCard } from '@/components/ui/metric-card';
import { RecentActivity } from '@/components/ui/recent-activity';
import { SystemStatus } from '@/components/ui/system-status';

export function SuperAdminDashboard() {
  const [metrics, setMetrics] = useState({
    totalTenants: 0,
    totalUsers: 0,
    totalReturns: 0,
    totalRevenue: 0,
    monthlyGrowth: 0,
    systemHealth: 95
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading dashboard data
    const timer = setTimeout(() => {
      setMetrics({
        totalTenants: 42,
        totalUsers: 2847,
        totalReturns: 12483,
        totalRevenue: 2847392,
        monthlyGrowth: 12.5,
        systemHealth: 98
      });
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const recentActivities = [
    {
      id: '1',
      type: 'tenant_created',
      description: 'New tenant "TaxPro Solutions" onboarded',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      severity: 'info'
    },
    {
      id: '2',
      type: 'system_alert',
      description: 'High API usage detected on OLT integration',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      severity: 'warning'
    },
    {
      id: '3',
      type: 'revenue_milestone',
      description: 'Monthly revenue exceeded $2.8M',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      severity: 'success'
    },
    {
      id: '4',
      type: 'user_registered',
      description: '247 new users registered today',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      severity: 'info'
    }
  ];

  const systemStatus = [
    { name: 'API Gateway', status: 'operational', uptime: '99.98%' },
    { name: 'Database', status: 'operational', uptime: '99.99%' },
    { name: 'Document Processing', status: 'operational', uptime: '99.95%' },
    { name: 'OLT Integration', status: 'degraded', uptime: '97.82%' },
    { name: 'Payment Processing', status: 'operational', uptime: '99.97%' },
    { name: 'Email Service', status: 'operational', uptime: '99.89%' }
  ];

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="h-8 bg-gray-200 rounded w-64 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-96 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="h-6 bg-gray-200 rounded w-32 mb-4 animate-pulse"></div>
              <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Super Admin Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Monitor system performance, manage tenants, and oversee platform operations
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Tenants"
          value={metrics.totalTenants}
          icon={Building2}
          trend={{ value: 8.2, isPositive: true }}
          description="Active tenants on platform"
        />
        <MetricCard
          title="Total Users"
          value={metrics.totalUsers.toLocaleString()}
          icon={Users}
          trend={{ value: 15.3, isPositive: true }}
          description="Registered users across all tenants"
        />
        <MetricCard
          title="Tax Returns Processed"
          value={metrics.totalReturns.toLocaleString()}
          icon={FileText}
          trend={{ value: 23.1, isPositive: true }}
          description="Returns processed this season"
        />
        <MetricCard
          title="Platform Revenue"
          value={`$${(metrics.totalRevenue / 1000000).toFixed(1)}M`}
          icon={DollarSign}
          trend={{ value: metrics.monthlyGrowth, isPositive: true }}
          description="Total revenue generated"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <Activity className="h-5 w-5 text-gray-400 mr-2" />
              <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
            </div>
          </div>
          <RecentActivity activities={recentActivities} />
        </div>

        {/* System Status */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Shield className="h-5 w-5 text-gray-400 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">System Status</h2>
              </div>
              <div className="flex items-center">
                <div className="h-2 w-2 bg-green-400 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">All Systems Operational</span>
              </div>
            </div>
          </div>
          <SystemStatus services={systemStatus} />
        </div>
      </div>

      {/* Performance Charts Section */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center">
            <TrendingUp className="h-5 w-5 text-gray-400 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Platform Performance</h2>
          </div>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{metrics.systemHealth}%</div>
              <div className="text-sm text-gray-600">System Health</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">47ms</div>
              <div className="text-sm text-gray-600">Avg Response Time</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">99.8%</div>
              <div className="text-sm text-gray-600">Uptime</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="flex items-center justify-center px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
              <Building2 className="h-5 w-5 mr-2" />
              Create New Tenant
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors">
              <Shield className="h-5 w-5 mr-2" />
              System Diagnostics
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors">
              <TrendingUp className="h-5 w-5 mr-2" />
              View Analytics
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
