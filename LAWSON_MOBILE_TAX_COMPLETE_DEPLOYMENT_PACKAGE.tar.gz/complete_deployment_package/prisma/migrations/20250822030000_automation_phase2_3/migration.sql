
-- Phase 2 & 3 Automation Features Migration

-- Advanced AI Deduction Engine Tables
CREATE TABLE "ai_deduction_models" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "model_name" TEXT NOT NULL,
    "model_version" TEXT NOT NULL,
    "model_type" TEXT NOT NULL, -- 'ml_classifier', 'neural_network', 'ensemble'
    "training_data" JSONB DEFAULT '{}',
    "accuracy_score" DECIMAL(5,4),
    "confidence_threshold" DECIMAL(5,4) DEFAULT 0.85,
    "status" TEXT DEFAULT 'active',
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "deduction_predictions" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "tax_return_id" UUID NOT NULL REFERENCES "tax_returns"("id") ON DELETE CASCADE,
    "model_id" UUID NOT NULL REFERENCES "ai_deduction_models"("id"),
    "deduction_category" TEXT NOT NULL,
    "predicted_amount" DECIMAL(10,2),
    "confidence_score" DECIMAL(5,4),
    "supporting_evidence" JSONB DEFAULT '{}',
    "status" TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
    "human_verified" BOOLEAN DEFAULT FALSE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Audit Defense System Tables
CREATE TABLE "audit_defense_cases" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "tax_return_id" UUID NOT NULL REFERENCES "tax_returns"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "case_number" TEXT UNIQUE NOT NULL,
    "audit_type" TEXT NOT NULL, -- 'correspondence', 'office', 'field'
    "irs_notice_date" DATE,
    "response_deadline" DATE,
    "case_status" TEXT DEFAULT 'active',
    "risk_level" TEXT DEFAULT 'medium',
    "defense_strategy" JSONB DEFAULT '{}',
    "correspondence_log" JSONB DEFAULT '[]',
    "resolution_outcome" TEXT,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "irs_correspondence" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "audit_case_id" UUID NOT NULL REFERENCES "audit_defense_cases"("id") ON DELETE CASCADE,
    "correspondence_type" TEXT NOT NULL, -- 'notice', 'response', 'request'
    "direction" TEXT NOT NULL, -- 'inbound', 'outbound'
    "subject" TEXT,
    "content" TEXT,
    "attachments" JSONB DEFAULT '[]',
    "ai_processed" BOOLEAN DEFAULT FALSE,
    "ai_analysis" JSONB DEFAULT '{}',
    "response_required" BOOLEAN DEFAULT FALSE,
    "response_deadline" DATE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Predictive Tax Planning Tables
CREATE TABLE "tax_planning_scenarios" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "scenario_name" TEXT NOT NULL,
    "tax_year" TEXT NOT NULL,
    "quarter" INTEGER, -- 1, 2, 3, 4 for quarterly planning
    "scenario_data" JSONB NOT NULL,
    "projected_liability" DECIMAL(10,2),
    "optimization_suggestions" JSONB DEFAULT '[]',
    "confidence_score" DECIMAL(5,4),
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "quarterly_recommendations" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "tax_year" TEXT NOT NULL,
    "quarter" INTEGER NOT NULL,
    "recommendation_type" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "potential_savings" DECIMAL(10,2),
    "implementation_deadline" DATE,
    "status" TEXT DEFAULT 'pending',
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Voice Processing Tables
CREATE TABLE "voice_processing_jobs" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "user_id" UUID NOT NULL REFERENCES "users"("id"),
    "audio_file_path" TEXT NOT NULL,
    "processing_type" TEXT NOT NULL, -- 'document_dictation', 'client_interview', 'tax_consultation'
    "status" TEXT DEFAULT 'queued',
    "transcript" TEXT,
    "extracted_data" JSONB DEFAULT '{}',
    "confidence_scores" JSONB DEFAULT '{}',
    "processing_duration" INTEGER, -- in seconds
    "created_at" TIMESTAMP DEFAULT NOW(),
    "completed_at" TIMESTAMP
);

CREATE TABLE "voice_commands" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "voice_job_id" UUID NOT NULL REFERENCES "voice_processing_jobs"("id") ON DELETE CASCADE,
    "command_type" TEXT NOT NULL,
    "command_text" TEXT NOT NULL,
    "parameters" JSONB DEFAULT '{}',
    "executed" BOOLEAN DEFAULT FALSE,
    "execution_result" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Intelligent Workflow Routing Tables
CREATE TABLE "workflow_rules" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "rule_name" TEXT NOT NULL,
    "rule_type" TEXT NOT NULL, -- 'routing', 'escalation', 'automation'
    "conditions" JSONB NOT NULL,
    "actions" JSONB NOT NULL,
    "priority" INTEGER DEFAULT 0,
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "workflow_executions" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "rule_id" UUID NOT NULL REFERENCES "workflow_rules"("id"),
    "tax_return_id" UUID REFERENCES "tax_returns"("id"),
    "trigger_data" JSONB NOT NULL,
    "execution_result" JSONB DEFAULT '{}',
    "status" TEXT DEFAULT 'pending',
    "executed_at" TIMESTAMP DEFAULT NOW()
);

-- AI Tax Strategy Optimization Tables
CREATE TABLE "tax_strategies" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "strategy_name" TEXT NOT NULL,
    "entity_structure" JSONB NOT NULL, -- multi-entity scenarios
    "optimization_goals" JSONB NOT NULL,
    "projected_savings" DECIMAL(10,2),
    "implementation_complexity" TEXT DEFAULT 'medium',
    "legal_requirements" JSONB DEFAULT '[]',
    "status" TEXT DEFAULT 'draft',
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "entity_relationships" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "strategy_id" UUID NOT NULL REFERENCES "tax_strategies"("id") ON DELETE CASCADE,
    "parent_entity" TEXT,
    "child_entity" TEXT,
    "relationship_type" TEXT NOT NULL,
    "ownership_percentage" DECIMAL(5,2),
    "tax_implications" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Business Formation Automation Tables
CREATE TABLE "business_formation_requests" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "client_id" UUID NOT NULL REFERENCES "clients"("id") ON DELETE CASCADE,
    "entity_type" TEXT NOT NULL, -- 'LLC', 'Corporation', 'Partnership', 'S-Corp'
    "state_of_formation" TEXT NOT NULL,
    "business_name" TEXT NOT NULL,
    "business_purpose" TEXT,
    "formation_data" JSONB NOT NULL,
    "status" TEXT DEFAULT 'pending',
    "formation_date" DATE,
    "ein_number" TEXT,
    "compliance_schedule" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "compliance_requirements" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "formation_request_id" UUID NOT NULL REFERENCES "business_formation_requests"("id") ON DELETE CASCADE,
    "requirement_type" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "due_date" DATE,
    "frequency" TEXT, -- 'annual', 'quarterly', 'monthly', 'one-time'
    "status" TEXT DEFAULT 'pending',
    "automated" BOOLEAN DEFAULT FALSE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Real-time Tax Law Updates Tables
CREATE TABLE "tax_law_updates" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "update_source" TEXT NOT NULL, -- 'IRS', 'State', 'Court', 'Congress'
    "jurisdiction" TEXT NOT NULL,
    "update_type" TEXT NOT NULL, -- 'rate_change', 'form_update', 'regulation_change'
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "effective_date" DATE,
    "impact_assessment" JSONB DEFAULT '{}',
    "affected_forms" TEXT[],
    "automated_adjustments" JSONB DEFAULT '{}',
    "status" TEXT DEFAULT 'active',
    "created_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "law_update_impacts" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "update_id" UUID NOT NULL REFERENCES "tax_law_updates"("id") ON DELETE CASCADE,
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "affected_returns" INTEGER DEFAULT 0,
    "estimated_impact" DECIMAL(10,2),
    "action_required" BOOLEAN DEFAULT FALSE,
    "action_items" JSONB DEFAULT '[]',
    "processed" BOOLEAN DEFAULT FALSE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Complex Return Processing Tables
CREATE TABLE "complex_return_processors" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "processor_name" TEXT NOT NULL,
    "supported_forms" TEXT[] NOT NULL, -- ['K-1', '1120S', '1065', '8825']
    "processing_rules" JSONB NOT NULL,
    "automation_level" DECIMAL(3,2) DEFAULT 0.95, -- 95% automation target
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "k1_processing" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "tax_return_id" UUID NOT NULL REFERENCES "tax_returns"("id") ON DELETE CASCADE,
    "k1_type" TEXT NOT NULL, -- '1065', '1120S', '1041'
    "partnership_name" TEXT,
    "ein" TEXT,
    "k1_data" JSONB NOT NULL,
    "processing_status" TEXT DEFAULT 'pending',
    "validation_results" JSONB DEFAULT '{}',
    "integration_status" TEXT DEFAULT 'pending',
    "created_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "rental_property_processing" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "tax_return_id" UUID NOT NULL REFERENCES "tax_returns"("id") ON DELETE CASCADE,
    "property_address" TEXT NOT NULL,
    "property_type" TEXT NOT NULL,
    "rental_income" DECIMAL(10,2),
    "expenses" JSONB NOT NULL,
    "depreciation_schedule" JSONB DEFAULT '{}',
    "processing_status" TEXT DEFAULT 'pending',
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- ML Audit Risk Assessment Tables
CREATE TABLE "audit_risk_models" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "model_name" TEXT NOT NULL,
    "model_version" TEXT NOT NULL,
    "risk_factors" JSONB NOT NULL,
    "accuracy_metrics" JSONB DEFAULT '{}',
    "training_date" TIMESTAMP,
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "audit_risk_assessments" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "tax_return_id" UUID NOT NULL REFERENCES "tax_returns"("id") ON DELETE CASCADE,
    "model_id" UUID NOT NULL REFERENCES "audit_risk_models"("id"),
    "overall_risk_score" DECIMAL(5,4) NOT NULL,
    "risk_category" TEXT NOT NULL, -- 'low', 'medium', 'high', 'critical'
    "risk_factors" JSONB NOT NULL,
    "prevention_recommendations" JSONB DEFAULT '[]',
    "monitoring_required" BOOLEAN DEFAULT FALSE,
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- Admin Monitoring Tables
CREATE TABLE "automation_metrics" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "metric_type" TEXT NOT NULL,
    "metric_name" TEXT NOT NULL,
    "metric_value" DECIMAL(10,4),
    "target_value" DECIMAL(10,4),
    "measurement_date" DATE NOT NULL,
    "created_at" TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "automation_errors" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "error_type" TEXT NOT NULL,
    "error_source" TEXT NOT NULL,
    "error_message" TEXT NOT NULL,
    "error_data" JSONB DEFAULT '{}',
    "severity" TEXT DEFAULT 'medium',
    "resolved" BOOLEAN DEFAULT FALSE,
    "resolution_notes" TEXT,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "resolved_at" TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_deduction_predictions_tax_return ON "deduction_predictions"("tax_return_id");
CREATE INDEX idx_audit_defense_cases_client ON "audit_defense_cases"("client_id");
CREATE INDEX idx_voice_processing_status ON "voice_processing_jobs"("status");
CREATE INDEX idx_workflow_executions_status ON "workflow_executions"("status");
CREATE INDEX idx_tax_law_updates_effective_date ON "tax_law_updates"("effective_date");
CREATE INDEX idx_audit_risk_assessments_risk_category ON "audit_risk_assessments"("risk_category");
CREATE INDEX idx_automation_metrics_date ON "automation_metrics"("measurement_date");
