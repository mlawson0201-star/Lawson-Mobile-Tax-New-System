
# Legal Documentation Suite
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. Terms of Service

### 1.1 Lawson Mobile Tax Terms of Service

**TERMS OF SERVICE**

**Effective Date: [INSERT DATE]**

These Terms of Service ("Terms") govern your use of the Lawson Mobile Tax platform and services provided by [INSERT LEGAL NAME] ("Company," "we," "us," or "our").

**1. ACCEPTANCE OF TERMS**
By accessing or using our services, you agree to be bound by these Terms and our Privacy Policy.

**2. SERVICES DESCRIPTION**
We provide tax preparation, e-filing, and related financial services through our platform.

**3. USER RESPONSIBILITIES**
- Provide accurate and complete information
- Maintain confidentiality of account credentials
- Comply with all applicable laws and regulations

**4. FEES AND PAYMENT**
- Base 1040: $485
- State Returns: $79 each
- Additional services as listed on our pricing page
- All fees are due upon completion of services

**5. PRIVACY AND DATA PROTECTION**
We protect your personal information in accordance with our Privacy Policy and applicable laws including GLBA.

**6. LIMITATION OF LIABILITY**
[INSERT STANDARD LIABILITY LIMITATIONS]

**7. GOVERNING LAW**
These Terms are governed by the laws of [INSERT STATE].

**Contact Information:**
[INSERT LEGAL NAME]
[INSERT REGISTERED ADDRESS]
Email: [INSERT SUPPORT EMAIL]
Phone: [INSERT SUPPORT PHONE]

---

## 2. Privacy Policy

### 2.1 GLBA-Compliant Privacy Policy

**PRIVACY POLICY**

**Last Updated: [INSERT DATE]**

[INSERT LEGAL NAME] ("we," "us," or "our") is committed to protecting your privacy and personal information.

**INFORMATION WE COLLECT**
- Personal identification information (name, SSN, address)
- Financial information (income, tax documents, bank accounts)
- Transaction information (payments, refunds)

**HOW WE USE YOUR INFORMATION**
- Prepare and file your tax returns
- Process payments and refunds
- Comply with legal requirements
- Improve our services

**INFORMATION SHARING**
We may share your information with:
- Service providers who assist our operations
- Government agencies as required by law
- Other parties with your consent

**YOUR RIGHTS**
- Access your personal information
- Correct inaccurate information
- Opt-out of marketing communications
- Request deletion (subject to legal requirements)

**SECURITY MEASURES**
We implement physical, electronic, and procedural safeguards to protect your information.

**CONTACT US**
Privacy Officer
[INSERT LEGAL NAME]
Email: privacy@lawsonmobiletax.com
Phone: [INSERT SUPPORT PHONE]

---

## 3. EPS Financial Disclosures

### 3.1 Refund Advance Disclosures

**REFUND ADVANCE DISCLOSURE**

This is a loan secured by your expected tax refund. Important terms:

- **APR**: [INSERT APR]%
- **Loan Amount**: $[INSERT AMOUNT]
- **Estimated Refund**: $[INSERT REFUND]
- **Repayment**: Automatically deducted from your tax refund

**RISKS**
- You are responsible for repayment even if your refund is less than expected
- Additional fees may apply if your return is rejected
- This loan may affect your credit score

**YOUR RIGHTS**
- You may cancel this loan within 3 business days
- You have the right to receive a copy of all loan documents
- You may file complaints with [INSERT REGULATORY BODY]

By accepting this loan, you authorize us to deduct the loan amount plus fees from your tax refund.

---

## 4. ERO Disclosures

### 4.1 Electronic Return Originator Disclosures

**ELECTRONIC FILING DISCLOSURE**

As your Electronic Return Originator (ERO), we will:
- Transmit your return to the IRS electronically
- Provide you with acknowledgment of receipt
- Notify you of acceptance or rejection

**YOUR RESPONSIBILITIES**
- Review your return for accuracy before signing
- Provide valid electronic signature authorization
- Maintain copies of all tax documents

**E-SIGNATURE AUTHORIZATION (Form 8879)**
By signing electronically, you authorize us to file your return and agree that your electronic signature has the same legal effect as a handwritten signature.

**ERO Information:**
[INSERT LEGAL NAME]
ERO EFIN: [INSERT EFIN]
Address: [INSERT REGISTERED ADDRESS]

---

## 5. White-Label Agreements

### 5.1 Reseller Agreement Template

**FORMALITY TAX RESELLER AGREEMENT**

This Agreement is between [INSERT LEGAL NAME] ("Platform") and the Reseller.

**1. SERVICES PROVIDED**
Platform provides white-label tax preparation services under Reseller's brand.

**2. REVENUE SHARING**
- Platform Fee: 30% of gross revenue
- Reseller Share: 70% of gross revenue
- Payments processed via Stripe Connect

**3. BRANDING AND MARKETING**
- Reseller may use custom branding
- Platform provides marketing materials and templates
- Reseller responsible for local marketing compliance

**4. COMPLIANCE REQUIREMENTS**
- Reseller must maintain appropriate licenses
- Platform handles IRS compliance and e-filing
- Both parties must comply with GLBA and privacy laws

**5. TERM AND TERMINATION**
- Initial term: 1 year, auto-renewing
- Either party may terminate with 30 days notice

**Contact for Agreement:**
Legal Department
Email: legal@formalitytax.com

---

## 6. Consent Forms

### 6.1 SMS Marketing Consent

**SMS MARKETING CONSENT**

By providing your mobile phone number, you consent to receive text messages from [INSERT LEGAL NAME] including:
- Service updates and notifications
- Marketing messages and promotions
- Account alerts and reminders

**Message Frequency:** Up to 10 messages per month during tax season
**Message and Data Rates:** Standard rates may apply
**Opt-Out:** Reply STOP to any message to unsubscribe
**Help:** Reply HELP for assistance

You may revoke consent at any time. Consent is not required for purchase.

**Carrier Disclaimer:** This service is available on major carriers. Check with your carrier for availability.

---

## 7. Compliance Checklists

### 7.1 GLBA Compliance Checklist

**GRAMM-LEACH-BLILEY ACT COMPLIANCE**

☐ **Safeguards Rule Implementation**
  - Designated Information Security Officer
  - Written information security program
  - Regular risk assessments
  - Employee training programs

☐ **Privacy Rule Compliance**
  - Privacy notices provided to customers
  - Opt-out mechanisms implemented
  - Customer consent tracking
  - Privacy policy updates

☐ **Pretexting Protection**
  - Identity verification procedures
  - Employee background checks
  - Access controls and monitoring
  - Incident response procedures

### 7.2 IRS Publication 4557 Compliance

**IRS SAFEGUARDING REQUIREMENTS**

☐ **Physical Safeguards**
  - Secure facilities and workstations
  - Controlled access to taxpayer data
  - Secure storage and disposal

☐ **Technical Safeguards**
  - Encryption of taxpayer data
  - Access controls and authentication
  - Audit logs and monitoring

☐ **Administrative Safeguards**
  - Security policies and procedures
  - Employee training and awareness
  - Incident response plan

---

*Document Version: 1.0*
*Last Updated: August 22, 2025*
*Legal Review Required: All documents require legal counsel review before use*

