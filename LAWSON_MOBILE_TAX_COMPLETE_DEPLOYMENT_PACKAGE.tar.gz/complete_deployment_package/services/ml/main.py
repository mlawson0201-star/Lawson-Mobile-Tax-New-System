
"""
Advanced ML Services for Lawson Mobile Tax Platform
Provides machine learning capabilities for Phase 2 & 3 automation features
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score
import joblib
import json
import os
from datetime import datetime, timedelta
import asyncio
import httpx
import logging
from transformers import pipeline
import torch
import whisper
import cv2
import pytesseract
from PIL import Image
import spacy
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
import xgboost as xgb
import lightgbm as lgb

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Lawson Tax ML Services - Financial Life Singularity", version="3.0.0-singularity")

# Next-Generation Imports (conditional based on feature flags)
try:
    import sys
    sys.path.append('/home/ubuntu/lawson-mobile-tax')
    from src.core.feature_flags import NEXTGEN_FLAGS, is_enabled
    from src.nextgen import initialize_singularity, get_singularity_status
    NEXTGEN_AVAILABLE = True
    logger.info("🚀 Next-generation features available - Financial Life Singularity mode activated")
except ImportError:
    NEXTGEN_AVAILABLE = False
    logger.warning("⚠️  Next-generation features not available - running in legacy mode")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load NLP models
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    logger.warning("spaCy model not found. Install with: python -m spacy download en_core_web_sm")
    nlp = None

try:
    nltk.download('vader_lexicon', quiet=True)
    sentiment_analyzer = SentimentIntensityAnalyzer()
except:
    logger.warning("NLTK VADER not available")
    sentiment_analyzer = None

# Load Whisper model for voice processing
try:
    whisper_model = whisper.load_model("base")
except:
    logger.warning("Whisper model not available")
    whisper_model = None

# Pydantic models
class DeductionPredictionRequest(BaseModel):
    tax_return_id: str
    client_data: Dict[str, Any]
    document_data: List[Dict[str, Any]]
    historical_data: Optional[Dict[str, Any]] = None

class DeductionPredictionResponse(BaseModel):
    predictions: List[Dict[str, Any]]
    confidence_scores: Dict[str, float]
    total_potential_savings: float
    processing_time: float

class AuditRiskAssessmentRequest(BaseModel):
    tax_return_id: str
    return_data: Dict[str, Any]
    client_profile: Dict[str, Any]
    historical_audits: Optional[List[Dict[str, Any]]] = None

class AuditRiskAssessmentResponse(BaseModel):
    overall_risk_score: float
    risk_category: str
    risk_factors: List[Dict[str, Any]]
    prevention_recommendations: List[str]
    monitoring_required: bool

class VoiceProcessingRequest(BaseModel):
    audio_file_path: str
    processing_type: str
    context: Optional[Dict[str, Any]] = None

class VoiceProcessingResponse(BaseModel):
    transcript: str
    extracted_data: Dict[str, Any]
    confidence_scores: Dict[str, float]
    action_items: List[str]

class TaxOptimizationRequest(BaseModel):
    client_id: str
    entity_structure: Dict[str, Any]
    financial_data: Dict[str, Any]
    goals: List[str]

class TaxOptimizationResponse(BaseModel):
    strategies: List[Dict[str, Any]]
    projected_savings: Dict[str, float]
    implementation_timeline: Dict[str, str]
    complexity_scores: Dict[str, float]

# ML Model Classes
class AdvancedDeductionEngine:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_columns = {}
        self.load_models()
    
    def load_models(self):
        """Load pre-trained deduction models"""
        model_types = ['business_expenses', 'home_office', 'charitable', 'medical', 'education']
        
        for model_type in model_types:
            try:
                model_path = f"/app/models/deduction_{model_type}.joblib"
                if os.path.exists(model_path):
                    self.models[model_type] = joblib.load(model_path)
                    logger.info(f"Loaded {model_type} deduction model")
                else:
                    # Create and train a basic model if not exists
                    self.models[model_type] = self._create_default_model(model_type)
                    logger.info(f"Created default {model_type} deduction model")
            except Exception as e:
                logger.error(f"Error loading {model_type} model: {e}")
                self.models[model_type] = self._create_default_model(model_type)
    
    def _create_default_model(self, model_type: str):
        """Create a default model for deduction prediction"""
        # This would be replaced with actual training data
        X_sample = np.random.rand(1000, 10)
        y_sample = np.random.rand(1000)
        
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_sample, (y_sample > 0.5).astype(int))
        
        return model
    
    def predict_deductions(self, tax_data: Dict[str, Any]) -> Dict[str, Any]:
        """Predict potential deductions using ML models"""
        start_time = datetime.now()
        predictions = {}
        confidence_scores = {}
        total_savings = 0.0
        
        for deduction_type, model in self.models.items():
            try:
                # Extract features for this deduction type
                features = self._extract_features(tax_data, deduction_type)
                
                if features is not None:
                    # Make prediction
                    prediction = model.predict_proba([features])[0]
                    confidence = max(prediction)
                    
                    if confidence > 0.7:  # High confidence threshold
                        estimated_amount = self._estimate_deduction_amount(
                            tax_data, deduction_type, confidence
                        )
                        
                        predictions[deduction_type] = {
                            'eligible': True,
                            'estimated_amount': estimated_amount,
                            'confidence': confidence,
                            'supporting_documents': self._get_required_docs(deduction_type),
                            'tax_code_references': self._get_tax_codes(deduction_type)
                        }
                        
                        total_savings += estimated_amount * 0.22  # Assume 22% tax rate
                        confidence_scores[deduction_type] = confidence
                    else:
                        predictions[deduction_type] = {
                            'eligible': False,
                            'confidence': confidence,
                            'reason': 'Low confidence in eligibility'
                        }
                        confidence_scores[deduction_type] = confidence
                        
            except Exception as e:
                logger.error(f"Error predicting {deduction_type}: {e}")
                predictions[deduction_type] = {
                    'eligible': False,
                    'error': str(e)
                }
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        return {
            'predictions': predictions,
            'confidence_scores': confidence_scores,
            'total_potential_savings': total_savings,
            'processing_time': processing_time
        }
    
    def _extract_features(self, tax_data: Dict[str, Any], deduction_type: str) -> Optional[List[float]]:
        """Extract features for specific deduction type"""
        try:
            # This would be customized for each deduction type
            features = []
            
            # Common features
            features.extend([
                tax_data.get('income', 0),
                tax_data.get('filing_status_code', 1),
                tax_data.get('dependents', 0),
                tax_data.get('age', 35),
                tax_data.get('state_code', 0)
            ])
            
            # Deduction-specific features
            if deduction_type == 'business_expenses':
                features.extend([
                    tax_data.get('business_income', 0),
                    tax_data.get('self_employed', 0),
                    len(tax_data.get('business_documents', [])),
                    tax_data.get('home_office_sqft', 0),
                    tax_data.get('business_miles', 0)
                ])
            elif deduction_type == 'charitable':
                features.extend([
                    tax_data.get('charitable_cash', 0),
                    tax_data.get('charitable_noncash', 0),
                    len(tax_data.get('charity_receipts', [])),
                    tax_data.get('itemizes', 0),
                    tax_data.get('volunteer_miles', 0)
                ])
            # Add more deduction-specific feature extraction
            
            return features[:10]  # Ensure consistent feature count
            
        except Exception as e:
            logger.error(f"Error extracting features for {deduction_type}: {e}")
            return None
    
    def _estimate_deduction_amount(self, tax_data: Dict[str, Any], 
                                 deduction_type: str, confidence: float) -> float:
        """Estimate the deduction amount based on tax data and confidence"""
        base_amounts = {
            'business_expenses': tax_data.get('business_income', 0) * 0.15,
            'home_office': min(tax_data.get('home_office_sqft', 0) * 5, 1500),
            'charitable': tax_data.get('charitable_cash', 0) + tax_data.get('charitable_noncash', 0),
            'medical': max(0, tax_data.get('medical_expenses', 0) - (tax_data.get('income', 0) * 0.075)),
            'education': min(tax_data.get('education_expenses', 0), 4000)
        }
        
        base_amount = base_amounts.get(deduction_type, 0)
        return base_amount * confidence
    
    def _get_required_docs(self, deduction_type: str) -> List[str]:
        """Get required supporting documents for deduction type"""
        doc_requirements = {
            'business_expenses': ['receipts', 'invoices', 'bank_statements', 'mileage_log'],
            'home_office': ['home_office_measurement', 'utility_bills', 'mortgage_interest'],
            'charitable': ['donation_receipts', 'acknowledgment_letters', 'appraisal_reports'],
            'medical': ['medical_bills', 'insurance_statements', 'prescription_receipts'],
            'education': ['tuition_statements', '1098-T', 'education_receipts']
        }
        return doc_requirements.get(deduction_type, [])
    
    def _get_tax_codes(self, deduction_type: str) -> List[str]:
        """Get relevant tax code references"""
        tax_codes = {
            'business_expenses': ['IRC Section 162', 'IRC Section 280A'],
            'home_office': ['IRC Section 280A(c)(1)', 'Publication 587'],
            'charitable': ['IRC Section 170', 'Publication 526'],
            'medical': ['IRC Section 213', 'Publication 502'],
            'education': ['IRC Section 25A', 'Publication 970']
        }
        return tax_codes.get(deduction_type, [])

class AuditRiskPredictor:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.risk_factors = {}
        self.load_model()
    
    def load_model(self):
        """Load audit risk prediction model"""
        try:
            model_path = "/app/models/audit_risk_model.joblib"
            if os.path.exists(model_path):
                self.model = joblib.load(model_path)
                logger.info("Loaded audit risk model")
            else:
                self.model = self._create_default_audit_model()
                logger.info("Created default audit risk model")
        except Exception as e:
            logger.error(f"Error loading audit risk model: {e}")
            self.model = self._create_default_audit_model()
    
    def _create_default_audit_model(self):
        """Create default audit risk model"""
        # Sample training data - would be replaced with real audit data
        X_sample = np.random.rand(5000, 15)
        y_sample = np.random.rand(5000)
        
        model = GradientBoostingRegressor(n_estimators=100, random_state=42)
        model.fit(X_sample, y_sample)
        
        return model
    
    def assess_audit_risk(self, return_data: Dict[str, Any], 
                         client_profile: Dict[str, Any]) -> Dict[str, Any]:
        """Assess audit risk for a tax return"""
        try:
            # Extract risk features
            features = self._extract_risk_features(return_data, client_profile)
            
            # Predict risk score
            risk_score = self.model.predict([features])[0]
            risk_score = max(0.0, min(1.0, risk_score))  # Clamp to [0,1]
            
            # Categorize risk
            risk_category = self._categorize_risk(risk_score)
            
            # Identify specific risk factors
            risk_factors = self._identify_risk_factors(return_data, client_profile, features)
            
            # Generate prevention recommendations
            recommendations = self._generate_recommendations(risk_factors, risk_score)
            
            # Determine if monitoring is required
            monitoring_required = risk_score > 0.6 or any(
                factor['severity'] == 'high' for factor in risk_factors
            )
            
            return {
                'overall_risk_score': risk_score,
                'risk_category': risk_category,
                'risk_factors': risk_factors,
                'prevention_recommendations': recommendations,
                'monitoring_required': monitoring_required
            }
            
        except Exception as e:
            logger.error(f"Error assessing audit risk: {e}")
            return {
                'overall_risk_score': 0.5,
                'risk_category': 'medium',
                'risk_factors': [{'factor': 'assessment_error', 'severity': 'medium'}],
                'prevention_recommendations': ['Manual review recommended'],
                'monitoring_required': True
            }
    
    def _extract_risk_features(self, return_data: Dict[str, Any], 
                              client_profile: Dict[str, Any]) -> List[float]:
        """Extract features for audit risk assessment"""
        features = []
        
        # Income-related features
        agi = return_data.get('adjusted_gross_income', 0)
        features.extend([
            agi,
            agi / 100000,  # Income level indicator
            return_data.get('business_income', 0) / max(agi, 1),
            return_data.get('investment_income', 0) / max(agi, 1),
            return_data.get('rental_income', 0) / max(agi, 1)
        ])
        
        # Deduction-related features
        total_deductions = return_data.get('total_deductions', 0)
        standard_deduction = return_data.get('standard_deduction', 12950)
        features.extend([
            total_deductions / max(agi, 1),
            1 if total_deductions > standard_deduction else 0,
            return_data.get('charitable_deductions', 0) / max(agi, 1),
            return_data.get('business_expenses', 0) / max(return_data.get('business_income', 1), 1),
            return_data.get('home_office_deduction', 0)
        ])
        
        # Client profile features
        features.extend([
            client_profile.get('previous_audits', 0),
            client_profile.get('years_as_client', 0),
            1 if client_profile.get('self_employed', False) else 0,
            1 if client_profile.get('cash_business', False) else 0,
            client_profile.get('complexity_score', 1)
        ])
        
        return features
    
    def _categorize_risk(self, risk_score: float) -> str:
        """Categorize risk score into risk levels"""
        if risk_score < 0.3:
            return 'low'
        elif risk_score < 0.6:
            return 'medium'
        elif risk_score < 0.8:
            return 'high'
        else:
            return 'critical'
    
    def _identify_risk_factors(self, return_data: Dict[str, Any], 
                              client_profile: Dict[str, Any], 
                              features: List[float]) -> List[Dict[str, Any]]:
        """Identify specific risk factors"""
        risk_factors = []
        
        agi = return_data.get('adjusted_gross_income', 0)
        
        # High income risk
        if agi > 200000:
            risk_factors.append({
                'factor': 'high_income',
                'description': 'High income increases audit probability',
                'severity': 'medium',
                'value': agi
            })
        
        # Disproportionate deductions
        total_deductions = return_data.get('total_deductions', 0)
        if total_deductions > agi * 0.5:
            risk_factors.append({
                'factor': 'high_deductions',
                'description': 'Deductions are high relative to income',
                'severity': 'high',
                'value': total_deductions / agi
            })
        
        # Business income without corresponding expenses
        business_income = return_data.get('business_income', 0)
        business_expenses = return_data.get('business_expenses', 0)
        if business_income > 50000 and business_expenses < business_income * 0.1:
            risk_factors.append({
                'factor': 'low_business_expenses',
                'description': 'Business expenses seem low for reported income',
                'severity': 'medium',
                'value': business_expenses / business_income
            })
        
        # Cash business
        if client_profile.get('cash_business', False):
            risk_factors.append({
                'factor': 'cash_business',
                'description': 'Cash-intensive businesses have higher audit risk',
                'severity': 'high',
                'value': 1
            })
        
        # Previous audit history
        if client_profile.get('previous_audits', 0) > 0:
            risk_factors.append({
                'factor': 'audit_history',
                'description': 'Previous audit history increases risk',
                'severity': 'medium',
                'value': client_profile.get('previous_audits', 0)
            })
        
        return risk_factors
    
    def _generate_recommendations(self, risk_factors: List[Dict[str, Any]], 
                                 risk_score: float) -> List[str]:
        """Generate prevention recommendations based on risk factors"""
        recommendations = []
        
        for factor in risk_factors:
            if factor['factor'] == 'high_deductions':
                recommendations.append(
                    "Ensure all deductions are properly documented with receipts and records"
                )
                recommendations.append(
                    "Consider spreading large deductions across multiple years if possible"
                )
            elif factor['factor'] == 'cash_business':
                recommendations.append(
                    "Maintain detailed daily cash receipts and deposit records"
                )
                recommendations.append(
                    "Implement point-of-sale system for better transaction tracking"
                )
            elif factor['factor'] == 'low_business_expenses':
                recommendations.append(
                    "Review business expense categories for missed deductions"
                )
                recommendations.append(
                    "Ensure proper business/personal expense separation"
                )
        
        # General high-risk recommendations
        if risk_score > 0.7:
            recommendations.extend([
                "Consider professional tax preparation review",
                "Maintain organized records for at least 7 years",
                "Document business purpose for all deductions",
                "Consider audit insurance coverage"
            ])
        
        return list(set(recommendations))  # Remove duplicates

class VoiceProcessor:
    def __init__(self):
        self.whisper_model = whisper_model
        self.nlp = nlp
        self.sentiment_analyzer = sentiment_analyzer
    
    async def process_voice(self, audio_file_path: str, 
                           processing_type: str, 
                           context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Process voice audio for tax-related information"""
        try:
            if not self.whisper_model:
                raise HTTPException(status_code=500, detail="Voice processing not available")
            
            # Transcribe audio
            result = self.whisper_model.transcribe(audio_file_path)
            transcript = result["text"]
            
            # Extract structured data based on processing type
            extracted_data = await self._extract_structured_data(
                transcript, processing_type, context
            )
            
            # Calculate confidence scores
            confidence_scores = self._calculate_confidence_scores(result, extracted_data)
            
            # Generate action items
            action_items = self._generate_action_items(extracted_data, processing_type)
            
            return {
                'transcript': transcript,
                'extracted_data': extracted_data,
                'confidence_scores': confidence_scores,
                'action_items': action_items
            }
            
        except Exception as e:
            logger.error(f"Error processing voice: {e}")
            raise HTTPException(status_code=500, detail=f"Voice processing failed: {e}")
    
    async def _extract_structured_data(self, transcript: str, 
                                     processing_type: str, 
                                     context: Dict[str, Any]) -> Dict[str, Any]:
        """Extract structured data from transcript"""
        extracted_data = {}
        
        if processing_type == 'document_dictation':
            extracted_data = self._extract_document_data(transcript)
        elif processing_type == 'client_interview':
            extracted_data = self._extract_interview_data(transcript)
        elif processing_type == 'tax_consultation':
            extracted_data = self._extract_consultation_data(transcript)
        
        return extracted_data
    
    def _extract_document_data(self, transcript: str) -> Dict[str, Any]:
        """Extract tax document data from dictation"""
        data = {
            'document_type': None,
            'amounts': [],
            'dates': [],
            'entities': [],
            'tax_items': []
        }
        
        if self.nlp:
            doc = self.nlp(transcript)
            
            # Extract monetary amounts
            for token in doc:
                if token.like_num and any(char in token.text for char in ['$', ',', '.']):
                    try:
                        amount = float(token.text.replace('$', '').replace(',', ''))
                        data['amounts'].append(amount)
                    except:
                        pass
            
            # Extract dates
            for ent in doc.ents:
                if ent.label_ == "DATE":
                    data['dates'].append(ent.text)
                elif ent.label_ in ["ORG", "PERSON"]:
                    data['entities'].append({
                        'text': ent.text,
                        'type': ent.label_
                    })
        
        # Extract tax-specific terms
        tax_terms = [
            'w-2', '1099', 'deduction', 'income', 'expense', 'receipt',
            'charitable', 'medical', 'business', 'mileage', 'depreciation'
        ]
        
        for term in tax_terms:
            if term.lower() in transcript.lower():
                data['tax_items'].append(term)
        
        return data
    
    def _extract_interview_data(self, transcript: str) -> Dict[str, Any]:
        """Extract client interview data"""
        data = {
            'client_info': {},
            'tax_situation': {},
            'questions': [],
            'concerns': [],
            'action_items': []
        }
        
        # Use sentiment analysis to identify concerns
        if self.sentiment_analyzer:
            sentences = transcript.split('.')
            for sentence in sentences:
                sentiment = self.sentiment_analyzer.polarity_scores(sentence)
                if sentiment['compound'] < -0.3:  # Negative sentiment
                    data['concerns'].append(sentence.strip())
        
        # Extract questions (sentences ending with ?)
        questions = [s.strip() for s in transcript.split('?') if s.strip()]
        data['questions'] = questions
        
        return data
    
    def _extract_consultation_data(self, transcript: str) -> Dict[str, Any]:
        """Extract tax consultation data"""
        data = {
            'topics_discussed': [],
            'recommendations': [],
            'follow_up_items': [],
            'tax_strategies': []
        }
        
        # Identify tax topics
        tax_topics = [
            'retirement planning', 'tax planning', 'deductions', 'credits',
            'business structure', 'investment', 'estate planning', 'audit'
        ]
        
        for topic in tax_topics:
            if topic.lower() in transcript.lower():
                data['topics_discussed'].append(topic)
        
        return data
    
    def _calculate_confidence_scores(self, whisper_result: Dict[str, Any], 
                                   extracted_data: Dict[str, Any]) -> Dict[str, float]:
        """Calculate confidence scores for voice processing"""
        scores = {
            'transcription': 0.85,  # Default Whisper confidence
            'extraction': 0.0,
            'overall': 0.0
        }
        
        # Calculate extraction confidence based on data completeness
        total_fields = len(extracted_data)
        filled_fields = sum(1 for v in extracted_data.values() if v)
        
        if total_fields > 0:
            scores['extraction'] = filled_fields / total_fields
        
        scores['overall'] = (scores['transcription'] + scores['extraction']) / 2
        
        return scores
    
    def _generate_action_items(self, extracted_data: Dict[str, Any], 
                              processing_type: str) -> List[str]:
        """Generate action items based on extracted data"""
        action_items = []
        
        if processing_type == 'document_dictation':
            if extracted_data.get('amounts'):
                action_items.append("Verify monetary amounts with source documents")
            if extracted_data.get('tax_items'):
                action_items.append("Categorize tax items for proper form placement")
        
        elif processing_type == 'client_interview':
            if extracted_data.get('questions'):
                action_items.append("Follow up on client questions")
            if extracted_data.get('concerns'):
                action_items.append("Address client concerns identified")
        
        elif processing_type == 'tax_consultation':
            if extracted_data.get('topics_discussed'):
                action_items.append("Document consultation topics in client file")
            if extracted_data.get('follow_up_items'):
                action_items.append("Schedule follow-up for action items")
        
        return action_items

class TaxStrategyOptimizer:
    def __init__(self):
        self.optimization_models = {}
        self.load_optimization_models()
    
    def load_optimization_models(self):
        """Load tax optimization models"""
        try:
            # Load different optimization models for various scenarios
            model_types = ['entity_structure', 'timing_strategies', 'deduction_optimization']
            
            for model_type in model_types:
                # Create ensemble models for complex optimization
                self.optimization_models[model_type] = {
                    'xgboost': xgb.XGBRegressor(n_estimators=100, random_state=42),
                    'lightgbm': lgb.LGBMRegressor(n_estimators=100, random_state=42),
                    'random_forest': RandomForestClassifier(n_estimators=100, random_state=42)
                }
                
                # Train with sample data (would use real data in production)
                X_sample = np.random.rand(1000, 20)
                y_sample = np.random.rand(1000)
                
                for name, model in self.optimization_models[model_type].items():
                    if name != 'random_forest':
                        model.fit(X_sample, y_sample)
                    else:
                        model.fit(X_sample, (y_sample > 0.5).astype(int))
                
                logger.info(f"Loaded {model_type} optimization models")
                
        except Exception as e:
            logger.error(f"Error loading optimization models: {e}")
    
    def optimize_tax_strategy(self, client_id: str, entity_structure: Dict[str, Any],
                             financial_data: Dict[str, Any], goals: List[str]) -> Dict[str, Any]:
        """Optimize tax strategy for complex scenarios"""
        try:
            strategies = []
            projected_savings = {}
            implementation_timeline = {}
            complexity_scores = {}
            
            # Analyze current structure
            current_tax_liability = self._calculate_current_liability(financial_data)
            
            # Generate optimization strategies
            for goal in goals:
                strategy = self._generate_strategy(goal, entity_structure, financial_data)
                if strategy:
                    strategies.append(strategy)
                    
                    # Calculate projected savings
                    savings = self._calculate_projected_savings(strategy, current_tax_liability)
                    projected_savings[strategy['name']] = savings
                    
                    # Estimate implementation timeline
                    timeline = self._estimate_implementation_timeline(strategy)
                    implementation_timeline[strategy['name']] = timeline
                    
                    # Calculate complexity score
                    complexity = self._calculate_complexity_score(strategy)
                    complexity_scores[strategy['name']] = complexity
            
            return {
                'strategies': strategies,
                'projected_savings': projected_savings,
                'implementation_timeline': implementation_timeline,
                'complexity_scores': complexity_scores
            }
            
        except Exception as e:
            logger.error(f"Error optimizing tax strategy: {e}")
            return {
                'strategies': [],
                'projected_savings': {},
                'implementation_timeline': {},
                'complexity_scores': {}
            }
    
    def _calculate_current_liability(self, financial_data: Dict[str, Any]) -> float:
        """Calculate current tax liability"""
        income = financial_data.get('total_income', 0)
        deductions = financial_data.get('total_deductions', 0)
        taxable_income = max(0, income - deductions)
        
        # Simplified tax calculation (would use actual tax tables)
        if taxable_income <= 10275:
            return taxable_income * 0.10
        elif taxable_income <= 41775:
            return 1027.50 + (taxable_income - 10275) * 0.12
        elif taxable_income <= 89450:
            return 4807.50 + (taxable_income - 41775) * 0.22
        else:
            return 15213.50 + (taxable_income - 89450) * 0.24
    
    def _generate_strategy(self, goal: str, entity_structure: Dict[str, Any],
                          financial_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Generate specific optimization strategy"""
        strategies = {
            'minimize_current_tax': self._strategy_minimize_current_tax,
            'maximize_deductions': self._strategy_maximize_deductions,
            'optimize_entity_structure': self._strategy_optimize_entity_structure,
            'timing_optimization': self._strategy_timing_optimization,
            'retirement_planning': self._strategy_retirement_planning
        }
        
        strategy_func = strategies.get(goal)
        if strategy_func:
            return strategy_func(entity_structure, financial_data)
        
        return None
    
    def _strategy_minimize_current_tax(self, entity_structure: Dict[str, Any],
                                     financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Strategy to minimize current year tax liability"""
        return {
            'name': 'Current Year Tax Minimization',
            'description': 'Strategies to reduce current year tax liability',
            'actions': [
                'Maximize retirement contributions',
                'Accelerate business expenses',
                'Consider equipment purchases for Section 179 deduction',
                'Harvest investment losses',
                'Defer income to next year if possible'
            ],
            'requirements': [
                'Cash flow analysis',
                'Investment portfolio review',
                'Business expense documentation'
            ],
            'estimated_savings': financial_data.get('total_income', 0) * 0.05,
            'implementation_difficulty': 'medium'
        }
    
    def _strategy_maximize_deductions(self, entity_structure: Dict[str, Any],
                                    financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Strategy to maximize available deductions"""
        return {
            'name': 'Deduction Maximization',
            'description': 'Identify and maximize all available deductions',
            'actions': [
                'Implement home office deduction',
                'Track business mileage',
                'Maximize charitable contributions',
                'Consider medical expense bunching',
                'Optimize business structure for deductions'
            ],
            'requirements': [
                'Detailed expense tracking',
                'Home office measurement',
                'Charitable contribution documentation'
            ],
            'estimated_savings': financial_data.get('total_income', 0) * 0.03,
            'implementation_difficulty': 'low'
        }
    
    def _strategy_optimize_entity_structure(self, entity_structure: Dict[str, Any],
                                          financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Strategy to optimize business entity structure"""
        current_structure = entity_structure.get('type', 'sole_proprietorship')
        
        recommendations = []
        if current_structure == 'sole_proprietorship' and financial_data.get('business_income', 0) > 50000:
            recommendations.append('Consider S-Corp election for self-employment tax savings')
        
        if financial_data.get('business_income', 0) > 200000:
            recommendations.append('Evaluate multi-entity structure for tax optimization')
        
        return {
            'name': 'Entity Structure Optimization',
            'description': 'Optimize business entity structure for tax efficiency',
            'actions': recommendations,
            'requirements': [
                'Legal entity formation',
                'Payroll setup for S-Corp',
                'Updated accounting systems'
            ],
            'estimated_savings': financial_data.get('business_income', 0) * 0.08,
            'implementation_difficulty': 'high'
        }
    
    def _strategy_timing_optimization(self, entity_structure: Dict[str, Any],
                                    financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Strategy for income and expense timing optimization"""
        return {
            'name': 'Income and Expense Timing',
            'description': 'Optimize timing of income and expenses across tax years',
            'actions': [
                'Defer year-end bonuses to next year',
                'Accelerate equipment purchases',
                'Time investment sales for optimal tax treatment',
                'Consider installment sales for large gains',
                'Bunch deductible expenses in alternating years'
            ],
            'requirements': [
                'Cash flow planning',
                'Investment timing analysis',
                'Coordination with business operations'
            ],
            'estimated_savings': financial_data.get('total_income', 0) * 0.04,
            'implementation_difficulty': 'medium'
        }
    
    def _strategy_retirement_planning(self, entity_structure: Dict[str, Any],
                                    financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Strategy for retirement planning tax optimization"""
        return {
            'name': 'Retirement Planning Optimization',
            'description': 'Maximize retirement savings for current and future tax benefits',
            'actions': [
                'Maximize 401(k) contributions',
                'Consider Roth IRA conversions',
                'Implement SEP-IRA or Solo 401(k) for business',
                'Evaluate defined benefit plans for high earners',
                'Plan for required minimum distributions'
            ],
            'requirements': [
                'Retirement plan setup',
                'Investment management',
                'Long-term financial planning'
            ],
            'estimated_savings': min(financial_data.get('total_income', 0) * 0.06, 25000),
            'implementation_difficulty': 'medium'
        }
    
    def _calculate_projected_savings(self, strategy: Dict[str, Any], 
                                   current_liability: float) -> float:
        """Calculate projected tax savings from strategy"""
        base_savings = strategy.get('estimated_savings', 0)
        
        # Apply confidence factor based on implementation difficulty
        difficulty = strategy.get('implementation_difficulty', 'medium')
        confidence_factors = {'low': 0.9, 'medium': 0.75, 'high': 0.6}
        confidence = confidence_factors.get(difficulty, 0.75)
        
        return base_savings * confidence
    
    def _estimate_implementation_timeline(self, strategy: Dict[str, Any]) -> str:
        """Estimate implementation timeline for strategy"""
        difficulty = strategy.get('implementation_difficulty', 'medium')
        
        timelines = {
            'low': '1-2 months',
            'medium': '3-6 months', 
            'high': '6-12 months'
        }
        
        return timelines.get(difficulty, '3-6 months')
    
    def _calculate_complexity_score(self, strategy: Dict[str, Any]) -> float:
        """Calculate complexity score for strategy implementation"""
        difficulty = strategy.get('implementation_difficulty', 'medium')
        num_actions = len(strategy.get('actions', []))
        num_requirements = len(strategy.get('requirements', []))
        
        base_scores = {'low': 0.3, 'medium': 0.6, 'high': 0.9}
        base_score = base_scores.get(difficulty, 0.6)
        
        # Adjust based on number of actions and requirements
        complexity_adjustment = (num_actions + num_requirements) * 0.05
        
        return min(1.0, base_score + complexity_adjustment)

# Initialize ML engines
deduction_engine = AdvancedDeductionEngine()
audit_risk_predictor = AuditRiskPredictor()
voice_processor = VoiceProcessor()
tax_optimizer = TaxStrategyOptimizer()

# API Endpoints
@app.post("/predict-deductions", response_model=DeductionPredictionResponse)
async def predict_deductions(request: DeductionPredictionRequest):
    """Predict potential tax deductions using advanced ML models"""
    try:
        # Combine client data and document data
        tax_data = {**request.client_data}
        
        # Add document-derived features
        for doc in request.document_data:
            doc_type = doc.get('type', 'unknown')
            if doc_type == 'w2':
                tax_data['w2_income'] = doc.get('wages', 0)
            elif doc_type == '1099':
                tax_data['1099_income'] = tax_data.get('1099_income', 0) + doc.get('income', 0)
            elif doc_type == 'receipt':
                category = doc.get('category', 'other')
                tax_data[f'{category}_expenses'] = tax_data.get(f'{category}_expenses', 0) + doc.get('amount', 0)
        
        # Add historical data if available
        if request.historical_data:
            tax_data.update(request.historical_data)
        
        result = deduction_engine.predict_deductions(tax_data)
        
        return DeductionPredictionResponse(**result)
        
    except Exception as e:
        logger.error(f"Error in predict_deductions: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/assess-audit-risk", response_model=AuditRiskAssessmentResponse)
async def assess_audit_risk(request: AuditRiskAssessmentRequest):
    """Assess audit risk using machine learning models"""
    try:
        result = audit_risk_predictor.assess_audit_risk(
            request.return_data, 
            request.client_profile
        )
        
        return AuditRiskAssessmentResponse(**result)
        
    except Exception as e:
        logger.error(f"Error in assess_audit_risk: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process-voice", response_model=VoiceProcessingResponse)
async def process_voice(request: VoiceProcessingRequest):
    """Process voice audio for tax information extraction"""
    try:
        result = await voice_processor.process_voice(
            request.audio_file_path,
            request.processing_type,
            request.context
        )
        
        return VoiceProcessingResponse(**result)
        
    except Exception as e:
        logger.error(f"Error in process_voice: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/upload-voice", response_model=dict)
async def upload_voice_file(file: UploadFile = File(...)):
    """Upload voice file for processing"""
    try:
        # Save uploaded file
        upload_dir = "/tmp/voice_uploads"
        os.makedirs(upload_dir, exist_ok=True)
        
        file_path = os.path.join(upload_dir, f"{datetime.now().isoformat()}_{file.filename}")
        
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        return {
            "file_path": file_path,
            "filename": file.filename,
            "size": len(content),
            "status": "uploaded"
        }
        
    except Exception as e:
        logger.error(f"Error uploading voice file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/optimize-tax-strategy", response_model=TaxOptimizationResponse)
async def optimize_tax_strategy(request: TaxOptimizationRequest):
    """Optimize tax strategy for complex multi-entity scenarios"""
    try:
        result = tax_optimizer.optimize_tax_strategy(
            request.client_id,
            request.entity_structure,
            request.financial_data,
            request.goals
        )
        
        return TaxOptimizationResponse(**result)
        
    except Exception as e:
        logger.error(f"Error in optimize_tax_strategy: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "services": {
            "deduction_engine": "active",
            "audit_risk_predictor": "active",
            "voice_processor": "active" if whisper_model else "unavailable",
            "tax_optimizer": "active"
        }
    }

@app.get("/models/status")
async def model_status():
    """Get status of all ML models"""
    return {
        "deduction_models": list(deduction_engine.models.keys()),
        "audit_risk_model": "loaded" if audit_risk_predictor.model else "not_loaded",
        "voice_models": {
            "whisper": "loaded" if whisper_model else "not_loaded",
            "nlp": "loaded" if nlp else "not_loaded",
            "sentiment": "loaded" if sentiment_analyzer else "not_loaded"
        },
        "optimization_models": list(tax_optimizer.optimization_models.keys())
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
