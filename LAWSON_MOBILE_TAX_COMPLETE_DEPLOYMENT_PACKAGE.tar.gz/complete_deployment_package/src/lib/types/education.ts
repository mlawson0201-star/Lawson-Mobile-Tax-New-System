
export interface LearningPath {
  id: string;
  title: string;
  description: string;
  targetPersona: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: number; // in minutes
  modules: LearningModule[];
  prerequisites: string[];
  completionRate: number;
  isPublished: boolean;
}

export interface LearningModule {
  id: string;
  title: string;
  description: string;
  type: 'video' | 'article' | 'interactive' | 'quiz' | 'calculator';
  content: string;
  videoUrl?: string;
  duration: number; // in minutes
  order: number;
  isCompleted?: boolean;
  quiz?: Quiz;
}

export interface Quiz {
  id: string;
  questions: QuizQuestion[];
  passingScore: number;
  maxAttempts: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  type: 'multiple_choice' | 'true_false' | 'fill_blank';
  options?: string[];
  correctAnswer: string | string[];
  explanation: string;
}

export interface TaxCalculator {
  id: string;
  name: string;
  description: string;
  type: 'income_tax' | 'business_deduction' | 'retirement' | 'investment' | 'self_employment';
  inputs: CalculatorInput[];
  formula: string;
  resultFields: CalculatorResult[];
  isActive: boolean;
  usageCount: number;
}

export interface CalculatorInput {
  id: string;
  label: string;
  type: 'number' | 'select' | 'boolean' | 'text';
  required: boolean;
  options?: string[];
  min?: number;
  max?: number;
  placeholder?: string;
  helpText?: string;
}

export interface CalculatorResult {
  id: string;
  label: string;
  value: number | string;
  format: 'currency' | 'percentage' | 'number' | 'text';
  description?: string;
}

export interface TaxGuidance {
  id: string;
  title: string;
  content: string;
  category: 'deductions' | 'credits' | 'planning' | 'compliance' | 'deadlines';
  targetPersonas: string[];
  priority: 'low' | 'medium' | 'high' | 'urgent';
  effectiveDate: Date;
  expirationDate?: Date;
  isPersonalized: boolean;
  tags: string[];
}

export interface VideoContent {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: number; // in seconds
  category: string;
  targetPersonas: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  viewCount: number;
  rating: number;
  transcript?: string;
  isPublished: boolean;
  createdAt: Date;
}

export interface Webinar {
  id: string;
  title: string;
  description: string;
  presenter: string;
  presenterBio: string;
  scheduledDate: Date;
  duration: number; // in minutes
  maxAttendees: number;
  registeredCount: number;
  attendedCount: number;
  category: string;
  targetPersonas: string[];
  meetingUrl: string;
  recordingUrl?: string;
  materials: string[];
  isLive: boolean;
  status: 'scheduled' | 'live' | 'completed' | 'cancelled';
}
