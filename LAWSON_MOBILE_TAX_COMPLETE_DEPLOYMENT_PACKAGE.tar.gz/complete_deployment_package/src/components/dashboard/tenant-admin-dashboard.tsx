
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { 
  Users, 
  FileText, 
  DollarSign, 
  TrendingUp, 
  UserCheck,
  CreditCard,
  Calendar,
  BarChart3
} from 'lucide-react';
import { MetricCard } from '@/components/ui/metric-card';
import { RecentActivity } from '@/components/ui/recent-activity';
import { formatCurrency } from '@/lib/utils';

export function TenantAdminDashboard() {
  const { data: session } = useSession() || {};
  const [metrics, setMetrics] = useState({
    totalClients: 0,
    activeReturns: 0,
    monthlyRevenue: 0,
    completedReturns: 0,
    growthRate: 0
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading tenant admin data
    const timer = setTimeout(() => {
      setMetrics({
        totalClients: 247,
        activeReturns: 89,
        monthlyRevenue: 47382,
        completedReturns: 158,
        growthRate: 18.5
      });
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const recentActivities = [
    {
      id: '1',
      type: 'client_registered',
      description: 'New client Sarah Johnson registered',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      severity: 'info' as const
    },
    {
      id: '2',
      type: 'return_completed',
      description: 'Tax return completed for Michael Davis (2024)',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      severity: 'success' as const
    },
    {
      id: '3',
      type: 'payment_received',
      description: 'Payment of $199 received from client',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      severity: 'success' as const
    },
    {
      id: '4',
      type: 'preparer_assigned',
      description: 'EA Mike Johnson assigned to complex return',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
      severity: 'info' as const
    }
  ];

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="h-8 bg-gray-200 rounded w-64 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-96 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="h-6 bg-gray-200 rounded w-32 mb-4 animate-pulse"></div>
              <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Tenant Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Manage your tax preparation business and monitor performance
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Clients"
          value={metrics.totalClients}
          icon={Users}
          trend={{ value: 12.3, isPositive: true }}
          description="Active clients this season"
        />
        <MetricCard
          title="Active Returns"
          value={metrics.activeReturns}
          icon={FileText}
          trend={{ value: 8.7, isPositive: true }}
          description="Returns in progress"
        />
        <MetricCard
          title="Monthly Revenue"
          value={formatCurrency(metrics.monthlyRevenue)}
          icon={DollarSign}
          trend={{ value: metrics.growthRate, isPositive: true }}
          description="Revenue this month"
        />
        <MetricCard
          title="Completed Returns"
          value={metrics.completedReturns}
          icon={UserCheck}
          trend={{ value: 15.2, isPositive: true }}
          description="Returns filed successfully"
        />
      </div>

      {/* Tax Season Progress */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg p-6 mb-8">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              2024 Tax Season Progress
            </h2>
            <p className="text-gray-600 mb-4">
              Your firm has processed {metrics.completedReturns + metrics.activeReturns} returns so far this season.
            </p>
            <div className="w-full bg-white rounded-full h-3 mb-4">
              <div 
                className="bg-blue-600 h-3 rounded-full transition-all duration-300" 
                style={{ width: `${((metrics.completedReturns) / (metrics.completedReturns + metrics.activeReturns)) * 100}%` }}
              ></div>
            </div>
            <div className="text-sm text-gray-600">
              {metrics.completedReturns} completed, {metrics.activeReturns} in progress
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">
              {Math.round((metrics.completedReturns / (metrics.completedReturns + metrics.activeReturns)) * 100)}%
            </div>
            <div className="text-sm text-gray-500">Complete</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
          </div>
          <RecentActivity activities={recentActivities} />
        </div>

        {/* Revenue Insights */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <BarChart3 className="h-5 w-5 text-gray-400 mr-2" />
              <h2 className="text-lg font-semibold text-gray-900">Revenue Insights</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-700">Average Return Value</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(189)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-green-600 font-medium">+12.3%</p>
                  <p className="text-xs text-gray-500">vs last month</p>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-700">Platform Revenue Share</p>
                  <p className="text-xl font-bold text-gray-900">{formatCurrency(14214)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">30% of gross</p>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-700">Net Revenue</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(33168)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-green-600 font-medium">+18.5%</p>
                  <p className="text-xs text-gray-500">vs last month</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <button className="flex items-center justify-center px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
              <Users className="h-5 w-5 mr-2" />
              Add Client
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors">
              <FileText className="h-5 w-5 mr-2" />
              New Return
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors">
              <TrendingUp className="h-5 w-5 mr-2" />
              View Reports
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100 transition-colors">
              <Calendar className="h-5 w-5 mr-2" />
              Schedule Review
            </button>
          </div>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Performance Summary</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">95.2%</div>
              <div className="text-sm text-gray-600 mt-1">Client Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">2.3 days</div>
              <div className="text-sm text-gray-600 mt-1">Avg. Turnaround Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">98.7%</div>
              <div className="text-sm text-gray-600 mt-1">E-file Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
