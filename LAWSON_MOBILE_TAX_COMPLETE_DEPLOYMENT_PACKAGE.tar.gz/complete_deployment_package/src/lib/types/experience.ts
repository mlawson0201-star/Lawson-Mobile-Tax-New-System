
export interface ClientProfile {
  id: string;
  userId: string;
  persona: ClientPersona;
  financialGoals: string[];
  riskTolerance: 'conservative' | 'moderate' | 'aggressive';
  lifeStage: 'student' | 'young_professional' | 'family' | 'pre_retirement' | 'retired';
  taxComplexity: 'simple' | 'moderate' | 'complex';
  preferredCommunication: 'email' | 'sms' | 'phone' | 'app';
  communicationFrequency: 'weekly' | 'monthly' | 'quarterly' | 'as_needed';
  timezone: string;
  lastUpdated: Date;
  completionScore: number; // 0-100
}

export interface ClientPortal {
  id: string;
  clientId: string;
  theme: 'light' | 'dark' | 'auto';
  layout: 'dashboard' | 'timeline' | 'cards';
  widgets: PortalWidget[];
  notifications: ClientNotification[];
  documents: ClientDocument[];
  tasks: ClientTask[];
  lastLogin: Date;
  customizations: Record<string, any>;
}

export interface PortalWidget {
  id: string;
  type: 'tax_summary' | 'deadlines' | 'documents' | 'progress' | 'recommendations' | 'calculator';
  title: string;
  position: { x: number; y: number };
  size: { width: number; height: number };
  isVisible: boolean;
  config: Record<string, any>;
}

export interface ClientNotification {
  id: string;
  clientId: string;
  type: 'deadline' | 'document_request' | 'tax_tip' | 'promotion' | 'system';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isRead: boolean;
  actionUrl?: string;
  scheduledDate?: Date;
  expirationDate?: Date;
  createdAt: Date;
}

export interface ClientDocument {
  id: string;
  clientId: string;
  name: string;
  type: 'w2' | '1099' | 'receipt' | 'tax_return' | 'other';
  fileUrl: string;
  uploadDate: Date;
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  extractedData?: Record<string, any>;
  tags: string[];
}

export interface ClientTask {
  id: string;
  clientId: string;
  title: string;
  description: string;
  type: 'document_upload' | 'form_completion' | 'review' | 'payment' | 'other';
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  dueDate?: Date;
  completedDate?: Date;
  assignedTo?: string;
  dependencies: string[];
}

export interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  type: 'welcome' | 'profile' | 'documents' | 'preferences' | 'verification' | 'completion';
  order: number;
  isRequired: boolean;
  estimatedTime: number; // in minutes
  completionRate: number;
  dropoffRate: number;
  component: string;
}

export interface ClientSuccessScore {
  clientId: string;
  overallScore: number; // 0-100
  categories: {
    engagement: number;
    satisfaction: number;
    completion: number;
    retention: number;
  };
  factors: {
    loginFrequency: number;
    taskCompletion: number;
    supportTickets: number;
    referrals: number;
    renewalProbability: number;
  };
  lastCalculated: Date;
  trend: 'improving' | 'stable' | 'declining';
  riskLevel: 'low' | 'medium' | 'high';
}
