
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create default tenant (Lawson Mobile Tax)
  const defaultTenant = await prisma.tenant.upsert({
    where: { domain: 'lawsonmobiletax.com' },
    update: {},
    create: {
      name: 'Lawson Mobile Tax',
      domain: 'lawsonmobiletax.com',
      legalName: 'Lawson Mobile Tax LLC',
      ein: '12-3456789',
      brandingConfig: {
        primaryColor: '#2563eb',
        secondaryColor: '#1e40af',
        logo: '/images/lawson-logo.png',
        favicon: '/images/favicon.ico'
      },
      settings: {
        features: {
          bankProducts: true,
          whiteLabel: true,
          aiProcessing: true
        },
        pricing: {
          basic: 199.99,
          complex: 649.99,
          business: 999.99,
          bankProductFee: 29.99
        }
      },
      subscriptionTier: 'enterprise',
      revenueShareRate: 0.00, // Platform takes 0% for default tenant
      active: true
    }
  });

  console.log('✅ Created default tenant:', defaultTenant.name);

  // Create test reseller tenant (Formality Tax)
  const resellerTenant = await prisma.tenant.upsert({
    where: { domain: 'formalitytax.com' },
    update: {},
    create: {
      name: 'Formality Tax',
      domain: 'formalitytax.com',
      legalName: 'Formality Tax Services Inc',
      ein: '98-7654321',
      brandingConfig: {
        primaryColor: '#059669',
        secondaryColor: '#047857',
        logo: '/images/formality-logo.png',
        favicon: '/images/formality-favicon.ico'
      },
      settings: {
        features: {
          bankProducts: true,
          whiteLabel: false,
          aiProcessing: true
        },
        pricing: {
          basic: 249.99,
          complex: 799.99,
          business: 1199.99,
          bankProductFee: 39.99
        }
      },
      subscriptionTier: 'professional',
      revenueShareRate: 0.30, // Platform takes 30%
      active: true
    }
  });

  console.log('✅ Created reseller tenant:', resellerTenant.name);

  // Create system roles
  const systemRoles = [
    {
      name: 'super_admin',
      description: 'Super Administrator with full system access',
      permissions: [{ resource: '*', action: '*' }],
      systemRole: true
    },
    {
      name: 'tenant_admin',
      description: 'Tenant Administrator with full tenant access',
      permissions: [
        { resource: 'user', action: '*', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] },
        { resource: 'client', action: '*', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] },
        { resource: 'tax_return', action: '*', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] }
      ],
      systemRole: true
    },
    {
      name: 'ea_cpa',
      description: 'Enrolled Agent / CPA with review authority',
      permissions: [
        { resource: 'client', action: 'read', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] },
        { resource: 'tax_return', action: '*', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] },
        { resource: 'efile', action: 'submit' }
      ],
      systemRole: true
    },
    {
      name: 'preparer',
      description: 'Tax preparer with limited access',
      permissions: [
        { resource: 'tax_return', action: 'read', conditions: [{ field: 'assignedPreparerId', operator: 'eq', value: '${user.id}' }] },
        { resource: 'document', action: 'read', conditions: [{ field: 'tenantId', operator: 'eq', value: '${user.tenantId}' }] }
      ],
      systemRole: true
    },
    {
      name: 'client',
      description: 'Client with access to own data',
      permissions: [
        { resource: 'tax_return', action: 'read', conditions: [{ field: 'clientId', operator: 'eq', value: '${user.clientId}' }] },
        { resource: 'document', action: '*', conditions: [{ field: 'clientId', operator: 'eq', value: '${user.clientId}' }] },
        { resource: 'payment', action: 'create', conditions: [{ field: 'clientId', operator: 'eq', value: '${user.clientId}' }] }
      ],
      systemRole: true
    }
  ];

  for (const roleData of systemRoles) {
    const role = await prisma.role.upsert({
      where: { 
        name: roleData.name // Using name as unique identifier
      },
      update: {},
      create: {
        name: roleData.name,
        description: roleData.description,
        permissions: roleData.permissions,
        systemRole: roleData.systemRole
      }
    });
    console.log('✅ Created system role:', role.name);
  }

  // Hash password for test users
  const hashedPassword = await bcrypt.hash('johndoe123', 12);

  // Create test super admin user
  const superAdminUser = await prisma.user.upsert({
    where: { cognitoUserId: 'test-super-admin-john-doe' },
    update: {},
    create: {
      tenantId: defaultTenant.id,
      cognitoUserId: 'test-super-admin-john-doe',
      email: 'john@doe.com',
      phone: '+1234567890',
      firstName: 'John',
      lastName: 'Doe',
      role: 'super_admin',
      profileData: {
        hashedPassword, // Store for testing
        title: 'Super Administrator',
        department: 'Engineering'
      },
      preferences: {
        theme: 'light',
        emailNotifications: true,
        smsNotifications: true
      },
      active: true
    }
  });

  console.log('✅ Created super admin user:', superAdminUser.email);

  // Create test tenant admin for reseller
  const tenantAdminUser = await prisma.user.upsert({
    where: { cognitoUserId: 'test-tenant-admin-sarah-wilson' },
    update: {},
    create: {
      tenantId: resellerTenant.id,
      cognitoUserId: 'test-tenant-admin-sarah-wilson',
      email: 'sarah@formalitytax.com',
      phone: '+1987654321',
      firstName: 'Sarah',
      lastName: 'Wilson',
      role: 'tenant_admin',
      profileData: {
        hashedPassword,
        title: 'CEO & Founder',
        department: 'Management'
      },
      preferences: {
        theme: 'light',
        emailNotifications: true,
        smsNotifications: true
      },
      active: true
    }
  });

  console.log('✅ Created tenant admin user:', tenantAdminUser.email);

  // Create test EA/CPA user
  const eaCpaUser = await prisma.user.upsert({
    where: { cognitoUserId: 'test-ea-cpa-mike-johnson' },
    update: {},
    create: {
      tenantId: defaultTenant.id,
      cognitoUserId: 'test-ea-cpa-mike-johnson',
      email: 'mike@lawsonmobiletax.com',
      phone: '+1555123456',
      firstName: 'Mike',
      lastName: 'Johnson',
      role: 'ea_cpa',
      profileData: {
        hashedPassword,
        title: 'Enrolled Agent',
        department: 'Tax Preparation',
        credentials: ['EA', 'CTEC'],
        licenseNumber: 'EA123456'
      },
      preferences: {
        theme: 'light',
        emailNotifications: true,
        smsNotifications: false
      },
      active: true
    }
  });

  console.log('✅ Created EA/CPA user:', eaCpaUser.email);

  // Create test client
  const testClient = await prisma.client.upsert({
    where: { 
      tenantId_email: {
        tenantId: defaultTenant.id,
        email: 'client@example.com'
      }
    },
    update: {},
    create: {
      tenantId: defaultTenant.id,
      createdByUserId: superAdminUser.id,
      email: 'client@example.com',
      phone: '+1555987654',
      firstName: 'Jane',
      lastName: 'Smith',
      ssnEncrypted: 'encrypted_123456789', // This would be properly encrypted in production
      dateOfBirth: new Date('1985-06-15'),
      address: {
        street1: '123 Main St',
        city: 'San Francisco',
        state: 'CA',
        zipCode: '94105',
        country: 'US'
      },
      filingStatus: 'single',
      personalInfo: {
        occupation: 'Software Engineer',
        employer: 'Tech Corp'
      },
      clientStatus: 'active',
      lifetimeValue: 299.98
    }
  });

  console.log('✅ Created test client:', testClient.email);

  // Create test tax return
  const testTaxReturn = await prisma.taxReturn.create({
    data: {
      tenantId: defaultTenant.id,
      clientId: testClient.id,
      assignedPreparerId: eaCpaUser.id,
      taxYear: '2024',
      returnType: '1040',
      status: 'in_progress',
      totalFee: 199.99,
      refundAmount: 2500.00,
      formData: {
        personalInfo: {
          taxpayer: {
            firstName: 'Jane',
            lastName: 'Smith',
            ssn: '123-45-6789'
          }
        },
        income: {
          wages: 85000,
          interest: 125.50,
          dividends: 250.00
        }
      },
      calculations: {
        agi: 85375.50,
        totalTax: 12850.00,
        totalCredits: 0,
        totalPayments: 15350.00,
        refundAmount: 2500.00
      },
      aiConfidenceScore: 0.95,
      requiresHumanReview: false
    }
  });

  console.log('✅ Created test tax return for tax year:', testTaxReturn.taxYear);

  // Create subscriptions for tenants
  await prisma.subscription.upsert({
    where: { tenantId: defaultTenant.id },
    update: {},
    create: {
      tenantId: defaultTenant.id,
      planType: 'enterprise',
      status: 'active',
      monthlyFee: 0, // Free for platform owner
      perReturnFee: 0,
      paymentProcessingFee: 0.029, // 2.9%
      includedReturns: -1, // Unlimited
      usedReturns: 0,
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
    }
  });

  await prisma.subscription.upsert({
    where: { tenantId: resellerTenant.id },
    update: {},
    create: {
      tenantId: resellerTenant.id,
      planType: 'professional',
      status: 'active',
      monthlyFee: 99.00,
      perReturnFee: 15.00,
      paymentProcessingFee: 0.029, // 2.9%
      includedReturns: 50,
      usedReturns: 0,
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
    }
  });

  console.log('✅ Created subscriptions for tenants');

  // Create system configurations
  const systemConfigs = [
    {
      tenantId: null,
      configKey: 'system.version',
      configValue: { version: '1.0.0', build: new Date().toISOString() },
      description: 'System version information'
    },
    {
      tenantId: null,
      configKey: 'features.ai_processing',
      configValue: { enabled: true, confidence_threshold: 0.95 },
      description: 'AI processing feature configuration'
    },
    {
      tenantId: null,
      configKey: 'integrations.olt',
      configValue: { 
        enabled: true, 
        sandbox_mode: true,
        base_url: 'https://api-sandbox.olt.com',
        timeout: 30000
      },
      description: 'OLT integration configuration'
    },
    {
      tenantId: null,
      configKey: 'integrations.eps_financial',
      configValue: { 
        enabled: true, 
        sandbox_mode: true,
        base_url: 'https://api-sandbox.epsfinancial.com',
        timeout: 30000
      },
      description: 'EPS Financial integration configuration'
    }
  ];

  for (const config of systemConfigs) {
    // For system-wide configs (tenantId is null), we need to handle differently
    const existingConfig = await prisma.systemConfig.findFirst({
      where: {
        configKey: config.configKey,
        tenantId: config.tenantId
      }
    });

    if (existingConfig) {
      await prisma.systemConfig.update({
        where: { id: existingConfig.id },
        data: {
          configValue: config.configValue,
          description: config.description,
          updatedBy: superAdminUser.id
        }
      });
    } else {
      await prisma.systemConfig.create({
        data: {
          ...config,
          updatedBy: superAdminUser.id
        }
      });
    }
  }

  console.log('✅ Created system configurations');

  console.log('🎉 Database seed completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Database seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
