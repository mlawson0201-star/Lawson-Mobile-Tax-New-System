
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Share2, Users, DollarSign, TrendingUp, Copy, Mail, 
  MessageSquare, Facebook, Twitter, Linkedin, Gift,
  Trophy, Star, Target, Clock, CheckCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import confetti from 'canvas-confetti';
import { ReferralProgram, Referral } from '@/lib/types/client-acquisition';

interface ReferralDashboardProps {
  program: ReferralProgram;
  userReferrals: Referral[];
  userStats: {
    totalReferrals: number;
    completedReferrals: number;
    totalEarnings: number;
    pendingEarnings: number;
    currentTier: string;
    nextTierProgress: number;
  };
  onShareReferral: (method: string, code: string) => void;
  onClaimReward: (referralId: string) => void;
}

const SHARING_METHODS = [
  { 
    id: 'copy', 
    name: 'Copy Link', 
    icon: Copy, 
    color: 'bg-gray-100 text-gray-700 hover:bg-gray-200' 
  },
  { 
    id: 'email', 
    name: 'Email', 
    icon: Mail, 
    color: 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
  },
  { 
    id: 'sms', 
    name: 'Text Message', 
    icon: MessageSquare, 
    color: 'bg-green-100 text-green-700 hover:bg-green-200' 
  },
  { 
    id: 'facebook', 
    name: 'Facebook', 
    icon: Facebook, 
    color: 'bg-blue-600 text-white hover:bg-blue-700' 
  },
  { 
    id: 'twitter', 
    name: 'Twitter', 
    icon: Twitter, 
    color: 'bg-sky-500 text-white hover:bg-sky-600' 
  },
  { 
    id: 'linkedin', 
    name: 'LinkedIn', 
    icon: Linkedin, 
    color: 'bg-blue-700 text-white hover:bg-blue-800' 
  }
];

const TIER_BENEFITS = {
  bronze: { name: 'Bronze', color: 'text-amber-600', multiplier: 1.0, perks: ['Basic rewards', 'Email support'] },
  silver: { name: 'Silver', color: 'text-gray-500', multiplier: 1.2, perks: ['20% bonus rewards', 'Priority support', 'Exclusive content'] },
  gold: { name: 'Gold', color: 'text-yellow-500', multiplier: 1.5, perks: ['50% bonus rewards', 'Dedicated support', 'Early access', 'VIP events'] },
  platinum: { name: 'Platinum', color: 'text-purple-600', multiplier: 2.0, perks: ['100% bonus rewards', 'Personal account manager', 'Custom solutions'] }
};

export default function ReferralDashboard({ 
  program, 
  userReferrals, 
  userStats, 
  onShareReferral, 
  onClaimReward 
}: ReferralDashboardProps) {
  const [referralCode, setReferralCode] = useState('LAWSON2024USER');
  const [activeTab, setActiveTab] = useState('overview');
  const [showCelebration, setShowCelebration] = useState(false);
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  const currentTier = TIER_BENEFITS[userStats.currentTier as keyof typeof TIER_BENEFITS] || TIER_BENEFITS.bronze;
  const referralLink = `https://lawsonmobiletax.com/signup?ref=${referralCode}`;

  const handleShare = async (method: string) => {
    onShareReferral(method, referralCode);
    
    if (method === 'copy') {
      await navigator.clipboard.writeText(referralLink);
      confettiReward();
    } else if (method === 'email') {
      const subject = encodeURIComponent('Get Expert Tax Help with Lawson Mobile Tax');
      const body = encodeURIComponent(`Hi! I've been using Lawson Mobile Tax for my taxes and thought you might be interested. They offer expert tax preparation with a maximum refund guarantee. Use my referral link to get started: ${referralLink}`);
      window.open(`mailto:?subject=${subject}&body=${body}`);
    } else if (method === 'facebook') {
      const url = encodeURIComponent(referralLink);
      const quote = encodeURIComponent('Get expert tax help with Lawson Mobile Tax - maximum refund guaranteed!');
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${quote}`);
    } else if (method === 'twitter') {
      const text = encodeURIComponent('Get expert tax help with @LawsonMobileTax - maximum refund guaranteed! Use my referral link:');
      const url = encodeURIComponent(referralLink);
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`);
    } else if (method === 'linkedin') {
      const url = encodeURIComponent(referralLink);
      const title = encodeURIComponent('Expert Tax Preparation - Lawson Mobile Tax');
      const summary = encodeURIComponent('Professional tax preparation with maximum refund guarantee');
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}&title=${title}&summary=${summary}`);
    }
  };

  const handleClaimReward = (referralId: string) => {
    onClaimReward(referralId);
    setShowCelebration(true);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
    setTimeout(() => setShowCelebration(false), 3000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'rewarded': return 'text-blue-600 bg-blue-100';
      case 'expired': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Referral Dashboard
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Earn rewards by referring friends and family to Lawson Mobile Tax. 
          Get ${program.referrerReward} for each successful referral!
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Referrals</p>
                <p className="text-2xl font-bold text-gray-900">{userStats.totalReferrals}</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-green-600">{userStats.completedReferrals}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Earnings</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(userStats.totalEarnings)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Current Tier</p>
                <p className={`text-2xl font-bold ${currentTier.color}`}>
                  {currentTier.name}
                </p>
              </div>
              <Trophy className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="share">Share & Earn</TabsTrigger>
          <TabsTrigger value="referrals">My Referrals</TabsTrigger>
          <TabsTrigger value="rewards">Rewards</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Tier Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="w-5 h-5" />
                <span>Referral Tier Progress</span>
              </CardTitle>
              <CardDescription>
                Unlock better rewards as you refer more friends
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full bg-current ${currentTier.color}`} />
                  <span className="font-medium">{currentTier.name} Tier</span>
                  <Badge variant="outline">{currentTier.multiplier}x multiplier</Badge>
                </div>
                <span className="text-sm text-gray-600">
                  {userStats.completedReferrals} referrals
                </span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress to next tier</span>
                  <span>{userStats.nextTierProgress}%</span>
                </div>
                <Progress value={userStats.nextTierProgress} className="h-2" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Current Benefits</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    {currentTier.perks.map((perk, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Earnings Breakdown</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Base earnings:</span>
                      <span className="font-medium">
                        {formatCurrency(userStats.totalEarnings / currentTier.multiplier)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tier bonus:</span>
                      <span className="font-medium text-green-600">
                        {formatCurrency(userStats.totalEarnings - (userStats.totalEarnings / currentTier.multiplier))}
                      </span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="font-medium">Total earned:</span>
                      <span className="font-bold text-purple-600">
                        {formatCurrency(userStats.totalEarnings)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Referral Activity</CardTitle>
              <CardDescription>
                Your latest referrals and their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userReferrals.slice(0, 5).map((referral) => (
                  <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          Referral #{referral.referralCode}
                        </p>
                        <p className="text-sm text-gray-600">
                          {referral.clickCount} clicks • {new Date(referral.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(referral.status)}>
                        {referral.status}
                      </Badge>
                      {referral.status === 'completed' && (
                        <span className="font-medium text-green-600">
                          {formatCurrency(referral.rewardAmount)}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="share" className="space-y-6">
          {/* Referral Link */}
          <Card>
            <CardHeader>
              <CardTitle>Your Referral Link</CardTitle>
              <CardDescription>
                Share this link to earn ${program.referrerReward} for each successful referral
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  value={referralLink}
                  readOnly
                  className="flex-1"
                />
                <Button onClick={() => handleShare('copy')}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              </div>
              
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-4">
                  Or share directly on social media
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {SHARING_METHODS.map((method) => (
                    <Button
                      key={method.id}
                      variant="outline"
                      className={`${method.color} border-0`}
                      onClick={() => handleShare(method.id)}
                    >
                      <method.icon className="w-4 h-4 mr-2" />
                      {method.name}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Referral Tips */}
          <Card>
            <CardHeader>
              <CardTitle>Maximize Your Referrals</CardTitle>
              <CardDescription>
                Tips to increase your referral success rate
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Target className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Target the Right People</h4>
                      <p className="text-sm text-gray-600">
                        Share with friends who need tax help - small business owners, freelancers, and investors.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Personal Touch</h4>
                      <p className="text-sm text-gray-600">
                        Add a personal message explaining why you recommend Lawson Mobile Tax.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Clock className="w-4 h-4 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Perfect Timing</h4>
                      <p className="text-sm text-gray-600">
                        Share during tax season (Jan-Apr) when people are actively looking for tax help.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Star className="w-4 h-4 text-yellow-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Share Your Experience</h4>
                      <p className="text-sm text-gray-600">
                        Tell them about your positive experience and the benefits you received.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>All Referrals</CardTitle>
              <CardDescription>
                Track the status of all your referrals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userReferrals.map((referral) => (
                  <div key={referral.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            Referral #{referral.referralCode}
                          </p>
                          <p className="text-sm text-gray-600">
                            Created {new Date(referral.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(referral.status)}>
                        {referral.status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Clicks</p>
                        <p className="font-medium">{referral.clickCount}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Status</p>
                        <p className="font-medium capitalize">{referral.status}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Reward</p>
                        <p className="font-medium">{formatCurrency(referral.rewardAmount)}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Conversion Date</p>
                        <p className="font-medium">
                          {referral.conversionDate 
                            ? new Date(referral.conversionDate).toLocaleDateString()
                            : 'Pending'
                          }
                        </p>
                      </div>
                    </div>
                    
                    {referral.status === 'completed' && (
                      <div className="mt-3 pt-3 border-t">
                        <Button
                          size="sm"
                          onClick={() => handleClaimReward(referral.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Gift className="w-4 h-4 mr-2" />
                          Claim Reward
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Reward Summary</CardTitle>
              <CardDescription>
                Your earnings and available rewards
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-green-50 rounded-lg">
                  <DollarSign className="w-12 h-12 text-green-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-green-600">
                    {formatCurrency(userStats.totalEarnings)}
                  </p>
                  <p className="text-sm text-gray-600">Total Earned</p>
                </div>
                
                <div className="text-center p-6 bg-yellow-50 rounded-lg">
                  <Clock className="w-12 h-12 text-yellow-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-yellow-600">
                    {formatCurrency(userStats.pendingEarnings)}
                  </p>
                  <p className="text-sm text-gray-600">Pending</p>
                </div>
                
                <div className="text-center p-6 bg-blue-50 rounded-lg">
                  <Gift className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-blue-600">
                    {formatCurrency(userStats.totalEarnings - userStats.pendingEarnings)}
                  </p>
                  <p className="text-sm text-gray-600">Available</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Program Details */}
          <Card>
            <CardHeader>
              <CardTitle>Program Details</CardTitle>
              <CardDescription>
                How the referral program works
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Reward Structure</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• You earn: {formatCurrency(program.referrerReward)} per referral</li>
                      <li>• Friend gets: {formatCurrency(program.refereeReward)} discount</li>
                      <li>• Minimum purchase: {formatCurrency(program.minimumPurchase || 0)}</li>
                      <li>• Rewards expire: {program.expirationDays || 'Never'} days</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Program Rules</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      {program.rules.map((rule, index) => (
                        <li key={index}>• {rule}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.8, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 50 }}
              className="bg-white rounded-lg p-8 max-w-md mx-4 text-center"
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Reward Claimed!
              </h3>
              <p className="text-gray-600 mb-4">
                Your referral reward has been added to your account. Keep sharing to earn more!
              </p>
              <Button onClick={() => setShowCelebration(false)}>
                Awesome!
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <span id="confetti" />
    </div>
  );
}
