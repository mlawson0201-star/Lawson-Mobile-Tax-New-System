
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      clientId, 
      planningHorizon, 
      incomeProjections, 
      lifeEvents, 
      businessPlans,
      investmentStrategy,
      retirementPlanning
    } = await request.json();

    if (!clientId) {
      return NextResponse.json({ error: 'Client ID required' }, { status: 400 });
    }

    // Get comprehensive client data
    const client = await prisma.client.findUnique({
      where: { id: clientId },
      include: {
        taxReturns: {
          orderBy: { taxYear: 'desc' },
          take: 5,
          include: {
            deductionSuggestions: true,
            taxOptimizationSuggestions: true,
          },
        },
        predictiveAnalytics: {
          where: { analytic_type: { in: ['client_retention', 'tax_planning', 'income_forecast'] } },
          orderBy: { generatedAt: 'desc' },
          take: 10,
        },
      },
    });

    if (!client) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{
          role: 'user',
          content: `You are an expert tax planning strategist with predictive analytics capabilities. Create a comprehensive year-round tax planning strategy with quarterly recommendations.

Client Profile:
- Name: ${client.firstName} ${client.lastName}
- Filing Status: ${client.filingStatus || 'unknown'}
- Historical Returns: ${client.taxReturns.length} years of data

Historical Tax Data:
${JSON.stringify(client.taxReturns.map(tr => ({
  year: tr.taxYear,
  refund: tr.refundAmount,
  totalFee: tr.totalFee,
  deductions: tr.deductionSuggestions.length,
  optimizations: tr.taxOptimizationSuggestions.length
})))}

Planning Parameters:
- Planning Horizon: ${planningHorizon || '12 months'}
- Income Projections: ${JSON.stringify(incomeProjections || {})}
- Life Events: ${JSON.stringify(lifeEvents || {})}
- Business Plans: ${JSON.stringify(businessPlans || {})}
- Investment Strategy: ${JSON.stringify(investmentStrategy || {})}
- Retirement Planning: ${JSON.stringify(retirementPlanning || {})}

Previous Analytics:
${JSON.stringify(client.predictiveAnalytics.slice(0, 3))}

Generate comprehensive predictive tax planning including:

1. Income Tax Projections:
   - Quarterly income estimates
   - Tax liability projections
   - Estimated payment calculations
   - Withholding optimization

2. Strategic Tax Planning:
   - Timing strategies for income/deductions
   - Year-end planning recommendations
   - Multi-year tax minimization
   - Tax bracket management

3. Life Event Tax Planning:
   - Marriage/divorce implications
   - Home purchase strategies
   - Job changes and relocations
   - Family planning considerations

4. Business Tax Optimization:
   - Entity structure optimization
   - Expense timing strategies
   - Equipment purchase timing
   - Retirement plan contributions

5. Investment Tax Planning:
   - Capital gains/loss harvesting
   - Asset location strategies
   - Roth conversion opportunities
   - Tax-efficient investing

6. Quarterly Action Plan:
   - Q1: Post-filing review and adjustments
   - Q2: Mid-year strategy implementation
   - Q3: Year-end planning preparation
   - Q4: Final optimization actions

7. Automation Triggers:
   - When to trigger specific strategies
   - Client notification schedules
   - Document preparation reminders
   - Deadline management

8. Risk Management:
   - Audit risk assessment
   - Compliance monitoring
   - Penalty avoidance strategies

Format response as JSON with detailed predictive planning strategy.`
        }],
        stream: true,
        max_tokens: 6000,
        response_format: { type: "json_object" }
      }),
    });

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = '';
        let partialRead = '';

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            let lines = partialRead.split('\n');
            partialRead = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  try {
                    const finalResult = JSON.parse(buffer);
                    
                    // Save predictive analytics record
                    await prisma.predictiveAnalytics.create({
                      data: {
                        tenantId: session.user.tenantId,
                        clientId: clientId,
                        analytic_type: 'comprehensive_tax_planning',
                        predictionData: finalResult,
                        confidenceInterval: {
                          low: finalResult.confidenceRange?.low || 0.7,
                          high: finalResult.confidenceRange?.high || 0.95,
                          mean: finalResult.confidenceRange?.mean || 0.85
                        },
                        forecastPeriod: planningHorizon || '12_months',
                        validUntil: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)), // 1 year
                      },
                    });

                    // Create quarterly reminders/notifications
                    if (finalResult.quarterlyActionPlan) {
                      const quarters = Object.keys(finalResult.quarterlyActionPlan);
                      for (const quarter of quarters) {
                        const quarterNumber = parseInt(quarter.replace('Q', ''));
                        const reminderDate = new Date();
                        reminderDate.setMonth((quarterNumber - 1) * 3);
                        
                        await prisma.notification.create({
                          data: {
                            tenantId: session.user.tenantId,
                            userId: session.user.id,
                            clientId: clientId,
                            type: 'tax_planning_reminder',
                            title: `${quarter} Tax Planning Actions`,
                            message: `Time to implement ${quarter} tax planning strategies`,
                            scheduledFor: reminderDate,
                            actionData: finalResult.quarterlyActionPlan[quarter],
                            priority: 'medium',
                            status: 'scheduled',
                          },
                        });
                      }
                    }

                    const finalData = JSON.stringify({
                      status: 'completed',
                      result: finalResult,
                      planningMetrics: {
                        projectedSavings: finalResult.projectedAnnualSavings || 0,
                        strategiesCount: finalResult.strategiesCount || 0,
                        quarterlyActionsCount: Object.keys(finalResult.quarterlyActionPlan || {}).length,
                        automationLevel: finalResult.automationPercentage || 85
                      }
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                    return;
                  } catch (e) {
                    controller.error(e);
                    return;
                  }
                }
                try {
                  const parsed = JSON.parse(data);
                  buffer += parsed.choices?.[0]?.delta?.content || '';
                  const progressData = JSON.stringify({
                    status: 'processing',
                    message: 'Generating comprehensive predictive tax planning strategy...'
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Predictive tax planning stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Predictive tax planning error:', error);
    return NextResponse.json(
      { error: 'Failed to generate predictive tax planning' },
      { status: 500 }
    );
  }
}
