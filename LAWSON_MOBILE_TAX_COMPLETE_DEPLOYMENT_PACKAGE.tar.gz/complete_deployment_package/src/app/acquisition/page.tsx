
'use client';

import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Users, MousePointer, DollarSign } from 'lucide-react';

// Import our new components
import LeadMagnetGenerator from '@/components/acquisition/lead-magnets/lead-magnet-generator';
import DynamicLandingPage from '@/components/acquisition/landing-pages/dynamic-landing-page';
import ABTestManager from '@/components/acquisition/conversion-engine/ab-test-manager';
import TestimonialManager from '@/components/acquisition/social-proof/testimonial-manager';
import ReferralDashboard from '@/components/acquisition/referral-system/referral-dashboard';

// Mock data
const mockPersonas = [
  {
    id: '1',
    type: 'w2_employee' as const,
    name: 'W-2 Employee',
    description: 'Individuals with traditional employment seeking simple tax filing',
    painPoints: ['Time constraints', 'Fear of mistakes', 'Want maximum refund'],
    preferences: {
      communicationChannel: 'email' as const,
      complexity: 'simple' as const,
      timing: 'immediate' as const
    },
    demographics: {
      ageRange: '25-45',
      incomeRange: '$40K-$80K',
      location: 'Urban/Suburban'
    }
  },
  {
    id: '2',
    type: 'small_business' as const,
    name: 'Small Business Owner',
    description: 'Entrepreneurs needing comprehensive business tax solutions',
    painPoints: ['Complex deductions', 'Quarterly taxes', 'Business/personal separation'],
    preferences: {
      communicationChannel: 'phone' as const,
      complexity: 'advanced' as const,
      timing: 'scheduled' as const
    },
    demographics: {
      ageRange: '30-55',
      incomeRange: '$60K-$200K',
      location: 'Mixed'
    }
  }
];

const mockLandingPageVariant = {
  id: '1',
  name: 'Default Landing Page',
  headline: 'Expert Tax Preparation Made Simple',
  subheadline: 'Get your maximum refund with our AI-powered tax platform',
  ctaText: 'Start Your Tax Return',
  ctaColor: '#3B82F6',
  heroImage: '/api/placeholder/600/400',
  testimonials: [
    {
      id: '1',
      clientName: 'Sarah Johnson',
      clientTitle: 'Small Business Owner',
      content: 'Lawson Mobile Tax saved me hours and got me a bigger refund than I expected!',
      rating: 5,
      imageUrl: '/api/placeholder/60/60',
      tags: ['business', 'refund'],
      isVerified: true,
      createdAt: new Date()
    }
  ],
  features: [
    'Maximum refund guarantee',
    'Expert review included',
    'Audit defense protection',
    'Mobile-first experience'
  ],
  conversionRate: 0.15,
  isActive: true
};

const mockABTests = [
  {
    id: '1',
    name: 'Homepage CTA Test',
    description: 'Testing different call-to-action buttons on the homepage',
    variants: [
      {
        id: 'control',
        name: 'Control',
        headline: 'Expert Tax Preparation Made Simple',
        subheadline: 'Get your maximum refund with our AI-powered tax platform',
        ctaText: 'Start Your Tax Return',
        ctaColor: '#3B82F6',
        heroImage: '/api/placeholder/600/400',
        testimonials: [],
        features: ['Maximum refund guarantee', 'Expert review included'],
        conversionRate: 0.12,
        isActive: true
      },
      {
        id: 'variant-a',
        name: 'Variant A',
        headline: 'Maximize Your Tax Refund Today',
        subheadline: 'Professional tax preparation with guaranteed results',
        ctaText: 'Get My Refund',
        ctaColor: '#10B981',
        heroImage: '/api/placeholder/600/400',
        testimonials: [],
        features: ['Guaranteed maximum refund', 'Professional review'],
        conversionRate: 0.15,
        isActive: true
      }
    ],
    trafficSplit: [50, 50],
    startDate: new Date('2024-01-01'),
    status: 'running' as const,
    metrics: {
      visitors: 5420,
      conversions: 731,
      conversionRate: 0.135,
      confidenceLevel: 95
    }
  }
];

const mockTestimonials = [
  {
    id: '1',
    clientName: 'Sarah Johnson',
    clientTitle: 'Small Business Owner',
    content: 'Lawson Mobile Tax saved me hours and got me a bigger refund than I expected! The business deduction tools are incredible.',
    rating: 5,
    videoUrl: 'https://example.com/video1',
    imageUrl: '/api/placeholder/60/60',
    tags: ['business', 'refund', 'deductions'],
    isVerified: true,
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    clientName: 'Mike Chen',
    clientTitle: 'Software Engineer',
    content: 'Super easy to use and the mobile app made filing my taxes a breeze. Highly recommend!',
    rating: 5,
    imageUrl: '/api/placeholder/60/60',
    tags: ['mobile', 'easy', 'w2'],
    isVerified: true,
    createdAt: new Date('2024-01-20')
  }
];

const mockReferralProgram = {
  id: '1',
  name: 'Refer & Earn Program',
  description: 'Earn $50 for each friend you refer who completes their tax return',
  rewardType: 'cash' as const,
  rewardAmount: 50,
  referrerReward: 50,
  refereeReward: 25,
  minimumPurchase: 100,
  expirationDays: 365,
  isActive: true,
  rules: [
    'Referred friend must complete their tax return',
    'Minimum purchase of $100 required',
    'Rewards paid within 30 days of completion',
    'No limit on number of referrals'
  ]
};

const mockUserReferrals = [
  {
    id: '1',
    referrerId: 'user1',
    referralCode: 'FRIEND2024',
    status: 'completed' as const,
    clickCount: 5,
    conversionDate: new Date('2024-01-25'),
    rewardAmount: 50,
    createdAt: new Date('2024-01-10')
  },
  {
    id: '2',
    referrerId: 'user1',
    referralCode: 'FAMILY2024',
    status: 'pending' as const,
    clickCount: 12,
    rewardAmount: 50,
    createdAt: new Date('2024-02-01')
  }
];

const mockUserStats = {
  totalReferrals: 8,
  completedReferrals: 3,
  totalEarnings: 150,
  pendingEarnings: 100,
  currentTier: 'silver',
  nextTierProgress: 65
};

export default function AcquisitionPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const handleGenerateLeadMagnet = (magnet: any) => {
    console.log('Generated lead magnet:', magnet);
  };

  const handleDownloadLeadMagnet = (magnetId: string) => {
    console.log('Download lead magnet:', magnetId);
  };

  const handleLandingPageConversion = (variantId: string, conversionType: string) => {
    console.log('Landing page conversion:', { variantId, conversionType });
  };

  const handleCreateABTest = (test: any) => {
    console.log('Create A/B test:', test);
  };

  const handleUpdateABTest = (testId: string, updates: any) => {
    console.log('Update A/B test:', { testId, updates });
  };

  const handleDeleteABTest = (testId: string) => {
    console.log('Delete A/B test:', testId);
  };

  const handleCreateTestimonial = (testimonial: any) => {
    console.log('Create testimonial:', testimonial);
  };

  const handleUpdateTestimonial = (id: string, updates: any) => {
    console.log('Update testimonial:', { id, updates });
  };

  const handleDeleteTestimonial = (id: string) => {
    console.log('Delete testimonial:', id);
  };

  const handleShareReferral = (method: string, code: string) => {
    console.log('Share referral:', { method, code });
  };

  const handleClaimReward = (referralId: string) => {
    console.log('Claim reward:', referralId);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Client Acquisition Hub
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl">
          Transform prospects into loyal clients with our comprehensive acquisition and conversion tools.
          Create personalized experiences that educate, engage, and convert.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                <p className="text-2xl font-bold text-green-600">13.5%</p>
                <p className="text-xs text-green-600">↑ 2.3% from last month</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Monthly Visitors</p>
                <p className="text-2xl font-bold text-blue-600">24,580</p>
                <p className="text-xs text-blue-600">↑ 8.1% from last month</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Lead Quality Score</p>
                <p className="text-2xl font-bold text-purple-600">8.7/10</p>
                <p className="text-xs text-purple-600">↑ 0.4 from last month</p>
              </div>
              <MousePointer className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Customer LTV</p>
                <p className="text-2xl font-bold text-orange-600">$1,247</p>
                <p className="text-xs text-orange-600">↑ $89 from last month</p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="lead-magnets">Lead Magnets</TabsTrigger>
          <TabsTrigger value="landing-pages">Landing Pages</TabsTrigger>
          <TabsTrigger value="ab-testing">A/B Testing</TabsTrigger>
          <TabsTrigger value="social-proof">Social Proof</TabsTrigger>
          <TabsTrigger value="referrals">Referrals</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Acquisition Funnel Performance</CardTitle>
                <CardDescription>
                  Track how prospects move through your acquisition funnel
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="font-medium">Visitors</span>
                    <Badge variant="outline">24,580</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="font-medium">Leads Generated</span>
                    <Badge variant="outline">4,127 (16.8%)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <span className="font-medium">Qualified Leads</span>
                    <Badge variant="outline">2,476 (60.0%)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <span className="font-medium">Conversions</span>
                    <Badge variant="outline">334 (13.5%)</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Performing Channels</CardTitle>
                <CardDescription>
                  Your best acquisition channels this month
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Organic Search</p>
                      <p className="text-sm text-gray-600">Google, Bing</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">18.2%</p>
                      <p className="text-xs text-gray-600">conversion rate</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Referral Program</p>
                      <p className="text-sm text-gray-600">Word of mouth</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-blue-600">24.7%</p>
                      <p className="text-xs text-gray-600">conversion rate</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Social Media</p>
                      <p className="text-sm text-gray-600">Facebook, LinkedIn</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-purple-600">12.4%</p>
                      <p className="text-xs text-gray-600">conversion rate</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Email Marketing</p>
                      <p className="text-sm text-gray-600">Newsletter, campaigns</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-orange-600">15.8%</p>
                      <p className="text-xs text-gray-600">conversion rate</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="lead-magnets">
          <LeadMagnetGenerator
            personas={mockPersonas}
            onGenerate={handleGenerateLeadMagnet}
            onDownload={handleDownloadLeadMagnet}
          />
        </TabsContent>

        <TabsContent value="landing-pages">
          <DynamicLandingPage
            variant={mockLandingPageVariant}
            persona={mockPersonas[0]}
            visitorData={{
              referrer: 'google.com',
              location: 'New York, NY',
              device: 'desktop',
              previousVisits: 2,
              timeOnSite: 180
            }}
            onConversion={handleLandingPageConversion}
          />
        </TabsContent>

        <TabsContent value="ab-testing">
          <ABTestManager
            tests={mockABTests}
            onCreateTest={handleCreateABTest}
            onUpdateTest={handleUpdateABTest}
            onDeleteTest={handleDeleteABTest}
          />
        </TabsContent>

        <TabsContent value="social-proof">
          <TestimonialManager
            testimonials={mockTestimonials}
            onCreateTestimonial={handleCreateTestimonial}
            onUpdateTestimonial={handleUpdateTestimonial}
            onDeleteTestimonial={handleDeleteTestimonial}
          />
        </TabsContent>

        <TabsContent value="referrals">
          <ReferralDashboard
            program={mockReferralProgram}
            userReferrals={mockUserReferrals}
            userStats={mockUserStats}
            onShareReferral={handleShareReferral}
            onClaimReward={handleClaimReward}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
