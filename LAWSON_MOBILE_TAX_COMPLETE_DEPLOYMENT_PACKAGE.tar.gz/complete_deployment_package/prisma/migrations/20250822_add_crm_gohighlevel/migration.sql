
-- CreateEnum
CREATE TYPE "LeadStatus" AS ENUM ('NEW', 'CONTACTED', 'QUALIFIED', 'PROPOSAL_SENT', 'NEGOTIATING', 'WON', 'LOST', 'NURTURING');

-- CreateEnum
CREATE TYPE "LeadSource" AS ENUM ('WEBSITE', 'REFERRAL', 'SOCIAL_MEDIA', 'GOOGLE_ADS', 'FACEBOOK_ADS', 'GOHIGHLEVEL', 'PHONE', 'EMAIL', 'WALK_IN', 'OTHER');

-- CreateEnum
CREATE TYPE "CommunicationType" AS ENUM ('EMAIL', 'SMS', 'PHONE_CALL', 'MEETING', 'NOTE', 'TASK', 'FOLLOW_UP');

-- CreateEnum
CREATE TYPE "TaskStatus" AS ENUM ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "TaskPriority" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'URGENT');

-- CreateEnum
CREATE TYPE "PipelineStageType" AS ENUM ('LEAD', 'PROSPECT', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST');

-- CreateEnum
CREATE TYPE "AutomationTrigger" AS ENUM ('LEAD_CREATED', 'LEAD_STATUS_CHANGED', 'TASK_COMPLETED', 'EMAIL_OPENED', 'SMS_REPLIED', 'APPOINTMENT_BOOKED', 'PAYMENT_RECEIVED');

-- CreateEnum
CREATE TYPE "AutomationAction" AS ENUM ('SEND_EMAIL', 'SEND_SMS', 'CREATE_TASK', 'UPDATE_LEAD_STATUS', 'SCHEDULE_FOLLOW_UP', 'ASSIGN_TO_USER', 'ADD_TAG', 'WEBHOOK_CALL');

-- CRM Lead Management
CREATE TABLE "crm_leads" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "first_name" VARCHAR(100) NOT NULL,
    "last_name" VARCHAR(100) NOT NULL,
    "email" VARCHAR(255) UNIQUE NOT NULL,
    "phone" VARCHAR(20),
    "company" VARCHAR(255),
    "job_title" VARCHAR(100),
    "status" "LeadStatus" NOT NULL DEFAULT 'NEW',
    "source" "LeadSource" NOT NULL DEFAULT 'WEBSITE',
    "lead_score" INTEGER DEFAULT 0,
    "estimated_value" DECIMAL(10,2),
    "expected_close_date" DATE,
    "assigned_to" UUID REFERENCES "users"("id"),
    "pipeline_stage_id" UUID,
    "gohighlevel_contact_id" VARCHAR(255),
    "custom_fields" JSONB DEFAULT '{}',
    "tags" TEXT[],
    "notes" TEXT,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- CRM Pipeline Stages
CREATE TABLE "crm_pipeline_stages" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "name" VARCHAR(100) NOT NULL,
    "description" TEXT,
    "stage_type" "PipelineStageType" NOT NULL,
    "order_index" INTEGER NOT NULL,
    "probability" DECIMAL(5,2) DEFAULT 0.00,
    "color" VARCHAR(7) DEFAULT '#3B82F6',
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- Add foreign key for pipeline stage
ALTER TABLE "crm_leads" ADD CONSTRAINT "crm_leads_pipeline_stage_id_fkey" 
    FOREIGN KEY ("pipeline_stage_id") REFERENCES "crm_pipeline_stages"("id");

-- CRM Communication Log
CREATE TABLE "crm_communication_logs" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "lead_id" UUID NOT NULL REFERENCES "crm_leads"("id") ON DELETE CASCADE,
    "user_id" UUID REFERENCES "users"("id"),
    "type" "CommunicationType" NOT NULL,
    "subject" VARCHAR(255),
    "content" TEXT,
    "direction" VARCHAR(10) CHECK (direction IN ('INBOUND', 'OUTBOUND')),
    "status" VARCHAR(20) DEFAULT 'SENT',
    "scheduled_at" TIMESTAMP,
    "completed_at" TIMESTAMP,
    "metadata" JSONB DEFAULT '{}',
    "gohighlevel_message_id" VARCHAR(255),
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- CRM Tasks
CREATE TABLE "crm_tasks" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "lead_id" UUID REFERENCES "crm_leads"("id") ON DELETE CASCADE,
    "assigned_to" UUID REFERENCES "users"("id"),
    "created_by" UUID REFERENCES "users"("id"),
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "status" "TaskStatus" NOT NULL DEFAULT 'PENDING',
    "priority" "TaskPriority" NOT NULL DEFAULT 'MEDIUM',
    "due_date" TIMESTAMP,
    "completed_at" TIMESTAMP,
    "reminder_at" TIMESTAMP,
    "tags" TEXT[],
    "metadata" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- CRM Appointments
CREATE TABLE "crm_appointments" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "lead_id" UUID REFERENCES "crm_leads"("id") ON DELETE CASCADE,
    "user_id" UUID REFERENCES "users"("id"),
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "start_time" TIMESTAMP NOT NULL,
    "end_time" TIMESTAMP NOT NULL,
    "location" VARCHAR(255),
    "meeting_type" VARCHAR(50) DEFAULT 'IN_PERSON',
    "meeting_url" VARCHAR(500),
    "status" VARCHAR(20) DEFAULT 'SCHEDULED',
    "reminder_sent" BOOLEAN DEFAULT false,
    "gohighlevel_appointment_id" VARCHAR(255),
    "metadata" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- GoHighLevel Integration Settings
CREATE TABLE "gohighlevel_settings" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "api_key" VARCHAR(500),
    "location_id" VARCHAR(255),
    "webhook_secret" VARCHAR(255),
    "oauth_access_token" VARCHAR(500),
    "oauth_refresh_token" VARCHAR(500),
    "oauth_expires_at" TIMESTAMP,
    "sync_enabled" BOOLEAN DEFAULT false,
    "sync_contacts" BOOLEAN DEFAULT true,
    "sync_appointments" BOOLEAN DEFAULT true,
    "sync_messages" BOOLEAN DEFAULT true,
    "auto_create_leads" BOOLEAN DEFAULT true,
    "default_pipeline_stage_id" UUID REFERENCES "crm_pipeline_stages"("id"),
    "field_mappings" JSONB DEFAULT '{}',
    "webhook_url" VARCHAR(500),
    "last_sync_at" TIMESTAMP,
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW(),
    UNIQUE("tenant_id")
);

-- CRM Automation Rules
CREATE TABLE "crm_automation_rules" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "trigger_type" "AutomationTrigger" NOT NULL,
    "trigger_conditions" JSONB DEFAULT '{}',
    "actions" JSONB NOT NULL,
    "is_active" BOOLEAN DEFAULT true,
    "execution_count" INTEGER DEFAULT 0,
    "last_executed_at" TIMESTAMP,
    "created_by" UUID REFERENCES "users"("id"),
    "created_at" TIMESTAMP DEFAULT NOW(),
    "updated_at" TIMESTAMP DEFAULT NOW()
);

-- CRM Automation Execution Log
CREATE TABLE "crm_automation_executions" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "rule_id" UUID NOT NULL REFERENCES "crm_automation_rules"("id") ON DELETE CASCADE,
    "lead_id" UUID REFERENCES "crm_leads"("id"),
    "trigger_data" JSONB,
    "execution_result" JSONB,
    "status" VARCHAR(20) DEFAULT 'SUCCESS',
    "error_message" TEXT,
    "executed_at" TIMESTAMP DEFAULT NOW()
);

-- CRM Analytics and Reporting
CREATE TABLE "crm_analytics_snapshots" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "snapshot_date" DATE NOT NULL,
    "total_leads" INTEGER DEFAULT 0,
    "new_leads" INTEGER DEFAULT 0,
    "qualified_leads" INTEGER DEFAULT 0,
    "converted_leads" INTEGER DEFAULT 0,
    "lost_leads" INTEGER DEFAULT 0,
    "total_pipeline_value" DECIMAL(12,2) DEFAULT 0,
    "average_deal_size" DECIMAL(10,2) DEFAULT 0,
    "conversion_rate" DECIMAL(5,2) DEFAULT 0,
    "average_sales_cycle" INTEGER DEFAULT 0,
    "lead_sources" JSONB DEFAULT '{}',
    "stage_distribution" JSONB DEFAULT '{}',
    "user_performance" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP DEFAULT NOW()
);

-- GoHighLevel Webhook Events Log
CREATE TABLE "gohighlevel_webhook_events" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "tenant_id" UUID NOT NULL REFERENCES "tenants"("id") ON DELETE CASCADE,
    "event_type" VARCHAR(100) NOT NULL,
    "event_data" JSONB NOT NULL,
    "processed" BOOLEAN DEFAULT false,
    "processing_result" JSONB,
    "error_message" TEXT,
    "signature" VARCHAR(255),
    "received_at" TIMESTAMP DEFAULT NOW(),
    "processed_at" TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX "idx_crm_leads_tenant_id" ON "crm_leads"("tenant_id");
CREATE INDEX "idx_crm_leads_status" ON "crm_leads"("status");
CREATE INDEX "idx_crm_leads_assigned_to" ON "crm_leads"("assigned_to");
CREATE INDEX "idx_crm_leads_email" ON "crm_leads"("email");
CREATE INDEX "idx_crm_leads_gohighlevel_contact_id" ON "crm_leads"("gohighlevel_contact_id");
CREATE INDEX "idx_crm_leads_created_at" ON "crm_leads"("created_at");

CREATE INDEX "idx_crm_communication_logs_lead_id" ON "crm_communication_logs"("lead_id");
CREATE INDEX "idx_crm_communication_logs_type" ON "crm_communication_logs"("type");
CREATE INDEX "idx_crm_communication_logs_created_at" ON "crm_communication_logs"("created_at");

CREATE INDEX "idx_crm_tasks_assigned_to" ON "crm_tasks"("assigned_to");
CREATE INDEX "idx_crm_tasks_status" ON "crm_tasks"("status");
CREATE INDEX "idx_crm_tasks_due_date" ON "crm_tasks"("due_date");

CREATE INDEX "idx_crm_appointments_user_id" ON "crm_appointments"("user_id");
CREATE INDEX "idx_crm_appointments_start_time" ON "crm_appointments"("start_time");
CREATE INDEX "idx_crm_appointments_status" ON "crm_appointments"("status");

CREATE INDEX "idx_gohighlevel_webhook_events_processed" ON "gohighlevel_webhook_events"("processed");
CREATE INDEX "idx_gohighlevel_webhook_events_event_type" ON "gohighlevel_webhook_events"("event_type");
CREATE INDEX "idx_gohighlevel_webhook_events_received_at" ON "gohighlevel_webhook_events"("received_at");

-- Insert default pipeline stages
INSERT INTO "crm_pipeline_stages" ("tenant_id", "name", "description", "stage_type", "order_index", "probability", "color") VALUES
-- These will be inserted per tenant, but we'll create a template
('00000000-0000-0000-0000-000000000000', 'New Lead', 'Initial contact or inquiry', 'LEAD', 1, 10.00, '#EF4444'),
('00000000-0000-0000-0000-000000000000', 'Contacted', 'First contact made', 'PROSPECT', 2, 25.00, '#F97316'),
('00000000-0000-0000-0000-000000000000', 'Qualified', 'Lead has been qualified', 'QUALIFIED', 3, 50.00, '#EAB308'),
('00000000-0000-0000-0000-000000000000', 'Proposal Sent', 'Proposal or quote sent', 'PROPOSAL', 4, 75.00, '#3B82F6'),
('00000000-0000-0000-0000-000000000000', 'Negotiating', 'In negotiation phase', 'NEGOTIATION', 5, 85.00, '#8B5CF6'),
('00000000-0000-0000-0000-000000000000', 'Won', 'Deal closed successfully', 'CLOSED_WON', 6, 100.00, '#10B981'),
('00000000-0000-0000-0000-000000000000', 'Lost', 'Deal lost or cancelled', 'CLOSED_LOST', 7, 0.00, '#6B7280');
