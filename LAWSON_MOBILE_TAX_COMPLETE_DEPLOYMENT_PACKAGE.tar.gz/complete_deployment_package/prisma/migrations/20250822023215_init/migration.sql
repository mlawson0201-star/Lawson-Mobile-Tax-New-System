-- CreateTable
CREATE TABLE "public"."tenants" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "domain" TEXT NOT NULL,
    "legal_name" TEXT NOT NULL,
    "ein" TEXT,
    "branding_config" JSONB NOT NULL DEFAULT '{}',
    "settings" JSONB NOT NULL DEFAULT '{}',
    "subscription_tier" TEXT NOT NULL DEFAULT 'basic',
    "revenue_share_rate" DECIMAL(5,4) NOT NULL DEFAULT 0.30,
    "stripe_connect_account_id" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tenants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."users" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "cognito_user_id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "first_name" TEXT NOT NULL,
    "last_name" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'client',
    "password_hash" TEXT,
    "profile_data" JSONB NOT NULL DEFAULT '{}',
    "preferences" JSONB NOT NULL DEFAULT '{}',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "last_login_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."roles" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "permissions" JSONB NOT NULL DEFAULT '[]',
    "system_role" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."user_roles" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "role_id" UUID NOT NULL,
    "assigned_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "assigned_by" UUID NOT NULL,

    CONSTRAINT "user_roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."clients" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "created_by_user_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "first_name" TEXT NOT NULL,
    "last_name" TEXT NOT NULL,
    "ssn_encrypted" TEXT,
    "date_of_birth" TIMESTAMP(3),
    "address" JSONB NOT NULL DEFAULT '{}',
    "filing_status" TEXT,
    "personal_info" JSONB NOT NULL DEFAULT '{}',
    "client_status" TEXT NOT NULL DEFAULT 'active',
    "lifetime_value" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clients_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."tax_returns" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "assigned_preparer_id" UUID,
    "tax_year" TEXT NOT NULL,
    "return_type" TEXT NOT NULL DEFAULT '1040',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "total_fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "refund_amount" DECIMAL(10,2),
    "form_data" JSONB NOT NULL DEFAULT '{}',
    "calculations" JSONB NOT NULL DEFAULT '{}',
    "ai_confidence_score" DECIMAL(5,4),
    "requires_human_review" BOOLEAN NOT NULL DEFAULT false,
    "review_notes" TEXT,
    "submitted_at" TIMESTAMP(3),
    "completed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tax_returns_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."tax_forms" (
    "id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "form_type" TEXT NOT NULL,
    "form_name" TEXT NOT NULL,
    "form_data" JSONB NOT NULL DEFAULT '{}',
    "validations" JSONB NOT NULL DEFAULT '[]',
    "confidence_score" DECIMAL(5,4) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tax_forms_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."documents" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "tax_return_id" UUID,
    "uploaded_by_user_id" UUID NOT NULL,
    "document_type" TEXT NOT NULL,
    "filename" TEXT NOT NULL,
    "s3_key" TEXT NOT NULL,
    "s3_bucket" TEXT NOT NULL,
    "file_size" INTEGER NOT NULL,
    "mime_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'uploaded',
    "ocr_results" JSONB,
    "ocr_confidence" DECIMAL(5,4),
    "extracted_data" JSONB NOT NULL DEFAULT '{}',
    "processed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."document_extractions" (
    "id" UUID NOT NULL,
    "document_id" UUID NOT NULL,
    "field_name" TEXT NOT NULL,
    "field_value" TEXT NOT NULL,
    "confidence_score" DECIMAL(5,4) NOT NULL,
    "validation_results" JSONB NOT NULL DEFAULT '{}',
    "manually_verified" BOOLEAN NOT NULL DEFAULT false,
    "verified_by_user_id" UUID,
    "verified_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "document_extractions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."payments" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "tax_return_id" UUID,
    "stripe_payment_intent_id" TEXT,
    "amount" DECIMAL(10,2) NOT NULL,
    "platform_fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "reseller_amount" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "payment_method" TEXT,
    "payment_metadata" JSONB NOT NULL DEFAULT '{}',
    "processed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "payments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."invoices" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "tax_return_id" UUID,
    "payment_id" UUID,
    "invoice_number" TEXT NOT NULL,
    "subtotal" DECIMAL(10,2) NOT NULL,
    "tax_amount" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "total_amount" DECIMAL(10,2) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "line_items" JSONB NOT NULL DEFAULT '[]',
    "due_date" TIMESTAMP(3) NOT NULL,
    "paid_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "invoices_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."bank_products" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "product_type" TEXT NOT NULL,
    "provider" TEXT NOT NULL DEFAULT 'eps_financial',
    "amount" DECIMAL(10,2) NOT NULL,
    "apr" DECIMAL(5,4),
    "fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "terms" JSONB NOT NULL DEFAULT '{}',
    "disclosures" JSONB NOT NULL DEFAULT '{}',
    "eps_application_id" TEXT,
    "approved_at" TIMESTAMP(3),
    "funded_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bank_products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."identity_verifications" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "persona_inquiry_id" TEXT NOT NULL,
    "verification_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "verification_data" JSONB NOT NULL DEFAULT '{}',
    "document_images" JSONB NOT NULL DEFAULT '{}',
    "liveness_check_passed" BOOLEAN NOT NULL DEFAULT false,
    "risk_assessment" JSONB NOT NULL DEFAULT '{}',
    "completed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "identity_verifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."efile_submissions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "olt_submission_id" TEXT,
    "federal_submission_id" TEXT,
    "state_submission_id" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "submission_data" JSONB NOT NULL DEFAULT '{}',
    "acknowledgment_data" JSONB NOT NULL DEFAULT '{}',
    "rejection_data" JSONB NOT NULL DEFAULT '{}',
    "retry_count" INTEGER NOT NULL DEFAULT 0,
    "submitted_at" TIMESTAMP(3),
    "accepted_at" TIMESTAMP(3),
    "rejected_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "efile_submissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."efile_status_history" (
    "id" UUID NOT NULL,
    "efile_submission_id" UUID NOT NULL,
    "previous_status" TEXT NOT NULL,
    "new_status" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "details" JSONB NOT NULL DEFAULT '{}',
    "changed_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "efile_status_history_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."review_tasks" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "assigned_to_user_id" UUID NOT NULL,
    "task_type" TEXT NOT NULL,
    "priority" TEXT NOT NULL DEFAULT 'medium',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "review_criteria" JSONB NOT NULL DEFAULT '{}',
    "review_results" JSONB NOT NULL DEFAULT '{}',
    "notes" TEXT,
    "assigned_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "review_tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."quality_checks" (
    "id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "performed_by_user_id" UUID NOT NULL,
    "check_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "check_results" JSONB NOT NULL DEFAULT '{}',
    "issues_found" JSONB NOT NULL DEFAULT '[]',
    "resolution_notes" TEXT,
    "performed_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "quality_checks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."notifications" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID,
    "client_id" UUID,
    "type" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "subject" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "scheduled_at" TIMESTAMP(3),
    "sent_at" TIMESTAMP(3),
    "delivered_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "notifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."communication_logs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "user_id" UUID,
    "communication_type" TEXT NOT NULL,
    "direction" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "occurred_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "communication_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."leads" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "first_name" TEXT,
    "last_name" TEXT,
    "source" TEXT NOT NULL,
    "campaign" TEXT,
    "utm_data" JSONB NOT NULL DEFAULT '{}',
    "status" TEXT NOT NULL DEFAULT 'active',
    "estimated_refund" DECIMAL(10,2),
    "qualification_data" JSONB NOT NULL DEFAULT '{}',
    "converted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "leads_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."marketing_campaigns" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "configuration" JSONB NOT NULL DEFAULT '{}',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "budget" DECIMAL(10,2),
    "spent" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "leads_generated" INTEGER NOT NULL DEFAULT 0,
    "conversions" INTEGER NOT NULL DEFAULT 0,
    "started_at" TIMESTAMP(3),
    "ended_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "marketing_campaigns_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."subscriptions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "stripe_subscription_id" TEXT,
    "plan_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "monthly_fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "per_return_fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "payment_processing_fee" DECIMAL(5,4) NOT NULL DEFAULT 0,
    "included_returns" INTEGER NOT NULL DEFAULT 0,
    "used_returns" INTEGER NOT NULL DEFAULT 0,
    "current_period_start" TIMESTAMP(3) NOT NULL,
    "current_period_end" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "subscriptions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."usage_metrics" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "subscription_id" UUID NOT NULL,
    "metric_type" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "unit_price" DECIMAL(10,2) NOT NULL,
    "total_amount" DECIMAL(10,2) NOT NULL,
    "usage_date" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "usage_metrics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."payouts" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "subscription_id" UUID,
    "stripe_transfer_id" TEXT,
    "amount" DECIMAL(10,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "payout_details" JSONB NOT NULL DEFAULT '{}',
    "period_start" TIMESTAMP(3) NOT NULL,
    "period_end" TIMESTAMP(3) NOT NULL,
    "processed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "payouts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."revenue_shares" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "payment_id" UUID NOT NULL,
    "payout_id" UUID,
    "gross_amount" DECIMAL(10,2) NOT NULL,
    "platform_fee" DECIMAL(10,2) NOT NULL,
    "reseller_amount" DECIMAL(10,2) NOT NULL,
    "platform_percentage" DECIMAL(5,4) NOT NULL,
    "calculated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "revenue_shares_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."audit_logs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "user_id" UUID,
    "action" TEXT NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_id" UUID,
    "old_values" JSONB,
    "new_values" JSONB,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "additional_data" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."consent_records" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "consent_type" TEXT NOT NULL,
    "version" TEXT NOT NULL,
    "granted" BOOLEAN NOT NULL,
    "consent_data" JSONB NOT NULL DEFAULT '{}',
    "ip_address" TEXT NOT NULL,
    "user_agent" TEXT NOT NULL,
    "granted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "revoked_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "consent_records_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."system_configs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "config_key" TEXT NOT NULL,
    "config_value" JSONB NOT NULL,
    "description" TEXT NOT NULL,
    "is_sensitive" BOOLEAN NOT NULL DEFAULT false,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "updated_by" UUID NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "system_configs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ai_model_data" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "model_type" TEXT NOT NULL,
    "model_version" TEXT NOT NULL,
    "training_data" JSONB NOT NULL,
    "accuracy_metrics" JSONB NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT false,
    "trained_at" TIMESTAMP(3) NOT NULL,
    "deployed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ai_model_data_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."deduction_suggestions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "ai_model_id" UUID NOT NULL,
    "deduction_category" TEXT NOT NULL,
    "deduction_amount" DECIMAL(10,2) NOT NULL,
    "confidence_score" DECIMAL(5,4) NOT NULL,
    "evidence_data" JSONB NOT NULL,
    "justification" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "review_notes" TEXT,
    "potential_savings" DECIMAL(10,2) NOT NULL,
    "risk_level" TEXT NOT NULL DEFAULT 'low',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "deduction_suggestions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."tax_optimization_suggestions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "optimization_type" TEXT NOT NULL,
    "current_tax_liability" DECIMAL(10,2) NOT NULL,
    "optimized_tax_liability" DECIMAL(10,2) NOT NULL,
    "estimated_savings" DECIMAL(10,2) NOT NULL,
    "optimization_strategy" JSONB NOT NULL,
    "implementation_steps" JSONB NOT NULL,
    "confidence_score" DECIMAL(5,4) NOT NULL,
    "valid_until" TIMESTAMP(3) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tax_optimization_suggestions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ai_processing_logs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "model_id" UUID NOT NULL,
    "input_data" JSONB NOT NULL,
    "output_data" JSONB NOT NULL,
    "processing_time" INTEGER NOT NULL,
    "confidence_score" DECIMAL(5,4),
    "error_log" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ai_processing_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."predictive_analytics" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID,
    "analytic_type" TEXT NOT NULL,
    "prediction_data" JSONB NOT NULL,
    "confidence_interval" JSONB NOT NULL,
    "forecast_period" TEXT NOT NULL,
    "actual_outcome" JSONB,
    "accuracy_score" DECIMAL(5,4),
    "generated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "valid_until" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "predictive_analytics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."push_notifications" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID,
    "client_id" UUID,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "notification_type" TEXT NOT NULL,
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "payload" JSONB NOT NULL DEFAULT '{}',
    "device_tokens" JSONB NOT NULL,
    "scheduled_for" TIMESTAMP(3),
    "sent_at" TIMESTAMP(3),
    "delivery_status" JSONB NOT NULL DEFAULT '{}',
    "open_rate" DECIMAL(5,4),
    "click_rate" DECIMAL(5,4),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "push_notifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."voice_processing" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "client_id" UUID,
    "audio_file_url" TEXT NOT NULL,
    "transcription_text" TEXT,
    "processing_status" TEXT NOT NULL DEFAULT 'pending',
    "extracted_data" JSONB,
    "confidence_score" DECIMAL(5,4),
    "language" TEXT NOT NULL DEFAULT 'en-US',
    "duration" INTEGER,
    "processed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "voice_processing_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ocr_processing" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "document_id" UUID NOT NULL,
    "image_url" TEXT NOT NULL,
    "extracted_text" TEXT,
    "structured_data" JSONB,
    "form_type" TEXT,
    "processing_engine" TEXT NOT NULL,
    "confidence_score" DECIMAL(5,4),
    "validation_status" TEXT NOT NULL DEFAULT 'pending',
    "validation_notes" TEXT,
    "real_time_processed" BOOLEAN NOT NULL DEFAULT false,
    "processing_time" INTEGER,
    "processed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ocr_processing_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."same_day_processing" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "premium_fee" DECIMAL(10,2) NOT NULL,
    "guaranteed_deadline" TIMESTAMP(3) NOT NULL,
    "current_stage" TEXT NOT NULL,
    "stage_timestamps" JSONB NOT NULL,
    "assigned_preparer_id" UUID,
    "assigned_reviewer_id" UUID,
    "priority_level" TEXT NOT NULL DEFAULT 'express',
    "sla_met" BOOLEAN,
    "completion_time" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMP(3),

    CONSTRAINT "same_day_processing_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."live_chat_sessions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "ea_cpa_user_id" UUID,
    "session_token" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'waiting',
    "topic" TEXT,
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "wait_time" INTEGER,
    "chat_duration" INTEGER,
    "satisfaction_rating" INTEGER,
    "resolution_status" TEXT,
    "started_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "connected_at" TIMESTAMP(3),
    "ended_at" TIMESTAMP(3),

    CONSTRAINT "live_chat_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."chat_messages" (
    "id" UUID NOT NULL,
    "session_id" UUID NOT NULL,
    "sender_id" UUID NOT NULL,
    "sender_type" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "message_type" TEXT NOT NULL DEFAULT 'text',
    "attachments" JSONB DEFAULT '[]',
    "is_read" BOOLEAN NOT NULL DEFAULT false,
    "read_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."appointment_bookings" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "ea_cpa_user_id" UUID,
    "appointment_type" TEXT NOT NULL,
    "scheduled_for" TIMESTAMP(3) NOT NULL,
    "duration" INTEGER NOT NULL DEFAULT 60,
    "timezone" TEXT NOT NULL DEFAULT 'America/New_York',
    "meeting_type" TEXT NOT NULL,
    "meeting_url" TEXT,
    "meeting_location" TEXT,
    "status" TEXT NOT NULL DEFAULT 'scheduled',
    "reminder_sent" JSONB NOT NULL DEFAULT '[]',
    "notes" TEXT,
    "fee" DECIMAL(10,2),
    "ai_suggested_questions" JSONB,
    "preparation_tasks" JSONB,
    "outcome_notes" TEXT,
    "follow_up_required" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "appointment_bookings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."refund_calculations" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID,
    "session_id" TEXT,
    "calculation_type" TEXT NOT NULL,
    "input_data" JSONB NOT NULL,
    "estimated_refund" DECIMAL(10,2) NOT NULL,
    "confidence_range" JSONB NOT NULL,
    "tax_liability" DECIMAL(10,2) NOT NULL,
    "effective_tax_rate" DECIMAL(5,4) NOT NULL,
    "marginal_tax_rate" DECIMAL(5,4) NOT NULL,
    "deductions_breakdown" JSONB NOT NULL,
    "credits_breakdown" JSONB NOT NULL,
    "assumptions_used" JSONB NOT NULL,
    "accuracy_disclaimer" TEXT NOT NULL,
    "valid_until" TIMESTAMP(3) NOT NULL,
    "actual_refund" DECIMAL(10,2),
    "accuracy_score" DECIMAL(5,4),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "refund_calculations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."subscription_plans" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "plan_name" TEXT NOT NULL,
    "plan_type" TEXT NOT NULL,
    "billing_cycle" TEXT NOT NULL,
    "base_price" DECIMAL(10,2) NOT NULL,
    "setup_fee" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "features" JSONB NOT NULL,
    "limits" JSONB NOT NULL,
    "tier_level" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "trial_period_days" INTEGER NOT NULL DEFAULT 0,
    "max_users" INTEGER,
    "max_tax_returns" INTEGER,
    "included_services" JSONB NOT NULL DEFAULT '[]',
    "add_on_pricing" JSONB NOT NULL DEFAULT '{}',
    "cancellation_policy" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "subscription_plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."subscriptions_enhanced" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "plan_id" UUID NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "current_period_start" TIMESTAMP(3) NOT NULL,
    "current_period_end" TIMESTAMP(3) NOT NULL,
    "trial_start" TIMESTAMP(3),
    "trial_end" TIMESTAMP(3),
    "cancelled_at" TIMESTAMP(3),
    "cancelled_reason" TEXT,
    "paused_at" TIMESTAMP(3),
    "pause_reason" TEXT,
    "usage_metrics" JSONB NOT NULL DEFAULT '{}',
    "last_billing_date" TIMESTAMP(3),
    "next_billing_date" TIMESTAMP(3),
    "proration_credits" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "auto_renew" BOOLEAN NOT NULL DEFAULT true,
    "renewal_reminders" JSONB NOT NULL DEFAULT '[]',
    "customizations" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "subscriptions_enhanced_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."billing_history" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "subscription_id" UUID NOT NULL,
    "billing_date" TIMESTAMP(3) NOT NULL,
    "amount" DECIMAL(10,2) NOT NULL,
    "taxes" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "fees" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "total_amount" DECIMAL(10,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "payment_method" TEXT NOT NULL,
    "payment_status" TEXT NOT NULL,
    "invoice_number" TEXT,
    "invoice_url" TEXT,
    "period_start" TIMESTAMP(3) NOT NULL,
    "period_end" TIMESTAMP(3) NOT NULL,
    "usage_details" JSONB,
    "discounts" JSONB DEFAULT '[]',
    "paid_at" TIMESTAMP(3),
    "failure_reason" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "billing_history_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."biometric_auth" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "biometric_type" TEXT NOT NULL,
    "biometric_hash" TEXT NOT NULL,
    "device_id" TEXT NOT NULL,
    "device_info" JSONB NOT NULL,
    "enrollment_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_used" TIMESTAMP(3),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "failure_count" INTEGER NOT NULL DEFAULT 0,
    "is_locked" BOOLEAN NOT NULL DEFAULT false,
    "lockout_until" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "biometric_auth_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."blockchain_audit_logs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_id" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "actor_id" TEXT NOT NULL,
    "actor_type" TEXT NOT NULL,
    "data_hash" TEXT NOT NULL,
    "previous_hash" TEXT,
    "block_hash" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "nonce" TEXT NOT NULL,
    "digital_signature" TEXT NOT NULL,
    "merkle_root" TEXT,
    "chain_validation" BOOLEAN NOT NULL DEFAULT false,
    "immutable_data" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "blockchain_audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."encryption_keys" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "key_name" TEXT NOT NULL,
    "key_type" TEXT NOT NULL,
    "encrypted_key" TEXT NOT NULL,
    "key_derivation_salt" TEXT NOT NULL,
    "algorithm" TEXT NOT NULL DEFAULT 'AES-256-GCM',
    "key_version" INTEGER NOT NULL DEFAULT 1,
    "rotation_schedule" TEXT,
    "last_rotated" TIMESTAMP(3),
    "next_rotation" TIMESTAMP(3),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "access_log" JSONB NOT NULL DEFAULT '[]',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "encryption_keys_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."video_testimonials" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "video_url" TEXT NOT NULL,
    "thumbnail_url" TEXT,
    "transcription" TEXT,
    "testimonial_type" TEXT NOT NULL,
    "rating" INTEGER NOT NULL,
    "tags" JSONB NOT NULL DEFAULT '[]',
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "verified_by" UUID,
    "is_public" BOOLEAN NOT NULL DEFAULT false,
    "display_order" INTEGER,
    "view_count" INTEGER NOT NULL DEFAULT 0,
    "like_count" INTEGER NOT NULL DEFAULT 0,
    "moderation_status" TEXT NOT NULL DEFAULT 'pending',
    "moderation_notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "video_testimonials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ea_cpa_profiles" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "license_number" TEXT,
    "license_state" TEXT,
    "license_expiry" TIMESTAMP(3),
    "certifications" JSONB NOT NULL DEFAULT '[]',
    "specializations" JSONB NOT NULL DEFAULT '[]',
    "years_experience" INTEGER,
    "education_background" JSONB,
    "professional_photo_url" TEXT,
    "biography" TEXT,
    "languages" JSONB NOT NULL DEFAULT '[]',
    "availability" JSONB NOT NULL DEFAULT '{}',
    "hourly_rate" DECIMAL(10,2),
    "client_rating" DECIMAL(3,2),
    "total_reviews" INTEGER NOT NULL DEFAULT 0,
    "completed_returns" INTEGER NOT NULL DEFAULT 0,
    "average_review_time" INTEGER,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "verification_badges" JSONB NOT NULL DEFAULT '[]',
    "social_links" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ea_cpa_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."client_reviews" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "ea_cpa_profile_id" UUID NOT NULL,
    "tax_return_id" UUID,
    "rating" INTEGER NOT NULL,
    "review_title" TEXT,
    "review_text" TEXT,
    "service_type" TEXT NOT NULL,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "is_public" BOOLEAN NOT NULL DEFAULT true,
    "helpful_count" INTEGER NOT NULL DEFAULT 0,
    "moderation_status" TEXT NOT NULL DEFAULT 'pending',
    "response_from_ea" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "client_reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."service_guarantees" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "guarantee_type" TEXT NOT NULL,
    "guarantee_name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "terms" TEXT NOT NULL,
    "coverage_amount" DECIMAL(10,2),
    "validity_period" TEXT,
    "eligibility_criteria" JSONB NOT NULL,
    "claim_process" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "display_order" INTEGER,
    "icon_url" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "service_guarantees_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."guarantee_claims" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "guarantee_id" UUID NOT NULL,
    "tax_return_id" UUID,
    "claim_amount" DECIMAL(10,2) NOT NULL,
    "claim_reason" TEXT NOT NULL,
    "supporting_documents" JSONB,
    "status" TEXT NOT NULL DEFAULT 'submitted',
    "review_notes" TEXT,
    "approved_amount" DECIMAL(10,2),
    "paid_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "guarantee_claims_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."community_forums" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "forum_name" TEXT NOT NULL,
    "description" TEXT,
    "category" TEXT NOT NULL,
    "is_moderated" BOOLEAN NOT NULL DEFAULT true,
    "moderator_ids" JSONB NOT NULL DEFAULT '[]',
    "is_public" BOOLEAN NOT NULL DEFAULT true,
    "post_count" INTEGER NOT NULL DEFAULT 0,
    "member_count" INTEGER NOT NULL DEFAULT 0,
    "display_order" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "community_forums_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."forum_posts" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "forum_id" UUID NOT NULL,
    "author_id" UUID NOT NULL,
    "author_type" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "is_sticky" BOOLEAN NOT NULL DEFAULT false,
    "is_locked" BOOLEAN NOT NULL DEFAULT false,
    "reply_count" INTEGER NOT NULL DEFAULT 0,
    "view_count" INTEGER NOT NULL DEFAULT 0,
    "like_count" INTEGER NOT NULL DEFAULT 0,
    "last_reply_at" TIMESTAMP(3),
    "moderation_status" TEXT NOT NULL DEFAULT 'published',
    "tags" JSONB NOT NULL DEFAULT '[]',
    "attachments" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "forum_posts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."forum_replies" (
    "id" UUID NOT NULL,
    "post_id" UUID NOT NULL,
    "author_id" UUID NOT NULL,
    "author_type" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "parent_reply_id" UUID,
    "like_count" INTEGER NOT NULL DEFAULT 0,
    "is_accepted_answer" BOOLEAN NOT NULL DEFAULT false,
    "moderation_status" TEXT NOT NULL DEFAULT 'published',
    "attachments" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "forum_replies_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."dual_review_workflows" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "tax_return_id" UUID NOT NULL,
    "workflow_type" TEXT NOT NULL,
    "current_stage" TEXT NOT NULL,
    "ai_review_results" JSONB,
    "ai_confidence_score" DECIMAL(5,4),
    "ai_recommendations" JSONB,
    "human_reviewer_id" UUID,
    "human_review_notes" TEXT,
    "human_overrides" JSONB,
    "discrepancies" JSONB,
    "final_approval_by" UUID,
    "quality_score" DECIMAL(5,4),
    "completion_time" INTEGER,
    "requires_escalation" BOOLEAN NOT NULL DEFAULT false,
    "escalation_reason" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMP(3),

    CONSTRAINT "dual_review_workflows_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ai_learning_data" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "model_type" TEXT NOT NULL,
    "input_data" JSONB NOT NULL,
    "expected_output" JSONB NOT NULL,
    "actual_output" JSONB NOT NULL,
    "human_feedback" JSONB,
    "correctness_score" DECIMAL(5,4),
    "learning_type" TEXT NOT NULL,
    "is_incorporated" BOOLEAN NOT NULL DEFAULT false,
    "incorporation_date" TIMESTAMP(3),
    "contributes_to_model" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ai_learning_data_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."performance_metrics" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "metric_type" TEXT NOT NULL,
    "metric_category" TEXT NOT NULL,
    "metric_name" TEXT NOT NULL,
    "metric_value" DECIMAL(15,6) NOT NULL,
    "target_value" DECIMAL(15,6),
    "thresholds" JSONB,
    "dimensions" JSONB,
    "measurement_period" TEXT NOT NULL,
    "aggregation_type" TEXT NOT NULL,
    "recorded_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "performance_metrics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."referral_programs" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "program_name" TEXT NOT NULL,
    "program_type" TEXT NOT NULL,
    "reward_structure" JSONB NOT NULL,
    "referrer_reward" DECIMAL(10,2) NOT NULL,
    "referee_reward" DECIMAL(10,2) NOT NULL,
    "minimum_qualification" JSONB NOT NULL,
    "gamification_rules" JSONB NOT NULL,
    "badge_system" JSONB NOT NULL,
    "leaderboard_enabled" BOOLEAN NOT NULL DEFAULT true,
    "season_duration" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "referral_programs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."referrals" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "program_id" UUID NOT NULL,
    "referrer_client_id" UUID NOT NULL,
    "referee_email" TEXT NOT NULL,
    "referee_client_id" UUID,
    "referral_code" TEXT NOT NULL,
    "referral_method" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "click_count" INTEGER NOT NULL DEFAULT 0,
    "sign_up_date" TIMESTAMP(3),
    "qualification_date" TIMESTAMP(3),
    "reward_date" TIMESTAMP(3),
    "referrer_reward_amount" DECIMAL(10,2),
    "referee_reward_amount" DECIMAL(10,2),
    "conversion_data" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "referrals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."language_support" (
    "id" UUID NOT NULL,
    "tenant_id" UUID,
    "language_code" TEXT NOT NULL,
    "language_name" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "completion_percentage" DECIMAL(5,2) NOT NULL,
    "default_for_region" JSONB,
    "translation_provider" TEXT,
    "quality_score" DECIMAL(5,4),
    "last_updated" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "language_support_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."translations" (
    "id" UUID NOT NULL,
    "language_id" UUID NOT NULL,
    "translation_key" TEXT NOT NULL,
    "original_text" TEXT NOT NULL,
    "translated_text" TEXT NOT NULL,
    "context" TEXT,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "verified_by" UUID,
    "translation_method" TEXT NOT NULL,
    "quality_score" DECIMAL(5,4),
    "usage_count" INTEGER NOT NULL DEFAULT 0,
    "last_used" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "translations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."franchise_locations" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "location_name" TEXT NOT NULL,
    "franchisee_id" UUID NOT NULL,
    "address" JSONB NOT NULL,
    "service_area" JSONB NOT NULL,
    "operating_status" TEXT NOT NULL DEFAULT 'active',
    "season_dates" JSONB,
    "capacity" JSONB NOT NULL,
    "performance_metrics" JSONB NOT NULL DEFAULT '{}',
    "compliance_status" TEXT NOT NULL DEFAULT 'compliant',
    "last_audit" TIMESTAMP(3),
    "next_audit" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "franchise_locations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."franchise_staff" (
    "id" UUID NOT NULL,
    "location_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "position" TEXT NOT NULL,
    "hire_date" TIMESTAMP(3) NOT NULL,
    "employment_status" TEXT NOT NULL DEFAULT 'active',
    "certifications" JSONB NOT NULL DEFAULT '[]',
    "performance_rating" DECIMAL(3,2),
    "last_training" TIMESTAMP(3),
    "next_training_due" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "franchise_staff_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."bank_partnerships" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "bank_name" TEXT NOT NULL,
    "partnership_type" TEXT NOT NULL,
    "api_credentials" JSONB NOT NULL,
    "commission_structure" JSONB NOT NULL,
    "product_offerings" JSONB NOT NULL,
    "integration_status" TEXT NOT NULL DEFAULT 'active',
    "contract_start" TIMESTAMP(3) NOT NULL,
    "contract_end" TIMESTAMP(3) NOT NULL,
    "performance_metrics" JSONB NOT NULL DEFAULT '{}',
    "compliance_requirements" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bank_partnerships_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."bank_referrals" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "partnership_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "product_type" TEXT NOT NULL,
    "referral_status" TEXT NOT NULL DEFAULT 'pending',
    "application_id" TEXT,
    "commission_amount" DECIMAL(10,2),
    "commission_paid" BOOLEAN NOT NULL DEFAULT false,
    "referral_data" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bank_referrals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."employer_partnerships" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "company_name" TEXT NOT NULL,
    "company_size" TEXT NOT NULL,
    "contact_person" TEXT NOT NULL,
    "contact_email" TEXT NOT NULL,
    "benefit_type" TEXT NOT NULL,
    "discount_percentage" DECIMAL(5,2),
    "employee_count" INTEGER NOT NULL,
    "contract_status" TEXT NOT NULL DEFAULT 'active',
    "onboarding_complete" BOOLEAN NOT NULL DEFAULT false,
    "portal_url" TEXT,
    "custom_branding" JSONB,
    "contract_start" TIMESTAMP(3) NOT NULL,
    "contract_end" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "employer_partnerships_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."employee_enrollments" (
    "id" UUID NOT NULL,
    "partnership_id" UUID NOT NULL,
    "employee_email" TEXT NOT NULL,
    "client_id" UUID,
    "enrollment_status" TEXT NOT NULL DEFAULT 'invited',
    "invite_token" TEXT,
    "registration_date" TIMESTAMP(3),
    "benefits_used" JSONB NOT NULL DEFAULT '[]',
    "total_savings" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "last_activity" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "employee_enrollments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."real_estate_partnerships" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "agent_name" TEXT NOT NULL,
    "brokerage_name" TEXT NOT NULL,
    "license_number" TEXT NOT NULL,
    "contact_info" JSONB NOT NULL,
    "service_areas" JSONB NOT NULL,
    "partnership_tier" TEXT NOT NULL,
    "commission_rate" DECIMAL(5,4) NOT NULL,
    "referral_volume" INTEGER NOT NULL DEFAULT 0,
    "conversion_rate" DECIMAL(5,4),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "join_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_referral" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "real_estate_partnerships_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."real_estate_referrals" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "partnership_id" UUID NOT NULL,
    "client_id" UUID,
    "transaction_type" TEXT NOT NULL,
    "property_value" DECIMAL(12,2),
    "referral_status" TEXT NOT NULL DEFAULT 'referred',
    "commission_amount" DECIMAL(10,2),
    "commission_paid" BOOLEAN NOT NULL DEFAULT false,
    "service_notes" TEXT,
    "completion_date" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "real_estate_referrals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."crypto_integrations" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "exchange_name" TEXT NOT NULL,
    "integration_type" TEXT NOT NULL,
    "api_credentials" JSONB,
    "supported_features" JSONB NOT NULL,
    "tax_reporting_capable" BOOLEAN NOT NULL DEFAULT true,
    "real_time_sync" BOOLEAN NOT NULL DEFAULT false,
    "last_sync_at" TIMESTAMP(3),
    "sync_frequency" TEXT NOT NULL DEFAULT 'daily',
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "error_log" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "crypto_integrations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."crypto_transactions" (
    "id" UUID NOT NULL,
    "tenant_id" UUID NOT NULL,
    "client_id" UUID NOT NULL,
    "integration_id" UUID NOT NULL,
    "transaction_id" TEXT NOT NULL,
    "transaction_type" TEXT NOT NULL,
    "cryptocurrency" TEXT NOT NULL,
    "amount" DECIMAL(18,8) NOT NULL,
    "usd_value" DECIMAL(12,2) NOT NULL,
    "fee_amount" DECIMAL(18,8),
    "fee_usd_value" DECIMAL(12,2),
    "transaction_date" TIMESTAMP(3) NOT NULL,
    "blockchain_hash" TEXT,
    "from_address" TEXT,
    "to_address" TEXT,
    "tax_implications" JSONB,
    "cost_basis" DECIMAL(12,2),
    "gain_loss" DECIMAL(12,2),
    "tax_category" TEXT,
    "is_processed" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "crypto_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "tenants_domain_key" ON "public"."tenants"("domain");

-- CreateIndex
CREATE UNIQUE INDEX "users_cognito_user_id_key" ON "public"."users"("cognito_user_id");

-- CreateIndex
CREATE UNIQUE INDEX "users_tenant_id_email_key" ON "public"."users"("tenant_id", "email");

-- CreateIndex
CREATE UNIQUE INDEX "roles_name_key" ON "public"."roles"("name");

-- CreateIndex
CREATE UNIQUE INDEX "clients_tenant_id_email_key" ON "public"."clients"("tenant_id", "email");

-- CreateIndex
CREATE UNIQUE INDEX "payments_stripe_payment_intent_id_key" ON "public"."payments"("stripe_payment_intent_id");

-- CreateIndex
CREATE UNIQUE INDEX "invoices_payment_id_key" ON "public"."invoices"("payment_id");

-- CreateIndex
CREATE UNIQUE INDEX "invoices_invoice_number_key" ON "public"."invoices"("invoice_number");

-- CreateIndex
CREATE UNIQUE INDEX "leads_tenant_id_email_key" ON "public"."leads"("tenant_id", "email");

-- CreateIndex
CREATE UNIQUE INDEX "subscriptions_tenant_id_key" ON "public"."subscriptions"("tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "system_configs_config_key_tenant_id_key" ON "public"."system_configs"("config_key", "tenant_id");

-- CreateIndex
CREATE UNIQUE INDEX "live_chat_sessions_session_token_key" ON "public"."live_chat_sessions"("session_token");

-- CreateIndex
CREATE UNIQUE INDEX "biometric_auth_user_id_device_id_biometric_type_key" ON "public"."biometric_auth"("user_id", "device_id", "biometric_type");

-- CreateIndex
CREATE INDEX "blockchain_audit_logs_tenant_id_resource_type_resource_id_idx" ON "public"."blockchain_audit_logs"("tenant_id", "resource_type", "resource_id");

-- CreateIndex
CREATE UNIQUE INDEX "encryption_keys_tenant_id_key_name_key_version_key" ON "public"."encryption_keys"("tenant_id", "key_name", "key_version");

-- CreateIndex
CREATE UNIQUE INDEX "ea_cpa_profiles_user_id_key" ON "public"."ea_cpa_profiles"("user_id");

-- CreateIndex
CREATE INDEX "performance_metrics_tenant_id_metric_type_recorded_at_idx" ON "public"."performance_metrics"("tenant_id", "metric_type", "recorded_at");

-- CreateIndex
CREATE UNIQUE INDEX "referrals_referral_code_key" ON "public"."referrals"("referral_code");

-- CreateIndex
CREATE UNIQUE INDEX "language_support_tenant_id_language_code_key" ON "public"."language_support"("tenant_id", "language_code");

-- CreateIndex
CREATE UNIQUE INDEX "translations_language_id_translation_key_key" ON "public"."translations"("language_id", "translation_key");

-- CreateIndex
CREATE UNIQUE INDEX "franchise_staff_location_id_user_id_key" ON "public"."franchise_staff"("location_id", "user_id");

-- CreateIndex
CREATE UNIQUE INDEX "employee_enrollments_invite_token_key" ON "public"."employee_enrollments"("invite_token");

-- CreateIndex
CREATE UNIQUE INDEX "employee_enrollments_partnership_id_employee_email_key" ON "public"."employee_enrollments"("partnership_id", "employee_email");

-- AddForeignKey
ALTER TABLE "public"."users" ADD CONSTRAINT "users_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."roles" ADD CONSTRAINT "roles_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_roles" ADD CONSTRAINT "user_roles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."user_roles" ADD CONSTRAINT "user_roles_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."clients" ADD CONSTRAINT "clients_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."clients" ADD CONSTRAINT "clients_created_by_user_id_fkey" FOREIGN KEY ("created_by_user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_returns" ADD CONSTRAINT "tax_returns_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_returns" ADD CONSTRAINT "tax_returns_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_returns" ADD CONSTRAINT "tax_returns_assigned_preparer_id_fkey" FOREIGN KEY ("assigned_preparer_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_forms" ADD CONSTRAINT "tax_forms_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."documents" ADD CONSTRAINT "documents_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."documents" ADD CONSTRAINT "documents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."documents" ADD CONSTRAINT "documents_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."documents" ADD CONSTRAINT "documents_uploaded_by_user_id_fkey" FOREIGN KEY ("uploaded_by_user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."document_extractions" ADD CONSTRAINT "document_extractions_document_id_fkey" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."document_extractions" ADD CONSTRAINT "document_extractions_verified_by_user_id_fkey" FOREIGN KEY ("verified_by_user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."payments" ADD CONSTRAINT "payments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."payments" ADD CONSTRAINT "payments_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."payments" ADD CONSTRAINT "payments_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."invoices" ADD CONSTRAINT "invoices_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."invoices" ADD CONSTRAINT "invoices_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."invoices" ADD CONSTRAINT "invoices_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."invoices" ADD CONSTRAINT "invoices_payment_id_fkey" FOREIGN KEY ("payment_id") REFERENCES "public"."payments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_products" ADD CONSTRAINT "bank_products_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_products" ADD CONSTRAINT "bank_products_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_products" ADD CONSTRAINT "bank_products_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."identity_verifications" ADD CONSTRAINT "identity_verifications_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."identity_verifications" ADD CONSTRAINT "identity_verifications_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."efile_submissions" ADD CONSTRAINT "efile_submissions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."efile_submissions" ADD CONSTRAINT "efile_submissions_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."efile_status_history" ADD CONSTRAINT "efile_status_history_efile_submission_id_fkey" FOREIGN KEY ("efile_submission_id") REFERENCES "public"."efile_submissions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."review_tasks" ADD CONSTRAINT "review_tasks_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."review_tasks" ADD CONSTRAINT "review_tasks_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."review_tasks" ADD CONSTRAINT "review_tasks_assigned_to_user_id_fkey" FOREIGN KEY ("assigned_to_user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."quality_checks" ADD CONSTRAINT "quality_checks_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."quality_checks" ADD CONSTRAINT "quality_checks_performed_by_user_id_fkey" FOREIGN KEY ("performed_by_user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."notifications" ADD CONSTRAINT "notifications_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."notifications" ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."notifications" ADD CONSTRAINT "notifications_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."communication_logs" ADD CONSTRAINT "communication_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."communication_logs" ADD CONSTRAINT "communication_logs_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."leads" ADD CONSTRAINT "leads_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."marketing_campaigns" ADD CONSTRAINT "marketing_campaigns_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."subscriptions" ADD CONSTRAINT "subscriptions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."usage_metrics" ADD CONSTRAINT "usage_metrics_subscription_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."payouts" ADD CONSTRAINT "payouts_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."payouts" ADD CONSTRAINT "payouts_subscription_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."revenue_shares" ADD CONSTRAINT "revenue_shares_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."revenue_shares" ADD CONSTRAINT "revenue_shares_payment_id_fkey" FOREIGN KEY ("payment_id") REFERENCES "public"."payments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."revenue_shares" ADD CONSTRAINT "revenue_shares_payout_id_fkey" FOREIGN KEY ("payout_id") REFERENCES "public"."payouts"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."audit_logs" ADD CONSTRAINT "audit_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."consent_records" ADD CONSTRAINT "consent_records_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."consent_records" ADD CONSTRAINT "consent_records_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."system_configs" ADD CONSTRAINT "system_configs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."system_configs" ADD CONSTRAINT "system_configs_updated_by_fkey" FOREIGN KEY ("updated_by") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ai_model_data" ADD CONSTRAINT "ai_model_data_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."deduction_suggestions" ADD CONSTRAINT "deduction_suggestions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."deduction_suggestions" ADD CONSTRAINT "deduction_suggestions_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."deduction_suggestions" ADD CONSTRAINT "deduction_suggestions_ai_model_id_fkey" FOREIGN KEY ("ai_model_id") REFERENCES "public"."ai_model_data"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_optimization_suggestions" ADD CONSTRAINT "tax_optimization_suggestions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."tax_optimization_suggestions" ADD CONSTRAINT "tax_optimization_suggestions_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ai_processing_logs" ADD CONSTRAINT "ai_processing_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ai_processing_logs" ADD CONSTRAINT "ai_processing_logs_model_id_fkey" FOREIGN KEY ("model_id") REFERENCES "public"."ai_model_data"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."predictive_analytics" ADD CONSTRAINT "predictive_analytics_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."predictive_analytics" ADD CONSTRAINT "predictive_analytics_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."push_notifications" ADD CONSTRAINT "push_notifications_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."push_notifications" ADD CONSTRAINT "push_notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."push_notifications" ADD CONSTRAINT "push_notifications_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."voice_processing" ADD CONSTRAINT "voice_processing_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."voice_processing" ADD CONSTRAINT "voice_processing_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."voice_processing" ADD CONSTRAINT "voice_processing_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ocr_processing" ADD CONSTRAINT "ocr_processing_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ocr_processing" ADD CONSTRAINT "ocr_processing_document_id_fkey" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."same_day_processing" ADD CONSTRAINT "same_day_processing_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."same_day_processing" ADD CONSTRAINT "same_day_processing_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."same_day_processing" ADD CONSTRAINT "same_day_processing_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."live_chat_sessions" ADD CONSTRAINT "live_chat_sessions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."live_chat_sessions" ADD CONSTRAINT "live_chat_sessions_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."live_chat_sessions" ADD CONSTRAINT "live_chat_sessions_ea_cpa_user_id_fkey" FOREIGN KEY ("ea_cpa_user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."chat_messages" ADD CONSTRAINT "chat_messages_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "public"."live_chat_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."appointment_bookings" ADD CONSTRAINT "appointment_bookings_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."appointment_bookings" ADD CONSTRAINT "appointment_bookings_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."appointment_bookings" ADD CONSTRAINT "appointment_bookings_ea_cpa_user_id_fkey" FOREIGN KEY ("ea_cpa_user_id") REFERENCES "public"."users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."refund_calculations" ADD CONSTRAINT "refund_calculations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."refund_calculations" ADD CONSTRAINT "refund_calculations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."subscription_plans" ADD CONSTRAINT "subscription_plans_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."subscriptions_enhanced" ADD CONSTRAINT "subscriptions_enhanced_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."subscriptions_enhanced" ADD CONSTRAINT "subscriptions_enhanced_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."subscriptions_enhanced" ADD CONSTRAINT "subscriptions_enhanced_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "public"."subscription_plans"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."billing_history" ADD CONSTRAINT "billing_history_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."billing_history" ADD CONSTRAINT "billing_history_subscription_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions_enhanced"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."biometric_auth" ADD CONSTRAINT "biometric_auth_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."biometric_auth" ADD CONSTRAINT "biometric_auth_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."blockchain_audit_logs" ADD CONSTRAINT "blockchain_audit_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."encryption_keys" ADD CONSTRAINT "encryption_keys_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."video_testimonials" ADD CONSTRAINT "video_testimonials_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."video_testimonials" ADD CONSTRAINT "video_testimonials_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ea_cpa_profiles" ADD CONSTRAINT "ea_cpa_profiles_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ea_cpa_profiles" ADD CONSTRAINT "ea_cpa_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."client_reviews" ADD CONSTRAINT "client_reviews_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."client_reviews" ADD CONSTRAINT "client_reviews_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."client_reviews" ADD CONSTRAINT "client_reviews_ea_cpa_profile_id_fkey" FOREIGN KEY ("ea_cpa_profile_id") REFERENCES "public"."ea_cpa_profiles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."client_reviews" ADD CONSTRAINT "client_reviews_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."service_guarantees" ADD CONSTRAINT "service_guarantees_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."guarantee_claims" ADD CONSTRAINT "guarantee_claims_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."guarantee_claims" ADD CONSTRAINT "guarantee_claims_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."guarantee_claims" ADD CONSTRAINT "guarantee_claims_guarantee_id_fkey" FOREIGN KEY ("guarantee_id") REFERENCES "public"."service_guarantees"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."guarantee_claims" ADD CONSTRAINT "guarantee_claims_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."community_forums" ADD CONSTRAINT "community_forums_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."forum_posts" ADD CONSTRAINT "forum_posts_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."forum_posts" ADD CONSTRAINT "forum_posts_forum_id_fkey" FOREIGN KEY ("forum_id") REFERENCES "public"."community_forums"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."forum_replies" ADD CONSTRAINT "forum_replies_post_id_fkey" FOREIGN KEY ("post_id") REFERENCES "public"."forum_posts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."forum_replies" ADD CONSTRAINT "forum_replies_parent_reply_id_fkey" FOREIGN KEY ("parent_reply_id") REFERENCES "public"."forum_replies"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."dual_review_workflows" ADD CONSTRAINT "dual_review_workflows_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."dual_review_workflows" ADD CONSTRAINT "dual_review_workflows_tax_return_id_fkey" FOREIGN KEY ("tax_return_id") REFERENCES "public"."tax_returns"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ai_learning_data" ADD CONSTRAINT "ai_learning_data_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."performance_metrics" ADD CONSTRAINT "performance_metrics_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."referral_programs" ADD CONSTRAINT "referral_programs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."referrals" ADD CONSTRAINT "referrals_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."referrals" ADD CONSTRAINT "referrals_program_id_fkey" FOREIGN KEY ("program_id") REFERENCES "public"."referral_programs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."referrals" ADD CONSTRAINT "referrals_referrer_client_id_fkey" FOREIGN KEY ("referrer_client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."referrals" ADD CONSTRAINT "referrals_referee_client_id_fkey" FOREIGN KEY ("referee_client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."language_support" ADD CONSTRAINT "language_support_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."translations" ADD CONSTRAINT "translations_language_id_fkey" FOREIGN KEY ("language_id") REFERENCES "public"."language_support"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."franchise_locations" ADD CONSTRAINT "franchise_locations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."franchise_locations" ADD CONSTRAINT "franchise_locations_franchisee_id_fkey" FOREIGN KEY ("franchisee_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."franchise_staff" ADD CONSTRAINT "franchise_staff_location_id_fkey" FOREIGN KEY ("location_id") REFERENCES "public"."franchise_locations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."franchise_staff" ADD CONSTRAINT "franchise_staff_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_partnerships" ADD CONSTRAINT "bank_partnerships_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_referrals" ADD CONSTRAINT "bank_referrals_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_referrals" ADD CONSTRAINT "bank_referrals_partnership_id_fkey" FOREIGN KEY ("partnership_id") REFERENCES "public"."bank_partnerships"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."bank_referrals" ADD CONSTRAINT "bank_referrals_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."employer_partnerships" ADD CONSTRAINT "employer_partnerships_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."employee_enrollments" ADD CONSTRAINT "employee_enrollments_partnership_id_fkey" FOREIGN KEY ("partnership_id") REFERENCES "public"."employer_partnerships"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."employee_enrollments" ADD CONSTRAINT "employee_enrollments_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."real_estate_partnerships" ADD CONSTRAINT "real_estate_partnerships_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."real_estate_referrals" ADD CONSTRAINT "real_estate_referrals_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."real_estate_referrals" ADD CONSTRAINT "real_estate_referrals_partnership_id_fkey" FOREIGN KEY ("partnership_id") REFERENCES "public"."real_estate_partnerships"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."real_estate_referrals" ADD CONSTRAINT "real_estate_referrals_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."crypto_integrations" ADD CONSTRAINT "crypto_integrations_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."crypto_transactions" ADD CONSTRAINT "crypto_transactions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."crypto_transactions" ADD CONSTRAINT "crypto_transactions_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."crypto_transactions" ADD CONSTRAINT "crypto_transactions_integration_id_fkey" FOREIGN KEY ("integration_id") REFERENCES "public"."crypto_integrations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
