
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  FileText,
  TrendingUp,
  Zap,
  Target,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3,
  Lightbulb,
  Star,
} from 'lucide-react';

interface AIDashboardProps {
  tenantId: string;
  userRole: string;
}

interface AIInsight {
  id: string;
  type: string;
  title: string;
  description: string;
  impact: number;
  confidence: number;
  status: string;
  createdAt: string;
}

interface AIMetrics {
  totalProcessed: number;
  averageConfidence: number;
  potentialSavings: number;
  processingTime: number;
  accuracy: number;
  trendsData: any[];
}

export function AIDashboard({ tenantId, userRole }: AIDashboardProps) {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [metrics, setMetrics] = useState<AIMetrics | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAIData();
  }, [tenantId]);

  const fetchAIData = async () => {
    try {
      setLoading(true);

      // Fetch AI insights and metrics
      const [insightsRes, metricsRes] = await Promise.all([
        fetch('/api/ai/predictive-analytics?analysisType=overview'),
        fetch('/api/ai/performance-metrics'),
      ]);

      if (insightsRes.ok) {
        const data = await insightsRes.json();
        setInsights(data.analytics || []);
      }

      if (metricsRes.ok) {
        const data = await metricsRes.json();
        setMetrics(data.metrics);
      }
    } catch (error) {
      console.error('Error fetching AI data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'deduction_discovery': return <Target className="h-5 w-5" />;
      case 'tax_optimization': return <TrendingUp className="h-5 w-5" />;
      case 'document_analysis': return <FileText className="h-5 w-5" />;
      case 'audit_risk': return <AlertTriangle className="h-5 w-5" />;
      default: return <Brain className="h-5 w-5" />;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600 bg-green-100';
    if (confidence >= 0.6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center space-x-3">
          <Brain className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">AI Intelligence Center</h1>
        </div>
        
        <div className="flex space-x-2">
          {['overview', 'insights', 'performance'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === tab
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </motion.div>

      {/* AI Metrics Cards */}
      {metrics && (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Documents Processed</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.totalProcessed.toLocaleString()}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
            <div className="mt-4 flex items-center text-sm text-green-600">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span>+23% this month</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Average Confidence</p>
                <p className="text-2xl font-bold text-gray-900">{Math.round(metrics.averageConfidence * 100)}%</p>
              </div>
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
            <div className="mt-4">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-yellow-600 h-2 rounded-full" 
                  style={{ width: `${metrics.averageConfidence * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Potential Savings</p>
                <p className="text-2xl font-bold text-gray-900">${metrics.potentialSavings.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
            <div className="mt-4 flex items-center text-sm text-green-600">
              <Zap className="h-4 w-4 mr-1" />
              <span>AI-discovered</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Processing Speed</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.processingTime}s</p>
              </div>
              <Clock className="h-8 w-8 text-purple-600" />
            </div>
            <div className="mt-4 flex items-center text-sm text-purple-600">
              <Zap className="h-4 w-4 mr-1" />
              <span>Avg per document</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Tab Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* AI Insights Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Lightbulb className="h-5 w-5 mr-2 text-yellow-600" />
                  Recent AI Insights
                </h3>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {insights.slice(0, 5).map((insight, index) => (
                    <motion.div
                      key={insight.id}
                      className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          {getInsightIcon(insight.type)}
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{insight.title}</h4>
                            <p className="text-sm text-gray-600 mt-1">{insight.description}</p>
                            <div className="flex items-center mt-2 space-x-4">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getConfidenceColor(insight.confidence)}`}>
                                {Math.round(insight.confidence * 100)}% Confidence
                              </span>
                              {insight.impact > 0 && (
                                <span className="text-sm text-green-600">
                                  ${insight.impact.toLocaleString()} impact
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className={`p-1 rounded-full ${
                          insight.status === 'implemented' ? 'bg-green-100' : 'bg-yellow-100'
                        }`}>
                          {insight.status === 'implemented' ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <Clock className="h-4 w-4 text-yellow-600" />
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* AI Performance Chart */}
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
                  AI Performance Trends
                </h3>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  {/* Placeholder for chart - in real app would use recharts */}
                  <div className="text-center">
                    <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p>Performance chart would be displayed here</p>
                    <p className="text-sm">Accuracy: {Math.round((metrics?.accuracy || 0.85) * 100)}%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 rounded-xl shadow-lg text-white">
              <h3 className="text-xl font-semibold mb-4">AI Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button className="bg-white/20 hover:bg-white/30 p-4 rounded-lg transition-colors backdrop-blur-sm">
                  <FileText className="h-6 w-6 mb-2" />
                  <p className="font-medium">Analyze Documents</p>
                  <p className="text-sm opacity-90">Process new uploads</p>
                </button>
                <button className="bg-white/20 hover:bg-white/30 p-4 rounded-lg transition-colors backdrop-blur-sm">
                  <Target className="h-6 w-6 mb-2" />
                  <p className="font-medium">Discover Deductions</p>
                  <p className="text-sm opacity-90">Find missed opportunities</p>
                </button>
                <button className="bg-white/20 hover:bg-white/30 p-4 rounded-lg transition-colors backdrop-blur-sm">
                  <TrendingUp className="h-6 w-6 mb-2" />
                  <p className="font-medium">Optimize Returns</p>
                  <p className="text-sm opacity-90">Maximize refunds</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'insights' && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">AI-Generated Insights</h3>
            {insights.map((insight, index) => (
              <motion.div
                key={insight.id}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    {getInsightIcon(insight.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-lg font-semibold text-gray-900">{insight.title}</h4>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getConfidenceColor(insight.confidence)}`}>
                        {Math.round(insight.confidence * 100)}% Confidence
                      </span>
                    </div>
                    <p className="text-gray-600 mt-2">{insight.description}</p>
                    <div className="mt-4 flex items-center space-x-6">
                      {insight.impact > 0 && (
                        <div className="flex items-center text-green-600">
                          <DollarSign className="h-4 w-4 mr-1" />
                          <span className="font-medium">${insight.impact.toLocaleString()} potential impact</span>
                        </div>
                      )}
                      <div className="flex items-center text-gray-500">
                        <Clock className="h-4 w-4 mr-1" />
                        <span className="text-sm">
                          {new Date(insight.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'performance' && (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900">AI Performance Metrics</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <h4 className="font-medium text-gray-900 mb-4">Model Accuracy</h4>
                <div className="space-y-4">
                  {[
                    { name: 'Document Extraction', accuracy: 0.94 },
                    { name: 'Deduction Discovery', accuracy: 0.87 },
                    { name: 'Tax Optimization', accuracy: 0.91 },
                    { name: 'Risk Assessment', accuracy: 0.89 },
                  ].map((model) => (
                    <div key={model.name} className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{model.name}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${model.accuracy * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900">
                          {Math.round(model.accuracy * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <h4 className="font-medium text-gray-900 mb-4">Processing Volume</h4>
                <div className="h-48 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                    <p>Volume trends chart</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
