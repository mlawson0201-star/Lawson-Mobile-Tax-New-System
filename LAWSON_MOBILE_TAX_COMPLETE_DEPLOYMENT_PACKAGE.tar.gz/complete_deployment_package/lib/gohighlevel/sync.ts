
import { prisma } from '@/lib/prisma';
import { createGoHighLevelClient, GoHighLevelContact, GoHighLevelAppointment } from './client';
import { LeadStatus, LeadSource, CommunicationType } from '@prisma/client';

export interface SyncResult {
  success: boolean;
  contactsSynced: number;
  appointmentsSynced: number;
  messagesSynced: number;
  errors: string[];
}

export class GoHighLevelSyncService {
  private tenantId: string;

  constructor(tenantId: string) {
    this.tenantId = tenantId;
  }

  async syncAll(): Promise<SyncResult> {
    const result: SyncResult = {
      success: true,
      contactsSynced: 0,
      appointmentsSynced: 0,
      messagesSynced: 0,
      errors: [],
    };

    try {
      const client = await createGoHighLevelClient(this.tenantId);
      if (!client) {
        result.success = false;
        result.errors.push('GoHighLevel client not configured');
        return result;
      }

      // Sync contacts
      const contactsResult = await this.syncContacts(client);
      result.contactsSynced = contactsResult.synced;
      result.errors.push(...contactsResult.errors);

      // Sync appointments
      const appointmentsResult = await this.syncAppointments(client);
      result.appointmentsSynced = appointmentsResult.synced;
      result.errors.push(...appointmentsResult.errors);

      // Update last sync timestamp
      await prisma.gohighlevel_settings.update({
        where: { tenant_id: this.tenantId },
        data: { last_sync_at: new Date() },
      });

      result.success = result.errors.length === 0;
    } catch (error) {
      console.error('Sync error:', error);
      result.success = false;
      result.errors.push(`Sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async syncContacts(client: any): Promise<{ synced: number; errors: string[] }> {
    const result = { synced: 0, errors: [] as string[] };

    try {
      // Get settings to check if contact sync is enabled
      const settings = await prisma.gohighlevel_settings.findUnique({
        where: { tenant_id: this.tenantId },
      });

      if (!settings?.sync_contacts) {
        return result;
      }

      // Get contacts from GoHighLevel (this would need pagination in production)
      const ghlContacts = await this.getGoHighLevelContacts(client);

      for (const ghlContact of ghlContacts) {
        try {
          await this.syncContact(ghlContact, settings);
          result.synced++;
        } catch (error) {
          console.error(`Error syncing contact ${ghlContact.id}:`, error);
          result.errors.push(`Contact ${ghlContact.email}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
    } catch (error) {
      console.error('Error in syncContacts:', error);
      result.errors.push(`Contact sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async syncContact(ghlContact: GoHighLevelContact, settings: any): Promise<void> {
    if (!ghlContact.id || !ghlContact.email) {
      throw new Error('Invalid contact data from GoHighLevel');
    }

    // Check if contact already exists
    let existingLead = await prisma.crm_leads.findFirst({
      where: {
        tenant_id: this.tenantId,
        OR: [
          { gohighlevel_contact_id: ghlContact.id },
          { email: ghlContact.email },
        ],
      },
    });

    const leadData = {
      first_name: ghlContact.firstName || '',
      last_name: ghlContact.lastName || '',
      email: ghlContact.email,
      phone: ghlContact.phone || null,
      company: ghlContact.customFields?.company || null,
      source: this.mapLeadSource(ghlContact.source),
      gohighlevel_contact_id: ghlContact.id,
      tags: ghlContact.tags || [],
      custom_fields: ghlContact.customFields || {},
      pipeline_stage_id: settings.default_pipeline_stage_id,
      updated_at: new Date(),
    };

    if (existingLead) {
      // Update existing lead
      await prisma.crm_leads.update({
        where: { id: existingLead.id },
        data: leadData,
      });
    } else {
      // Create new lead
      await prisma.crm_leads.create({
        data: {
          ...leadData,
          tenant_id: this.tenantId,
          status: LeadStatus.NEW,
          created_at: new Date(),
        },
      });
    }
  }

  private async syncAppointments(client: any): Promise<{ synced: number; errors: string[] }> {
    const result = { synced: 0, errors: [] as string[] };

    try {
      const settings = await prisma.gohighlevel_settings.findUnique({
        where: { tenant_id: this.tenantId },
      });

      if (!settings?.sync_appointments) {
        return result;
      }

      // Get appointments from the last 30 days
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30);
      
      const ghlAppointments = await client.getAppointments(
        undefined,
        startDate.toISOString(),
        undefined
      );

      for (const ghlAppointment of ghlAppointments) {
        try {
          await this.syncAppointment(ghlAppointment);
          result.synced++;
        } catch (error) {
          console.error(`Error syncing appointment ${ghlAppointment.id}:`, error);
          result.errors.push(`Appointment ${ghlAppointment.id}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
    } catch (error) {
      console.error('Error in syncAppointments:', error);
      result.errors.push(`Appointment sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async syncAppointment(ghlAppointment: GoHighLevelAppointment): Promise<void> {
    if (!ghlAppointment.id || !ghlAppointment.contactId) {
      throw new Error('Invalid appointment data from GoHighLevel');
    }

    // Find the corresponding lead
    const lead = await prisma.crm_leads.findFirst({
      where: {
        tenant_id: this.tenantId,
        gohighlevel_contact_id: ghlAppointment.contactId,
      },
    });

    if (!lead) {
      console.warn(`No lead found for GoHighLevel contact ${ghlAppointment.contactId}`);
      return;
    }

    // Check if appointment already exists
    const existingAppointment = await prisma.crm_appointments.findFirst({
      where: {
        tenant_id: this.tenantId,
        gohighlevel_appointment_id: ghlAppointment.id,
      },
    });

    const appointmentData = {
      lead_id: lead.id,
      title: ghlAppointment.title || 'GoHighLevel Appointment',
      description: ghlAppointment.notes || null,
      start_time: new Date(ghlAppointment.startTime),
      end_time: new Date(ghlAppointment.endTime),
      status: ghlAppointment.appointmentStatus || 'SCHEDULED',
      gohighlevel_appointment_id: ghlAppointment.id,
      updated_at: new Date(),
    };

    if (existingAppointment) {
      await prisma.crm_appointments.update({
        where: { id: existingAppointment.id },
        data: appointmentData,
      });
    } else {
      await prisma.crm_appointments.create({
        data: {
          ...appointmentData,
          tenant_id: this.tenantId,
          created_at: new Date(),
        },
      });
    }
  }

  private async getGoHighLevelContacts(client: any): Promise<GoHighLevelContact[]> {
    // In a real implementation, this would handle pagination
    // For now, we'll get a limited set of contacts
    try {
      return await client.searchContacts('', 100);
    } catch (error) {
      console.error('Error fetching GoHighLevel contacts:', error);
      return [];
    }
  }

  private mapLeadSource(ghlSource?: string): LeadSource {
    if (!ghlSource) return LeadSource.GOHIGHLEVEL;

    const sourceMap: Record<string, LeadSource> = {
      'website': LeadSource.WEBSITE,
      'referral': LeadSource.REFERRAL,
      'social': LeadSource.SOCIAL_MEDIA,
      'facebook': LeadSource.FACEBOOK_ADS,
      'google': LeadSource.GOOGLE_ADS,
      'phone': LeadSource.PHONE,
      'email': LeadSource.EMAIL,
    };

    const normalizedSource = ghlSource.toLowerCase();
    return sourceMap[normalizedSource] || LeadSource.GOHIGHLEVEL;
  }

  // Push local leads to GoHighLevel
  async pushLeadToGoHighLevel(leadId: string): Promise<boolean> {
    try {
      const client = await createGoHighLevelClient(this.tenantId);
      if (!client) {
        throw new Error('GoHighLevel client not configured');
      }

      const lead = await prisma.crm_leads.findUnique({
        where: { id: leadId },
      });

      if (!lead) {
        throw new Error('Lead not found');
      }

      // Skip if already synced
      if (lead.gohighlevel_contact_id) {
        return true;
      }

      const ghlContact: GoHighLevelContact = {
        firstName: lead.first_name,
        lastName: lead.last_name,
        email: lead.email,
        phone: lead.phone || undefined,
        source: lead.source.toLowerCase(),
        tags: lead.tags || [],
        customFields: {
          ...lead.custom_fields,
          lawsonMobileTaxLeadId: lead.id,
          leadStatus: lead.status,
        },
      };

      const createdContact = await client.createContact(ghlContact);

      // Update lead with GoHighLevel contact ID
      await prisma.crm_leads.update({
        where: { id: leadId },
        data: {
          gohighlevel_contact_id: createdContact.id,
          updated_at: new Date(),
        },
      });

      return true;
    } catch (error) {
      console.error('Error pushing lead to GoHighLevel:', error);
      return false;
    }
  }

  // Update GoHighLevel contact when lead changes
  async updateGoHighLevelContact(leadId: string): Promise<boolean> {
    try {
      const client = await createGoHighLevelClient(this.tenantId);
      if (!client) {
        return false;
      }

      const lead = await prisma.crm_leads.findUnique({
        where: { id: leadId },
      });

      if (!lead || !lead.gohighlevel_contact_id) {
        return false;
      }

      const updates: Partial<GoHighLevelContact> = {
        firstName: lead.first_name,
        lastName: lead.last_name,
        email: lead.email,
        phone: lead.phone || undefined,
        tags: lead.tags || [],
        customFields: {
          ...lead.custom_fields,
          leadStatus: lead.status,
          lastUpdated: new Date().toISOString(),
        },
      };

      await client.updateContact(lead.gohighlevel_contact_id, updates);
      return true;
    } catch (error) {
      console.error('Error updating GoHighLevel contact:', error);
      return false;
    }
  }
}

// Utility function to create sync service
export function createSyncService(tenantId: string): GoHighLevelSyncService {
  return new GoHighLevelSyncService(tenantId);
}
