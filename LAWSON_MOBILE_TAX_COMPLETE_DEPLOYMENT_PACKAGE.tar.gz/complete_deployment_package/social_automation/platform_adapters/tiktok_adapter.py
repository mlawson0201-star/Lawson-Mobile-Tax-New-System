
"""
TikTok adapter using Content Posting API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class TikTokAdapter(BasePlatformAdapter):
    """Adapter for TikTok using Content Posting API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.client_key = credentials.get('client_key')
        self.client_secret = credentials.get('client_secret')
        self.base_url = "https://open.tiktokapis.com/v2"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            url = f"{self.base_url}/user/info/"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                user_info = response.json()
                data = user_info.get('data', {})
                user = data.get('user', {})
                logger.info(f"Authenticated as: {user.get('display_name', 'Unknown')}")
                return True
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post content to TikTok"""
        try:
            if not media_urls or len(media_urls) == 0:
                return {"success": False, "error": "TikTok requires video content"}
            
            # Format caption with hashtags
            caption = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                caption = f"{content} {hashtag_text}"
            
            # TikTok allows up to 2200 characters for captions
            caption = self.validate_content_length(caption, 2200)
            
            # First, upload the video
            video_url = media_urls[0]  # TikTok posts are primarily video
            upload_result = await self._upload_video(video_url)
            
            if not upload_result.get('success'):
                return upload_result
            
            # Create the post
            url = f"{self.base_url}/post/publish/video/init/"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            post_data = {
                'post_info': {
                    'title': caption,
                    'privacy_level': kwargs.get('privacy_level', 'SELF_ONLY'),  # PUBLIC_TO_EVERYONE, MUTUAL_FOLLOW_FRIENDS, SELF_ONLY
                    'disable_duet': kwargs.get('disable_duet', False),
                    'disable_comment': kwargs.get('disable_comment', False),
                    'disable_stitch': kwargs.get('disable_stitch', False),
                    'video_cover_timestamp_ms': kwargs.get('cover_timestamp', 1000)
                },
                'source_info': {
                    'source': 'FILE_UPLOAD',
                    'video_size': upload_result.get('video_size', 0),
                    'chunk_size': upload_result.get('chunk_size', 0),
                    'total_chunk_count': upload_result.get('total_chunks', 1)
                }
            }
            
            response = requests.post(url, headers=headers, json=post_data)
            
            if response.status_code == 200:
                result = response.json()
                data = result.get('data', {})
                
                if result.get('error', {}).get('code') == 'ok':
                    return {
                        "success": True,
                        "post_id": data.get('publish_id'),
                        "upload_url": data.get('upload_url'),
                        "platform_response": result
                    }
                else:
                    error_msg = result.get('error', {}).get('message', 'Unknown error')
                    return {"success": False, "error": error_msg}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
                
        except Exception as e:
            logger.error(f"Error posting to TikTok: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def _upload_video(self, video_url: str) -> Dict[str, Any]:
        """Upload video to TikTok"""
        try:
            # This is a simplified version - actual implementation would need:
            # 1. Download video from URL
            # 2. Get video metadata (size, duration, etc.)
            # 3. Upload in chunks if needed
            
            # For now, return mock success
            return {
                "success": True,
                "video_size": 1024000,  # Mock size
                "chunk_size": 1024000,
                "total_chunks": 1
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a TikTok post"""
        try:
            # TikTok API doesn't support native scheduling
            # This would be handled by our internal scheduler
            
            return {
                "success": True,
                "message": "TikTok post scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "TikTok API doesn't support native scheduling"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a TikTok post"""
        try:
            url = f"{self.base_url}/video/list/"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            params = {
                'fields': 'id,title,video_description,duration,cover_image_url,create_time,view_count,like_count,comment_count,share_count'
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                data = result.get('data', {})
                videos = data.get('videos', [])
                
                # Find the specific video by post_id
                video_data = None
                for video in videos:
                    if video.get('id') == post_id:
                        video_data = video
                        break
                
                if video_data:
                    analytics = {
                        "post_id": post_id,
                        "views": video_data.get('view_count', 0),
                        "likes": video_data.get('like_count', 0),
                        "comments": video_data.get('comment_count', 0),
                        "shares": video_data.get('share_count', 0),
                        "created_time": video_data.get('create_time'),
                        "title": video_data.get('title', ''),
                        "duration": video_data.get('duration', 0)
                    }
                    
                    return {"success": True, "analytics": analytics}
                else:
                    return {"success": False, "error": "Video not found"}
            else:
                error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a TikTok post"""
        try:
            url = f"{self.base_url}/post/publish/video/delete/"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            data = {'video_id': post_id}
            response = requests.post(url, headers=headers, json=data)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('error', {}).get('code') == 'ok'
            
            return False
            
        except Exception as e:
            logger.error(f"Error deleting TikTok post: {str(e)}")
            return False
    
    async def upload_draft(self, content: str, media_urls: List[str] = None,
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Upload content as draft to TikTok"""
        try:
            if not media_urls or len(media_urls) == 0:
                return {"success": False, "error": "TikTok requires video content"}
            
            # Format caption with hashtags
            caption = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                caption = f"{content} {hashtag_text}"
            
            caption = self.validate_content_length(caption, 2200)
            
            # Upload as draft (similar to post_content but with draft flag)
            url = f"{self.base_url}/post/publish/video/init/"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            post_data = {
                'post_info': {
                    'title': caption,
                    'privacy_level': 'SELF_ONLY',  # Draft mode
                    'auto_add_music': kwargs.get('auto_add_music', False)
                },
                'source_info': {
                    'source': 'FILE_UPLOAD'
                }
            }
            
            response = requests.post(url, headers=headers, json=post_data)
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "draft_id": result.get('data', {}).get('publish_id'),
                    "message": "Video uploaded as draft",
                    "platform_response": result
                }
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
