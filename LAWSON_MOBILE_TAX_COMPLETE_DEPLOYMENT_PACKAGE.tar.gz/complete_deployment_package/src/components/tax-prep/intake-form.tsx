
'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from 'react-hot-toast'

const intakeSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().optional(),
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  ssn: z.string().regex(/^\d{3}-\d{2}-\d{4}$/, 'SSN must be in format XXX-XX-XXXX'),
  filingStatus: z.enum(['SINGLE', 'MARRIED_FILING_JOINTLY', 'MARRIED_FILING_SEPARATELY', 'HEAD_OF_HOUSEHOLD', 'QUALIFYING_WIDOW']),
  address: z.object({
    street: z.string().min(1, 'Street address is required'),
    city: z.string().min(1, 'City is required'),
    state: z.string().min(2, 'State is required'),
    zipCode: z.string().regex(/^\d{5}(-\d{4})?$/, 'Valid ZIP code is required'),
  }),
  spouseInfo: z.object({
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    ssn: z.string().optional(),
    dateOfBirth: z.string().optional(),
  }).optional(),
})

type IntakeFormData = z.infer<typeof intakeSchema>

interface IntakeFormProps {
  onSubmit: (data: IntakeFormData) => void
  isLoading?: boolean
}

export function IntakeForm({ onSubmit, isLoading }: IntakeFormProps) {
  const [step, setStep] = useState(1)
  const totalSteps = 3

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<IntakeFormData>({
    resolver: zodResolver(intakeSchema),
  })

  const filingStatus = watch('filingStatus')
  const isMarried = filingStatus === 'MARRIED_FILING_JOINTLY' || filingStatus === 'MARRIED_FILING_SEPARATELY'

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1)
    }
  }

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const onFormSubmit = (data: IntakeFormData) => {
    onSubmit(data)
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Tax Return Intake - Step {step} of {totalSteps}</CardTitle>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Personal Information</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    {...register('firstName')}
                    className={errors.firstName ? 'border-red-500' : ''}
                  />
                  {errors.firstName && (
                    <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    {...register('lastName')}
                    className={errors.lastName ? 'border-red-500' : ''}
                  />
                  {errors.lastName && (
                    <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  className={errors.email ? 'border-red-500' : ''}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="phone">Phone (Optional)</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...register('phone')}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    {...register('dateOfBirth')}
                    className={errors.dateOfBirth ? 'border-red-500' : ''}
                  />
                  {errors.dateOfBirth && (
                    <p className="text-red-500 text-sm mt-1">{errors.dateOfBirth.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="ssn">Social Security Number</Label>
                  <Input
                    id="ssn"
                    placeholder="XXX-XX-XXXX"
                    {...register('ssn')}
                    className={errors.ssn ? 'border-red-500' : ''}
                  />
                  {errors.ssn && (
                    <p className="text-red-500 text-sm mt-1">{errors.ssn.message}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="filingStatus">Filing Status</Label>
                <Select onValueChange={(value) => setValue('filingStatus', value as any)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select filing status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SINGLE">Single</SelectItem>
                    <SelectItem value="MARRIED_FILING_JOINTLY">Married Filing Jointly</SelectItem>
                    <SelectItem value="MARRIED_FILING_SEPARATELY">Married Filing Separately</SelectItem>
                    <SelectItem value="HEAD_OF_HOUSEHOLD">Head of Household</SelectItem>
                    <SelectItem value="QUALIFYING_WIDOW">Qualifying Widow(er)</SelectItem>
                  </SelectContent>
                </Select>
                {errors.filingStatus && (
                  <p className="text-red-500 text-sm mt-1">{errors.filingStatus.message}</p>
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Address Information</h3>
              
              <div>
                <Label htmlFor="street">Street Address</Label>
                <Input
                  id="street"
                  {...register('address.street')}
                  className={errors.address?.street ? 'border-red-500' : ''}
                />
                {errors.address?.street && (
                  <p className="text-red-500 text-sm mt-1">{errors.address.street.message}</p>
                )}
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    {...register('address.city')}
                    className={errors.address?.city ? 'border-red-500' : ''}
                  />
                  {errors.address?.city && (
                    <p className="text-red-500 text-sm mt-1">{errors.address.city.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    {...register('address.state')}
                    className={errors.address?.state ? 'border-red-500' : ''}
                  />
                  {errors.address?.state && (
                    <p className="text-red-500 text-sm mt-1">{errors.address.state.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="zipCode">ZIP Code</Label>
                  <Input
                    id="zipCode"
                    {...register('address.zipCode')}
                    className={errors.address?.zipCode ? 'border-red-500' : ''}
                  />
                  {errors.address?.zipCode && (
                    <p className="text-red-500 text-sm mt-1">{errors.address.zipCode.message}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">
                {isMarried ? 'Spouse Information' : 'Review Information'}
              </h3>
              
              {isMarried && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="spouseFirstName">Spouse First Name</Label>
                      <Input
                        id="spouseFirstName"
                        {...register('spouseInfo.firstName')}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="spouseLastName">Spouse Last Name</Label>
                      <Input
                        id="spouseLastName"
                        {...register('spouseInfo.lastName')}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="spouseDateOfBirth">Spouse Date of Birth</Label>
                      <Input
                        id="spouseDateOfBirth"
                        type="date"
                        {...register('spouseInfo.dateOfBirth')}
                      />
                    </div>

                    <div>
                      <Label htmlFor="spouseSSN">Spouse SSN</Label>
                      <Input
                        id="spouseSSN"
                        placeholder="XXX-XX-XXXX"
                        {...register('spouseInfo.ssn')}
                      />
                    </div>
                  </div>
                </>
              )}

              {!isMarried && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">
                    Please review your information before submitting. You can go back to make changes if needed.
                  </p>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-between pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={handlePrevious}
              disabled={step === 1}
            >
              Previous
            </Button>
            
            {step < totalSteps ? (
              <Button type="button" onClick={handleNext}>
                Next
              </Button>
            ) : (
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Creating...' : 'Create Tax Return'}
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
