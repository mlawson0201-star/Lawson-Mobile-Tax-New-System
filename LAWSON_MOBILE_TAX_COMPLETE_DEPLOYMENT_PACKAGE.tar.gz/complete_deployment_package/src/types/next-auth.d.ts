
import NextAuth from 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      tenantId: string
      tenantDomain: string
      roles: string[]
    }
  }

  interface User {
    id: string
    tenantId: string
    tenantDomain: string
    roles: string[]
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    tenantId: string
    tenantDomain: string
    roles: string[]
  }
}
