
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building, 
  ArrowRight, 
  ArrowLeft,
  CheckCircle,
  Users,
  MapPin,
  FileText,
  DollarSign,
  Calendar,
  Download,
  Send
} from 'lucide-react';

interface BusinessFormationData {
  businessType: string;
  businessName: string;
  state: string;
  industry: string;
  owners: Array<{
    name: string;
    email: string;
    ownershipPercentage: number;
    role: string;
  }>;
  taxElection: string;
  planningNeeds: string[];
  operatingAgreement: boolean;
  einRequired: boolean;
  bankAccount: boolean;
  expectedRevenue: string;
  numberOfEmployees: string;
}

interface FormationResult {
  status: string;
  result?: any;
  automationLevel?: string;
  nextSteps?: string[];
}

const STEPS = [
  { id: 'type', title: 'Business Type', icon: Building },
  { id: 'details', title: 'Business Details', icon: FileText },
  { id: 'ownership', title: 'Ownership Structure', icon: Users },
  { id: 'tax', title: 'Tax Elections', icon: DollarSign },
  { id: 'planning', title: 'Planning Needs', icon: Calendar },
  { id: 'review', title: 'Review & Submit', icon: CheckCircle },
];

export default function BusinessFormationWizard() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<BusinessFormationData>({
    businessType: '',
    businessName: '',
    state: '',
    industry: '',
    owners: [{ name: '', email: '', ownershipPercentage: 100, role: 'owner' }],
    taxElection: '',
    planningNeeds: [],
    operatingAgreement: false,
    einRequired: true,
    bankAccount: false,
    expectedRevenue: '',
    numberOfEmployees: '1'
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<FormationResult | null>(null);

  const businessTypes = [
    { value: 'llc', label: 'Limited Liability Company (LLC)', description: 'Flexible structure, pass-through taxation' },
    { value: 'corporation', label: 'C Corporation', description: 'Traditional corporate structure, double taxation' },
    { value: 's_corp', label: 'S Corporation', description: 'Pass-through taxation, ownership restrictions' },
    { value: 'partnership', label: 'Partnership', description: 'Multiple owners, pass-through taxation' },
    { value: 'sole_prop', label: 'Sole Proprietorship', description: 'Simple structure for single owner' }
  ];

  const industries = [
    'Technology/Software', 'Consulting', 'Real Estate', 'Healthcare', 
    'Retail/E-commerce', 'Professional Services', 'Manufacturing', 
    'Construction', 'Food & Beverage', 'Education', 'Other'
  ];

  const taxElections = [
    { value: 'default', label: 'Default Tax Treatment' },
    { value: 'scorp', label: 'S Corporation Election' },
    { value: 'ccorp', label: 'C Corporation Election' },
    { value: 'partnership', label: 'Partnership Election' },
    { value: 'disregarded', label: 'Disregarded Entity' }
  ];

  const planningOptions = [
    'Asset Protection Planning',
    'Estate Planning Integration',
    'Tax Optimization Strategies',
    'Multi-State Operations',
    'International Business',
    'Employee Benefit Plans',
    'Succession Planning',
    'Intellectual Property Protection'
  ];

  const nextStep = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const addOwner = () => {
    setFormData(prev => ({
      ...prev,
      owners: [...prev.owners, { name: '', email: '', ownershipPercentage: 0, role: 'owner' }]
    }));
  };

  const updateOwner = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      owners: prev.owners.map((owner, i) => 
        i === index ? { ...owner, [field]: value } : owner
      )
    }));
  };

  const removeOwner = (index: number) => {
    setFormData(prev => ({
      ...prev,
      owners: prev.owners.filter((_, i) => i !== index)
    }));
  };

  const togglePlanningNeed = (need: string) => {
    setFormData(prev => ({
      ...prev,
      planningNeeds: prev.planningNeeds.includes(need)
        ? prev.planningNeeds.filter(n => n !== need)
        : [...prev.planningNeeds, need]
    }));
  };

  const submitFormation = async () => {
    setIsProcessing(true);
    
    try {
      const response = await fetch('/api/automation/business-formation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let partialRead = '';

      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined };
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        let lines = partialRead.split('\n');
        partialRead = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.status === 'completed') {
                setResult(parsed);
                setIsProcessing(false);
                return;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Business formation error:', error);
      setIsProcessing(false);
    }
  };

  const renderStepContent = () => {
    switch (STEPS[currentStep].id) {
      case 'type':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Choose Your Business Structure</h2>
            <div className="grid gap-4">
              {businessTypes.map((type) => (
                <motion.div
                  key={type.value}
                  whileHover={{ scale: 1.02 }}
                  className={`p-6 border-2 rounded-xl cursor-pointer transition-colors ${
                    formData.businessType === type.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => setFormData(prev => ({ ...prev, businessType: type.value }))}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`p-2 rounded-lg ${
                      formData.businessType === type.value ? 'bg-blue-500' : 'bg-gray-300'
                    }`}>
                      <Building className={`h-5 w-5 ${
                        formData.businessType === type.value ? 'text-white' : 'text-gray-600'
                      }`} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{type.label}</h3>
                      <p className="text-sm text-gray-600 mt-1">{type.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        );

      case 'details':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Business Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Business Name
                </label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={(e) => setFormData(prev => ({ ...prev, businessName: e.target.value }))}
                  placeholder="Enter your business name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  State of Formation
                </label>
                <select
                  value={formData.state}
                  onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select State</option>
                  <option value="DE">Delaware</option>
                  <option value="CA">California</option>
                  <option value="NY">New York</option>
                  <option value="TX">Texas</option>
                  <option value="FL">Florida</option>
                  {/* Add more states as needed */}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Industry
                </label>
                <select
                  value={formData.industry}
                  onChange={(e) => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Industry</option>
                  {industries.map(industry => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expected Annual Revenue
                </label>
                <select
                  value={formData.expectedRevenue}
                  onChange={(e) => setFormData(prev => ({ ...prev, expectedRevenue: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Revenue Range</option>
                  <option value="0-50k">$0 - $50,000</option>
                  <option value="50k-250k">$50,000 - $250,000</option>
                  <option value="250k-1m">$250,000 - $1,000,000</option>
                  <option value="1m+">$1,000,000+</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 'ownership':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Ownership Structure</h2>
              <button
                onClick={addOwner}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Add Owner
              </button>
            </div>
            
            <div className="space-y-4">
              {formData.owners.map((owner, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-6 border border-gray-200 rounded-lg space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-900">Owner {index + 1}</h3>
                    {formData.owners.length > 1 && (
                      <button
                        onClick={() => removeOwner(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={owner.name}
                      onChange={(e) => updateOwner(index, 'name', e.target.value)}
                      className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    
                    <input
                      type="email"
                      placeholder="Email Address"
                      value={owner.email}
                      onChange={(e) => updateOwner(index, 'email', e.target.value)}
                      className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    
                    <input
                      type="number"
                      placeholder="Ownership %"
                      min="0"
                      max="100"
                      value={owner.ownershipPercentage}
                      onChange={(e) => updateOwner(index, 'ownershipPercentage', parseFloat(e.target.value) || 0)}
                      className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                Total Ownership: {formData.owners.reduce((sum, owner) => sum + owner.ownershipPercentage, 0)}%
              </p>
            </div>
          </div>
        );

      case 'tax':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Tax Elections</h2>
            <div className="grid gap-4">
              {taxElections.map((election) => (
                <motion.div
                  key={election.value}
                  whileHover={{ scale: 1.01 }}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    formData.taxElection === election.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => setFormData(prev => ({ ...prev, taxElection: election.value }))}
                >
                  <h3 className="font-semibold text-gray-900">{election.label}</h3>
                </motion.div>
              ))}
            </div>
          </div>
        );

      case 'planning':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Additional Planning Needs</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {planningOptions.map((option) => (
                <motion.div
                  key={option}
                  whileHover={{ scale: 1.02 }}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    formData.planningNeeds.includes(option)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => togglePlanningNeed(option)}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                      formData.planningNeeds.includes(option)
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                    }`}>
                      {formData.planningNeeds.includes(option) && (
                        <CheckCircle className="w-3 h-3 text-white" />
                      )}
                    </div>
                    <span className="text-gray-900">{option}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        );

      case 'review':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Review Your Business Formation</h2>
            <div className="bg-gray-50 p-6 rounded-lg space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900">Business Type:</h3>
                <p className="text-gray-700">{businessTypes.find(t => t.value === formData.businessType)?.label}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900">Business Name:</h3>
                <p className="text-gray-700">{formData.businessName}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900">State:</h3>
                <p className="text-gray-700">{formData.state}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900">Industry:</h3>
                <p className="text-gray-700">{formData.industry}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900">Owners:</h3>
                {formData.owners.map((owner, index) => (
                  <p key={index} className="text-gray-700">
                    {owner.name} ({owner.ownershipPercentage}%)
                  </p>
                ))}
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900">Tax Election:</h3>
                <p className="text-gray-700">{taxElections.find(t => t.value === formData.taxElection)?.label}</p>
              </div>
              
              {formData.planningNeeds.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900">Planning Needs:</h3>
                  <ul className="text-gray-700 list-disc list-inside">
                    {formData.planningNeeds.map((need, index) => (
                      <li key={index}>{need}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (isProcessing) {
    return (
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Generating Business Formation Plan
          </h2>
          <p className="text-gray-600">
            Creating comprehensive formation documents and tax strategy...
          </p>
        </motion.div>
      </div>
    );
  }

  if (result) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Success Header */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-6">
          <div className="flex items-center space-x-3">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div>
              <h2 className="text-xl font-semibold text-green-900">
                Business Formation Plan Generated
              </h2>
              <p className="text-green-700">
                Automation Level: {result.automationLevel || 'Advanced'}
              </p>
            </div>
          </div>
        </div>

        {/* Results Content */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Formation Package Complete</h3>
          
          {result.nextSteps && result.nextSteps.length > 0 && (
            <div className="mb-6">
              <h4 className="font-semibold text-gray-900 mb-3">Next Steps:</h4>
              <div className="space-y-2">
                {result.nextSteps.map((step: string, index: number) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <p className="text-gray-700">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-4">
            <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Download className="h-4 w-4" />
              <span>Download Formation Package</span>
            </button>
            
            <button className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
              <Send className="h-4 w-4" />
              <span>File Documents</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900">Business Formation Wizard</h1>
        <p className="text-lg text-gray-600 mt-2">
          Automated business setup with integrated tax planning
        </p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-between">
        {STEPS.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={step.id} className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                index <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="ml-3">
                <p className={`text-sm font-medium ${
                  index <= currentStep ? 'text-blue-600' : 'text-gray-500'
                }`}>
                  {step.title}
                </p>
              </div>
              {index < STEPS.length - 1 && (
                <div className={`hidden lg:block mx-4 w-12 h-0.5 ${
                  index < currentStep ? 'bg-blue-600' : 'bg-gray-200'
                }`} />
              )}
            </div>
          );
        })}
      </div>

      {/* Step Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderStepContent()}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between mt-8">
          <button
            onClick={prevStep}
            disabled={currentStep === 0}
            className="flex items-center space-x-2 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Previous</span>
          </button>

          {currentStep === STEPS.length - 1 ? (
            <button
              onClick={submitFormation}
              className="flex items-center space-x-2 px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Building className="h-4 w-4" />
              <span>Create Business</span>
            </button>
          ) : (
            <button
              onClick={nextStep}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <span>Next</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
