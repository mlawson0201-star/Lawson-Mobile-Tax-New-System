

import Link from 'next/link';
import { ArrowRight, Shield, Zap, Users, Award, CheckCircle } from 'lucide-react';
import { getCurrentTenant } from '@/lib/tenant';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const tenant = await getCurrentTenant();
  const tenantName = tenant?.name || 'Lawson Mobile Tax';
  const primaryColor = tenant?.brandingConfig?.primaryColor || '#6a0dad';

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              {tenant?.brandingConfig?.logo ? (
                <img src={tenant.brandingConfig.logo} alt={tenantName} className="h-10 w-auto" />
              ) : (
                <div className="h-10 w-10 bg-gradient-to-br from-purple-600 to-purple-800 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">LMT</span>
                </div>
              )}
              <span className="ml-3 text-xl font-bold text-gray-900">{tenantName}</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link
                href="/auth/signin"
                className="text-gray-600 hover:text-gray-900 font-medium"
              >
                Sign In
              </Link>
              <Link
                href="/auth/signup"
                className="text-white font-medium px-4 py-2 rounded-lg transition-colors duration-200 hover:opacity-90"
                style={{ backgroundColor: primaryColor }}
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              AI-Powered Tax Preparation
              <span className="block text-blue-600">Made Simple</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Experience the future of tax preparation with our AI-powered platform. 
              Get accurate returns, human oversight, and maximum refunds - all at transparent pricing.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link
                href="/auth/signup"
                className="text-white font-semibold px-8 py-4 rounded-xl transition-all duration-200 flex items-center justify-center group hover:opacity-90"
                style={{ backgroundColor: primaryColor }}
              >
                Start Your Return
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/auth/signin"
                className="border-2 border-gray-300 hover:border-gray-400 text-gray-700 font-semibold px-8 py-4 rounded-xl transition-all duration-200 flex items-center justify-center"
              >
                Sign In
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-gray-500">
              <div className="flex items-center">
                <Shield className="h-5 w-5 mr-2 text-green-600" />
                Bank-Level Security
              </div>
              <div className="flex items-center">
                <Award className="h-5 w-5 mr-2 text-blue-600" />
                IRS Approved
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-purple-600" />
                Expert Review
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose {tenantName}?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform combines cutting-edge AI technology with human expertise 
              to deliver accurate, fast, and affordable tax preparation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8 card-hover">
              <div className="h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center mb-6">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">AI-Powered Accuracy</h3>
              <p className="text-gray-600 mb-6">
                Our advanced AI engine processes your documents with 95%+ accuracy, 
                catching deductions you might miss and ensuring maximum refunds.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Automatic document processing
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Deduction optimization
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Error detection & correction
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl p-8 card-hover">
              <div className="h-12 w-12 bg-green-600 rounded-xl flex items-center justify-center mb-6">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Expert Human Review</h3>
              <p className="text-gray-600 mb-6">
                Every return is reviewed by certified tax professionals (EAs and CPAs) 
                to ensure accuracy and compliance before filing.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Licensed tax professionals
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Quality assurance checks
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Personal support available
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-100 rounded-2xl p-8 card-hover">
              <div className="h-12 w-12 bg-purple-600 rounded-xl flex items-center justify-center mb-6">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Transparent Pricing</h3>
              <p className="text-gray-600 mb-6">
                No hidden fees, no surprise charges. You'll know exactly what you'll pay 
                before you file, with competitive rates and money-back guarantee.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Fixed, transparent pricing
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  No hidden fees
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Maximum refund guarantee
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600">
              Choose the plan that's right for your tax situation. No surprises, no hidden fees.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Basic Tax Return</h3>
                <p className="text-gray-600 mb-4">Perfect for simple tax situations</p>
                <div className="text-4xl font-bold text-gray-900">
                  $199-499
                  <span className="text-lg font-normal text-gray-500">/return</span>
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>W-2 and basic forms</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Standard deduction optimization</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>AI-powered accuracy check</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Expert review included</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>E-filing included</span>
                </li>
              </ul>
              
              <Link
                href="/auth/signup"
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-900 font-semibold py-3 px-6 rounded-xl transition-colors duration-200 text-center block"
              >
                Get Started
              </Link>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border-2 border-purple-500 p-8 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-purple-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
              
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Premium Tax Return</h3>
                <p className="text-gray-600 mb-4">For complex tax situations</p>
                <div className="text-4xl font-bold text-gray-900">
                  $649-999
                  <span className="text-lg font-normal text-gray-500">/return</span>
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Everything in Basic</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Business income (Schedule C)</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Rental properties (Schedule E)</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Stock transactions (Schedule D)</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>State return included</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Priority support</span>
                </li>
              </ul>
              
              <Link
                href="/auth/signup"
                className="w-full text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200 text-center block"
                style={{ backgroundColor: '#6a0dad' }}
              >
                Get Started
              </Link>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Business Tax Return</h3>
                <p className="text-gray-600 mb-4">For business tax needs</p>
                <div className="text-4xl font-bold text-gray-900">
                  $999-1599
                  <span className="text-lg font-normal text-gray-500">/return</span>
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Business tax returns</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Corporate filings</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Partnership returns</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Advanced business deductions</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Dedicated tax professional</span>
                </li>
              </ul>
              
              <Link
                href="/auth/signup"
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-900 font-semibold py-3 px-6 rounded-xl transition-colors duration-200 text-center block"
              >
                Get Started
              </Link>
            </div>
          </div>

          {/* Monthly Services Section */}
          <div className="mt-16">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Monthly Services</h3>
              <p className="text-lg text-gray-600">Ongoing tax and financial management</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">AI Financial Advisor</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$29<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">AI-powered financial insights and tax planning</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Premium Analytics</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$99<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">Advanced financial analytics and reporting</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Business Suite</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$299<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">Complete business tax management</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Enterprise</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$999<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">Enterprise-grade tax management</p>
              </div>
            </div>
          </div>

          {/* Add-on Services Section */}
          <div className="mt-16">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Add-on Services</h3>
              <p className="text-lg text-gray-600">Enhanced services for your specific needs</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Ask Melika GPT</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$19.99<span className="text-sm font-normal">+</span></div>
                <p className="text-gray-600 text-sm">AI tax assistant for instant answers to your tax questions</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Bookkeeping Basic</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$49<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">Basic bookkeeping and expense tracking</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Bookkeeping Premium</h4>
                <div className="text-2xl font-bold text-gray-900 mb-4">$149<span className="text-sm font-normal">/month</span></div>
                <p className="text-gray-600 text-sm">Advanced bookkeeping with financial reports</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20" style={{ backgroundColor: primaryColor }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to File Your Taxes?
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Join thousands of satisfied customers who trust {tenantName} for their tax preparation needs.
          </p>
          <Link
            href="/auth/signup"
            className="bg-white font-semibold px-8 py-4 rounded-xl hover:bg-gray-50 transition-colors duration-200 inline-flex items-center"
            style={{ color: primaryColor }}
          >
            Get Started Today
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                {tenant?.brandingConfig?.logo ? (
                  <img src={tenant.brandingConfig.logo} alt={tenantName} className="h-8 w-auto" />
                ) : (
                  <div className="h-8 w-8 bg-gradient-to-br from-purple-600 to-purple-800 rounded flex items-center justify-center">
                    <span className="text-white font-bold text-xs">LMT</span>
                  </div>
                )}
                <span className="ml-2 text-lg font-semibold">{tenantName}</span>
              </div>
              <p className="text-gray-400">
                AI-powered tax preparation with human expertise. 
                Get accurate returns with maximum refunds.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">Tax Preparation</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Pricing</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Features</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">About</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Support</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Terms of Service</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Security</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
            <p>&copy; 2025 {tenantName}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
