
# API Documentation
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. API Overview

### 1.1 Architecture
The Lawson Mobile Tax platform provides a comprehensive GraphQL API for client applications and REST endpoints for webhooks and file operations. The API is designed with multi-tenancy, security, and scalability as core principles.

### 1.2 Base URLs
- **Production**: `https://api.lawsonmobiletax.com`
- **Staging**: `https://api-staging.lawsonmobiletax.com`
- **Development**: `http://localhost:4000`

### 1.3 Authentication
All API requests require authentication using JWT tokens obtained through AWS Cognito or API keys for service-to-service communication.

```typescript
// Authentication header format
headers: {
  'Authorization': 'Bearer <jwt_token>',
  'X-Tenant-ID': '<tenant_uuid>',
  'Content-Type': 'application/json'
}
```

---

## 2. GraphQL API

### 2.1 GraphQL Endpoint
- **URL**: `/graphql`
- **Method**: POST
- **Content-Type**: `application/json`

### 2.2 Schema Overview

```graphql
type Query {
  # User Management
  me: User!
  users(filter: UserFilter, pagination: Pagination): UserConnection!
  
  # Client Management
  client(id: ID!): Client
  clients(filter: ClientFilter, pagination: Pagination): ClientConnection!
  
  # Tax Return Management
  taxReturn(id: ID!): TaxReturn
  taxReturns(filter: TaxReturnFilter, pagination: Pagination): TaxReturnConnection!
  
  # Document Management
  document(id: ID!): Document
  documents(filter: DocumentFilter, pagination: Pagination): DocumentConnection!
  
  # Payment Management
  payment(id: ID!): Payment
  payments(filter: PaymentFilter, pagination: Pagination): PaymentConnection!
  
  # Analytics & Reporting
  dashboardMetrics(dateRange: DateRange!): DashboardMetrics!
  revenueAnalytics(dateRange: DateRange!): RevenueAnalytics!
  
  # White-Label Management
  tenant: Tenant!
  tenantSettings: TenantSettings!
}

type Mutation {
  # User Management
  createUser(input: CreateUserInput!): User!
  updateUser(id: ID!, input: UpdateUserInput!): User!
  deleteUser(id: ID!): Boolean!
  
  # Client Management
  createClient(input: CreateClientInput!): Client!
  updateClient(id: ID!, input: UpdateClientInput!): Client!
  
  # Tax Return Operations
  createTaxReturn(input: CreateTaxReturnInput!): TaxReturn!
  updateTaxReturn(id: ID!, input: UpdateTaxReturnInput!): TaxReturn!
  submitForReview(id: ID!): TaxReturn!
  approveReturn(id: ID!): TaxReturn!
  submitToEFile(id: ID!): EFileSubmission!
  
  # Document Operations
  uploadDocument(input: UploadDocumentInput!): Document!
  processDocument(id: ID!): Document!
  deleteDocument(id: ID!): Boolean!
  
  # Payment Operations
  createPayment(input: CreatePaymentInput!): Payment!
  processRefundAdvance(input: RefundAdvanceInput!): RefundAdvance!
  
  # White-Label Operations
  updateTenantSettings(input: UpdateTenantSettingsInput!): TenantSettings!
  updateBranding(input: UpdateBrandingInput!): TenantBranding!
}

type Subscription {
  # Real-time Updates
  taxReturnUpdated(id: ID!): TaxReturn!
  documentProcessed(id: ID!): Document!
  eFileStatusChanged(returnId: ID!): EFileSubmission!
  paymentStatusChanged(paymentId: ID!): Payment!
  notificationReceived(userId: ID!): Notification!
}
```

### 2.3 Core Types

#### 2.3.1 User Types
```graphql
type User {
  id: ID!
  email: String!
  firstName: String!
  lastName: String!
  phone: String
  role: UserRole!
  profile: UserProfile!
  tenant: Tenant!
  active: Boolean!
  lastLoginAt: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
}

type UserProfile {
  avatar: String
  timezone: String
  language: String
  preferences: UserPreferences!
  address: Address
}

type UserPreferences {
  emailNotifications: Boolean!
  smsNotifications: Boolean!
  marketingEmails: Boolean!
  theme: String!
}

enum UserRole {
  SUPER_ADMIN
  TENANT_ADMIN
  PREPARER
  EA
  CPA
  CLIENT
  SUPPORT
}

input CreateUserInput {
  email: String!
  firstName: String!
  lastName: String!
  phone: String
  role: UserRole!
  profile: UserProfileInput
}

input UpdateUserInput {
  firstName: String
  lastName: String
  phone: String
  profile: UserProfileInput
  active: Boolean
}
```

#### 2.3.2 Client Types
```graphql
type Client {
  id: ID!
  email: String!
  firstName: String!
  lastName: String!
  phone: String
  dateOfBirth: Date
  ssn: String # Encrypted
  address: Address!
  filingStatus: FilingStatus!
  personalInfo: ClientPersonalInfo!
  taxReturns: [TaxReturn!]!
  documents: [Document!]!
  payments: [Payment!]!
  status: ClientStatus!
  lifetimeValue: Float!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type Address {
  street1: String!
  street2: String
  city: String!
  state: String!
  zipCode: String!
  country: String!
}

type ClientPersonalInfo {
  occupation: String
  employer: String
  spouseInfo: SpouseInfo
  dependents: [Dependent!]!
  bankAccounts: [BankAccount!]!
}

type SpouseInfo {
  firstName: String!
  lastName: String!
  ssn: String
  dateOfBirth: Date
  occupation: String
}

type Dependent {
  firstName: String!
  lastName: String!
  ssn: String
  dateOfBirth: Date!
  relationship: String!
  qualifyingChild: Boolean!
}

enum FilingStatus {
  SINGLE
  MARRIED_FILING_JOINTLY
  MARRIED_FILING_SEPARATELY
  HEAD_OF_HOUSEHOLD
  QUALIFYING_WIDOW
}

enum ClientStatus {
  ACTIVE
  INACTIVE
  SUSPENDED
  ARCHIVED
}

input CreateClientInput {
  email: String!
  firstName: String!
  lastName: String!
  phone: String
  dateOfBirth: Date
  address: AddressInput!
  filingStatus: FilingStatus!
  personalInfo: ClientPersonalInfoInput
}
```

#### 2.3.3 Tax Return Types
```graphql
type TaxReturn {
  id: ID!
  client: Client!
  assignedPreparer: User
  taxYear: Int!
  returnType: String!
  status: TaxReturnStatus!
  totalFee: Float!
  refundAmount: Float
  forms: [TaxForm!]!
  documents: [Document!]!
  calculations: TaxCalculations!
  aiConfidenceScore: Float
  requiresHumanReview: Boolean!
  reviewNotes: String
  eFileSubmission: EFileSubmission
  payments: [Payment!]!
  submittedAt: DateTime
  completedAt: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
}

type TaxForm {
  id: ID!
  formType: String!
  formName: String!
  data: JSON!
  validations: [ValidationResult!]!
  confidenceScore: Float!
  status: FormStatus!
  createdAt: DateTime!
  updatedAt: DateTime!
}

type TaxCalculations {
  agi: Float!
  totalTax: Float!
  totalCredits: Float!
  totalPayments: Float!
  refundAmount: Float!
  amountOwed: Float!
  effectiveTaxRate: Float!
  marginalTaxRate: Float!
  breakdown: TaxBreakdown!
}

type TaxBreakdown {
  federalTax: Float!
  stateTax: Float!
  selfEmploymentTax: Float!
  alternativeMinimumTax: Float!
  childTaxCredit: Float!
  earnedIncomeCredit: Float!
  educationCredits: Float!
  otherCredits: Float!
}

type ValidationResult {
  field: String!
  rule: String!
  status: ValidationStatus!
  message: String!
  severity: ValidationSeverity!
}

enum TaxReturnStatus {
  DRAFT
  DOCUMENTS_PENDING
  IN_PROGRESS
  REVIEW_REQUIRED
  CLIENT_REVIEW
  READY_TO_FILE
  FILED
  ACCEPTED
  REJECTED
  COMPLETED
}

enum FormStatus {
  DRAFT
  IN_PROGRESS
  COMPLETED
  VALIDATED
  ERROR
}

enum ValidationStatus {
  PASSED
  FAILED
  WARNING
  PENDING
}

enum ValidationSeverity {
  INFO
  WARNING
  ERROR
  CRITICAL
}

input CreateTaxReturnInput {
  clientId: ID!
  taxYear: Int!
  returnType: String!
  filingStatus: FilingStatus!
}

input UpdateTaxReturnInput {
  assignedPreparerId: ID
  status: TaxReturnStatus
  formData: JSON
  reviewNotes: String
}
```

#### 2.3.4 Document Types
```graphql
type Document {
  id: ID!
  client: Client!
  taxReturn: TaxReturn
  uploadedBy: User!
  documentType: DocumentType!
  filename: String!
  fileSize: Int!
  mimeType: String!
  url: String!
  status: DocumentStatus!
  ocrResults: OCRResults
  extractedData: JSON!
  processedAt: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
}

type OCRResults {
  confidence: Float!
  extractedFields: [ExtractedField!]!
  validations: [ValidationResult!]!
  processingTime: Int!
}

type ExtractedField {
  fieldName: String!
  fieldValue: String!
  confidence: Float!
  boundingBox: BoundingBox
  manuallyVerified: Boolean!
}

type BoundingBox {
  x: Float!
  y: Float!
  width: Float!
  height: Float!
}

enum DocumentType {
  W2
  FORM_1099_NEC
  FORM_1099_INT
  FORM_1099_DIV
  FORM_1099_B
  FORM_1099_K
  FORM_1098
  FORM_1095_A
  K1
  BANK_STATEMENT
  ID_DOCUMENT
  OTHER
}

enum DocumentStatus {
  UPLOADED
  PROCESSING
  PROCESSED
  FAILED
  VERIFIED
  ARCHIVED
}

input UploadDocumentInput {
  clientId: ID!
  taxReturnId: ID
  documentType: DocumentType!
  filename: String!
  fileSize: Int!
  mimeType: String!
}
```

#### 2.3.5 Payment Types
```graphql
type Payment {
  id: ID!
  client: Client!
  taxReturn: TaxReturn
  stripePaymentIntentId: String
  amount: Float!
  platformFee: Float!
  resellerAmount: Float!
  currency: String!
  status: PaymentStatus!
  paymentMethod: PaymentMethod!
  metadata: JSON!
  processedAt: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
}

type RefundAdvance {
  id: ID!
  client: Client!
  taxReturn: TaxReturn!
  productType: String!
  provider: String!
  amount: Float!
  apr: Float
  fee: Float!
  status: RefundAdvanceStatus!
  terms: JSON!
  disclosures: JSON!
  epsApplicationId: String
  approvedAt: DateTime
  fundedAt: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
}

enum PaymentStatus {
  PENDING
  PROCESSING
  SUCCEEDED
  FAILED
  CANCELED
  REFUNDED
}

enum PaymentMethod {
  CARD
  ACH
  REFUND_DEDUCTION
}

enum RefundAdvanceStatus {
  PENDING
  UNDER_REVIEW
  APPROVED
  FUNDED
  DECLINED
  CANCELED
}

input CreatePaymentInput {
  clientId: ID!
  taxReturnId: ID
  amount: Float!
  paymentMethodId: String!
  currency: String = "USD"
}

input RefundAdvanceInput {
  clientId: ID!
  taxReturnId: ID!
  productCode: String!
  requestedAmount: Float!
  bankAccountInfo: BankAccountInput!
}
```

---

## 3. REST API Endpoints

### 3.1 Authentication Endpoints

#### 3.1.1 User Registration
```http
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+1234567890",
  "tenantId": "tenant-uuid"
}

Response:
{
  "user": {
    "id": "user-uuid",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "client",
    "active": true
  },
  "tokens": {
    "accessToken": "jwt-access-token",
    "refreshToken": "jwt-refresh-token",
    "expiresIn": 3600
  }
}
```

#### 3.1.2 User Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}

Response:
{
  "user": {
    "id": "user-uuid",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "client",
    "tenantId": "tenant-uuid"
  },
  "tokens": {
    "accessToken": "jwt-access-token",
    "refreshToken": "jwt-refresh-token",
    "expiresIn": 3600
  }
}
```

#### 3.1.3 Token Refresh
```http
POST /auth/refresh
Content-Type: application/json

{
  "refreshToken": "jwt-refresh-token"
}

Response:
{
  "accessToken": "new-jwt-access-token",
  "expiresIn": 3600
}
```

### 3.2 File Upload Endpoints

#### 3.2.1 Get Upload URL
```http
GET /api/documents/upload-url?documentType=w2&filename=w2_2024.pdf&fileSize=1024000
Authorization: Bearer <jwt_token>
X-Tenant-ID: <tenant_uuid>

Response:
{
  "uploadUrl": "https://s3.amazonaws.com/bucket/presigned-url",
  "fields": {
    "key": "documents/tenant-uuid/client-uuid/document-uuid.pdf",
    "policy": "base64-encoded-policy",
    "signature": "signature"
  },
  "documentId": "document-uuid",
  "expiresIn": 3600
}
```

#### 3.2.2 Confirm Upload
```http
POST /api/documents/{documentId}/confirm
Authorization: Bearer <jwt_token>
X-Tenant-ID: <tenant_uuid>

{
  "clientId": "client-uuid",
  "taxReturnId": "return-uuid"
}

Response:
{
  "document": {
    "id": "document-uuid",
    "filename": "w2_2024.pdf",
    "status": "uploaded",
    "documentType": "w2",
    "createdAt": "2025-08-22T10:00:00Z"
  }
}
```

#### 3.2.3 Process Document
```http
POST /api/documents/{documentId}/process
Authorization: Bearer <jwt_token>
X-Tenant-ID: <tenant_uuid>

Response:
{
  "status": "processing",
  "estimatedCompletionTime": "2025-08-22T10:05:00Z"
}
```

### 3.3 Webhook Endpoints

#### 3.3.1 Stripe Webhooks
```http
POST /webhooks/stripe
Content-Type: application/json
Stripe-Signature: <stripe_signature>

{
  "id": "evt_1234567890",
  "object": "event",
  "type": "payment_intent.succeeded",
  "data": {
    "object": {
      "id": "pi_1234567890",
      "amount": 48500,
      "currency": "usd",
      "status": "succeeded",
      "metadata": {
        "tenant_id": "tenant-uuid",
        "client_id": "client-uuid",
        "tax_return_id": "return-uuid"
      }
    }
  }
}

Response:
{
  "received": true
}
```

#### 3.3.2 OLT Webhooks
```http
POST /webhooks/olt
Content-Type: application/json
X-OLT-Signature: <olt_signature>

{
  "eventType": "efile.accepted",
  "returnId": "olt-return-id",
  "submissionId": "olt-submission-id",
  "data": {
    "federalAcceptanceId": "federal-id",
    "stateAcceptanceId": "state-id",
    "acceptedAt": "2025-08-22T10:00:00Z"
  },
  "timestamp": "2025-08-22T10:00:00Z"
}

Response:
{
  "received": true
}
```

#### 3.3.3 EPS Financial Webhooks
```http
POST /webhooks/eps
Content-Type: application/json
X-EPS-Signature: <eps_signature>

{
  "eventType": "advance.funded",
  "applicationId": "eps-app-id",
  "data": {
    "amount": 5000.00,
    "fundedAt": "2025-08-22T10:00:00Z",
    "bankAccount": {
      "last4": "1234",
      "routingNumber": "021000021"
    }
  },
  "timestamp": "2025-08-22T10:00:00Z"
}

Response:
{
  "received": true
}
```

#### 3.3.4 Persona Webhooks
```http
POST /webhooks/persona
Content-Type: application/json
Persona-Signature: <persona_signature>

{
  "type": "inquiry.completed",
  "id": "inq_1234567890",
  "attributes": {
    "status": "completed",
    "referenceId": "client_uuid",
    "completedAt": "2025-08-22T10:00:00Z",
    "verifications": [
      {
        "type": "government-id",
        "status": "passed",
        "checks": [
          {
            "name": "id_comparison",
            "status": "passed"
          }
        ]
      }
    ]
  }
}

Response:
{
  "received": true
}
```

---

## 4. API Sequence Diagrams

### 4.1 Tax Return Creation Flow

```mermaid
sequenceDiagram
    participant Client
    participant API
    participant TaxService
    participant DocumentService
    participant AIService
    participant Database
    
    Client->>API: createTaxReturn(input)
    API->>TaxService: Create return
    TaxService->>Database: Store return
    TaxService-->>API: Return created
    API-->>Client: TaxReturn object
    
    Client->>API: uploadDocument(input)
    API->>DocumentService: Get upload URL
    DocumentService-->>API: Presigned URL
    API-->>Client: Upload URL
    
    Client->>S3: Upload document
    S3-->>Client: Upload complete
    
    Client->>API: confirmUpload(documentId)
    API->>DocumentService: Process document
    DocumentService->>AIService: Extract data
    AIService-->>DocumentService: OCR results
    DocumentService->>Database: Store results
    DocumentService-->>API: Processing complete
    API-->>Client: Document processed
    
    DocumentService->>TaxService: Document ready
    TaxService->>AIService: Calculate tax
    AIService-->>TaxService: Calculations
    TaxService->>Database: Update return
    TaxService->>Client: Return updated (via subscription)
```

### 4.2 Payment Processing Flow

```mermaid
sequenceDiagram
    participant Client
    participant API
    participant PaymentService
    participant Stripe
    participant TaxService
    participant Database
    
    Client->>API: createPayment(input)
    API->>PaymentService: Process payment
    PaymentService->>Stripe: Create PaymentIntent
    Stripe-->>PaymentService: PaymentIntent created
    PaymentService->>Database: Store payment
    PaymentService-->>API: Payment created
    API-->>Client: Payment object
    
    Client->>Stripe: Confirm payment
    Stripe->>Stripe: Process payment
    Stripe->>API: Webhook: payment_intent.succeeded
    API->>PaymentService: Handle webhook
    PaymentService->>Database: Update payment status
    PaymentService->>TaxService: Payment confirmed
    TaxService->>Database: Update return status
    PaymentService-->>API: Webhook processed
    API-->>Stripe: 200 OK
    
    TaxService->>Client: Return status updated (via subscription)
```

### 4.3 E-Filing Flow

```mermaid
sequenceDiagram
    participant Client
    participant API
    participant TaxService
    participant OLTService
    participant IRS
    participant Database
    
    Client->>API: submitToEFile(returnId)
    API->>TaxService: Submit return
    TaxService->>OLTService: Create OLT return
    OLTService-->>TaxService: Return created
    
    TaxService->>OLTService: Submit e-file
    OLTService->>IRS: Submit return
    IRS-->>OLTService: Acknowledgment
    OLTService->>Database: Store submission
    OLTService-->>TaxService: Submission created
    TaxService-->>API: E-file submitted
    API-->>Client: EFileSubmission object
    
    loop Status Polling
        OLTService->>IRS: Check status
        IRS-->>OLTService: Status update
        OLTService->>API: Webhook: efile.accepted
        API->>TaxService: Handle webhook
        TaxService->>Database: Update status
        TaxService->>Client: Status updated (via subscription)
    end
```

### 4.4 White-Label Tenant Onboarding

```mermaid
sequenceDiagram
    participant Reseller
    participant API
    participant TenantService
    participant StripeService
    participant DNSService
    participant Database
    
    Reseller->>API: Apply for white-label
    API->>TenantService: Create application
    TenantService->>Database: Store application
    TenantService->>TenantService: Background check
    
    alt Application Approved
        TenantService->>StripeService: Create Connect account
        StripeService->>Stripe: Create account
        Stripe-->>StripeService: Account created
        StripeService-->>TenantService: Account ID
        
        TenantService->>DNSService: Configure subdomain
        DNSService-->>TenantService: DNS configured
        
        TenantService->>Database: Create tenant
        TenantService-->>API: Tenant created
        API-->>Reseller: Onboarding link
        
        Reseller->>Stripe: Complete onboarding
        Stripe->>API: Webhook: account.updated
        API->>TenantService: Handle webhook
        TenantService->>Database: Update tenant status
        TenantService->>Reseller: Onboarding complete
    else Application Rejected
        TenantService-->>API: Application rejected
        API-->>Reseller: Rejection notice
    end
```

---

## 5. Error Handling

### 5.1 Error Response Format
```json
{
  "errors": [
    {
      "code": "VALIDATION_ERROR",
      "message": "Invalid input provided",
      "field": "email",
      "details": {
        "constraint": "email_format",
        "received": "invalid-email"
      }
    }
  ],
  "data": null
}
```

### 5.2 Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUTHENTICATION_REQUIRED` | 401 | Valid authentication token required |
| `AUTHORIZATION_DENIED` | 403 | Insufficient permissions for operation |
| `RESOURCE_NOT_FOUND` | 404 | Requested resource does not exist |
| `VALIDATION_ERROR` | 400 | Input validation failed |
| `RATE_LIMIT_EXCEEDED` | 429 | API rate limit exceeded |
| `INTERNAL_SERVER_ERROR` | 500 | Unexpected server error |
| `SERVICE_UNAVAILABLE` | 503 | External service temporarily unavailable |
| `TENANT_NOT_FOUND` | 404 | Tenant does not exist |
| `INSUFFICIENT_PERMISSIONS` | 403 | User lacks required permissions |
| `DOCUMENT_PROCESSING_FAILED` | 422 | Document could not be processed |
| `PAYMENT_FAILED` | 402 | Payment processing failed |
| `EFILE_SUBMISSION_FAILED` | 422 | E-filing submission failed |

### 5.3 GraphQL Error Extensions
```json
{
  "errors": [
    {
      "message": "Tax return not found",
      "extensions": {
        "code": "RESOURCE_NOT_FOUND",
        "field": "taxReturn",
        "resourceId": "return-uuid",
        "tenantId": "tenant-uuid"
      },
      "path": ["taxReturn"],
      "locations": [{"line": 2, "column": 3}]
    }
  ]
}
```

---

## 6. Rate Limiting

### 6.1 Rate Limit Headers
```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1692700800
X-RateLimit-Window: 3600
```

### 6.2 Rate Limit Tiers

| User Type | Requests/Hour | Burst Limit |
|-----------|---------------|-------------|
| Client | 1,000 | 100 |
| Preparer | 5,000 | 500 |
| Admin | 10,000 | 1,000 |
| API Key | 50,000 | 5,000 |

### 6.3 Rate Limit Exceeded Response
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "API rate limit exceeded",
    "retryAfter": 3600,
    "limit": 1000,
    "window": 3600
  }
}
```

---

## 7. Pagination

### 7.1 Cursor-Based Pagination
```graphql
query GetTaxReturns($first: Int!, $after: String) {
  taxReturns(first: $first, after: $after) {
    edges {
      node {
        id
        taxYear
        status
        totalFee
      }
      cursor
    }
    pageInfo {
      hasNextPage
      hasPreviousPage
      startCursor
      endCursor
    }
    totalCount
  }
}
```

### 7.2 Pagination Response
```json
{
  "data": {
    "taxReturns": {
      "edges": [
        {
          "node": {
            "id": "return-1",
            "taxYear": 2024,
            "status": "COMPLETED",
            "totalFee": 485.00
          },
          "cursor": "cursor-1"
        }
      ],
      "pageInfo": {
        "hasNextPage": true,
        "hasPreviousPage": false,
        "startCursor": "cursor-1",
        "endCursor": "cursor-10"
      },
      "totalCount": 150
    }
  }
}
```

---

## 8. Filtering and Sorting

### 8.1 Filter Input Types
```graphql
input TaxReturnFilter {
  status: [TaxReturnStatus!]
  taxYear: IntFilter
  totalFee: FloatFilter
  clientId: ID
  assignedPreparerId: ID
  createdAt: DateTimeFilter
  search: String
}

input IntFilter {
  eq: Int
  ne: Int
  gt: Int
  gte: Int
  lt: Int
  lte: Int
  in: [Int!]
  notIn: [Int!]
}

input FloatFilter {
  eq: Float
  ne: Float
  gt: Float
  gte: Float
  lt: Float
  lte: Float
  in: [Float!]
  notIn: [Float!]
}

input DateTimeFilter {
  eq: DateTime
  ne: DateTime
  gt: DateTime
  gte: DateTime
  lt: DateTime
  lte: DateTime
}

input SortInput {
  field: String!
  direction: SortDirection!
}

enum SortDirection {
  ASC
  DESC
}
```

### 8.2 Filter Example
```graphql
query GetFilteredReturns {
  taxReturns(
    filter: {
      status: [IN_PROGRESS, REVIEW_REQUIRED]
      taxYear: { eq: 2024 }
      totalFee: { gte: 400.00 }
      createdAt: { 
        gte: "2025-01-01T00:00:00Z"
        lte: "2025-12-31T23:59:59Z"
      }
    }
    sort: [
      { field: "createdAt", direction: DESC }
      { field: "totalFee", direction: ASC }
    ]
    first: 20
  ) {
    edges {
      node {
        id
        status
        totalFee
        createdAt
      }
    }
  }
}
```

---

## 9. Real-time Subscriptions

### 9.1 WebSocket Connection
```javascript
import { createClient } from 'graphql-ws';

const client = createClient({
  url: 'wss://api.lawsonmobiletax.com/graphql',
  connectionParams: {
    authorization: `Bearer ${token}`,
    tenantId: tenantId
  }
});
```

### 9.2 Subscription Examples

#### 9.2.1 Tax Return Updates
```graphql
subscription TaxReturnUpdates($returnId: ID!) {
  taxReturnUpdated(id: $returnId) {
    id
    status
    aiConfidenceScore
    requiresHumanReview
    calculations {
      refundAmount
      totalTax
    }
    updatedAt
  }
}
```

#### 9.2.2 Document Processing
```graphql
subscription DocumentProcessing($documentId: ID!) {
  documentProcessed(id: $documentId) {
    id
    status
    ocrResults {
      confidence
      extractedFields {
        fieldName
        fieldValue
        confidence
      }
    }
    processedAt
  }
}
```

#### 9.2.3 E-File Status Changes
```graphql
subscription EFileStatus($returnId: ID!) {
  eFileStatusChanged(returnId: $returnId) {
    id
    status
    federalSubmissionId
    stateSubmissionId
    acknowledgmentData
    rejectionData
    updatedAt
  }
}
```

---

## 10. API Versioning

### 10.1 Version Header
```http
X-API-Version: 2024-08-22
```

### 10.2 Supported Versions
- `2024-08-22` (Current)
- `2024-01-15` (Deprecated, supported until 2025-08-22)

### 10.3 Version Deprecation Notice
```json
{
  "data": { ... },
  "warnings": [
    {
      "code": "API_VERSION_DEPRECATED",
      "message": "API version 2024-01-15 is deprecated and will be removed on 2025-08-22",
      "deprecatedVersion": "2024-01-15",
      "currentVersion": "2024-08-22",
      "sunsetDate": "2025-08-22"
    }
  ]
}
```

---

## 11. SDK Examples

### 11.1 JavaScript/TypeScript SDK
```typescript
import { LawsonTaxAPI } from '@lawson-tax/api-client';

const client = new LawsonTaxAPI({
  apiUrl: 'https://api.lawsonmobiletax.com',
  accessToken: 'your-jwt-token',
  tenantId: 'your-tenant-id'
});

// Create a tax return
const taxReturn = await client.taxReturns.create({
  clientId: 'client-uuid',
  taxYear: 2024,
  returnType: '1040',
  filingStatus: 'SINGLE'
});

// Upload a document
const uploadUrl = await client.documents.getUploadUrl({
  documentType: 'W2',
  filename: 'w2_2024.pdf',
  fileSize: 1024000
});

// Subscribe to updates
client.subscriptions.taxReturnUpdated(taxReturn.id, (update) => {
  console.log('Tax return updated:', update);
});
```

### 11.2 Python SDK
```python
from lawson_tax_api import LawsonTaxClient

client = LawsonTaxClient(
    api_url='https://api.lawsonmobiletax.com',
    access_token='your-jwt-token',
    tenant_id='your-tenant-id'
)

# Create a tax return
tax_return = client.tax_returns.create(
    client_id='client-uuid',
    tax_year=2024,
    return_type='1040',
    filing_status='SINGLE'
)

# Get tax returns with filtering
returns = client.tax_returns.list(
    filter={
        'status': ['IN_PROGRESS', 'REVIEW_REQUIRED'],
        'tax_year': {'eq': 2024}
    },
    sort=[
        {'field': 'created_at', 'direction': 'DESC'}
    ],
    limit=20
)
```

---

## 12. Testing

### 12.1 Test Environment
- **Base URL**: `https://api-test.lawsonmobiletax.com`
- **GraphQL Playground**: `https://api-test.lawsonmobiletax.com/graphql`

### 12.2 Test Data
```json
{
  "testTenant": {
    "id": "test-tenant-uuid",
    "domain": "test.formalitytax.com"
  },
  "testUser": {
    "email": "test@example.com",
    "password": "TestPassword123!",
    "role": "client"
  },
  "testClient": {
    "id": "test-client-uuid",
    "email": "client@example.com",
    "firstName": "Test",
    "lastName": "Client"
  }
}
```

### 12.3 Test API Keys
```bash
# Test environment API key
LAWSON_TAX_API_KEY=test_sk_1234567890abcdef

# Webhook test endpoints
STRIPE_TEST_WEBHOOK_SECRET=whsec_test_1234567890
OLT_TEST_WEBHOOK_SECRET=olt_test_webhook_secret
```

---

*Document Version: 1.0*
*Last Updated: August 22, 2025*
*Next Review: September 22, 2025*

---

## Appendices

### Appendix A: Complete GraphQL Schema
[INSERT COMPLETE GRAPHQL SCHEMA]

### Appendix B: OpenAPI Specification
[INSERT OPENAPI/SWAGGER SPECIFICATION]

### Appendix C: Postman Collection
[INSERT POSTMAN COLLECTION EXPORT]

### Appendix D: SDK Documentation
[INSERT DETAILED SDK DOCUMENTATION]

