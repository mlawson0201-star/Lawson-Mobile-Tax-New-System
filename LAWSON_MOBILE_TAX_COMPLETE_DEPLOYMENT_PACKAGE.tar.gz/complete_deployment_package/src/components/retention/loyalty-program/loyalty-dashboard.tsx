
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Trophy, Star, Gift, Crown, Zap, TrendingUp, 
  Calendar, ShoppingBag, Users, Award, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import confetti from 'canvas-confetti';
import { 
  LoyaltyProgram, LoyaltyTier, LoyaltyReward, 
  ClientPoints, PointsTransaction 
} from '@/lib/types/retention';

interface LoyaltyDashboardProps {
  program: LoyaltyProgram;
  clientPoints: ClientPoints;
  availableRewards: LoyaltyReward[];
  pointsHistory: PointsTransaction[];
  onRedeemReward: (rewardId: string) => void;
  onEarnPoints: (points: number, description: string) => void;
}

const TIER_COLORS = {
  bronze: 'from-amber-400 to-amber-600',
  silver: 'from-gray-400 to-gray-600',
  gold: 'from-yellow-400 to-yellow-600',
  platinum: 'from-purple-400 to-purple-600'
};

const TIER_ICONS = {
  bronze: Trophy,
  silver: Star,
  gold: Crown,
  platinum: Sparkles
};

const POINT_EARNING_ACTIVITIES = [
  { activity: 'Complete tax return', points: 500, icon: '📋' },
  { activity: 'Refer a friend', points: 1000, icon: '👥' },
  { activity: 'Write a review', points: 250, icon: '⭐' },
  { activity: 'Complete learning module', points: 100, icon: '📚' },
  { activity: 'Upload documents early', points: 150, icon: '📄' },
  { activity: 'Use tax calculator', points: 50, icon: '🧮' },
  { activity: 'Attend webinar', points: 200, icon: '🎓' },
  { activity: 'Update profile', points: 75, icon: '👤' }
];

export default function LoyaltyDashboard({
  program,
  clientPoints,
  availableRewards,
  pointsHistory,
  onRedeemReward,
  onEarnPoints
}: LoyaltyDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [showRedemption, setShowRedemption] = useState(false);
  const [selectedReward, setSelectedReward] = useState<LoyaltyReward | null>(null);
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  const currentTier = program.tiers.find(tier => tier.name.toLowerCase() === clientPoints.currentTier.toLowerCase()) || program.tiers[0];
  const nextTier = program.tiers.find(tier => tier.minPoints > clientPoints.totalPoints);
  const TierIcon = TIER_ICONS[currentTier.name.toLowerCase() as keyof typeof TIER_ICONS] || Trophy;

  const progressToNextTier = nextTier 
    ? ((clientPoints.totalPoints - currentTier.minPoints) / (nextTier.minPoints - currentTier.minPoints)) * 100
    : 100;

  const handleRedeemReward = (reward: LoyaltyReward) => {
    if (clientPoints.availablePoints >= reward.pointsCost) {
      onRedeemReward(reward.id);
      setShowRedemption(true);
      setSelectedReward(reward);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setTimeout(() => setShowRedemption(false), 3000);
    }
  };

  const getRewardsByCategory = () => {
    const categories = availableRewards.reduce((acc, reward) => {
      if (!acc[reward.type]) {
        acc[reward.type] = [];
      }
      acc[reward.type].push(reward);
      return acc;
    }, {} as Record<string, LoyaltyReward[]>);

    return categories;
  };

  const getRecentTransactions = () => {
    return pointsHistory
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);
  };

  const formatPoints = (points: number) => {
    return points.toLocaleString();
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'earned': return '💰';
      case 'redeemed': return '🎁';
      case 'expired': return '⏰';
      case 'bonus': return '🎉';
      default: return '📊';
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'earned': return 'text-green-600';
      case 'redeemed': return 'text-blue-600';
      case 'expired': return 'text-red-600';
      case 'bonus': return 'text-purple-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Loyalty Rewards Program
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Earn points for every interaction and redeem them for valuable rewards
        </p>
      </div>

      {/* Current Status Card */}
      <Card className="overflow-hidden">
        <div className={`bg-gradient-to-r ${TIER_COLORS[currentTier.name.toLowerCase() as keyof typeof TIER_COLORS]} p-6 text-white`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <TierIcon className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">{currentTier.name} Member</h3>
                <p className="text-white/80">
                  {currentTier.multiplier}x points multiplier
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold">{formatPoints(clientPoints.availablePoints)}</p>
              <p className="text-white/80">Available Points</p>
            </div>
          </div>
        </div>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{formatPoints(clientPoints.totalPoints)}</p>
              <p className="text-sm text-gray-600">Total Points Earned</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{formatPoints(clientPoints.lifetimePoints)}</p>
              <p className="text-sm text-gray-600">Lifetime Points</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">
                {nextTier ? formatPoints(clientPoints.nextTierPoints) : '∞'}
              </p>
              <p className="text-sm text-gray-600">
                {nextTier ? `Points to ${nextTier.name}` : 'Max Tier Reached'}
              </p>
            </div>
          </div>

          {nextTier && (
            <div className="mt-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Progress to {nextTier.name}</span>
                <span>{Math.round(progressToNextTier)}%</span>
              </div>
              <Progress value={progressToNextTier} className="h-3" />
              <p className="text-xs text-gray-600 mt-2">
                Earn {formatPoints(nextTier.minPoints - clientPoints.totalPoints)} more points to unlock {nextTier.name} benefits
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="rewards">Rewards</TabsTrigger>
          <TabsTrigger value="earn">Earn Points</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Tier Benefits */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Award className="w-5 h-5" />
                <span>Your {currentTier.name} Benefits</span>
              </CardTitle>
              <CardDescription>
                Exclusive perks for {currentTier.name} tier members
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentTier.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Star className="w-4 h-4 text-green-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-900">{benefit}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">
                  {pointsHistory.filter(t => t.type === 'earned').length}
                </p>
                <p className="text-sm text-gray-600">Activities Completed</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Gift className="w-6 h-6 text-purple-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">
                  {pointsHistory.filter(t => t.type === 'redeemed').length}
                </p>
                <p className="text-sm text-gray-600">Rewards Redeemed</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-green-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">
                  {currentTier.multiplier}x
                </p>
                <p className="text-sm text-gray-600">Points Multiplier</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>
                Your latest points transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {getRecentTransactions().slice(0, 5).map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{getTransactionIcon(transaction.type)}</span>
                      <div>
                        <p className="font-medium text-gray-900">{transaction.description}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(transaction.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className={`text-right ${getTransactionColor(transaction.type)}`}>
                      <p className="font-bold">
                        {transaction.type === 'redeemed' ? '-' : '+'}
                        {formatPoints(Math.abs(transaction.points))}
                      </p>
                      <p className="text-xs text-gray-500">{transaction.type}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Available Rewards
            </h3>
            <p className="text-gray-600">
              Redeem your points for valuable rewards and benefits
            </p>
          </div>

          {Object.entries(getRewardsByCategory()).map(([category, rewards]) => (
            <div key={category} className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-900 capitalize">
                {category.replace('_', ' ')} Rewards
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rewards.map((reward) => (
                  <Card key={reward.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="text-center mb-4">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Gift className="w-8 h-8 text-blue-600" />
                        </div>
                        <h5 className="font-semibold text-gray-900 mb-2">{reward.name}</h5>
                        <p className="text-sm text-gray-600 mb-3">{reward.description}</p>
                        <div className="flex items-center justify-center space-x-2 mb-3">
                          <span className="text-2xl font-bold text-blue-600">
                            {formatPoints(reward.pointsCost)}
                          </span>
                          <span className="text-sm text-gray-600">points</span>
                        </div>
                        {reward.value > 0 && (
                          <p className="text-sm text-green-600 font-medium">
                            Value: ${reward.value}
                          </p>
                        )}
                      </div>

                      <div className="space-y-2">
                        {reward.maxRedemptions && (
                          <div className="flex justify-between text-xs text-gray-600">
                            <span>Redeemed:</span>
                            <span>{reward.redemptionCount}/{reward.maxRedemptions}</span>
                          </div>
                        )}
                        {reward.expirationDate && (
                          <div className="flex justify-between text-xs text-gray-600">
                            <span>Expires:</span>
                            <span>{new Date(reward.expirationDate).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>

                      <Button
                        className="w-full mt-4"
                        onClick={() => handleRedeemReward(reward)}
                        disabled={
                          !reward.isAvailable ||
                          clientPoints.availablePoints < reward.pointsCost ||
                          (reward.maxRedemptions && reward.redemptionCount >= reward.maxRedemptions)
                        }
                      >
                        {clientPoints.availablePoints < reward.pointsCost
                          ? `Need ${formatPoints(reward.pointsCost - clientPoints.availablePoints)} more points`
                          : 'Redeem Now'
                        }
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="earn" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Ways to Earn Points
            </h3>
            <p className="text-gray-600">
              Complete activities to earn points and climb the loyalty tiers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {POINT_EARNING_ACTIVITIES.map((activity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-3xl">{activity.icon}</div>
                      <div>
                        <h4 className="font-medium text-gray-900">{activity.activity}</h4>
                        <p className="text-sm text-gray-600">
                          Earn {formatPoints(activity.points * currentTier.multiplier)} points
                        </p>
                        {currentTier.multiplier > 1 && (
                          <p className="text-xs text-blue-600">
                            {currentTier.multiplier}x {currentTier.name} bonus applied
                          </p>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => onEarnPoints(activity.points * currentTier.multiplier, activity.activity)}
                    >
                      Start
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Bonus Opportunities */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <span>Bonus Opportunities</span>
              </CardTitle>
              <CardDescription>
                Limited-time ways to earn extra points
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-purple-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Tax Season Bonus</h4>
                      <p className="text-sm text-gray-600">Double points for all activities until April 15th</p>
                    </div>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">2x Points</Badge>
                </div>

                <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-green-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Referral Streak</h4>
                      <p className="text-sm text-gray-600">Refer 3 friends this month for bonus points</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">+500 Bonus</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-900">Points History</h3>
            <div className="flex space-x-2">
              <Badge variant="outline">
                {pointsHistory.length} transactions
              </Badge>
              <Badge className="bg-green-100 text-green-800">
                {formatPoints(pointsHistory.filter(t => t.type === 'earned').reduce((sum, t) => sum + t.points, 0))} earned
              </Badge>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {getRecentTransactions().map((transaction) => (
                  <div key={transaction.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-2xl">{getTransactionIcon(transaction.type)}</div>
                        <div>
                          <h4 className="font-medium text-gray-900">{transaction.description}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{new Date(transaction.createdAt).toLocaleDateString()}</span>
                            <Badge variant="outline" className="text-xs">
                              {transaction.type}
                            </Badge>
                            {transaction.referenceId && (
                              <span className="text-xs">Ref: {transaction.referenceId}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className={`text-right ${getTransactionColor(transaction.type)}`}>
                        <p className="text-lg font-bold">
                          {transaction.type === 'redeemed' ? '-' : '+'}
                          {formatPoints(Math.abs(transaction.points))}
                        </p>
                        <p className="text-xs text-gray-500">points</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Redemption Success Modal */}
      <AnimatePresence>
        {showRedemption && selectedReward && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.8, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 50 }}
              className="bg-white rounded-lg p-8 max-w-md mx-4 text-center"
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Reward Redeemed!
              </h3>
              <p className="text-gray-600 mb-4">
                You've successfully redeemed <strong>{selectedReward.name}</strong> for{' '}
                <strong>{formatPoints(selectedReward.pointsCost)} points</strong>.
              </p>
              <p className="text-sm text-gray-500 mb-6">
                Check your email for redemption details and instructions.
              </p>
              <Button onClick={() => setShowRedemption(false)}>
                Continue Earning
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <span id="confetti" />
    </div>
  );
}
