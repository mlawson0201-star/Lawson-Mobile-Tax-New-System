
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { createGoHighLevelClient } from '@/lib/gohighlevel/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'GET':
      return handleGetSettings(req, res, tenantId);
    case 'POST':
    case 'PUT':
      return handleUpdateSettings(req, res, tenantId);
    case 'DELETE':
      return handleDeleteSettings(req, res, tenantId);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetSettings(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const settings = await prisma.gohighlevel_settings.findUnique({
      where: { tenant_id: tenantId },
    });

    if (!settings) {
      return res.status(200).json({
        settings: {
          configured: false,
          syncEnabled: false,
          syncContacts: true,
          syncAppointments: true,
          syncMessages: true,
          autoCreateLeads: true,
        },
      });
    }

    // Don't expose sensitive data
    const safeSettings = {
      configured: !!settings.api_key,
      locationId: settings.location_id,
      syncEnabled: settings.sync_enabled,
      syncContacts: settings.sync_contacts,
      syncAppointments: settings.sync_appointments,
      syncMessages: settings.sync_messages,
      autoCreateLeads: settings.auto_create_leads,
      defaultPipelineStageId: settings.default_pipeline_stage_id,
      webhookUrl: settings.webhook_url,
      lastSyncAt: settings.last_sync_at,
      fieldMappings: settings.field_mappings,
    };

    res.status(200).json({ settings: safeSettings });
  } catch (error) {
    console.error('Error fetching GoHighLevel settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
}

async function handleUpdateSettings(req: res, tenantId: string) {
  try {
    const {
      apiKey,
      locationId,
      webhookSecret,
      syncEnabled = false,
      syncContacts = true,
      syncAppointments = true,
      syncMessages = true,
      autoCreateLeads = true,
      defaultPipelineStageId,
      fieldMappings = {},
    } = req.body;

    if (!apiKey) {
      return res.status(400).json({ error: 'API key is required' });
    }

    // Test the API key
    try {
      const testClient = new (await import('@/lib/gohighlevel/client')).GoHighLevelClient(tenantId, {
        apiKey,
        locationId,
      });
      
      const isValid = await testClient.testConnection();
      if (!isValid) {
        return res.status(400).json({ error: 'Invalid API key or configuration' });
      }
    } catch (error) {
      return res.status(400).json({ error: 'Failed to validate API key' });
    }

    // Generate webhook URL
    const webhookUrl = `${process.env.NEXTAUTH_URL}/api/gohighlevel/webhook?locationId=${locationId}`;

    const settingsData = {
      tenant_id: tenantId,
      api_key: apiKey,
      location_id: locationId,
      webhook_secret: webhookSecret,
      sync_enabled: syncEnabled,
      sync_contacts: syncContacts,
      sync_appointments: syncAppointments,
      sync_messages: syncMessages,
      auto_create_leads: autoCreateLeads,
      default_pipeline_stage_id: defaultPipelineStageId,
      field_mappings: fieldMappings,
      webhook_url: webhookUrl,
      updated_at: new Date(),
    };

    const settings = await prisma.gohighlevel_settings.upsert({
      where: { tenant_id: tenantId },
      update: settingsData,
      create: settingsData,
    });

    res.status(200).json({
      message: 'Settings updated successfully',
      webhookUrl,
      settings: {
        configured: true,
        locationId: settings.location_id,
        syncEnabled: settings.sync_enabled,
        syncContacts: settings.sync_contacts,
        syncAppointments: settings.sync_appointments,
        syncMessages: settings.sync_messages,
        autoCreateLeads: settings.auto_create_leads,
        webhookUrl: settings.webhook_url,
      },
    });
  } catch (error) {
    console.error('Error updating GoHighLevel settings:', error);
    res.status(500).json({ error: 'Failed to update settings' });
  }
}

async function handleDeleteSettings(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    await prisma.gohighlevel_settings.delete({
      where: { tenant_id: tenantId },
    });

    res.status(200).json({ message: 'Settings deleted successfully' });
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Settings not found' });
    }
    console.error('Error deleting GoHighLevel settings:', error);
    res.status(500).json({ error: 'Failed to delete settings' });
  }
}
