
"""
Snapchat adapter using Snapchat Marketing API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class SnapchatAdapter(BasePlatformAdapter):
    """Adapter for Snapchat using Marketing API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.client_id = credentials.get('client_id')
        self.client_secret = credentials.get('client_secret')
        self.base_url = "https://adsapi.snapchat.com/v1"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            url = f"{self.base_url}/me"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                user_info = response.json()
                data = user_info.get('organizations', [])
                if data:
                    org_name = data[0].get('organization', {}).get('name', 'Unknown')
                    logger.info(f"Authenticated for organization: {org_name}")
                    return True
                else:
                    logger.error("No organizations found")
                    return False
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Create Snapchat content (primarily for ads)"""
        try:
            # Note: Snapchat Marketing API is primarily for advertising
            # Organic content posting is not available through public API
            
            if not media_urls or len(media_urls) == 0:
                return {"success": False, "error": "Snapchat requires media content"}
            
            # This would be for creating ad creative
            ad_account_id = kwargs.get('ad_account_id')
            if not ad_account_id:
                return {"success": False, "error": "Ad account ID required for Snapchat"}
            
            # Format content
            description = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                description = f"{content} {hashtag_text}"
            
            # Create creative asset
            url = f"{self.base_url}/adaccounts/{ad_account_id}/creatives"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            creative_data = {
                'creatives': [{
                    'name': kwargs.get('name', 'Snapchat Creative'),
                    'type': kwargs.get('creative_type', 'SNAP_AD'),
                    'packaging_status': 'PENDING',
                    'ad_product': kwargs.get('ad_product', 'SNAP_ADS'),
                    'top_snap_media_id': kwargs.get('media_id'),  # Would need to upload media first
                    'headline': kwargs.get('headline', content[:50]),
                    'brand_name': kwargs.get('brand_name', 'Lawson Mobile Tax'),
                    'call_to_action': kwargs.get('cta', 'LEARN_MORE')
                }]
            }
            
            response = requests.post(url, headers=headers, json=creative_data)
            
            if response.status_code == 200:
                result = response.json()
                creatives = result.get('creatives', [])
                if creatives:
                    creative = creatives[0]
                    return {
                        "success": True,
                        "post_id": creative.get('creative', {}).get('id'),
                        "creative_id": creative.get('creative', {}).get('id'),
                        "platform_response": result,
                        "note": "Created as ad creative - organic posting not available"
                    }
                else:
                    return {"success": False, "error": "No creative created"}
            else:
                error_msg = f"Failed to create creative: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            logger.error(f"Error creating Snapchat content: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule Snapchat content"""
        try:
            # Snapchat Marketing API doesn't support organic post scheduling
            # This would be handled by our internal scheduler for ad campaigns
            
            return {
                "success": True,
                "message": "Snapchat content scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "Snapchat API is primarily for advertising, not organic posts"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for Snapchat creative/ad"""
        try:
            # Get creative stats (for ads)
            ad_account_id = post_id.split('_')[0] if '_' in post_id else None
            if not ad_account_id:
                return {"success": False, "error": "Invalid post ID format"}
            
            url = f"{self.base_url}/creatives/{post_id}/stats"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            # Get stats for the last 7 days
            end_time = datetime.now()
            start_time = end_time.replace(day=end_time.day-7)
            
            params = {
                'granularity': 'TOTAL',
                'start_time': start_time.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
                'end_time': end_time.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
                'fields': 'impressions,swipes,spend,video_views'
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                stats = result.get('total_stats', [])
                
                if stats:
                    stat_data = stats[0].get('stats', {})
                    analytics = {
                        "post_id": post_id,
                        "impressions": stat_data.get('impressions', 0),
                        "swipes": stat_data.get('swipes', 0),
                        "video_views": stat_data.get('video_views', 0),
                        "spend": stat_data.get('spend', 0),
                        "period": "7 days",
                        "note": "Ad creative analytics"
                    }
                    
                    return {"success": True, "analytics": analytics}
                else:
                    return {"success": False, "error": "No stats available"}
            else:
                error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete Snapchat creative"""
        try:
            url = f"{self.base_url}/creatives/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.delete(url, headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            logger.error(f"Error deleting Snapchat creative: {str(e)}")
            return False
    
    async def upload_media(self, media_url: str, media_type: str = "IMAGE") -> Dict[str, Any]:
        """Upload media to Snapchat"""
        try:
            # This is a simplified version - actual implementation would need:
            # 1. Download media from URL
            # 2. Upload to Snapchat's media upload endpoint
            # 3. Get media ID for use in creatives
            
            return {
                "success": False,
                "error": "Media upload not fully implemented",
                "note": "Requires binary media upload implementation"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_ad_accounts(self) -> Dict[str, Any]:
        """Get available ad accounts"""
        try:
            url = f"{self.base_url}/me/adaccounts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                ad_accounts = result.get('adaccounts', [])
                
                account_list = []
                for account in ad_accounts:
                    account_data = account.get('adaccount', {})
                    account_list.append({
                        'id': account_data.get('id'),
                        'name': account_data.get('name'),
                        'status': account_data.get('status'),
                        'currency': account_data.get('currency'),
                        'timezone': account_data.get('timezone')
                    })
                
                return {"success": True, "ad_accounts": account_list}
            else:
                error_msg = f"Failed to get ad accounts: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
