
'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Crown,
  Check,
  Star,
  Zap,
  Shield,
  Users,
  Building2,
  CreditCard,
  Calendar,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  DollarSign,
  Package,
} from 'lucide-react';

interface SubscriptionPlan {
  id: string;
  planName: string;
  planType: 'individual' | 'family' | 'business' | 'enterprise';
  billingCycle: 'monthly' | 'quarterly' | 'annual';
  basePrice: number;
  tierLevel: 'basic' | 'premium' | 'professional' | 'enterprise';
  features: string[];
  limits: {
    maxTaxReturns: number;
    maxUsers: number;
    storageGB: number;
  };
  isActive: boolean;
  trialPeriodDays: number;
}

interface Subscription {
  id: string;
  status: 'trial' | 'active' | 'past_due' | 'cancelled' | 'suspended';
  currentPeriodStart: string;
  currentPeriodEnd: string;
  trialEnd?: string;
  autoRenew: boolean;
  usageMetrics: {
    taxReturnsUsed: number;
    storageUsed: number;
    aiProcessingUsed: number;
  };
  plan: SubscriptionPlan;
}

interface SubscriptionManagementProps {
  tenantId: string;
  clientId: string;
}

export function SubscriptionManagement({ tenantId, clientId }: SubscriptionManagementProps) {
  const [availablePlans, setAvailablePlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  useEffect(() => {
    fetchSubscriptionData();
  }, [tenantId, clientId]);

  const fetchSubscriptionData = async () => {
    try {
      setLoading(true);
      const [plansRes, subscriptionRes] = await Promise.all([
        fetch('/api/subscriptions/plans'),
        fetch(`/api/subscriptions/current?clientId=${clientId}`),
      ]);

      if (plansRes.ok) {
        const plansData = await plansRes.json();
        setAvailablePlans(plansData.plans || []);
      }

      if (subscriptionRes.ok) {
        const subData = await subscriptionRes.json();
        setCurrentSubscription(subData.subscription);
      }
    } catch (error) {
      console.error('Error fetching subscription data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = async (planId: string) => {
    try {
      const response = await fetch('/api/subscriptions/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId,
          billingCycle,
          clientId,
        }),
      });

      if (response.ok) {
        setShowUpgradeModal(false);
        fetchSubscriptionData();
      }
    } catch (error) {
      console.error('Error upgrading subscription:', error);
    }
  };

  const getPlanIcon = (tierLevel: string) => {
    switch (tierLevel) {
      case 'basic': return <Package className="h-6 w-6" />;
      case 'premium': return <Star className="h-6 w-6" />;
      case 'professional': return <Zap className="h-6 w-6" />;
      case 'enterprise': return <Crown className="h-6 w-6" />;
      default: return <Package className="h-6 w-6" />;
    }
  };

  const getPlanColor = (tierLevel: string) => {
    switch (tierLevel) {
      case 'basic': return 'from-gray-500 to-gray-600';
      case 'premium': return 'from-blue-500 to-blue-600';
      case 'professional': return 'from-purple-500 to-purple-600';
      case 'enterprise': return 'from-yellow-500 to-yellow-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-96 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-gray-900">Subscription Management</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Choose the perfect plan for your tax preparation needs. All plans include our AI-powered features and expert support.
        </p>
      </div>

      {/* Current Subscription Status */}
      {currentSubscription && (
        <motion.div
          className="bg-white rounded-xl shadow-lg border border-gray-200 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Current Subscription</h2>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              currentSubscription.status === 'active' ? 'bg-green-100 text-green-800' :
              currentSubscription.status === 'trial' ? 'bg-blue-100 text-blue-800' :
              'bg-red-100 text-red-800'
            }`}>
              {currentSubscription.status.charAt(0).toUpperCase() + currentSubscription.status.slice(1)}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-1">{currentSubscription.plan.planName}</h3>
              <p className="text-2xl font-bold text-blue-600">${currentSubscription.plan.basePrice}</p>
              <p className="text-sm text-gray-500">per {currentSubscription.plan.billingCycle.slice(0, -2)}</p>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-1">Usage</h3>
              <p className="text-lg font-semibold text-gray-900">
                {currentSubscription.usageMetrics.taxReturnsUsed} / {currentSubscription.plan.limits.maxTaxReturns}
              </p>
              <p className="text-sm text-gray-500">Tax Returns</p>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-1">Next Billing</h3>
              <p className="text-lg font-semibold text-gray-900">
                {new Date(currentSubscription.currentPeriodEnd).toLocaleDateString()}
              </p>
              <p className="text-sm text-gray-500">Auto-renew: {currentSubscription.autoRenew ? 'On' : 'Off'}</p>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-1">Storage</h3>
              <p className="text-lg font-semibold text-gray-900">
                {Math.round(currentSubscription.usageMetrics.storageUsed / 1024)} GB
              </p>
              <p className="text-sm text-gray-500">of {currentSubscription.plan.limits.storageGB} GB</p>
            </div>
          </div>

          {currentSubscription.status === 'trial' && currentSubscription.trialEnd && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg flex items-center space-x-3">
              <Clock className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Trial Period</p>
                <p className="text-sm text-blue-700">
                  Your trial expires on {new Date(currentSubscription.trialEnd).toLocaleDateString()}
                </p>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* Billing Cycle Toggle */}
      <div className="flex justify-center">
        <div className="bg-gray-100 p-1 rounded-lg">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              billingCycle === 'monthly'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('annual')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              billingCycle === 'annual'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Annual
            <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
              Save 20%
            </span>
          </button>
        </div>
      </div>

      {/* Available Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {availablePlans
          .filter(plan => plan.billingCycle === billingCycle)
          .map((plan, index) => (
            <motion.div
              key={plan.id}
              className={`relative bg-white rounded-xl shadow-lg border-2 overflow-hidden ${
                currentSubscription?.plan.id === plan.id
                  ? 'border-blue-500'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              {plan.tierLevel === 'professional' && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
                  <div className="bg-purple-600 text-white px-4 py-1 rounded-b-lg text-sm font-medium">
                    Most Popular
                  </div>
                </div>
              )}

              <div className={`bg-gradient-to-r ${getPlanColor(plan.tierLevel)} p-6 text-white`}>
                <div className="flex items-center justify-between mb-4">
                  {getPlanIcon(plan.tierLevel)}
                  {currentSubscription?.plan.id === plan.id && (
                    <CheckCircle className="h-6 w-6" />
                  )}
                </div>
                <h3 className="text-xl font-bold mb-2">{plan.planName}</h3>
                <div className="flex items-baseline">
                  <span className="text-3xl font-bold">
                    ${billingCycle === 'annual' ? Math.round(plan.basePrice * 0.8) : plan.basePrice}
                  </span>
                  <span className="text-sm opacity-80 ml-1">
                    /{billingCycle === 'annual' ? 'month' : 'month'}
                  </span>
                </div>
                {billingCycle === 'annual' && (
                  <p className="text-sm opacity-80 mt-1">
                    Billed annually (${plan.basePrice * 12 * 0.8}/year)
                  </p>
                )}
              </div>

              <div className="p-6 space-y-4">
                <div className="space-y-3">
                  {plan.features.slice(0, 6).map((feature, idx) => (
                    <div key={idx} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tax Returns:</span>
                    <span className="font-medium">
                      {plan.limits.maxTaxReturns === -1 ? 'Unlimited' : plan.limits.maxTaxReturns}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Users:</span>
                    <span className="font-medium">
                      {plan.limits.maxUsers === -1 ? 'Unlimited' : plan.limits.maxUsers}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Storage:</span>
                    <span className="font-medium">{plan.limits.storageGB} GB</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedPlan(plan.id);
                    setShowUpgradeModal(true);
                  }}
                  disabled={currentSubscription?.plan.id === plan.id}
                  className={`w-full py-2 px-4 rounded-lg font-medium transition-colors ${
                    currentSubscription?.plan.id === plan.id
                      ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {currentSubscription?.plan.id === plan.id ? 'Current Plan' : 'Choose Plan'}
                </button>

                {plan.trialPeriodDays > 0 && currentSubscription?.status !== 'trial' && (
                  <p className="text-center text-sm text-gray-500">
                    {plan.trialPeriodDays} day free trial
                  </p>
                )}
              </div>
            </motion.div>
          ))}
      </div>

      {/* Feature Comparison */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Feature Comparison</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr>
                <th className="text-left text-sm font-medium text-gray-500 pb-4">Features</th>
                {['Basic', 'Premium', 'Professional', 'Enterprise'].map((tier) => (
                  <th key={tier} className="text-center text-sm font-medium text-gray-500 pb-4 px-4">
                    {tier}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="space-y-2">
              {[
                'AI Document Processing',
                'Deduction Discovery',
                'Tax Optimization',
                'Live Chat Support',
                'Same-day Processing',
                'Audit Protection',
                'Multi-user Access',
                'API Access',
                'White-label Options',
              ].map((feature) => (
                <tr key={feature} className="border-t">
                  <td className="py-3 text-sm text-gray-700">{feature}</td>
                  <td className="py-3 text-center px-4">
                    <Check className="h-4 w-4 text-green-500 mx-auto" />
                  </td>
                  <td className="py-3 text-center px-4">
                    <Check className="h-4 w-4 text-green-500 mx-auto" />
                  </td>
                  <td className="py-3 text-center px-4">
                    <Check className="h-4 w-4 text-green-500 mx-auto" />
                  </td>
                  <td className="py-3 text-center px-4">
                    <Check className="h-4 w-4 text-green-500 mx-auto" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upgrade Confirmation Modal */}
      <AnimatePresence>
        {showUpgradeModal && selectedPlan && (
          <motion.div
            className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-xl p-6 max-w-md w-full"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Confirm Plan Change</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to upgrade to this plan? The change will take effect immediately.
              </p>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowUpgradeModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => selectedPlan && handleUpgrade(selectedPlan)}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Confirm Upgrade
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
