
"""
Configuration settings for social media automation platform
"""
import os
from typing import Dict, Any
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "sqlite:///./social_automation.db"
    
    # Redis for Celery
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # OpenAI for content generation
    OPENAI_API_KEY: str = ""
    
    # Facebook/Instagram
    FACEBOOK_APP_ID: str = ""
    FACEBOOK_APP_SECRET: str = ""
    FACEBOOK_ACCESS_TOKEN: str = ""
    
    # Twitter/X
    TWITTER_API_KEY: str = ""
    TWITTER_API_SECRET: str = ""
    TWITTER_ACCESS_TOKEN: str = ""
    TWITTER_ACCESS_TOKEN_SECRET: str = ""
    TWITTER_BEARER_TOKEN: str = ""
    
    # LinkedIn
    LINKEDIN_CLIENT_ID: str = ""
    LINKEDIN_CLIENT_SECRET: str = ""
    LINKEDIN_ACCESS_TOKEN: str = ""
    
    # TikTok
    TIKTOK_CLIENT_KEY: str = ""
    TIKTOK_CLIENT_SECRET: str = ""
    TIKTOK_ACCESS_TOKEN: str = ""
    
    # YouTube
    YOUTUBE_API_KEY: str = ""
    YOUTUBE_CLIENT_ID: str = ""
    YOUTUBE_CLIENT_SECRET: str = ""
    
    # Pinterest
    PINTEREST_APP_ID: str = ""
    PINTEREST_APP_SECRET: str = ""
    PINTEREST_ACCESS_TOKEN: str = ""
    
    # Snapchat
    SNAPCHAT_CLIENT_ID: str = ""
    SNAPCHAT_CLIENT_SECRET: str = ""
    SNAPCHAT_ACCESS_TOKEN: str = ""
    
    # Reddit
    REDDIT_CLIENT_ID: str = ""
    REDDIT_CLIENT_SECRET: str = ""
    REDDIT_USERNAME: str = ""
    REDDIT_PASSWORD: str = ""
    
    # Google My Business
    GMB_CLIENT_ID: str = ""
    GMB_CLIENT_SECRET: str = ""
    GMB_ACCESS_TOKEN: str = ""
    
    # Application settings
    SECRET_KEY: str = "your-secret-key-here"
    DEBUG: bool = True
    
    class Config:
        env_file = ".env"

settings = Settings()

# Platform configurations
PLATFORM_CONFIGS = {
    "facebook": {
        "name": "Facebook",
        "enabled": bool(settings.FACEBOOK_ACCESS_TOKEN),
        "features": ["posts", "stories", "pages", "groups"],
        "rate_limits": {"posts_per_hour": 25, "posts_per_day": 200}
    },
    "instagram": {
        "name": "Instagram", 
        "enabled": bool(settings.FACEBOOK_ACCESS_TOKEN),
        "features": ["posts", "stories", "reels", "igtv"],
        "rate_limits": {"posts_per_hour": 25, "posts_per_day": 200}
    },
    "twitter": {
        "name": "Twitter/X",
        "enabled": bool(settings.TWITTER_ACCESS_TOKEN),
        "features": ["tweets", "threads", "spaces"],
        "rate_limits": {"posts_per_hour": 300, "posts_per_day": 2400}
    },
    "linkedin": {
        "name": "LinkedIn",
        "enabled": bool(settings.LINKEDIN_ACCESS_TOKEN),
        "features": ["posts", "articles", "company_pages"],
        "rate_limits": {"posts_per_hour": 20, "posts_per_day": 100}
    },
    "tiktok": {
        "name": "TikTok",
        "enabled": bool(settings.TIKTOK_ACCESS_TOKEN),
        "features": ["videos", "stories"],
        "rate_limits": {"posts_per_hour": 10, "posts_per_day": 50}
    },
    "youtube": {
        "name": "YouTube",
        "enabled": bool(settings.YOUTUBE_API_KEY),
        "features": ["videos", "shorts", "community_posts"],
        "rate_limits": {"posts_per_hour": 6, "posts_per_day": 50}
    },
    "pinterest": {
        "name": "Pinterest",
        "enabled": bool(settings.PINTEREST_ACCESS_TOKEN),
        "features": ["pins", "boards", "story_pins"],
        "rate_limits": {"posts_per_hour": 50, "posts_per_day": 500}
    },
    "snapchat": {
        "name": "Snapchat",
        "enabled": bool(settings.SNAPCHAT_ACCESS_TOKEN),
        "features": ["snaps", "stories", "ads"],
        "rate_limits": {"posts_per_hour": 20, "posts_per_day": 100}
    },
    "reddit": {
        "name": "Reddit",
        "enabled": bool(settings.REDDIT_CLIENT_ID),
        "features": ["posts", "comments"],
        "rate_limits": {"posts_per_hour": 10, "posts_per_day": 50}
    },
    "google_my_business": {
        "name": "Google My Business",
        "enabled": bool(settings.GMB_ACCESS_TOKEN),
        "features": ["posts", "updates", "reviews"],
        "rate_limits": {"posts_per_hour": 10, "posts_per_day": 50}
    }
}
