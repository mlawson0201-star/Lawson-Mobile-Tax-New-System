
'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Star, Shield, Clock, DollarSign, Users, CheckCircle, ArrowRight, Play } from 'lucide-react';
import { ClientPersona, LandingPageVariant, Testimonial } from '@/lib/types/client-acquisition';
import PersonalizationEngine from '@/lib/ai/personalization';

interface DynamicLandingPageProps {
  variant: LandingPageVariant;
  persona?: ClientPersona;
  visitorData?: {
    referrer?: string;
    location?: string;
    device?: string;
    previousVisits?: number;
    timeOnSite?: number;
  };
  onConversion: (variantId: string, conversionType: string) => void;
}

const TRUST_INDICATORS = [
  { icon: Shield, text: 'Bank-Level Security', description: '256-bit SSL encryption' },
  { icon: Users, text: '50,000+ Happy Clients', description: 'Trusted nationwide' },
  { icon: Star, text: '4.9/5 Rating', description: 'Excellent reviews' },
  { icon: CheckCircle, text: 'IRS Approved', description: 'Authorized e-file provider' }
];

const URGENCY_MESSAGES = {
  tax_season: 'Tax deadline approaching! File before April 15th.',
  year_end: 'Year-end tax planning deadline! Optimize before December 31st.',
  limited_time: 'Limited time offer - Save 30% on all services!',
  spots_remaining: 'Only 12 spots remaining for premium service this month.'
};

export default function DynamicLandingPage({ 
  variant, 
  persona, 
  visitorData, 
  onConversion 
}: DynamicLandingPageProps) {
  const [personalizedContent, setPersonalizedContent] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [showVideo, setShowVideo] = useState(false);

  useEffect(() => {
    const loadPersonalizedContent = async () => {
      const engine = PersonalizationEngine.getInstance();
      const content = await engine.personalizeLandingPage(visitorData || {}, persona);
      setPersonalizedContent(content);
      setIsLoading(false);
    };

    loadPersonalizedContent();
  }, [persona, visitorData]);

  useEffect(() => {
    // Rotate testimonials every 5 seconds
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % variant.testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [variant.testimonials.length]);

  const handleCTAClick = (ctaType: string) => {
    onConversion(variant.id, ctaType);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const content = personalizedContent || {
    headline: variant.headline,
    subheadline: variant.subheadline,
    ctaText: variant.ctaText,
    features: variant.features,
    urgency: ''
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Urgency Bar */}
      <AnimatePresence>
        {content.urgency && (
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            className="bg-red-600 text-white py-2 px-4 text-center text-sm font-medium"
          >
            ⚠️ {content.urgency}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              {/* Persona Badge */}
              {persona && (
                <Badge variant="outline" className="text-blue-600 border-blue-600">
                  Designed for {persona.name}s
                </Badge>
              )}

              {/* Headlines */}
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  {content.headline}
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  {content.subheadline}
                </p>
              </div>

              {/* Key Benefits */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {content.features.map((feature: string, index: number) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </motion.div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="text-lg px-8 py-4"
                  style={{ backgroundColor: variant.ctaColor }}
                  onClick={() => handleCTAClick('primary')}
                >
                  {content.ctaText}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-4"
                  onClick={() => setShowVideo(true)}
                >
                  <Play className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap gap-6 pt-4">
                {TRUST_INDICATORS.map((indicator, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm text-gray-600">
                    <indicator.icon className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">{indicator.text}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Right Column - Hero Image/Video */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={variant.heroImage}
                  alt="Tax preparation platform"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                
                {/* Play Button Overlay */}
                <button
                  onClick={() => setShowVideo(true)}
                  className="absolute inset-0 flex items-center justify-center group"
                >
                  <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-white transition-colors duration-200">
                    <Play className="w-8 h-8 text-blue-600 ml-1" />
                  </div>
                </button>
              </div>

              {/* Floating Stats */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">$3,247</div>
                    <div className="text-sm text-gray-600">Avg. Refund</div>
                  </div>
                </div>
              </div>

              <div className="absolute -top-6 -right-6 bg-white rounded-xl shadow-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">15 min</div>
                    <div className="text-sm text-gray-600">Avg. Time</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Trusted by Thousands of Satisfied Clients
            </h2>
            <p className="text-lg text-gray-600">
              See what our clients are saying about their experience
            </p>
          </div>

          {/* Testimonial Carousel */}
          <div className="relative max-w-4xl mx-auto">
            <AnimatePresence mode="wait">
              {variant.testimonials.length > 0 && (
                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="p-8 text-center">
                    <CardContent className="space-y-6">
                      <div className="flex justify-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < variant.testimonials[currentTestimonial].rating
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <blockquote className="text-xl text-gray-700 italic">
                        "{variant.testimonials[currentTestimonial].content}"
                      </blockquote>
                      <div className="flex items-center justify-center space-x-4">
                        {variant.testimonials[currentTestimonial].imageUrl && (
                          <img
                            src={variant.testimonials[currentTestimonial].imageUrl}
                            alt={variant.testimonials[currentTestimonial].clientName}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                        )}
                        <div className="text-left">
                          <div className="font-semibold text-gray-900">
                            {variant.testimonials[currentTestimonial].clientName}
                          </div>
                          {variant.testimonials[currentTestimonial].clientTitle && (
                            <div className="text-sm text-gray-600">
                              {variant.testimonials[currentTestimonial].clientTitle}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Testimonial Dots */}
            <div className="flex justify-center space-x-2 mt-6">
              {variant.testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                    index === currentTestimonial ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-bold">
              Ready to Get Your Maximum Refund?
            </h2>
            <p className="text-xl text-blue-100">
              Join thousands of satisfied clients who trust us with their taxes.
              Get started in just 2 minutes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="secondary"
                className="text-lg px-8 py-4"
                onClick={() => handleCTAClick('final')}
              >
                {content.ctaText}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-blue-600"
                onClick={() => handleCTAClick('consultation')}
              >
                Free Consultation
              </Button>
            </div>
            <p className="text-sm text-blue-200">
              No credit card required • 100% satisfaction guarantee • Free support
            </p>
          </motion.div>
        </div>
      </section>

      {/* Video Modal */}
      <AnimatePresence>
        {showVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
            onClick={() => setShowVideo(false)}
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              className="bg-white rounded-lg p-6 max-w-4xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold">Platform Demo</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowVideo(false)}
                >
                  ✕
                </Button>
              </div>
              <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                <p className="text-gray-600">Demo video would play here</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
