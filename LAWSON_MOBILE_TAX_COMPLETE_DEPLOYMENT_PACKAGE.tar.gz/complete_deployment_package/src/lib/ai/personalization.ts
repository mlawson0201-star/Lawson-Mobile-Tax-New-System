
import { ClientProfile, ClientSuccessScore } from '../types/experience';
import { ClientPersona } from '../types/client-acquisition';
import { LearningPath, TaxGuidance, VideoContent } from '../types/education';

export class PersonalizationEngine {
  private static instance: PersonalizationEngine;

  public static getInstance(): PersonalizationEngine {
    if (!PersonalizationEngine.instance) {
      PersonalizationEngine.instance = new PersonalizationEngine();
    }
    return PersonalizationEngine.instance;
  }

  /**
   * Generate personalized content recommendations based on client profile
   */
  async getContentRecommendations(
    clientProfile: ClientProfile,
    contentType: 'learning' | 'guidance' | 'video' | 'all' = 'all'
  ): Promise<{
    learningPaths: LearningPath[];
    guidance: TaxGuidance[];
    videos: VideoContent[];
    confidence: number;
  }> {
    const recommendations = {
      learningPaths: [] as LearningPath[],
      guidance: [] as TaxGuidance[],
      videos: [] as VideoContent[],
      confidence: 0
    };

    // Simulate AI-powered content matching
    const personaWeights = this.getPersonaWeights(clientProfile.persona);
    const complexityFilter = this.getComplexityFilter(clientProfile.taxComplexity);
    const lifeStagePreferences = this.getLifeStagePreferences(clientProfile.lifeStage);

    // Mock recommendation logic (in production, this would use ML models)
    if (contentType === 'learning' || contentType === 'all') {
      recommendations.learningPaths = await this.mockGetLearningPaths(
        personaWeights,
        complexityFilter
      );
    }

    if (contentType === 'guidance' || contentType === 'all') {
      recommendations.guidance = await this.mockGetTaxGuidance(
        clientProfile.persona.type,
        lifeStagePreferences
      );
    }

    if (contentType === 'video' || contentType === 'all') {
      recommendations.videos = await this.mockGetVideoContent(
        personaWeights,
        complexityFilter
      );
    }

    recommendations.confidence = this.calculateConfidenceScore(clientProfile);

    return recommendations;
  }

  /**
   * Personalize landing page content based on visitor behavior
   */
  async personalizeLandingPage(
    visitorData: {
      referrer?: string;
      location?: string;
      device?: string;
      previousVisits?: number;
      timeOnSite?: number;
    },
    persona?: ClientPersona
  ): Promise<{
    headline: string;
    subheadline: string;
    ctaText: string;
    features: string[];
    testimonials: any[];
    urgency: string;
  }> {
    const personalization = {
      headline: 'Expert Tax Preparation Made Simple',
      subheadline: 'Get your maximum refund with our AI-powered tax platform',
      ctaText: 'Start Your Tax Return',
      features: [
        'Maximum refund guarantee',
        'Expert review included',
        'Audit defense protection'
      ],
      testimonials: [],
      urgency: ''
    };

    // Personalize based on persona
    if (persona) {
      switch (persona.type) {
        case 'small_business':
          personalization.headline = 'Business Tax Solutions That Save You Time & Money';
          personalization.subheadline = 'Maximize deductions and minimize stress with our business tax experts';
          personalization.ctaText = 'Get Business Tax Help';
          personalization.features = [
            'Business deduction optimization',
            'Quarterly tax planning',
            'Entity structure advice'
          ];
          break;
        case 'investor':
          personalization.headline = 'Investment Tax Strategies for Maximum Returns';
          personalization.subheadline = 'Optimize your investment taxes with advanced strategies';
          personalization.ctaText = 'Optimize My Investments';
          personalization.features = [
            'Tax loss harvesting',
            'Capital gains optimization',
            'Portfolio tax planning'
          ];
          break;
        case 'retiree':
          personalization.headline = 'Retirement Tax Planning Made Simple';
          personalization.subheadline = 'Navigate retirement taxes with confidence and ease';
          personalization.ctaText = 'Plan My Retirement Taxes';
          personalization.features = [
            'RMD calculations',
            'Social Security optimization',
            'Healthcare deductions'
          ];
          break;
      }
    }

    // Add urgency based on time of year
    const currentMonth = new Date().getMonth();
    if (currentMonth >= 0 && currentMonth <= 3) { // Jan-Apr (tax season)
      personalization.urgency = 'Tax deadline approaching! File before April 15th.';
    } else if (currentMonth >= 10) { // Nov-Dec (year-end planning)
      personalization.urgency = 'Year-end tax planning deadline! Optimize before December 31st.';
    }

    return personalization;
  }

  /**
   * Generate personalized email content
   */
  async personalizeEmail(
    clientProfile: ClientProfile,
    emailType: 'welcome' | 'reminder' | 'education' | 'promotion',
    context?: any
  ): Promise<{
    subject: string;
    content: string;
    cta: string;
    personalizationScore: number;
  }> {
    const email = {
      subject: '',
      content: '',
      cta: '',
      personalizationScore: 0
    };

    const firstName = context?.firstName || 'there';
    const personaType = clientProfile.persona.type;

    switch (emailType) {
      case 'welcome':
        email.subject = `Welcome to Lawson Mobile Tax, ${firstName}!`;
        email.content = this.generateWelcomeContent(clientProfile);
        email.cta = 'Complete Your Profile';
        break;
      case 'reminder':
        email.subject = this.generateReminderSubject(clientProfile, context);
        email.content = this.generateReminderContent(clientProfile, context);
        email.cta = 'Take Action Now';
        break;
      case 'education':
        email.subject = this.generateEducationSubject(clientProfile);
        email.content = this.generateEducationContent(clientProfile);
        email.cta = 'Learn More';
        break;
      case 'promotion':
        email.subject = this.generatePromotionSubject(clientProfile);
        email.content = this.generatePromotionContent(clientProfile);
        email.cta = 'Claim Offer';
        break;
    }

    email.personalizationScore = this.calculatePersonalizationScore(clientProfile, email);

    return email;
  }

  private getPersonaWeights(persona: ClientPersona): Record<string, number> {
    const baseWeights = {
      simplicity: 0.5,
      expertise: 0.5,
      speed: 0.5,
      cost: 0.5,
      support: 0.5
    };

    switch (persona.type) {
      case 'w2_employee':
        return { ...baseWeights, simplicity: 0.9, speed: 0.8, cost: 0.7 };
      case 'small_business':
        return { ...baseWeights, expertise: 0.9, support: 0.8, cost: 0.6 };
      case 'investor':
        return { ...baseWeights, expertise: 0.9, simplicity: 0.3, cost: 0.4 };
      case 'retiree':
        return { ...baseWeights, support: 0.9, simplicity: 0.8, speed: 0.4 };
      case 'freelancer':
        return { ...baseWeights, cost: 0.8, speed: 0.7, expertise: 0.6 };
      default:
        return baseWeights;
    }
  }

  private getComplexityFilter(complexity: string): string[] {
    switch (complexity) {
      case 'simple':
        return ['beginner'];
      case 'moderate':
        return ['beginner', 'intermediate'];
      case 'complex':
        return ['intermediate', 'advanced'];
      default:
        return ['beginner', 'intermediate'];
    }
  }

  private getLifeStagePreferences(lifeStage: string): string[] {
    switch (lifeStage) {
      case 'student':
        return ['education_credits', 'student_loans', 'first_job'];
      case 'young_professional':
        return ['career_growth', 'home_buying', 'retirement_start'];
      case 'family':
        return ['child_credits', 'education_savings', 'family_planning'];
      case 'pre_retirement':
        return ['retirement_planning', 'catch_up_contributions', 'estate_planning'];
      case 'retired':
        return ['rmd_planning', 'social_security', 'healthcare_costs'];
      default:
        return [];
    }
  }

  private async mockGetLearningPaths(
    weights: Record<string, number>,
    complexity: string[]
  ): Promise<LearningPath[]> {
    // Mock implementation - in production, this would query a database
    return [
      {
        id: '1',
        title: 'Tax Basics for Beginners',
        description: 'Learn the fundamentals of tax preparation',
        targetPersona: 'w2_employee',
        difficulty: 'beginner',
        estimatedTime: 120,
        modules: [],
        prerequisites: [],
        completionRate: 85,
        isPublished: true
      }
    ];
  }

  private async mockGetTaxGuidance(
    personaType: string,
    preferences: string[]
  ): Promise<TaxGuidance[]> {
    // Mock implementation
    return [
      {
        id: '1',
        title: 'Year-End Tax Planning Tips',
        content: 'Important strategies to consider before year-end',
        category: 'planning',
        targetPersonas: [personaType],
        priority: 'high',
        effectiveDate: new Date(),
        isPersonalized: true,
        tags: preferences
      }
    ];
  }

  private async mockGetVideoContent(
    weights: Record<string, number>,
    complexity: string[]
  ): Promise<VideoContent[]> {
    // Mock implementation
    return [
      {
        id: '1',
        title: 'Understanding Tax Deductions',
        description: 'A comprehensive guide to tax deductions',
        videoUrl: 'https://example.com/video1',
        thumbnailUrl: 'https://i.ytimg.com/vi/Sf6mhJwsyTw/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBhZR1zo-hskuzUYVw0dvdcqLoKXQ',
        duration: 600,
        category: 'deductions',
        targetPersonas: ['w2_employee'],
        difficulty: 'beginner',
        tags: ['deductions', 'basics'],
        viewCount: 1250,
        rating: 4.8,
        isPublished: true,
        createdAt: new Date()
      }
    ];
  }

  private calculateConfidenceScore(profile: ClientProfile): number {
    let score = 0.5; // Base confidence

    // Increase confidence based on profile completeness
    if (profile.completionScore > 80) score += 0.3;
    else if (profile.completionScore > 60) score += 0.2;
    else if (profile.completionScore > 40) score += 0.1;

    // Adjust based on data quality
    if (profile.financialGoals.length > 0) score += 0.1;
    if (profile.preferredCommunication) score += 0.1;

    return Math.min(score, 1.0);
  }

  private generateWelcomeContent(profile: ClientProfile): string {
    const personaType = profile.persona.type;
    const baseContent = `We're excited to help you with your tax needs! Based on your profile, we've customized your experience to focus on what matters most to you.`;

    switch (personaType) {
      case 'small_business':
        return `${baseContent} As a business owner, you'll have access to our business tax optimization tools and quarterly planning resources.`;
      case 'investor':
        return `${baseContent} As an investor, you'll find our investment tax strategies and portfolio optimization tools particularly valuable.`;
      default:
        return `${baseContent} We've prepared personalized tax guidance and resources just for you.`;
    }
  }

  private generateReminderSubject(profile: ClientProfile, context: any): string {
    const urgency = context?.urgent ? 'URGENT: ' : '';
    const action = context?.action || 'Complete your tax return';
    return `${urgency}${action} - Don't miss out!`;
  }

  private generateReminderContent(profile: ClientProfile, context: any): string {
    return `Hi there! We noticed you haven't completed ${context?.action || 'your tax return'} yet. Based on your profile, this should only take about ${context?.estimatedTime || '15'} minutes.`;
  }

  private generateEducationSubject(profile: ClientProfile): string {
    const topics = this.getLifeStagePreferences(profile.lifeStage);
    const topic = topics[0] || 'tax planning';
    return `New insights on ${topic.replace('_', ' ')} for you`;
  }

  private generateEducationContent(profile: ClientProfile): string {
    return `We've found some new tax strategies that could benefit someone in your situation. Check out our latest resources tailored specifically for your needs.`;
  }

  private generatePromotionSubject(profile: ClientProfile): string {
    return `Exclusive offer for ${profile.persona.name.toLowerCase()}s - Save 25%`;
  }

  private generatePromotionContent(profile: ClientProfile): string {
    return `As a valued client, we're offering you an exclusive 25% discount on our premium services. This offer is specifically designed for clients like you.`;
  }

  private calculatePersonalizationScore(profile: ClientProfile, email: any): number {
    let score = 0;

    // Check for personalization elements
    if (email.subject.includes(profile.persona.type)) score += 0.3;
    if (email.content.includes('your profile') || email.content.includes('your situation')) score += 0.2;
    if (email.content.length > 100) score += 0.2; // Detailed content
    if (email.cta.includes('Your') || email.cta.includes('My')) score += 0.1;

    // Bonus for persona-specific content
    if (profile.persona.type === 'small_business' && email.content.includes('business')) score += 0.2;

    return Math.min(score, 1.0);
  }
}

export default PersonalizationEngine;
