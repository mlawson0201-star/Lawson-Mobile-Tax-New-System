
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { mlClient } from '@/lib/ml-client';
import { z } from 'zod';

const DeductionEngineRequestSchema = z.object({
  taxReturnId: z.string(),
  clientId: z.string(),
  analysisType: z.enum(['comprehensive', 'targeted', 'audit_safe']),
  includeHistorical: z.boolean().default(true),
  confidenceThreshold: z.number().min(0).max(1).default(0.75),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { taxReturnId, clientId, analysisType, includeHistorical, confidenceThreshold } = 
      DeductionEngineRequestSchema.parse(body);

    // Get tax return and client data
    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: {
        client: {
          include: {
            documents: true,
            taxReturns: {
              where: { taxYear: { not: taxReturn?.taxYear } },
              take: 3,
              orderBy: { createdAt: 'desc' }
            }
          }
        },
        documents: {
          include: {
            extractions: true
          }
        }
      }
    });

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
    }

    // Prepare ML request data
    const clientData = {
      id: taxReturn.client.id,
      income: taxReturn.formData?.income || 0,
      filingStatus: taxReturn.formData?.filingStatus || 'single',
      dependents: taxReturn.formData?.dependents || 0,
      businessIncome: taxReturn.formData?.businessIncome || 0,
      selfEmployed: taxReturn.client.personalInfo?.selfEmployed || false,
      homeOwner: taxReturn.client.personalInfo?.homeOwner || false,
      hasChildren: (taxReturn.formData?.dependents || 0) > 0,
      charitableDonations: taxReturn.formData?.charitableDonations || 0,
      medicalExpenses: taxReturn.formData?.medicalExpenses || 0,
      educationExpenses: taxReturn.formData?.educationExpenses || 0,
      businessExpenses: taxReturn.formData?.businessExpenses || 0,
    };

    // Process document data
    const documentData = taxReturn.documents.map(doc => ({
      type: doc.documentType,
      extractedData: doc.extractedData,
      confidence: doc.ocrConfidence || 0.8,
      amount: doc.extractedData?.amount || 0,
      category: doc.extractedData?.category || 'other',
    }));

    // Include historical data if requested
    let historicalData = {};
    if (includeHistorical && taxReturn.client.taxReturns.length > 0) {
      historicalData = {
        previousReturns: taxReturn.client.taxReturns.map(tr => ({
          taxYear: tr.taxYear,
          totalDeductions: tr.formData?.totalDeductions || 0,
          agi: tr.formData?.agi || 0,
          refundAmount: tr.refundAmount || 0,
        })),
        averageDeductions: taxReturn.client.taxReturns.reduce(
          (sum, tr) => sum + (tr.formData?.totalDeductions || 0), 0
        ) / taxReturn.client.taxReturns.length,
      };
    }

    // Call ML service for deduction predictions
    const mlResponse = await mlClient.predictDeductions({
      tax_return_id: taxReturnId,
      client_data: clientData,
      document_data: documentData,
      historical_data: includeHistorical ? historicalData : undefined,
    });

    // Filter predictions by confidence threshold
    const filteredPredictions = Object.entries(mlResponse.predictions)
      .filter(([_, prediction]: [string, any]) => 
        prediction.confidence >= confidenceThreshold
      )
      .reduce((acc, [key, prediction]) => ({ ...acc, [key]: prediction }), {});

    // Save high-confidence predictions to database
    const savedPredictions = [];
    for (const [category, prediction] of Object.entries(filteredPredictions)) {
      const pred = prediction as any;
      if (pred.eligible && pred.estimated_amount > 0) {
        const savedPrediction = await prisma.deductionPrediction.create({
          data: {
            tenantId: taxReturn.tenantId,
            taxReturnId: taxReturnId,
            modelId: 'advanced-deduction-engine-v2',
            deductionCategory: category,
            predictedAmount: pred.estimated_amount,
            confidenceScore: pred.confidence,
            supportingEvidence: {
              requiredDocuments: pred.supporting_documents || [],
              taxCodeReferences: pred.tax_code_references || [],
              reasoning: pred.reasoning || '',
              estimationMethod: pred.estimation_method || 'ml_model',
            },
            status: pred.confidence > 0.9 ? 'approved' : 'pending',
            humanVerified: false,
          }
        });
        savedPredictions.push(savedPrediction);
      }
    }

    // Generate comprehensive analysis report
    const analysisReport = {
      summary: {
        totalPredictions: Object.keys(filteredPredictions).length,
        highConfidencePredictions: Object.values(filteredPredictions)
          .filter((p: any) => p.confidence > 0.9).length,
        potentialSavings: mlResponse.total_potential_savings,
        processingTime: mlResponse.processing_time,
      },
      predictions: filteredPredictions,
      recommendations: generateRecommendations(filteredPredictions, analysisType),
      nextSteps: generateNextSteps(filteredPredictions, taxReturn),
      complianceNotes: generateComplianceNotes(filteredPredictions),
    };

    // Update tax return with AI analysis
    await prisma.taxReturn.update({
      where: { id: taxReturnId },
      data: {
        aiConfidenceScore: mlResponse.confidence_scores ? 
          Object.values(mlResponse.confidence_scores).reduce((a, b) => a + b, 0) / 
          Object.values(mlResponse.confidence_scores).length : 0.8,
        calculations: {
          ...taxReturn.calculations,
          aiDeductionAnalysis: analysisReport,
          lastAnalyzed: new Date().toISOString(),
        }
      }
    });

    return NextResponse.json({
      success: true,
      analysis: analysisReport,
      savedPredictions: savedPredictions.length,
      mlMetrics: {
        totalPotentialSavings: mlResponse.total_potential_savings,
        averageConfidence: mlResponse.confidence_scores ? 
          Object.values(mlResponse.confidence_scores).reduce((a, b) => a + b, 0) / 
          Object.values(mlResponse.confidence_scores).length : 0,
        processingTime: mlResponse.processing_time,
      }
    });

  } catch (error) {
    console.error('Advanced Deduction Engine Error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze deductions', details: error.message },
      { status: 500 }
    );
  }
}

function generateRecommendations(predictions: any, analysisType: string): string[] {
  const recommendations = [];
  
  for (const [category, prediction] of Object.entries(predictions)) {
    const pred = prediction as any;
    if (pred.eligible && pred.confidence > 0.8) {
      switch (category) {
        case 'business_expenses':
          recommendations.push(
            `Maximize business expense deductions: Potential savings of $${pred.estimated_amount.toFixed(2)}`
          );
          recommendations.push(
            'Ensure all business expenses are properly documented with receipts and business purpose'
          );
          break;
        case 'home_office':
          recommendations.push(
            `Claim home office deduction: Estimated $${pred.estimated_amount.toFixed(2)} deduction available`
          );
          recommendations.push(
            'Measure home office space and maintain records of home expenses'
          );
          break;
        case 'charitable':
          recommendations.push(
            `Optimize charitable deductions: Additional $${pred.estimated_amount.toFixed(2)} may be deductible`
          );
          recommendations.push(
            'Gather all charitable contribution receipts and acknowledgment letters'
          );
          break;
      }
    }
  }

  if (analysisType === 'audit_safe') {
    recommendations.push('All recommendations have been filtered for audit safety');
    recommendations.push('Consider additional documentation for deductions over industry averages');
  }

  return recommendations;
}

function generateNextSteps(predictions: any, taxReturn: any): string[] {
  const nextSteps = [];
  
  const highValuePredictions = Object.entries(predictions)
    .filter(([_, pred]: [string, any]) => pred.estimated_amount > 500)
    .sort(([_, a]: [string, any], [__, b]: [string, any]) => b.estimated_amount - a.estimated_amount);

  if (highValuePredictions.length > 0) {
    nextSteps.push('Review high-value deduction opportunities in order of potential savings');
    
    highValuePredictions.slice(0, 3).forEach(([category, pred]: [string, any]) => {
      nextSteps.push(
        `${category.replace('_', ' ').toUpperCase()}: Gather ${pred.supporting_documents?.join(', ') || 'supporting documents'}`
      );
    });
  }

  nextSteps.push('Schedule client consultation to review deduction opportunities');
  nextSteps.push('Update tax return with approved deductions');
  nextSteps.push('Perform final compliance review before filing');

  return nextSteps;
}

function generateComplianceNotes(predictions: any): string[] {
  const notes = [];
  
  for (const [category, prediction] of Object.entries(predictions)) {
    const pred = prediction as any;
    if (pred.eligible && pred.tax_code_references) {
      notes.push(
        `${category.toUpperCase()}: Governed by ${pred.tax_code_references.join(', ')}`
      );
    }
  }

  notes.push('All deductions must be substantiated with proper documentation');
  notes.push('Business deductions require clear business purpose and ordinary/necessary test');
  notes.push('Charitable deductions require contemporaneous written acknowledgment for amounts over $250');

  return notes;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const taxReturnId = searchParams.get('taxReturnId');
    const tenantId = searchParams.get('tenantId');

    if (!taxReturnId && !tenantId) {
      return NextResponse.json({ error: 'taxReturnId or tenantId required' }, { status: 400 });
    }

    let predictions;
    if (taxReturnId) {
      predictions = await prisma.deductionPrediction.findMany({
        where: { taxReturnId },
        orderBy: { confidenceScore: 'desc' }
      });
    } else {
      predictions = await prisma.deductionPrediction.findMany({
        where: { tenantId },
        include: {
          taxReturn: {
            include: {
              client: {
                select: { firstName: true, lastName: true, email: true }
              }
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 50
      });
    }

    return NextResponse.json({
      predictions,
      summary: {
        total: predictions.length,
        pending: predictions.filter(p => p.status === 'pending').length,
        approved: predictions.filter(p => p.status === 'approved').length,
        totalPotentialSavings: predictions.reduce((sum, p) => sum + Number(p.predictedAmount), 0),
      }
    });

  } catch (error) {
    console.error('Get Deduction Predictions Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve predictions' },
      { status: 500 }
    );
  }
}
