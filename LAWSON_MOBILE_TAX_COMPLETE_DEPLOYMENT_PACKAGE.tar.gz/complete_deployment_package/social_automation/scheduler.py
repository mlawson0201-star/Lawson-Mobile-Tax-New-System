
"""
Social media post scheduler using Celery and APScheduler
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from celery import Celery
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.executors.pool import ThreadPoolExecutor
import logging
from sqlalchemy.orm import Session

from config import settings
from database import get_db, Post, SocialAccount, Campaign
from platform_adapters import PlatformAdapterFactory
from ai_content import AIContentGenerator
from analytics import AnalyticsCollector

logger = logging.getLogger(__name__)

# Celery configuration
celery_app = Celery(
    'social_automation',
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_routes={
        'social_automation.scheduler.post_to_platform': {'queue': 'posts'},
        'social_automation.scheduler.collect_analytics': {'queue': 'analytics'},
        'social_automation.scheduler.generate_content': {'queue': 'content'},
    }
)

# APScheduler configuration
jobstores = {
    'default': SQLAlchemyJobStore(url=settings.DATABASE_URL)
}
executors = {
    'default': ThreadPoolExecutor(20),
}
job_defaults = {
    'coalesce': False,
    'max_instances': 3
}

scheduler = AsyncIOScheduler(
    jobstores=jobstores,
    executors=executors,
    job_defaults=job_defaults
)

class SocialMediaScheduler:
    """Main scheduler for social media automation"""
    
    def __init__(self):
        self.ai_generator = AIContentGenerator()
        self.analytics_collector = AnalyticsCollector()
        
    async def start(self):
        """Start the scheduler"""
        scheduler.start()
        logger.info("Social media scheduler started")
    
    async def stop(self):
        """Stop the scheduler"""
        scheduler.shutdown()
        logger.info("Social media scheduler stopped")
    
    async def schedule_post(self, post_data: Dict[str, Any]) -> str:
        """Schedule a single post"""
        try:
            post_id = post_data.get('post_id')
            scheduled_time = post_data.get('scheduled_time')
            
            if isinstance(scheduled_time, str):
                scheduled_time = datetime.fromisoformat(scheduled_time)
            
            # Schedule the job
            job = scheduler.add_job(
                func=self._execute_scheduled_post,
                trigger='date',
                run_date=scheduled_time,
                args=[post_data],
                id=f"post_{post_id}",
                replace_existing=True
            )
            
            logger.info(f"Scheduled post {post_id} for {scheduled_time}")
            return job.id
            
        except Exception as e:
            logger.error(f"Error scheduling post: {str(e)}")
            raise
    
    async def schedule_campaign(self, campaign_id: int) -> List[str]:
        """Schedule all posts for a campaign"""
        try:
            db = next(get_db())
            campaign = db.query(Campaign).filter(Campaign.id == campaign_id).first()
            
            if not campaign:
                raise ValueError(f"Campaign {campaign_id} not found")
            
            job_ids = []
            posting_schedule = campaign.posting_schedule or {}
            
            # Generate posts based on campaign configuration
            posts = await self._generate_campaign_posts(campaign, db)
            
            for post_data in posts:
                job_id = await self.schedule_post(post_data)
                job_ids.append(job_id)
            
            logger.info(f"Scheduled {len(job_ids)} posts for campaign {campaign_id}")
            return job_ids
            
        except Exception as e:
            logger.error(f"Error scheduling campaign: {str(e)}")
            raise
        finally:
            db.close()
    
    async def _generate_campaign_posts(self, campaign: Campaign, db: Session) -> List[Dict[str, Any]]:
        """Generate posts for a campaign based on its configuration"""
        posts = []
        
        try:
            platforms = campaign.platforms or []
            content_templates = campaign.content_templates or []
            schedule_config = campaign.posting_schedule or {}
            
            # Get posting frequency and times
            frequency = schedule_config.get('frequency', 'daily')  # daily, weekly, monthly
            times = schedule_config.get('times', ['09:00', '15:00'])  # Times to post
            days_of_week = schedule_config.get('days_of_week', [0, 1, 2, 3, 4])  # Mon-Fri
            
            current_date = campaign.start_date
            end_date = campaign.end_date or (campaign.start_date + timedelta(days=30))
            
            post_id_counter = 1
            
            while current_date <= end_date:
                # Check if we should post on this day
                if frequency == 'daily' or (frequency == 'weekly' and current_date.weekday() in days_of_week):
                    
                    for time_str in times:
                        hour, minute = map(int, time_str.split(':'))
                        post_datetime = current_date.replace(hour=hour, minute=minute)
                        
                        # Skip past dates
                        if post_datetime <= datetime.now():
                            continue
                        
                        for platform in platforms:
                            # Get platform-specific accounts
                            accounts = db.query(SocialAccount).filter(
                                SocialAccount.platform == platform,
                                SocialAccount.is_active == True
                            ).all()
                            
                            for account in accounts:
                                # Generate content for this post
                                content_data = await self.ai_generator.generate_campaign_content(
                                    campaign, platform, content_templates
                                )
                                
                                post_data = {
                                    'post_id': f"{campaign.id}_{post_id_counter}",
                                    'campaign_id': campaign.id,
                                    'account_id': account.id,
                                    'platform': platform,
                                    'content': content_data.get('content', ''),
                                    'hashtags': content_data.get('hashtags', []),
                                    'media_urls': content_data.get('media_urls', []),
                                    'scheduled_time': post_datetime,
                                    'metadata': content_data.get('metadata', {})
                                }
                                
                                posts.append(post_data)
                                post_id_counter += 1
                
                # Move to next day
                if frequency == 'daily':
                    current_date += timedelta(days=1)
                elif frequency == 'weekly':
                    current_date += timedelta(days=7)
                elif frequency == 'monthly':
                    # Move to next month
                    if current_date.month == 12:
                        current_date = current_date.replace(year=current_date.year + 1, month=1)
                    else:
                        current_date = current_date.replace(month=current_date.month + 1)
            
            return posts
            
        except Exception as e:
            logger.error(f"Error generating campaign posts: {str(e)}")
            return []
    
    async def _execute_scheduled_post(self, post_data: Dict[str, Any]):
        """Execute a scheduled post"""
        try:
            # Use Celery for actual posting to handle retries and failures
            post_to_platform.delay(post_data)
            
        except Exception as e:
            logger.error(f"Error executing scheduled post: {str(e)}")
            raise
    
    async def cancel_scheduled_post(self, post_id: str) -> bool:
        """Cancel a scheduled post"""
        try:
            job_id = f"post_{post_id}"
            scheduler.remove_job(job_id)
            logger.info(f"Cancelled scheduled post {post_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error cancelling scheduled post: {str(e)}")
            return False
    
    async def get_scheduled_posts(self) -> List[Dict[str, Any]]:
        """Get all scheduled posts"""
        try:
            jobs = scheduler.get_jobs()
            scheduled_posts = []
            
            for job in jobs:
                if job.id.startswith('post_'):
                    scheduled_posts.append({
                        'job_id': job.id,
                        'post_id': job.id.replace('post_', ''),
                        'next_run_time': job.next_run_time.isoformat() if job.next_run_time else None,
                        'function': job.func.__name__,
                        'args': job.args
                    })
            
            return scheduled_posts
            
        except Exception as e:
            logger.error(f"Error getting scheduled posts: {str(e)}")
            return []
    
    async def reschedule_post(self, post_id: str, new_time: datetime) -> bool:
        """Reschedule an existing post"""
        try:
            job_id = f"post_{post_id}"
            scheduler.modify_job(job_id, next_run_time=new_time)
            logger.info(f"Rescheduled post {post_id} to {new_time}")
            return True
            
        except Exception as e:
            logger.error(f"Error rescheduling post: {str(e)}")
            return False

# Celery tasks
@celery_app.task(bind=True, autoretry_for=(Exception,), retry_kwargs={'max_retries': 3, 'countdown': 60})
def post_to_platform(self, post_data: Dict[str, Any]):
    """Celery task to post content to a platform"""
    try:
        # Run the async function in a new event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(_post_to_platform_async(post_data))
        loop.close()
        return result
        
    except Exception as e:
        logger.error(f"Error in post_to_platform task: {str(e)}")
        raise

async def _post_to_platform_async(post_data: Dict[str, Any]) -> Dict[str, Any]:
    """Async function to post content to a platform"""
    try:
        db = next(get_db())
        
        # Get account information
        account_id = post_data.get('account_id')
        account = db.query(SocialAccount).filter(SocialAccount.id == account_id).first()
        
        if not account:
            raise ValueError(f"Account {account_id} not found")
        
        # Create platform adapter
        credentials = {
            'access_token': account.access_token,
            'refresh_token': account.refresh_token,
            # Add other platform-specific credentials as needed
        }
        
        adapter = PlatformAdapterFactory.create_adapter(account.platform, credentials)
        
        # Authenticate
        auth_success = await adapter.authenticate()
        if not auth_success:
            raise Exception(f"Authentication failed for {account.platform}")
        
        # Post content
        result = await adapter.post_content(
            content=post_data.get('content', ''),
            media_urls=post_data.get('media_urls', []),
            hashtags=post_data.get('hashtags', []),
            **post_data.get('metadata', {})
        )
        
        # Update database
        post_record = Post(
            account_id=account_id,
            platform=account.platform,
            content=post_data.get('content', ''),
            media_urls=post_data.get('media_urls', []),
            hashtags=post_data.get('hashtags', []),
            scheduled_time=post_data.get('scheduled_time'),
            posted_time=datetime.utcnow(),
            status='posted' if result.get('success') else 'failed',
            platform_post_id=result.get('post_id'),
            error_message=result.get('error') if not result.get('success') else None
        )
        
        db.add(post_record)
        db.commit()
        
        # Schedule analytics collection
        if result.get('success'):
            collect_analytics.apply_async(
                args=[post_record.id, result.get('post_id')],
                countdown=3600  # Collect analytics after 1 hour
            )
        
        logger.info(f"Posted to {account.platform}: {result}")
        return result
        
    except Exception as e:
        logger.error(f"Error posting to platform: {str(e)}")
        raise
    finally:
        db.close()

@celery_app.task(bind=True, autoretry_for=(Exception,), retry_kwargs={'max_retries': 5, 'countdown': 300})
def collect_analytics(self, post_record_id: int, platform_post_id: str):
    """Celery task to collect analytics for a post"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(_collect_analytics_async(post_record_id, platform_post_id))
        loop.close()
        return result
        
    except Exception as e:
        logger.error(f"Error in collect_analytics task: {str(e)}")
        raise

async def _collect_analytics_async(post_record_id: int, platform_post_id: str) -> Dict[str, Any]:
    """Async function to collect analytics for a post"""
    try:
        db = next(get_db())
        
        # Get post record
        post_record = db.query(Post).filter(Post.id == post_record_id).first()
        if not post_record:
            raise ValueError(f"Post record {post_record_id} not found")
        
        # Get account
        account = db.query(SocialAccount).filter(SocialAccount.id == post_record.account_id).first()
        if not account:
            raise ValueError(f"Account {post_record.account_id} not found")
        
        # Create platform adapter
        credentials = {
            'access_token': account.access_token,
            'refresh_token': account.refresh_token,
        }
        
        adapter = PlatformAdapterFactory.create_adapter(account.platform, credentials)
        
        # Authenticate
        auth_success = await adapter.authenticate()
        if not auth_success:
            raise Exception(f"Authentication failed for {account.platform}")
        
        # Get analytics
        analytics_result = await adapter.get_post_analytics(platform_post_id)
        
        if analytics_result.get('success'):
            # Update post record with analytics
            post_record.engagement_metrics = analytics_result.get('analytics', {})
            db.commit()
            
            # Schedule next analytics collection (daily for first week, then weekly)
            days_since_post = (datetime.utcnow() - post_record.posted_time).days
            if days_since_post < 7:
                # Collect daily for first week
                collect_analytics.apply_async(
                    args=[post_record_id, platform_post_id],
                    countdown=86400  # 24 hours
                )
            elif days_since_post < 30:
                # Collect weekly for first month
                collect_analytics.apply_async(
                    args=[post_record_id, platform_post_id],
                    countdown=604800  # 7 days
                )
        
        logger.info(f"Collected analytics for post {post_record_id}: {analytics_result}")
        return analytics_result
        
    except Exception as e:
        logger.error(f"Error collecting analytics: {str(e)}")
        raise
    finally:
        db.close()

@celery_app.task
def generate_content(template_id: int, platform: str, context: Dict[str, Any] = None):
    """Celery task to generate content using AI"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        ai_generator = AIContentGenerator()
        result = loop.run_until_complete(
            ai_generator.generate_content_from_template(template_id, platform, context or {})
        )
        
        loop.close()
        return result
        
    except Exception as e:
        logger.error(f"Error in generate_content task: {str(e)}")
        raise

# Periodic tasks
@celery_app.task
def cleanup_old_posts():
    """Clean up old posts and analytics data"""
    try:
        db = next(get_db())
        
        # Delete posts older than 1 year
        cutoff_date = datetime.utcnow() - timedelta(days=365)
        old_posts = db.query(Post).filter(Post.created_at < cutoff_date).all()
        
        for post in old_posts:
            db.delete(post)
        
        db.commit()
        logger.info(f"Cleaned up {len(old_posts)} old posts")
        
    except Exception as e:
        logger.error(f"Error in cleanup task: {str(e)}")
    finally:
        db.close()

# Schedule periodic tasks
celery_app.conf.beat_schedule = {
    'cleanup-old-posts': {
        'task': 'social_automation.scheduler.cleanup_old_posts',
        'schedule': 86400.0,  # Run daily
    },
}
