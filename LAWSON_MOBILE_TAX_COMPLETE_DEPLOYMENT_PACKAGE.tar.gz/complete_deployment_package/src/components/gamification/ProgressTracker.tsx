"use client";

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Trophy, 
  Star, 
  Target, 
  Zap, 
  Gift, 
  Users, 
  Calendar,
  TrendingUp,
  Award,
  Flame,
  CheckCircle,
  Clock,
  Crown,
  Sparkles,
  Medal,
  Rocket
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface XPEvent {
  id: string;
  category: string;
  points: number;
  description: string;
  timestamp: Date;
  multiplier: number;
  bonus_reason?: string;
}

interface Milestone {
  id: string;
  name: string;
  description: string;
  icon: string;
  xp_reward: number;
  completed: boolean;
  progress: number;
  total_required: number;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  unlock_date?: Date;
}

interface UserProgress {
  current_stage: string;
  completion_percentage: number;
  total_xp: number;
  level: number;
  current_streak: number;
  rank: number;
  next_level_xp: number;
  level_progress: number;
}

export default function ProgressTracker() {
  const [activeTab, setActiveTab] = useState('progress');
  const [userProgress, setUserProgress] = useState<UserProgress>({
    current_stage: 'deduction_optimization',
    completion_percentage: 67,
    total_xp: 8450,
    level: 12,
    current_streak: 7,
    rank: 23,
    next_level_xp: 1550,
    level_progress: 73
  });

  const [recentXP, setRecentXP] = useState<XPEvent[]>([
    {
      id: '1',
      category: 'document_upload',
      points: 150,
      description: 'Uploaded W-2 form',
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      multiplier: 1.5,
      bonus_reason: 'Early bird bonus'
    },
    {
      id: '2',
      category: 'optimization_found',
      points: 300,
      description: 'Found $1,200 in tax savings',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      multiplier: 1.0
    },
    {
      id: '3',
      category: 'streak_bonus',
      points: 75,
      description: '7-day activity streak',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      multiplier: 1.0
    }
  ]);

  const [milestones, setMilestones] = useState<Milestone[]>([
    {
      id: 'first_document',
      name: 'First Document',
      description: 'Upload your first tax document',
      icon: '📄',
      xp_reward: 100,
      completed: true,
      progress: 1,
      total_required: 1
    },
    {
      id: 'document_collector',
      name: 'Document Collector',
      description: 'Upload 5 tax documents',
      icon: '📚',
      xp_reward: 250,
      completed: true,
      progress: 5,
      total_required: 5
    },
    {
      id: 'deduction_optimizer',
      name: 'Deduction Optimizer',
      description: 'Find $1000+ in tax savings',
      icon: '🎯',
      xp_reward: 750,
      completed: false,
      progress: 800,
      total_required: 1000
    },
    {
      id: 'perfectionist',
      name: 'Perfectionist',
      description: 'Complete with 100% accuracy',
      icon: '⭐',
      xp_reward: 1500,
      completed: false,
      progress: 0,
      total_required: 1
    }
  ]);

  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: 'speed_demon',
      title: 'Speed Demon',
      description: 'Complete tax prep in under 2 hours',
      icon: '⚡',
      rarity: 'rare',
      unlocked: true,
      unlock_date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3)
    },
    {
      id: 'savings_master',
      title: 'Savings Master',
      description: 'Find over $5,000 in tax savings',
      icon: '💰',
      rarity: 'epic',
      unlocked: false
    },
    {
      id: 'streak_warrior',
      title: 'Streak Warrior',
      description: 'Maintain a 30-day activity streak',
      icon: '🔥',
      rarity: 'legendary',
      unlocked: false
    },
    {
      id: 'early_bird',
      title: 'Early Bird',
      description: 'File taxes before February 15th',
      icon: '🐦',
      rarity: 'common',
      unlocked: true,
      unlock_date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10)
    }
  ]);

  const [leaderboard] = useState([
    { rank: 1, username: 'TaxNinja2025', xp: 15420, level: 28, streak: 45 },
    { rank: 2, username: 'DeductionMaster', xp: 14890, level: 27, streak: 32 },
    { rank: 3, username: 'OptimizeThis', xp: 13750, level: 25, streak: 28 },
    { rank: 23, username: 'You', xp: 8450, level: 12, streak: 7 },
    { rank: 24, username: 'TaxPro2024', xp: 8320, level: 12, streak: 15 }
  ]);

  useEffect(() => {
    // Simulate real-time XP updates
    const interval = setInterval(() => {
      if (Math.random() < 0.1) { // 10% chance every 5 seconds
        const newXP: XPEvent = {
          id: Date.now().toString(),
          category: 'form_completion',
          points: Math.floor(Math.random() * 100) + 50,
          description: 'Completed tax form section',
          timestamp: new Date(),
          multiplier: 1.0
        };
        
        setRecentXP(prev => [newXP, ...prev.slice(0, 9)]);
        setUserProgress(prev => ({
          ...prev,
          total_xp: prev.total_xp + newXP.points
        }));
        
        // Trigger celebration
        triggerCelebration('xp');
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const triggerCelebration = (type: 'xp' | 'milestone' | 'achievement' | 'level') => {
    const colors = {
      xp: ['#FFD700', '#FFA500'],
      milestone: ['#9333EA', '#C084FC'],
      achievement: ['#10B981', '#34D399'],
      level: ['#EF4444', '#F87171']
    };

    confetti({
      particleCount: type === 'level' ? 150 : 100,
      spread: type === 'level' ? 100 : 70,
      origin: { y: 0.6 },
      colors: colors[type]
    });
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-500';
      case 'rare': return 'bg-blue-500';
      case 'epic': return 'bg-purple-500';
      case 'legendary': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else if (diffInMinutes < 1440) {
      return `${Math.floor(diffInMinutes / 60)}h ago`;
    } else {
      return `${Math.floor(diffInMinutes / 1440)}d ago`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Level and XP */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Trophy className="h-8 w-8 text-yellow-600" />
            Tax Progress Tracker
          </h1>
          <p className="text-muted-foreground mt-1">
            Level up your tax preparation with XP and achievements
          </p>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              Level {userProgress.level}
            </div>
            <div className="text-sm text-muted-foreground">
              {userProgress.total_xp.toLocaleString()} XP
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600 flex items-center gap-1">
              <Flame className="h-6 w-6" />
              {userProgress.current_streak}
            </div>
            <div className="text-sm text-muted-foreground">
              Day Streak
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              #{userProgress.rank}
            </div>
            <div className="text-sm text-muted-foreground">
              Global Rank
            </div>
          </div>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Tax Completion</h3>
              <Badge variant="outline">{userProgress.completion_percentage}%</Badge>
            </div>
            <Progress value={userProgress.completion_percentage} className="mb-2" />
            <p className="text-sm text-muted-foreground">
              Current stage: {userProgress.current_stage.replace('_', ' ')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Level Progress</h3>
              <Badge variant="outline">{userProgress.level_progress}%</Badge>
            </div>
            <Progress value={userProgress.level_progress} className="mb-2" />
            <p className="text-sm text-muted-foreground">
              {userProgress.next_level_xp.toLocaleString()} XP to next level
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Milestones</h3>
              <Badge variant="outline">
                {milestones.filter(m => m.completed).length}/{milestones.length}
              </Badge>
            </div>
            <div className="flex gap-2">
              {milestones.slice(0, 4).map((milestone) => (
                <div
                  key={milestone.id}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                    milestone.completed 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {milestone.completed ? <CheckCircle className="h-4 w-4" /> : milestone.icon}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="progress">Progress</TabsTrigger>
          <TabsTrigger value="milestones">Milestones</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          <TabsTrigger value="rewards">Rewards</TabsTrigger>
        </TabsList>

        <TabsContent value="progress" className="space-y-6">
          {/* Recent XP Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Recent XP Activity
              </CardTitle>
              <CardDescription>
                Your latest experience point earnings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentXP.map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Star className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium">{event.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatTimeAgo(event.timestamp)}
                          {event.bonus_reason && ` • ${event.bonus_reason}`}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">
                        +{event.points} XP
                      </div>
                      {event.multiplier > 1 && (
                        <div className="text-xs text-orange-600">
                          {event.multiplier}x multiplier
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Progress Stages */}
          <Card>
            <CardHeader>
              <CardTitle>Tax Preparation Stages</CardTitle>
              <CardDescription>
                Track your progress through each stage of tax preparation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { stage: 'getting_started', name: 'Getting Started', completed: true, xp: 100 },
                  { stage: 'document_collection', name: 'Document Collection', completed: true, xp: 300 },
                  { stage: 'income_entry', name: 'Income Entry', completed: true, xp: 500 },
                  { stage: 'deduction_optimization', name: 'Deduction Optimization', completed: false, xp: 750 },
                  { stage: 'review_validation', name: 'Review & Validation', completed: false, xp: 400 },
                  { stage: 'e_filing', name: 'E-Filing', completed: false, xp: 200 }
                ].map((stage, index) => (
                  <div key={stage.stage} className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      stage.completed 
                        ? 'bg-green-500 text-white' 
                        : stage.stage === userProgress.current_stage
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-200 text-gray-500'
                    }`}>
                      {stage.completed ? (
                        <CheckCircle className="h-4 w-4" />
                      ) : (
                        <span className="text-sm font-bold">{index + 1}</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{stage.name}</h4>
                        <Badge variant="outline">+{stage.xp} XP</Badge>
                      </div>
                      {stage.stage === userProgress.current_stage && (
                        <div className="mt-2">
                          <Progress value={67} className="h-2" />
                          <p className="text-xs text-muted-foreground mt-1">67% complete</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="milestones" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Milestones
              </CardTitle>
              <CardDescription>
                Complete milestones to earn bonus XP and unlock achievements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {milestones.map((milestone) => (
                  <div key={milestone.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{milestone.icon}</span>
                        <div>
                          <h4 className="font-medium">{milestone.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {milestone.description}
                          </p>
                        </div>
                      </div>
                      {milestone.completed && (
                        <Badge className="bg-green-500">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Complete
                        </Badge>
                      )}
                    </div>
                    
                    {!milestone.completed && (
                      <div className="mb-3">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{milestone.progress}/{milestone.total_required}</span>
                        </div>
                        <Progress 
                          value={(milestone.progress / milestone.total_required) * 100} 
                          className="h-2"
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-purple-600">
                        +{milestone.xp_reward} XP
                      </Badge>
                      {milestone.completed && (
                        <span className="text-sm text-green-600 font-medium">
                          Earned!
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Achievements
              </CardTitle>
              <CardDescription>
                Unlock special achievements for exceptional performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {achievements.map((achievement) => (
                  <div 
                    key={achievement.id} 
                    className={`border rounded-lg p-4 ${
                      achievement.unlocked ? 'bg-gradient-to-br from-yellow-50 to-orange-50' : 'opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-3xl">{achievement.icon}</span>
                      <Badge className={`${getRarityColor(achievement.rarity)} text-white`}>
                        {achievement.rarity}
                      </Badge>
                    </div>
                    
                    <h4 className="font-medium mb-1">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">
                      {achievement.description}
                    </p>
                    
                    {achievement.unlocked ? (
                      <div className="flex items-center gap-2 text-sm text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        <span>
                          Unlocked {achievement.unlock_date && formatTimeAgo(achievement.unlock_date)}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>Locked</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Global Leaderboard
              </CardTitle>
              <CardDescription>
                See how you rank against other tax preparers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((user, index) => (
                  <div 
                    key={user.rank} 
                    className={`flex items-center justify-between p-4 border rounded-lg ${
                      user.username === 'You' ? 'bg-blue-50 border-blue-200' : ''
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                        user.rank === 1 ? 'bg-yellow-500 text-white' :
                        user.rank === 2 ? 'bg-gray-400 text-white' :
                        user.rank === 3 ? 'bg-orange-600 text-white' :
                        'bg-gray-200 text-gray-700'
                      }`}>
                        {user.rank <= 3 ? (
                          user.rank === 1 ? <Crown className="h-4 w-4" /> :
                          user.rank === 2 ? <Medal className="h-4 w-4" /> :
                          <Award className="h-4 w-4" />
                        ) : (
                          user.rank
                        )}
                      </div>
                      <div>
                        <div className="font-medium flex items-center gap-2">
                          {user.username}
                          {user.username === 'You' && (
                            <Badge variant="outline">You</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Level {user.level} • {user.streak} day streak
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{user.xp.toLocaleString()} XP</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5" />
                Rewards Store
              </CardTitle>
              <CardDescription>
                Redeem your XP for exclusive rewards and benefits
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  {
                    id: 'premium_support',
                    name: 'Premium Support',
                    description: '1 month of priority customer support',
                    cost: 2000,
                    icon: '🎧',
                    available: true
                  },
                  {
                    id: 'tax_consultation',
                    name: 'Tax Consultation',
                    description: '30-minute session with a tax professional',
                    cost: 5000,
                    icon: '👨‍💼',
                    available: true
                  },
                  {
                    id: 'audit_protection',
                    name: 'Audit Protection',
                    description: '1 year of audit defense coverage',
                    cost: 10000,
                    icon: '🛡️',
                    available: false
                  },
                  {
                    id: 'early_access',
                    name: 'Early Access',
                    description: 'Beta access to new features',
                    cost: 1500,
                    icon: '🚀',
                    available: true
                  },
                  {
                    id: 'custom_theme',
                    name: 'Custom Theme',
                    description: 'Personalize your dashboard appearance',
                    cost: 800,
                    icon: '🎨',
                    available: true
                  },
                  {
                    id: 'referral_bonus',
                    name: 'Referral Bonus',
                    description: 'Double XP for next 5 referrals',
                    cost: 3000,
                    icon: '💫',
                    available: true
                  }
                ].map((reward) => (
                  <div key={reward.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-3xl">{reward.icon}</span>
                      <Badge variant={reward.available ? 'default' : 'secondary'}>
                        {reward.cost.toLocaleString()} XP
                      </Badge>
                    </div>
                    
                    <h4 className="font-medium mb-1">{reward.name}</h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      {reward.description}
                    </p>
                    
                    <Button 
                      size="sm" 
                      className="w-full"
                      disabled={!reward.available || userProgress.total_xp < reward.cost}
                    >
                      {userProgress.total_xp >= reward.cost ? 'Redeem' : 'Not Enough XP'}
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
