
import { ClientProfile } from '../types/experience';
import { LearningPath, TaxCalculator, VideoContent } from '../types/education';
import { ValueAddedService, LoyaltyReward } from '../types/retention';

export interface Recommendation {
  id: string;
  type: 'content' | 'service' | 'action' | 'reward';
  title: string;
  description: string;
  confidence: number;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  category: string;
  estimatedValue: number;
  reasoning: string[];
  actionUrl?: string;
  expiresAt?: Date;
}

export class RecommendationEngine {
  private static instance: RecommendationEngine;

  public static getInstance(): RecommendationEngine {
    if (!RecommendationEngine.instance) {
      RecommendationEngine.instance = new RecommendationEngine();
    }
    return RecommendationEngine.instance;
  }

  /**
   * Generate comprehensive recommendations for a client
   */
  async generateRecommendations(
    clientProfile: ClientProfile,
    context: {
      currentServices: string[];
      recentActivity: any;
      seasonalFactors: any;
      behaviorData: any;
    }
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Content recommendations
    const contentRecs = await this.generateContentRecommendations(clientProfile, context);
    recommendations.push(...contentRecs);

    // Service recommendations
    const serviceRecs = await this.generateServiceRecommendations(clientProfile, context);
    recommendations.push(...serviceRecs);

    // Action recommendations
    const actionRecs = await this.generateActionRecommendations(clientProfile, context);
    recommendations.push(...actionRecs);

    // Reward recommendations
    const rewardRecs = await this.generateRewardRecommendations(clientProfile, context);
    recommendations.push(...rewardRecs);

    // Sort by priority and confidence
    return recommendations.sort((a, b) => {
      const priorityWeight = { urgent: 4, high: 3, medium: 2, low: 1 };
      const aScore = priorityWeight[a.priority] * a.confidence;
      const bScore = priorityWeight[b.priority] * b.confidence;
      return bScore - aScore;
    });
  }

  /**
   * Generate content recommendations (learning paths, videos, calculators)
   */
  private async generateContentRecommendations(
    profile: ClientProfile,
    context: any
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Learning path recommendations
    if (profile.completionScore < 70) {
      recommendations.push({
        id: 'learning-path-basics',
        type: 'content',
        title: 'Complete Your Tax Education Journey',
        description: 'Finish the personalized learning path designed for your situation',
        confidence: 0.85,
        priority: 'high',
        category: 'education',
        estimatedValue: 500,
        reasoning: [
          'Profile completion is below 70%',
          'Learning paths improve client satisfaction by 40%',
          'Matches your persona preferences'
        ],
        actionUrl: '/education/learning-paths'
      });
    }

    // Calculator recommendations based on persona
    const calculatorRec = this.getCalculatorRecommendation(profile);
    if (calculatorRec) {
      recommendations.push(calculatorRec);
    }

    // Video content recommendations
    if (context.recentActivity.videoWatchTime < 300) { // Less than 5 minutes
      recommendations.push({
        id: 'video-content',
        type: 'content',
        title: 'Watch: Tax Tips for Your Situation',
        description: 'Personalized video content based on your tax profile',
        confidence: 0.70,
        priority: 'medium',
        category: 'education',
        estimatedValue: 200,
        reasoning: [
          'Low video engagement detected',
          'Visual learners retain 65% more information',
          'Content matches your complexity level'
        ],
        actionUrl: '/education/videos'
      });
    }

    return recommendations;
  }

  /**
   * Generate service upgrade/addition recommendations
   */
  private async generateServiceRecommendations(
    profile: ClientProfile,
    context: any
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Business consulting for small business owners
    if (profile.persona.type === 'small_business' && !context.currentServices.includes('business_consulting')) {
      recommendations.push({
        id: 'business-consulting',
        type: 'service',
        title: 'Upgrade to Business Tax Consulting',
        description: 'Get year-round business tax advice and quarterly planning',
        confidence: 0.80,
        priority: 'high',
        category: 'service_upgrade',
        estimatedValue: 2400,
        reasoning: [
          'Small business owners save average $3,200 annually',
          'Quarterly planning prevents costly mistakes',
          '89% of business clients renew this service'
        ],
        actionUrl: '/services/business-consulting'
      });
    }

    // Audit protection for complex returns
    if (profile.taxComplexity === 'complex' && !context.currentServices.includes('audit_protection')) {
      recommendations.push({
        id: 'audit-protection',
        type: 'service',
        title: 'Add Audit Defense Protection',
        description: 'Protect yourself with professional audit representation',
        confidence: 0.75,
        priority: 'medium',
        category: 'protection',
        estimatedValue: 299,
        reasoning: [
          'Complex returns have 3x higher audit risk',
          'Average audit defense costs $2,500 without protection',
          'Peace of mind for complex tax situations'
        ],
        actionUrl: '/services/audit-protection'
      });
    }

    // Investment planning for investors
    if (profile.persona.type === 'investor' && !context.currentServices.includes('investment_planning')) {
      recommendations.push({
        id: 'investment-planning',
        type: 'service',
        title: 'Investment Tax Optimization',
        description: 'Maximize after-tax returns with strategic tax planning',
        confidence: 0.85,
        priority: 'high',
        category: 'optimization',
        estimatedValue: 1800,
        reasoning: [
          'Tax-loss harvesting can save 15-25% annually',
          'Strategic planning improves portfolio efficiency',
          'Investors see average 12% improvement in after-tax returns'
        ],
        actionUrl: '/services/investment-planning'
      });
    }

    return recommendations;
  }

  /**
   * Generate action recommendations (tasks, deadlines, optimizations)
   */
  private async generateActionRecommendations(
    profile: ClientProfile,
    context: any
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Year-end tax planning
    const currentMonth = new Date().getMonth();
    if (currentMonth >= 9 && currentMonth <= 11) { // Oct-Dec
      recommendations.push({
        id: 'year-end-planning',
        type: 'action',
        title: 'Complete Year-End Tax Planning',
        description: 'Optimize your taxes before December 31st deadline',
        confidence: 0.90,
        priority: 'urgent',
        category: 'deadline',
        estimatedValue: 1500,
        reasoning: [
          'Year-end planning deadline approaching',
          'Average savings of $1,500 for proactive planning',
          'Limited time for tax optimization strategies'
        ],
        actionUrl: '/planning/year-end',
        expiresAt: new Date(new Date().getFullYear(), 11, 31) // Dec 31
      });
    }

    // Document upload reminder
    if (context.recentActivity.documentsUploaded < 3) {
      recommendations.push({
        id: 'upload-documents',
        type: 'action',
        title: 'Upload Missing Tax Documents',
        description: 'Complete your tax return by uploading remaining documents',
        confidence: 0.80,
        priority: 'high',
        category: 'completion',
        estimatedValue: 0,
        reasoning: [
          'Incomplete document uploads detected',
          'Missing documents delay processing by 5-7 days',
          'Complete uploads improve accuracy'
        ],
        actionUrl: '/dashboard/documents'
      });
    }

    // Profile completion
    if (profile.completionScore < 80) {
      recommendations.push({
        id: 'complete-profile',
        type: 'action',
        title: 'Complete Your Tax Profile',
        description: 'Unlock personalized recommendations by completing your profile',
        confidence: 0.75,
        priority: 'medium',
        category: 'onboarding',
        estimatedValue: 300,
        reasoning: [
          'Profile completion improves recommendation accuracy',
          'Complete profiles receive 40% more relevant content',
          'Better personalization leads to higher satisfaction'
        ],
        actionUrl: '/profile/complete'
      });
    }

    return recommendations;
  }

  /**
   * Generate loyalty reward recommendations
   */
  private async generateRewardRecommendations(
    profile: ClientProfile,
    context: any
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Points redemption reminder
    if (context.loyaltyPoints && context.loyaltyPoints > 1000) {
      recommendations.push({
        id: 'redeem-points',
        type: 'reward',
        title: 'Redeem Your Loyalty Points',
        description: `You have ${context.loyaltyPoints} points available for rewards`,
        confidence: 0.70,
        priority: 'medium',
        category: 'loyalty',
        estimatedValue: context.loyaltyPoints * 0.01, // 1 cent per point
        reasoning: [
          `${context.loyaltyPoints} points available for redemption`,
          'Points expire after 12 months of inactivity',
          'Redeeming points increases engagement'
        ],
        actionUrl: '/loyalty/rewards'
      });
    }

    // Referral opportunity
    if (context.recentActivity.referralsSent < 1 && profile.completionScore > 80) {
      recommendations.push({
        id: 'refer-friends',
        type: 'reward',
        title: 'Earn $50 for Each Referral',
        description: 'Share Lawson Mobile Tax with friends and earn rewards',
        confidence: 0.65,
        priority: 'low',
        category: 'referral',
        estimatedValue: 50,
        reasoning: [
          'High satisfaction score indicates referral potential',
          'Referral program offers $50 per successful referral',
          'Satisfied clients refer an average of 2.3 people'
        ],
        actionUrl: '/referrals'
      });
    }

    return recommendations;
  }

  /**
   * Get calculator recommendation based on client persona
   */
  private getCalculatorRecommendation(profile: ClientProfile): Recommendation | null {
    const calculatorMap = {
      'small_business': {
        id: 'business-deduction-calculator',
        title: 'Business Deduction Calculator',
        description: 'Maximize your business tax deductions',
        category: 'business_tools'
      },
      'investor': {
        id: 'investment-tax-calculator',
        title: 'Investment Tax Calculator',
        description: 'Calculate capital gains and tax-loss harvesting opportunities',
        category: 'investment_tools'
      },
      'retiree': {
        id: 'retirement-tax-calculator',
        title: 'Retirement Tax Calculator',
        description: 'Plan your RMDs and Social Security taxation',
        category: 'retirement_tools'
      },
      'freelancer': {
        id: 'self-employment-calculator',
        title: 'Self-Employment Tax Calculator',
        description: 'Calculate quarterly taxes and deductions',
        category: 'freelancer_tools'
      }
    };

    const calc = calculatorMap[profile.persona.type as keyof typeof calculatorMap];
    if (!calc) return null;

    return {
      id: calc.id,
      type: 'content',
      title: `Try Our ${calc.title}`,
      description: calc.description,
      confidence: 0.75,
      priority: 'medium',
      category: calc.category,
      estimatedValue: 150,
      reasoning: [
        `Designed specifically for ${profile.persona.name.toLowerCase()}s`,
        'Interactive tools improve understanding by 60%',
        'Helps identify potential savings opportunities'
      ],
      actionUrl: `/calculators/${calc.id}`
    };
  }

  /**
   * Generate seasonal recommendations
   */
  async generateSeasonalRecommendations(
    profile: ClientProfile,
    currentDate: Date = new Date()
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];
    const month = currentDate.getMonth();

    // Tax season (Jan-Apr)
    if (month >= 0 && month <= 3) {
      recommendations.push({
        id: 'tax-season-prep',
        type: 'action',
        title: 'Tax Season Preparation',
        description: 'Get ready for tax season with our preparation checklist',
        confidence: 0.95,
        priority: 'urgent',
        category: 'seasonal',
        estimatedValue: 0,
        reasoning: [
          'Tax season is here - deadline approaching',
          'Early preparation reduces stress and errors',
          'Organized clients file 2 weeks faster on average'
        ],
        actionUrl: '/tax-season/preparation'
      });
    }

    // Year-end planning (Oct-Dec)
    if (month >= 9 && month <= 11) {
      recommendations.push({
        id: 'year-end-strategies',
        type: 'action',
        title: 'Year-End Tax Strategies',
        description: 'Implement tax-saving strategies before December 31st',
        confidence: 0.90,
        priority: 'high',
        category: 'seasonal',
        estimatedValue: 1200,
        reasoning: [
          'Year-end planning window is open',
          'Strategic moves can save significant taxes',
          'December 31st deadline for most strategies'
        ],
        actionUrl: '/planning/year-end-strategies'
      });
    }

    // Mid-year review (Jun-Aug)
    if (month >= 5 && month <= 7) {
      recommendations.push({
        id: 'mid-year-review',
        type: 'action',
        title: 'Mid-Year Tax Review',
        description: 'Review your tax situation and adjust withholdings',
        confidence: 0.70,
        priority: 'medium',
        category: 'seasonal',
        estimatedValue: 800,
        reasoning: [
          'Mid-year is ideal for tax planning adjustments',
          'Withholding adjustments prevent year-end surprises',
          'Early planning provides more options'
        ],
        actionUrl: '/planning/mid-year-review'
      });
    }

    return recommendations;
  }

  /**
   * Generate recommendations based on client behavior patterns
   */
  async generateBehaviorBasedRecommendations(
    profile: ClientProfile,
    behaviorData: {
      pageViews: Record<string, number>;
      timeSpent: Record<string, number>;
      searchQueries: string[];
      clickPatterns: any[];
    }
  ): Promise<Recommendation[]> {
    const recommendations: Recommendation[] = [];

    // Analyze most viewed content
    const topPages = Object.entries(behaviorData.pageViews)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3);

    // If user frequently visits calculator pages
    if (topPages.some(([page]) => page.includes('calculator'))) {
      recommendations.push({
        id: 'advanced-calculators',
        type: 'content',
        title: 'Explore Advanced Tax Calculators',
        description: 'Access our full suite of specialized tax calculators',
        confidence: 0.80,
        priority: 'medium',
        category: 'tools',
        estimatedValue: 200,
        reasoning: [
          'High engagement with calculator tools detected',
          'Advanced calculators provide deeper insights',
          'Tool users are 3x more likely to upgrade services'
        ],
        actionUrl: '/calculators/advanced'
      });
    }

    // If user searches for specific topics
    const commonSearches = behaviorData.searchQueries
      .map(q => q.toLowerCase())
      .filter(q => q.includes('deduction') || q.includes('credit'));

    if (commonSearches.length > 2) {
      recommendations.push({
        id: 'deduction-guide',
        type: 'content',
        title: 'Complete Deduction & Credit Guide',
        description: 'Comprehensive guide to all available deductions and credits',
        confidence: 0.75,
        priority: 'medium',
        category: 'education',
        estimatedValue: 300,
        reasoning: [
          'Multiple searches for deduction information',
          'Comprehensive guides improve understanding',
          'Better knowledge leads to higher satisfaction'
        ],
        actionUrl: '/education/deductions-credits'
      });
    }

    return recommendations;
  }
}

export default RecommendationEngine;
