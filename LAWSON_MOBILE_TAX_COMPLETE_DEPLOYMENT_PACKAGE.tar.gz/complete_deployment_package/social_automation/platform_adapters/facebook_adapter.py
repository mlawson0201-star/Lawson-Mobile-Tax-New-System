
"""
Facebook and Instagram adapter using Graph API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class FacebookAdapter(BasePlatformAdapter):
    """Adapter for Facebook and Instagram using Graph API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.page_id = credentials.get('page_id')
        self.app_id = credentials.get('app_id')
        self.app_secret = credentials.get('app_secret')
        self.base_url = "https://graph.facebook.com/v19.0"
        
    async def authenticate(self) -> bool:
        """Verify access token and get user info"""
        try:
            url = f"{self.base_url}/me"
            params = {
                'access_token': self.access_token,
                'fields': 'id,name'
            }
            
            response = requests.get(url, params=params)
            if response.status_code == 200:
                user_info = response.json()
                logger.info(f"Authenticated as: {user_info.get('name')}")
                return True
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post content to Facebook/Instagram"""
        try:
            # Determine if this is for Instagram or Facebook
            is_instagram = kwargs.get('is_instagram', False)
            target_id = kwargs.get('instagram_account_id', self.page_id) if is_instagram else self.page_id
            
            # Format content with hashtags
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content}\n\n{hashtag_text}"
            
            # Validate content length
            max_length = 2200 if not is_instagram else 2200
            full_content = self.validate_content_length(full_content, max_length)
            
            if media_urls and len(media_urls) > 0:
                # Post with media
                return await self._post_with_media(target_id, full_content, media_urls, is_instagram)
            else:
                # Text-only post
                return await self._post_text_only(target_id, full_content, is_instagram)
                
        except Exception as e:
            logger.error(f"Error posting content: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def _post_text_only(self, target_id: str, content: str, is_instagram: bool = False) -> Dict[str, Any]:
        """Post text-only content"""
        try:
            if is_instagram:
                # Instagram requires media for posts, so we can't do text-only posts
                return {"success": False, "error": "Instagram requires media for posts"}
            
            url = f"{self.base_url}/{target_id}/feed"
            data = {
                'message': content,
                'access_token': self.access_token
            }
            
            response = requests.post(url, data=data)
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "post_id": result.get('id'),
                    "platform_response": result
                }
            else:
                error_msg = response.json().get('error', {}).get('message', 'Unknown error')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _post_with_media(self, target_id: str, content: str, media_urls: List[str], 
                              is_instagram: bool = False) -> Dict[str, Any]:
        """Post content with media attachments"""
        try:
            if is_instagram:
                # Instagram media posting
                url = f"{self.base_url}/{target_id}/media"
                
                # For Instagram, we need to create media object first, then publish
                media_data = {
                    'image_url': media_urls[0],  # Instagram supports one image per post
                    'caption': content,
                    'access_token': self.access_token
                }
                
                # Create media object
                response = requests.post(url, data=media_data)
                
                if response.status_code == 200:
                    creation_id = response.json().get('id')
                    
                    # Publish the media
                    publish_url = f"{self.base_url}/{target_id}/media_publish"
                    publish_data = {
                        'creation_id': creation_id,
                        'access_token': self.access_token
                    }
                    
                    publish_response = requests.post(publish_url, data=publish_data)
                    
                    if publish_response.status_code == 200:
                        result = publish_response.json()
                        return {
                            "success": True,
                            "post_id": result.get('id'),
                            "platform_response": result
                        }
                    else:
                        error_msg = publish_response.json().get('error', {}).get('message', 'Publish failed')
                        return {"success": False, "error": error_msg}
                else:
                    error_msg = response.json().get('error', {}).get('message', 'Media creation failed')
                    return {"success": False, "error": error_msg}
            else:
                # Facebook photo posting
                url = f"{self.base_url}/{target_id}/photos"
                
                data = {
                    'url': media_urls[0],  # Facebook supports one image per post via URL
                    'caption': content,
                    'access_token': self.access_token
                }
                
                response = requests.post(url, data=data)
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": True,
                        "post_id": result.get('id'),
                        "platform_response": result
                    }
                else:
                    error_msg = response.json().get('error', {}).get('message', 'Unknown error')
                    return {"success": False, "error": error_msg}
                    
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a post for later (Facebook Pages only)"""
        try:
            # Convert datetime to Unix timestamp
            scheduled_timestamp = int(scheduled_time.timestamp())
            
            # Format content with hashtags
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content}\n\n{hashtag_text}"
            
            full_content = self.validate_content_length(full_content, 2200)
            
            url = f"{self.base_url}/{self.page_id}/feed"
            data = {
                'message': full_content,
                'scheduled_publish_time': scheduled_timestamp,
                'published': 'false',
                'access_token': self.access_token
            }
            
            if media_urls and len(media_urls) > 0:
                data['link'] = media_urls[0]  # For scheduled posts, use link instead of photo upload
            
            response = requests.post(url, data=data)
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "post_id": result.get('id'),
                    "scheduled_time": scheduled_time.isoformat(),
                    "platform_response": result
                }
            else:
                error_msg = response.json().get('error', {}).get('message', 'Unknown error')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a specific post"""
        try:
            url = f"{self.base_url}/{post_id}"
            params = {
                'fields': 'id,message,created_time,likes.summary(true),comments.summary(true),shares',
                'access_token': self.access_token
            }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                analytics = {
                    "post_id": post_id,
                    "likes": data.get('likes', {}).get('summary', {}).get('total_count', 0),
                    "comments": data.get('comments', {}).get('summary', {}).get('total_count', 0),
                    "shares": data.get('shares', {}).get('count', 0),
                    "created_time": data.get('created_time'),
                    "message": data.get('message', '')
                }
                
                return {"success": True, "analytics": analytics}
            else:
                error_msg = response.json().get('error', {}).get('message', 'Unknown error')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a post"""
        try:
            url = f"{self.base_url}/{post_id}"
            params = {'access_token': self.access_token}
            
            response = requests.delete(url, params=params)
            return response.status_code == 200
            
        except Exception as e:
            logger.error(f"Error deleting post: {str(e)}")
            return False
    
    async def refresh_token(self) -> bool:
        """Refresh long-lived access token"""
        try:
            url = f"{self.base_url}/oauth/access_token"
            params = {
                'grant_type': 'fb_exchange_token',
                'client_id': self.app_id,
                'client_secret': self.app_secret,
                'fb_exchange_token': self.access_token
            }
            
            response = requests.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                self.access_token = data.get('access_token')
                logger.info("Access token refreshed successfully")
                return True
            else:
                logger.error(f"Token refresh failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Token refresh error: {str(e)}")
            return False
