"""
Tax Progress Tracker with XP System
Gamified tax preparation progress tracking with experience points and milestones
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import json
from sqlalchemy.orm import Session
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base

logger = logging.getLogger(__name__)

Base = declarative_base()

class ProgressStage(Enum):
    """Tax preparation progress stages"""
    GETTING_STARTED = "getting_started"
    DOCUMENT_COLLECTION = "document_collection"
    INCOME_ENTRY = "income_entry"
    DEDUCTION_OPTIMIZATION = "deduction_optimization"
    REVIEW_VALIDATION = "review_validation"
    E_FILING = "e_filing"
    COMPLETED = "completed"

class XPCategory(Enum):
    """Experience point categories"""
    DOCUMENT_UPLOAD = "document_upload"
    FORM_COMPLETION = "form_completion"
    OPTIMIZATION_FOUND = "optimization_found"
    MILESTONE_REACHED = "milestone_reached"
    EARLY_COMPLETION = "early_completion"
    ACCURACY_BONUS = "accuracy_bonus"
    REFERRAL_BONUS = "referral_bonus"
    STREAK_BONUS = "streak_bonus"

@dataclass
class XPEvent:
    """Experience point earning event"""
    category: XPCategory
    points: int
    description: str
    timestamp: datetime
    multiplier: float = 1.0
    bonus_reason: Optional[str] = None

@dataclass
class ProgressMilestone:
    """Progress milestone definition"""
    id: str
    name: str
    description: str
    stage: ProgressStage
    xp_reward: int
    requirements: Dict[str, Any]
    icon: str
    celebration_message: str

@dataclass
class UserProgress:
    """User's tax preparation progress"""
    user_id: str
    current_stage: ProgressStage
    completion_percentage: float
    total_xp: int
    level: int
    milestones_completed: List[str]
    current_streak: int
    last_activity: datetime
    estimated_completion: Optional[datetime]

class UserProgressModel(Base):
    """Database model for user progress"""
    __tablename__ = "user_progress"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(50), unique=True, nullable=False)
    current_stage = Column(String(50), nullable=False)
    completion_percentage = Column(Float, default=0.0)
    total_xp = Column(Integer, default=0)
    level = Column(Integer, default=1)
    milestones_completed = Column(Text)  # JSON array
    current_streak = Column(Integer, default=0)
    last_activity = Column(DateTime, default=datetime.utcnow)
    estimated_completion = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class XPEventModel(Base):
    """Database model for XP events"""
    __tablename__ = "xp_events"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(50), nullable=False)
    category = Column(String(50), nullable=False)
    points = Column(Integer, nullable=False)
    description = Column(String(500), nullable=False)
    multiplier = Column(Float, default=1.0)
    bonus_reason = Column(String(200))
    timestamp = Column(DateTime, default=datetime.utcnow)

class TaxProgressTracker:
    """
    Tax Progress Tracker with XP System
    
    Features:
    - Real-time progress tracking across tax preparation stages
    - Experience point system with multiple earning categories
    - Dynamic milestone system with rewards
    - Streak tracking for consistent engagement
    - Predictive completion estimation
    - Celebration triggers for achievements
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
        self.milestones = self._initialize_milestones()
        self.xp_values = self._initialize_xp_values()
        self.level_thresholds = self._calculate_level_thresholds()
    
    async def track_progress_update(
        self,
        user_id: str,
        stage: ProgressStage,
        completion_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Track user progress update and award XP
        
        Args:
            user_id: User identifier
            stage: Current progress stage
            completion_data: Stage completion data
            
        Returns:
            Progress update result with XP earned and celebrations
        """
        try:
            # Get or create user progress
            user_progress = await self._get_or_create_progress(user_id)
            
            # Calculate progress percentage
            new_percentage = await self._calculate_completion_percentage(
                stage, completion_data
            )
            
            # Award XP for progress
            xp_events = await self._award_progress_xp(
                user_id, stage, user_progress.completion_percentage, new_percentage
            )
            
            # Check for milestone completions
            milestone_rewards = await self._check_milestone_completions(
                user_id, stage, completion_data
            )
            
            # Update streak
            streak_bonus = await self._update_activity_streak(user_id)
            
            # Update user progress
            user_progress.current_stage = stage
            user_progress.completion_percentage = new_percentage
            user_progress.last_activity = datetime.utcnow()
            user_progress.estimated_completion = await self._estimate_completion_time(
                user_progress
            )
            
            # Calculate total XP and level
            total_xp_earned = sum(event.points for event in xp_events)
            if streak_bonus:
                total_xp_earned += streak_bonus.points
                xp_events.append(streak_bonus)
            
            user_progress.total_xp += total_xp_earned
            user_progress.level = self._calculate_level(user_progress.total_xp)
            
            # Save to database
            await self._save_progress_update(user_progress, xp_events)
            
            # Prepare celebration data
            celebrations = await self._prepare_celebrations(
                xp_events, milestone_rewards, user_progress
            )
            
            result = {
                "user_id": user_id,
                "stage": stage.value,
                "completion_percentage": new_percentage,
                "xp_earned": total_xp_earned,
                "total_xp": user_progress.total_xp,
                "level": user_progress.level,
                "current_streak": user_progress.current_streak,
                "milestones_completed": milestone_rewards,
                "celebrations": celebrations,
                "estimated_completion": user_progress.estimated_completion,
                "next_milestone": await self._get_next_milestone(user_progress)
            }
            
            logger.info(f"Progress updated for user {user_id}: {new_percentage}% complete, {total_xp_earned} XP earned")
            return result
            
        except Exception as e:
            logger.error(f"Error tracking progress for user {user_id}: {str(e)}")
            raise
    
    async def award_bonus_xp(
        self,
        user_id: str,
        category: XPCategory,
        points: int,
        description: str,
        multiplier: float = 1.0,
        bonus_reason: Optional[str] = None
    ) -> XPEvent:
        """
        Award bonus XP for special achievements
        
        Args:
            user_id: User identifier
            category: XP category
            points: Base points to award
            description: Description of achievement
            multiplier: XP multiplier
            bonus_reason: Reason for bonus
            
        Returns:
            XP event created
        """
        try:
            final_points = int(points * multiplier)
            
            xp_event = XPEvent(
                category=category,
                points=final_points,
                description=description,
                timestamp=datetime.utcnow(),
                multiplier=multiplier,
                bonus_reason=bonus_reason
            )
            
            # Update user's total XP
            user_progress = await self._get_or_create_progress(user_id)
            user_progress.total_xp += final_points
            user_progress.level = self._calculate_level(user_progress.total_xp)
            
            # Save XP event
            await self._save_xp_event(user_id, xp_event)
            await self._save_progress_update(user_progress, [])
            
            logger.info(f"Bonus XP awarded to user {user_id}: {final_points} points for {description}")
            return xp_event
            
        except Exception as e:
            logger.error(f"Error awarding bonus XP to user {user_id}: {str(e)}")
            raise
    
    async def get_user_progress_summary(self, user_id: str) -> Dict[str, Any]:
        """
        Get comprehensive progress summary for user
        
        Args:
            user_id: User identifier
            
        Returns:
            Complete progress summary
        """
        try:
            user_progress = await self._get_or_create_progress(user_id)
            
            # Get recent XP events
            recent_xp = await self._get_recent_xp_events(user_id, days=7)
            
            # Get milestone progress
            milestone_progress = await self._get_milestone_progress(user_progress)
            
            # Calculate level progress
            level_progress = self._calculate_level_progress(user_progress.total_xp)
            
            # Get leaderboard position
            leaderboard_position = await self._get_leaderboard_position(user_id)
            
            summary = {
                "user_id": user_id,
                "current_stage": user_progress.current_stage.value,
                "completion_percentage": user_progress.completion_percentage,
                "total_xp": user_progress.total_xp,
                "level": user_progress.level,
                "level_progress": level_progress,
                "current_streak": user_progress.current_streak,
                "milestones_completed": len(user_progress.milestones_completed),
                "total_milestones": len(self.milestones),
                "recent_xp_events": [asdict(event) for event in recent_xp],
                "milestone_progress": milestone_progress,
                "leaderboard_position": leaderboard_position,
                "estimated_completion": user_progress.estimated_completion,
                "last_activity": user_progress.last_activity
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting progress summary for user {user_id}: {str(e)}")
            raise
    
    async def get_progress_leaderboard(
        self,
        limit: int = 100,
        timeframe: str = "all_time"
    ) -> List[Dict[str, Any]]:
        """
        Get progress leaderboard
        
        Args:
            limit: Number of users to return
            timeframe: Timeframe for leaderboard (all_time, monthly, weekly)
            
        Returns:
            Leaderboard data
        """
        try:
            # This would query the database for top users
            # For now, return placeholder data
            leaderboard = [
                {
                    "rank": 1,
                    "user_id": "user_123",
                    "username": "TaxMaster2025",
                    "total_xp": 15000,
                    "level": 25,
                    "completion_percentage": 100.0,
                    "current_streak": 45
                }
            ]
            
            return leaderboard
            
        except Exception as e:
            logger.error(f"Error getting progress leaderboard: {str(e)}")
            raise
    
    # Private helper methods
    
    def _initialize_milestones(self) -> List[ProgressMilestone]:
        """Initialize progress milestones"""
        return [
            ProgressMilestone(
                id="first_document",
                name="First Document Uploaded",
                description="Upload your first tax document",
                stage=ProgressStage.DOCUMENT_COLLECTION,
                xp_reward=100,
                requirements={"documents_uploaded": 1},
                icon="📄",
                celebration_message="Great start! You've uploaded your first document!"
            ),
            ProgressMilestone(
                id="document_collector",
                name="Document Collector",
                description="Upload 5 tax documents",
                stage=ProgressStage.DOCUMENT_COLLECTION,
                xp_reward=250,
                requirements={"documents_uploaded": 5},
                icon="📚",
                celebration_message="Excellent! You're building a solid document collection!"
            ),
            ProgressMilestone(
                id="income_complete",
                name="Income Master",
                description="Complete all income entries",
                stage=ProgressStage.INCOME_ENTRY,
                xp_reward=500,
                requirements={"income_forms_complete": True},
                icon="💰",
                celebration_message="Outstanding! All your income is properly documented!"
            ),
            ProgressMilestone(
                id="deduction_optimizer",
                name="Deduction Optimizer",
                description="Find $1000+ in tax savings",
                stage=ProgressStage.DEDUCTION_OPTIMIZATION,
                xp_reward=750,
                requirements={"tax_savings_found": 1000},
                icon="🎯",
                celebration_message="Amazing! You've optimized your deductions like a pro!"
            ),
            ProgressMilestone(
                id="early_bird",
                name="Early Bird",
                description="Complete taxes before March 1st",
                stage=ProgressStage.COMPLETED,
                xp_reward=1000,
                requirements={"completion_date": "before_march_1"},
                icon="🐦",
                celebration_message="Incredible! You're ahead of the game with early completion!"
            ),
            ProgressMilestone(
                id="perfectionist",
                name="Perfectionist",
                description="Complete with 100% accuracy",
                stage=ProgressStage.COMPLETED,
                xp_reward=1500,
                requirements={"accuracy_score": 1.0},
                icon="⭐",
                celebration_message="Perfect! Your attention to detail is exceptional!"
            )
        ]
    
    def _initialize_xp_values(self) -> Dict[XPCategory, int]:
        """Initialize XP values for different categories"""
        return {
            XPCategory.DOCUMENT_UPLOAD: 50,
            XPCategory.FORM_COMPLETION: 100,
            XPCategory.OPTIMIZATION_FOUND: 200,
            XPCategory.MILESTONE_REACHED: 0,  # Variable based on milestone
            XPCategory.EARLY_COMPLETION: 500,
            XPCategory.ACCURACY_BONUS: 300,
            XPCategory.REFERRAL_BONUS: 1000,
            XPCategory.STREAK_BONUS: 25  # Per day of streak
        }
    
    def _calculate_level_thresholds(self) -> List[int]:
        """Calculate XP thresholds for each level"""
        thresholds = [0]  # Level 1 starts at 0 XP
        
        for level in range(1, 101):  # Support up to level 100
            # Exponential growth with diminishing returns
            xp_needed = int(100 * (level ** 1.5))
            thresholds.append(thresholds[-1] + xp_needed)
        
        return thresholds
    
    def _calculate_level(self, total_xp: int) -> int:
        """Calculate user level based on total XP"""
        for level, threshold in enumerate(self.level_thresholds):
            if total_xp < threshold:
                return max(1, level)
        return len(self.level_thresholds) - 1
    
    def _calculate_level_progress(self, total_xp: int) -> Dict[str, Any]:
        """Calculate progress within current level"""
        current_level = self._calculate_level(total_xp)
        
        if current_level >= len(self.level_thresholds) - 1:
            return {
                "current_level": current_level,
                "next_level": current_level,
                "xp_in_level": 0,
                "xp_needed": 0,
                "progress_percentage": 100.0
            }
        
        current_threshold = self.level_thresholds[current_level - 1]
        next_threshold = self.level_thresholds[current_level]
        
        xp_in_level = total_xp - current_threshold
        xp_needed = next_threshold - current_threshold
        progress_percentage = (xp_in_level / xp_needed) * 100
        
        return {
            "current_level": current_level,
            "next_level": current_level + 1,
            "xp_in_level": xp_in_level,
            "xp_needed": xp_needed,
            "progress_percentage": progress_percentage
        }
    
    async def _get_or_create_progress(self, user_id: str) -> UserProgress:
        """Get or create user progress record"""
        # This would query the database
        # For now, return a default progress object
        return UserProgress(
            user_id=user_id,
            current_stage=ProgressStage.GETTING_STARTED,
            completion_percentage=0.0,
            total_xp=0,
            level=1,
            milestones_completed=[],
            current_streak=0,
            last_activity=datetime.utcnow(),
            estimated_completion=None
        )
    
    async def _calculate_completion_percentage(
        self,
        stage: ProgressStage,
        completion_data: Dict[str, Any]
    ) -> float:
        """Calculate overall completion percentage"""
        stage_weights = {
            ProgressStage.GETTING_STARTED: 5,
            ProgressStage.DOCUMENT_COLLECTION: 20,
            ProgressStage.INCOME_ENTRY: 25,
            ProgressStage.DEDUCTION_OPTIMIZATION: 25,
            ProgressStage.REVIEW_VALIDATION: 15,
            ProgressStage.E_FILING: 8,
            ProgressStage.COMPLETED: 2
        }
        
        # Calculate base percentage from stage
        stage_list = list(ProgressStage)
        stage_index = stage_list.index(stage)
        
        base_percentage = sum(
            stage_weights[stage_list[i]] 
            for i in range(stage_index)
        )
        
        # Add partial completion within current stage
        stage_completion = completion_data.get("stage_completion", 0.0)
        current_stage_contribution = stage_weights[stage] * stage_completion
        
        total_percentage = base_percentage + current_stage_contribution
        return min(total_percentage, 100.0)
    
    async def _award_progress_xp(
        self,
        user_id: str,
        stage: ProgressStage,
        old_percentage: float,
        new_percentage: float
    ) -> List[XPEvent]:
        """Award XP for progress made"""
        xp_events = []
        
        # Award XP for percentage milestones crossed
        milestones_crossed = []
        for milestone in [10, 25, 50, 75, 90, 100]:
            if old_percentage < milestone <= new_percentage:
                milestones_crossed.append(milestone)
        
        for milestone in milestones_crossed:
            xp_amount = int(milestone * 5)  # 5 XP per percentage point
            
            xp_event = XPEvent(
                category=XPCategory.MILESTONE_REACHED,
                points=xp_amount,
                description=f"Reached {milestone}% completion",
                timestamp=datetime.utcnow()
            )
            xp_events.append(xp_event)
        
        return xp_events
    
    async def _check_milestone_completions(
        self,
        user_id: str,
        stage: ProgressStage,
        completion_data: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Check for milestone completions"""
        completed_milestones = []
        
        for milestone in self.milestones:
            if milestone.stage == stage:
                if await self._is_milestone_completed(milestone, completion_data):
                    completed_milestones.append({
                        "milestone": asdict(milestone),
                        "xp_earned": milestone.xp_reward
                    })
        
        return completed_milestones
    
    async def _is_milestone_completed(
        self,
        milestone: ProgressMilestone,
        completion_data: Dict[str, Any]
    ) -> bool:
        """Check if a milestone is completed"""
        for requirement, expected_value in milestone.requirements.items():
            actual_value = completion_data.get(requirement)
            
            if isinstance(expected_value, bool):
                if actual_value != expected_value:
                    return False
            elif isinstance(expected_value, (int, float)):
                if actual_value is None or actual_value < expected_value:
                    return False
            elif isinstance(expected_value, str):
                # Handle special string requirements
                if expected_value == "before_march_1":
                    if datetime.now().month >= 3:
                        return False
        
        return True
    
    async def _update_activity_streak(self, user_id: str) -> Optional[XPEvent]:
        """Update user's activity streak"""
        # This would check if user was active yesterday and update streak
        # For now, return a placeholder streak bonus
        return XPEvent(
            category=XPCategory.STREAK_BONUS,
            points=50,
            description="Daily activity streak bonus",
            timestamp=datetime.utcnow()
        )
    
    async def _estimate_completion_time(self, user_progress: UserProgress) -> Optional[datetime]:
        """Estimate completion time based on current progress"""
        if user_progress.completion_percentage == 0:
            return None
        
        # Simple estimation based on current progress rate
        days_since_start = (datetime.utcnow() - user_progress.last_activity).days or 1
        progress_per_day = user_progress.completion_percentage / days_since_start
        
        if progress_per_day > 0:
            remaining_percentage = 100 - user_progress.completion_percentage
            estimated_days = remaining_percentage / progress_per_day
            return datetime.utcnow() + timedelta(days=estimated_days)
        
        return None
    
    async def _prepare_celebrations(
        self,
        xp_events: List[XPEvent],
        milestone_rewards: List[Dict[str, Any]],
        user_progress: UserProgress
    ) -> List[Dict[str, Any]]:
        """Prepare celebration data for frontend"""
        celebrations = []
        
        # XP celebrations
        total_xp = sum(event.points for event in xp_events)
        if total_xp > 0:
            celebrations.append({
                "type": "xp_earned",
                "title": f"+{total_xp} XP Earned!",
                "message": "Great progress on your tax preparation!",
                "animation": "xp_burst",
                "duration": 3000
            })
        
        # Milestone celebrations
        for milestone_reward in milestone_rewards:
            milestone = milestone_reward["milestone"]
            celebrations.append({
                "type": "milestone_completed",
                "title": f"{milestone['icon']} {milestone['name']}",
                "message": milestone["celebration_message"],
                "animation": "confetti",
                "duration": 5000,
                "xp_reward": milestone["xp_reward"]
            })
        
        # Level up celebrations
        # This would check if user leveled up and add appropriate celebration
        
        return celebrations
    
    async def _get_next_milestone(self, user_progress: UserProgress) -> Optional[Dict[str, Any]]:
        """Get the next milestone for the user"""
        completed_milestones = set(user_progress.milestones_completed)
        
        for milestone in self.milestones:
            if milestone.id not in completed_milestones:
                return asdict(milestone)
        
        return None
    
    async def _save_progress_update(
        self,
        user_progress: UserProgress,
        xp_events: List[XPEvent]
    ):
        """Save progress update to database"""
        # This would save to the database
        # For now, just log the update
        logger.info(f"Saving progress update for user {user_progress.user_id}")
    
    async def _save_xp_event(self, user_id: str, xp_event: XPEvent):
        """Save XP event to database"""
        # This would save to the database
        logger.info(f"Saving XP event for user {user_id}: {xp_event.points} points")
    
    async def _get_recent_xp_events(self, user_id: str, days: int) -> List[XPEvent]:
        """Get recent XP events for user"""
        # This would query the database
        return []
    
    async def _get_milestone_progress(self, user_progress: UserProgress) -> Dict[str, Any]:
        """Get milestone progress for user"""
        completed = len(user_progress.milestones_completed)
        total = len(self.milestones)
        
        return {
            "completed": completed,
            "total": total,
            "percentage": (completed / total) * 100 if total > 0 else 0
        }
    
    async def _get_leaderboard_position(self, user_id: str) -> int:
        """Get user's position on leaderboard"""
        # This would query the database
        return 1  # Placeholder
