
'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

interface CommunicationFormProps {
  leadId: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export function CommunicationForm({ leadId, onSuccess, onCancel }: CommunicationFormProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    type: 'EMAIL',
    subject: '',
    content: '',
    direction: 'OUTBOUND',
    scheduledAt: '',
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        leadId,
        scheduledAt: formData.scheduledAt || null,
      };

      const response = await fetch('/api/crm/communications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: 'Communication Logged',
          description: 'Communication has been recorded successfully.',
        });
        onSuccess();
      } else {
        throw new Error(data.error || 'Failed to log communication');
      }
    } catch (error) {
      console.error('Error logging communication:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to log communication',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="type">Type</Label>
          <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EMAIL">Email</SelectItem>
              <SelectItem value="SMS">SMS</SelectItem>
              <SelectItem value="PHONE_CALL">Phone Call</SelectItem>
              <SelectItem value="MEETING">Meeting</SelectItem>
              <SelectItem value="NOTE">Note</SelectItem>
              <SelectItem value="TASK">Task</SelectItem>
              <SelectItem value="FOLLOW_UP">Follow Up</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="direction">Direction</Label>
          <Select value={formData.direction} onValueChange={(value) => handleInputChange('direction', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="OUTBOUND">Outbound</SelectItem>
              <SelectItem value="INBOUND">Inbound</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {(formData.type === 'EMAIL' || formData.type === 'MEETING') && (
        <div>
          <Label htmlFor="subject">Subject</Label>
          <Input
            id="subject"
            value={formData.subject}
            onChange={(e) => handleInputChange('subject', e.target.value)}
            placeholder="Enter subject"
          />
        </div>
      )}
      
      <div>
        <Label htmlFor="content">Content *</Label>
        <Textarea
          id="content"
          value={formData.content}
          onChange={(e) => handleInputChange('content', e.target.value)}
          placeholder="Enter communication details..."
          rows={4}
          required
        />
      </div>
      
      <div>
        <Label htmlFor="scheduledAt">Scheduled At (optional)</Label>
        <Input
          id="scheduledAt"
          type="datetime-local"
          value={formData.scheduledAt}
          onChange={(e) => handleInputChange('scheduledAt', e.target.value)}
        />
        <p className="text-xs text-muted-foreground mt-1">
          Leave empty if this communication happened now
        </p>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Logging...' : 'Log Communication'}
        </Button>
      </div>
    </form>
  );
}
