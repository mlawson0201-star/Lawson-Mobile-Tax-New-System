
import AdvancedAutomationDashboard from '@/components/automation/advanced-automation-dashboard';

export const dynamic = 'force-dynamic';

export default function AutomationPage() {
  return (
    <div className="space-y-8">
      <AdvancedAutomationDashboard />
    </div>
  );
}
