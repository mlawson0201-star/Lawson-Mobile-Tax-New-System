
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const audioFile = formData.get('audioFile') as File;
    const clientId = formData.get('clientId') as string;
    const language = formData.get('language') as string || 'en-US';
    const context = formData.get('context') as string; // 'tax_info', 'questions', 'documents'

    if (!audioFile) {
      return NextResponse.json({ error: 'Audio file is required' }, { status: 400 });
    }

    // Convert audio to base64 for processing
    const arrayBuffer = await audioFile.arrayBuffer();
    const base64Audio = Buffer.from(arrayBuffer).toString('base64');
    const audioDataUri = `data:${audioFile.type};base64,${base64Audio}`;

    // Create processing record
    const voiceRecord = await prisma.voiceProcessing.create({
      data: {
        tenantId: session.user.tenantId,
        userId: session.user.id,
        clientId: clientId || null,
        audioFileUrl: audioDataUri,
        language,
        duration: Math.round(audioFile.size / 16000), // Rough estimate
        processingStatus: 'processing',
      },
    });

    try {
      // Process with AI for speech-to-text and content extraction
      const transcriptionPrompt = `
        Process this audio file for tax-related information extraction:

        Context: ${context || 'general tax information'}
        Language: ${language}

        Please:
        1. Transcribe the audio to text
        2. Extract structured tax information if present
        3. Identify any potential tax deductions or credits mentioned
        4. Flag any questions or concerns that need professional attention

        Return JSON format:
        {
          "transcription": "full text transcription",
          "confidence": 0.0-1.0,
          "extracted_tax_info": {
            "income": {"wages": number, "self_employment": number},
            "deductions": {"medical": number, "charitable": number},
            "questions": ["list of questions or concerns"],
            "action_items": ["what needs to be done"]
          },
          "language_detected": "language code",
          "audio_quality": "excellent | good | fair | poor",
          "next_steps": ["recommended next steps"]
        }
      `;

      // Note: In a real implementation, you would use proper speech-to-text APIs
      // like Google Speech-to-Text, Azure Speech, or AWS Transcribe
      const aiResponse = await fetch(`${process.env.ABACUSAI_BASE_URL || 'https://apps.abacus.ai'}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'gpt-4.1-mini',
          messages: [
            {
              role: 'user',
              content: transcriptionPrompt
            }
          ],
          response_format: { type: "json_object" },
          max_tokens: 3000,
        }),
      });

      if (!aiResponse.ok) {
        throw new Error(`Voice processing failed: ${aiResponse.statusText}`);
      }

      const aiResult = await aiResponse.json();
      const processedData = JSON.parse(aiResult.choices[0].message.content);

      // Update the voice processing record
      const updatedRecord = await prisma.voiceProcessing.update({
        where: { id: voiceRecord.id },
        data: {
          transcriptionText: processedData.transcription,
          extractedData: processedData.extracted_tax_info,
          confidenceScore: processedData.confidence,
          processingStatus: 'completed',
          processedAt: new Date(),
        },
      });

      // If this is tax information, create tasks or suggestions
      if (processedData.extracted_tax_info?.questions?.length > 0 && clientId) {
        // Create follow-up tasks for the EA/CPA
        for (const question of processedData.extracted_tax_info.questions) {
          await prisma.notification.create({
            data: {
              tenantId: session.user.tenantId,
              userId: session.user.id,
              clientId,
              type: 'voice_question',
              title: 'Voice Question Received',
              message: `Client asked: ${question}`,
              data: {
                voiceProcessingId: voiceRecord.id,
                transcription: processedData.transcription,
              },
            },
          });
        }
      }

      return NextResponse.json({
        success: true,
        voiceProcessingId: updatedRecord.id,
        transcription: processedData.transcription,
        extractedData: processedData.extracted_tax_info,
        confidence: processedData.confidence,
        nextSteps: processedData.next_steps,
        audioQuality: processedData.audio_quality,
      });

    } catch (processingError) {
      // Update record with error status
      await prisma.voiceProcessing.update({
        where: { id: voiceRecord.id },
        data: {
          processingStatus: 'failed',
        },
      });

      throw processingError;
    }

  } catch (error: any) {
    console.error('Voice processing error:', error);
    return NextResponse.json(
      { error: 'Voice processing failed', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve voice processing history
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const clientId = searchParams.get('clientId');
    const status = searchParams.get('status');

    const voiceProcessings = await prisma.voiceProcessing.findMany({
      where: {
        tenantId: session.user.tenantId,
        ...(clientId && { clientId }),
        ...(status && { processingStatus: status }),
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({
      success: true,
      voiceProcessings,
      count: voiceProcessings.length,
    });
  } catch (error: any) {
    console.error('Get voice processing error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve voice processing records', details: error?.message },
      { status: 500 }
    );
  }
}
