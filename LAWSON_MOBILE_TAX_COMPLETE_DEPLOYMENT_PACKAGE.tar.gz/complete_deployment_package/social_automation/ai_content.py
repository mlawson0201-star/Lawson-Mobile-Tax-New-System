
"""
AI-powered content generation for social media posts
"""
import openai
from typing import Dict, List, Optional, Any
import json
import random
from datetime import datetime, timedelta
import logging
from sqlalchemy.orm import Session

from config import settings
from database import ContentTemplate, Campaign

logger = logging.getLogger(__name__)

# Set OpenAI API key
openai.api_key = settings.OPENAI_API_KEY

class AIContentGenerator:
    """AI-powered content generator for social media"""
    
    def __init__(self):
        self.tax_keywords = [
            "tax deduction", "tax refund", "tax preparation", "tax planning",
            "tax season", "IRS", "tax filing", "tax savings", "tax tips",
            "business taxes", "personal taxes", "tax deadline", "tax forms",
            "tax credits", "tax advice", "tax professional", "tax service"
        ]
        
        self.seasonal_themes = {
            "tax_season": {
                "months": [1, 2, 3, 4],
                "themes": ["deadline reminders", "tax tips", "refund tracking", "last-minute filing"]
            },
            "summer": {
                "months": [6, 7, 8],
                "themes": ["mid-year planning", "quarterly taxes", "business expenses", "vacation deductions"]
            },
            "fall": {
                "months": [9, 10, 11],
                "themes": ["year-end planning", "tax strategy", "retirement planning", "business planning"]
            },
            "winter": {
                "months": [12],
                "themes": ["year-end deductions", "charitable giving", "tax prep", "new year planning"]
            }
        }
    
    async def generate_content_from_template(self, template_id: int, platform: str, 
                                           context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Generate content from a template"""
        try:
            from database import get_db
            db = next(get_db())
            
            template = db.query(ContentTemplate).filter(ContentTemplate.id == template_id).first()
            if not template:
                return {"success": False, "error": "Template not found"}
            
            # Get platform-specific constraints
            platform_config = self._get_platform_config(platform)
            
            # Prepare context
            full_context = {
                "platform": platform,
                "current_date": datetime.now().strftime("%Y-%m-%d"),
                "current_season": self._get_current_season(),
                "template_category": template.category,
                **context
            }
            
            # Generate content using AI
            content_result = await self._generate_ai_content(
                template.template_text,
                platform_config,
                full_context
            )
            
            if content_result.get("success"):
                # Get platform-specific hashtags
                hashtags = self._get_platform_hashtags(platform, template.hashtags or {})
                
                # Generate media suggestions if needed
                media_suggestions = await self._generate_media_suggestions(
                    content_result.get("content", ""),
                    template.category,
                    platform
                )
                
                return {
                    "success": True,
                    "content": content_result.get("content"),
                    "hashtags": hashtags,
                    "media_suggestions": media_suggestions,
                    "platform": platform,
                    "template_id": template_id
                }
            else:
                return content_result
                
        except Exception as e:
            logger.error(f"Error generating content from template: {str(e)}")
            return {"success": False, "error": str(e)}
        finally:
            db.close()
    
    async def generate_campaign_content(self, campaign: Campaign, platform: str, 
                                      template_ids: List[int]) -> Dict[str, Any]:
        """Generate content for a campaign"""
        try:
            # Select a random template from the campaign's templates
            template_id = random.choice(template_ids) if template_ids else None
            
            if not template_id:
                # Generate generic campaign content
                return await self._generate_generic_campaign_content(campaign, platform)
            
            # Use template-based generation
            context = {
                "campaign_name": campaign.name,
                "campaign_description": campaign.description,
                "campaign_start_date": campaign.start_date.strftime("%Y-%m-%d"),
                "campaign_end_date": campaign.end_date.strftime("%Y-%m-%d") if campaign.end_date else None
            }
            
            return await self.generate_content_from_template(template_id, platform, context)
            
        except Exception as e:
            logger.error(f"Error generating campaign content: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def _generate_ai_content(self, template_text: str, platform_config: Dict[str, Any], 
                                 context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate content using OpenAI"""
        try:
            # Create prompt
            prompt = self._create_content_prompt(template_text, platform_config, context)
            
            # Call OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a professional social media content creator specializing in tax services and financial advice. Create engaging, informative, and compliant content for tax professionals."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=platform_config.get("max_tokens", 500),
                temperature=0.7
            )
            
            content = response.choices[0].message.content.strip()
            
            # Validate content length
            max_length = platform_config.get("max_length", 2000)
            if len(content) > max_length:
                content = content[:max_length-3] + "..."
            
            return {
                "success": True,
                "content": content,
                "tokens_used": response.usage.total_tokens
            }
            
        except Exception as e:
            logger.error(f"Error generating AI content: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _create_content_prompt(self, template_text: str, platform_config: Dict[str, Any], 
                             context: Dict[str, Any]) -> str:
        """Create a prompt for content generation"""
        platform = context.get("platform", "generic")
        max_length = platform_config.get("max_length", 2000)
        
        prompt = f"""
Create engaging social media content for {platform} based on the following template and context:

Template: {template_text}

Context:
- Platform: {platform}
- Current Date: {context.get('current_date')}
- Season: {context.get('current_season')}
- Category: {context.get('template_category')}

Platform Requirements:
- Maximum length: {max_length} characters
- Style: {platform_config.get('style', 'professional')}
- Tone: {platform_config.get('tone', 'informative and helpful')}

Additional Context:
{json.dumps({k: v for k, v in context.items() if k not in ['platform', 'current_date', 'current_season', 'template_category']}, indent=2)}

Requirements:
1. Make the content engaging and relevant to tax services
2. Include a clear call-to-action
3. Ensure compliance with tax industry regulations
4. Adapt the tone and style for {platform}
5. Keep within the character limit
6. Make it actionable and valuable for the audience

Generate the content now:
"""
        return prompt
    
    def _get_platform_config(self, platform: str) -> Dict[str, Any]:
        """Get platform-specific configuration"""
        configs = {
            "facebook": {
                "max_length": 2200,
                "max_tokens": 400,
                "style": "conversational",
                "tone": "friendly and informative"
            },
            "instagram": {
                "max_length": 2200,
                "max_tokens": 400,
                "style": "visual-focused",
                "tone": "inspiring and motivational"
            },
            "twitter": {
                "max_length": 280,
                "max_tokens": 100,
                "style": "concise",
                "tone": "direct and helpful"
            },
            "linkedin": {
                "max_length": 3000,
                "max_tokens": 500,
                "style": "professional",
                "tone": "authoritative and educational"
            },
            "tiktok": {
                "max_length": 2200,
                "max_tokens": 300,
                "style": "trendy",
                "tone": "energetic and engaging"
            },
            "youtube": {
                "max_length": 5000,
                "max_tokens": 800,
                "style": "descriptive",
                "tone": "educational and detailed"
            },
            "pinterest": {
                "max_length": 500,
                "max_tokens": 150,
                "style": "descriptive",
                "tone": "inspiring and actionable"
            },
            "reddit": {
                "max_length": 10000,
                "max_tokens": 1000,
                "style": "conversational",
                "tone": "helpful and community-focused"
            }
        }
        
        return configs.get(platform, {
            "max_length": 2000,
            "max_tokens": 400,
            "style": "professional",
            "tone": "informative"
        })
    
    def _get_platform_hashtags(self, platform: str, template_hashtags: Dict[str, List[str]]) -> List[str]:
        """Get platform-specific hashtags"""
        # Base tax-related hashtags
        base_hashtags = [
            "TaxTips", "TaxPrep", "TaxSeason", "TaxAdvice", "TaxPlanning",
            "TaxRefund", "TaxDeductions", "TaxProfessional", "TaxService",
            "LawsonMobileTax", "MobileTaxService", "TaxHelp"
        ]
        
        # Platform-specific hashtags
        platform_hashtags = {
            "instagram": ["InstaFinance", "MoneyTips", "FinancialLiteracy", "SmallBusiness"],
            "twitter": ["TaxTwitter", "FinTech", "SmallBiz", "Entrepreneur"],
            "linkedin": ["ProfessionalServices", "BusinessFinance", "Accounting", "SmallBusinessOwner"],
            "tiktok": ["TaxTok", "MoneyTok", "FinanceTips", "BusinessTips"],
            "facebook": ["LocalBusiness", "TaxExperts", "CommunitySupport"],
            "pinterest": ["TaxOrganization", "FinancialPlanning", "BusinessTips", "MoneyManagement"]
        }
        
        # Get template-specific hashtags for the platform
        template_platform_hashtags = template_hashtags.get(platform, [])
        
        # Combine and limit hashtags
        all_hashtags = base_hashtags + platform_hashtags.get(platform, []) + template_platform_hashtags
        
        # Platform-specific limits
        hashtag_limits = {
            "instagram": 30,
            "twitter": 2,  # Twitter works better with fewer hashtags
            "linkedin": 5,
            "tiktok": 20,
            "facebook": 10,
            "pinterest": 20
        }
        
        limit = hashtag_limits.get(platform, 10)
        return random.sample(all_hashtags, min(len(all_hashtags), limit))
    
    async def _generate_media_suggestions(self, content: str, category: str, platform: str) -> List[Dict[str, Any]]:
        """Generate media suggestions for content"""
        try:
            # Create prompt for media suggestions
            prompt = f"""
Based on this social media content for {platform}, suggest appropriate visual media:

Content: {content}
Category: {category}
Platform: {platform}

Suggest 3-5 specific image or video ideas that would complement this content. For each suggestion, provide:
1. Type (image/video/infographic)
2. Description
3. Key visual elements
4. Text overlay suggestions (if any)

Format as JSON array with objects containing: type, description, visual_elements, text_overlay
"""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a visual content strategist. Provide practical, specific media suggestions for social media posts."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            suggestions_text = response.choices[0].message.content.strip()
            
            try:
                suggestions = json.loads(suggestions_text)
                return suggestions if isinstance(suggestions, list) else []
            except json.JSONDecodeError:
                # Fallback to generic suggestions
                return self._get_generic_media_suggestions(category, platform)
                
        except Exception as e:
            logger.error(f"Error generating media suggestions: {str(e)}")
            return self._get_generic_media_suggestions(category, platform)
    
    def _get_generic_media_suggestions(self, category: str, platform: str) -> List[Dict[str, Any]]:
        """Get generic media suggestions based on category and platform"""
        suggestions = {
            "tax_tips": [
                {
                    "type": "infographic",
                    "description": "Tax deduction checklist infographic",
                    "visual_elements": ["checklist", "calculator", "money symbols"],
                    "text_overlay": "Tax Deductions You Might Be Missing"
                },
                {
                    "type": "image",
                    "description": "Professional tax consultant at desk",
                    "visual_elements": ["professional person", "desk", "documents", "calculator"],
                    "text_overlay": "Expert Tax Advice"
                }
            ],
            "promotional": [
                {
                    "type": "image",
                    "description": "Mobile tax service van or professional with tablet",
                    "visual_elements": ["mobile service", "professional", "technology"],
                    "text_overlay": "Convenient Mobile Tax Service"
                }
            ],
            "seasonal": [
                {
                    "type": "image",
                    "description": "Calendar with tax deadline highlighted",
                    "visual_elements": ["calendar", "deadline date", "urgent colors"],
                    "text_overlay": "Don't Miss the Deadline!"
                }
            ]
        }
        
        return suggestions.get(category, suggestions["tax_tips"])
    
    def _get_current_season(self) -> str:
        """Get current season based on month"""
        current_month = datetime.now().month
        
        for season, data in self.seasonal_themes.items():
            if current_month in data["months"]:
                return season
        
        return "general"
    
    async def _generate_generic_campaign_content(self, campaign: Campaign, platform: str) -> Dict[str, Any]:
        """Generate generic campaign content when no templates are available"""
        try:
            platform_config = self._get_platform_config(platform)
            
            prompt = f"""
Create social media content for a tax service campaign:

Campaign: {campaign.name}
Description: {campaign.description}
Platform: {platform}
Start Date: {campaign.start_date.strftime('%Y-%m-%d')}

Create engaging content that:
1. Promotes the campaign
2. Provides value to potential tax clients
3. Includes a clear call-to-action
4. Fits {platform}'s style and character limit ({platform_config.get('max_length')} characters)
5. Is professional yet approachable

Generate the content now:
"""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a professional social media content creator for tax services."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=platform_config.get("max_tokens", 400),
                temperature=0.7
            )
            
            content = response.choices[0].message.content.strip()
            hashtags = self._get_platform_hashtags(platform, {})
            
            return {
                "success": True,
                "content": content,
                "hashtags": hashtags,
                "media_suggestions": self._get_generic_media_suggestions("promotional", platform)
            }
            
        except Exception as e:
            logger.error(f"Error generating generic campaign content: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def generate_response_to_comment(self, original_post: str, comment: str, platform: str) -> Dict[str, Any]:
        """Generate AI response to a comment"""
        try:
            platform_config = self._get_platform_config(platform)
            
            prompt = f"""
Generate a professional, helpful response to this comment on a tax service social media post:

Original Post: {original_post}
Comment: {comment}
Platform: {platform}

Requirements:
1. Be professional and helpful
2. Stay on topic about tax services
3. Be concise (max {platform_config.get('max_length', 500)} characters)
4. Include a subtle call-to-action if appropriate
5. Be friendly and engaging
6. Address the commenter's question or concern directly

Generate the response:
"""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a professional tax service representative responding to social media comments. Be helpful, accurate, and professional."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=200,
                temperature=0.6
            )
            
            reply_content = response.choices[0].message.content.strip()
            
            return {
                "success": True,
                "response": reply_content,
                "platform": platform
            }
            
        except Exception as e:
            logger.error(f"Error generating comment response: {str(e)}")
            return {"success": False, "error": str(e)}
