
# Integration Specifications
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. Integration Architecture Overview

### 1.1 Integration Strategy
The platform integrates with multiple third-party services to provide comprehensive tax preparation, payment processing, identity verification, and communication capabilities. All integrations follow a consistent pattern with circuit breakers, retry logic, and comprehensive error handling.

### 1.2 Integration Flow Diagram

```mermaid
graph TB
    subgraph "Lawson Mobile Tax Platform"
        API[API Gateway]
        TAX[Tax Service]
        DOC[Document Service]
        PAY[Payment Service]
        ID[Identity Service]
        COMM[Communication Service]
        WORKFLOW[Temporal Workflows]
    end
    
    subgraph "Tax & E-Filing"
        OLT[OLT Pro/Partner APIs]
        IRS[IRS MeF Direct<br/>(Future)]
    end
    
    subgraph "Financial Services"
        STRIPE[Stripe Payments]
        STRIPE_CONNECT[Stripe Connect]
        EPS[EPS Financial]
    end
    
    subgraph "Identity & Verification"
        PERSONA[Persona Identity]
        COGNITO[AWS Cognito]
    end
    
    subgraph "Communications"
        TWILIO[Twilio SMS]
        CUSTOMERIO[Customer.io Email]
        SNS[AWS SNS]
    end
    
    subgraph "Marketing & Analytics"
        SEGMENT[Segment Events]
        META[Meta Ads API]
        GOOGLE[Google Ads API]
        PLAID[Plaid<br/>(Optional)]
    end
    
    TAX --> OLT
    TAX --> IRS
    PAY --> STRIPE
    PAY --> STRIPE_CONNECT
    PAY --> EPS
    ID --> PERSONA
    ID --> COGNITO
    COMM --> TWILIO
    COMM --> CUSTOMERIO
    COMM --> SNS
    API --> SEGMENT
    WORKFLOW --> META
    WORKFLOW --> GOOGLE
    DOC --> PLAID
```

---

## 2. OLT (Online Tax Solutions) Integration

### 2.1 OLT API Overview
OLT provides comprehensive tax calculation and e-filing services through their Pro and Partner API tiers.

#### 2.1.1 Authentication & Configuration
```typescript
interface OLTConfig {
  apiKey: string;
  apiSecret: string;
  environment: 'sandbox' | 'production';
  baseUrl: string;
  timeout: number;
  retryAttempts: number;
}

class OLTClient {
  private config: OLTConfig;
  private httpClient: AxiosInstance;
  
  constructor(config: OLTConfig) {
    this.config = config;
    this.httpClient = axios.create({
      baseURL: config.baseUrl,
      timeout: config.timeout,
      headers: {
        'Authorization': `Bearer ${this.generateJWT()}`,
        'Content-Type': 'application/json',
        'X-API-Version': '2024'
      }
    });
    
    this.setupInterceptors();
  }
  
  private generateJWT(): string {
    return jwt.sign(
      { 
        iss: this.config.apiKey,
        aud: 'olt-api',
        exp: Math.floor(Date.now() / 1000) + 3600 
      },
      this.config.apiSecret,
      { algorithm: 'HS256' }
    );
  }
}
```

#### 2.1.2 Tax Return Creation
```typescript
interface OLTTaxReturn {
  taxYear: number;
  taxpayer: {
    firstName: string;
    lastName: string;
    ssn: string;
    dateOfBirth: string;
    address: Address;
  };
  spouse?: {
    firstName: string;
    lastName: string;
    ssn: string;
    dateOfBirth: string;
  };
  filingStatus: 'single' | 'married_filing_jointly' | 'married_filing_separately' | 'head_of_household' | 'qualifying_widow';
  forms: OLTForm[];
  dependents?: Dependent[];
}

interface OLTForm {
  formType: string;
  formData: Record<string, any>;
  attachments?: string[];
}

class OLTTaxService {
  async createReturn(returnData: TaxReturnData): Promise<OLTReturn> {
    const oltReturn: OLTTaxReturn = {
      taxYear: returnData.taxYear,
      taxpayer: this.mapTaxpayerInfo(returnData.taxpayer),
      filingStatus: returnData.filingStatus,
      forms: this.mapFormsToOLT(returnData.forms)
    };
    
    const response = await this.client.post('/returns', oltReturn);
    return response.data;
  }
  
  async calculateTax(returnId: string): Promise<TaxCalculation> {
    const response = await this.client.post(`/returns/${returnId}/calculate`);
    return response.data;
  }
  
  async validateReturn(returnId: string): Promise<ValidationResult> {
    const response = await this.client.post(`/returns/${returnId}/validate`);
    return response.data;
  }
}
```

#### 2.1.3 E-Filing Workflow
```mermaid
sequenceDiagram
    participant Platform
    participant OLT
    participant IRS
    participant StateAgency
    
    Platform->>OLT: Create Return
    OLT-->>Platform: Return ID
    
    Platform->>OLT: Calculate Tax
    OLT-->>Platform: Calculations
    
    Platform->>OLT: Validate Return
    OLT-->>Platform: Validation Results
    
    Platform->>OLT: Submit E-File
    OLT->>IRS: Federal Submission
    OLT->>StateAgency: State Submission
    
    IRS-->>OLT: Acknowledgment
    StateAgency-->>OLT: Acknowledgment
    OLT-->>Platform: Filing Status
    
    loop Status Polling
        Platform->>OLT: Check Status
        OLT-->>Platform: Current Status
    end
```

#### 2.1.4 E-Filing Implementation
```typescript
interface EFileSubmission {
  returnId: string;
  submissionType: 'federal' | 'state' | 'both';
  stateCode?: string;
  pin: string;
  signature: {
    taxpayerSignature: boolean;
    spouseSignature?: boolean;
    preparerSignature: boolean;
    signatureDate: string;
  };
}

class OLTEFileService {
  async submitReturn(submission: EFileSubmission): Promise<EFileResult> {
    try {
      const response = await this.client.post('/efile/submit', {
        returnId: submission.returnId,
        submissionType: submission.submissionType,
        stateCode: submission.stateCode,
        electronicSignature: submission.signature,
        preparerInfo: await this.getPreparerInfo()
      });
      
      // Store submission for tracking
      await this.storeSubmission(response.data);
      
      return response.data;
    } catch (error) {
      await this.handleEFileError(error, submission);
      throw error;
    }
  }
  
  async checkStatus(submissionId: string): Promise<EFileStatus> {
    const response = await this.client.get(`/efile/status/${submissionId}`);
    
    // Update local status
    await this.updateSubmissionStatus(submissionId, response.data);
    
    return response.data;
  }
  
  async handleRejection(submissionId: string): Promise<RejectionDetails> {
    const response = await this.client.get(`/efile/rejection/${submissionId}`);
    
    // Parse rejection codes and create correction tasks
    await this.createCorrectionTasks(response.data);
    
    return response.data;
  }
}
```

#### 2.1.5 Webhook Handling
```typescript
interface OLTWebhookPayload {
  eventType: 'return.calculated' | 'efile.accepted' | 'efile.rejected' | 'efile.processed';
  returnId: string;
  submissionId?: string;
  data: Record<string, any>;
  timestamp: string;
  signature: string;
}

class OLTWebhookHandler {
  async handleWebhook(payload: OLTWebhookPayload): Promise<void> {
    // Verify webhook signature
    if (!this.verifySignature(payload)) {
      throw new Error('Invalid webhook signature');
    }
    
    switch (payload.eventType) {
      case 'return.calculated':
        await this.handleReturnCalculated(payload);
        break;
      case 'efile.accepted':
        await this.handleEFileAccepted(payload);
        break;
      case 'efile.rejected':
        await this.handleEFileRejected(payload);
        break;
      case 'efile.processed':
        await this.handleEFileProcessed(payload);
        break;
    }
  }
  
  private async handleEFileAccepted(payload: OLTWebhookPayload): Promise<void> {
    await this.updateReturnStatus(payload.returnId, 'accepted');
    await this.notifyClient(payload.returnId, 'return_accepted');
    await this.triggerUpsellWorkflow(payload.returnId);
  }
  
  private async handleEFileRejected(payload: OLTWebhookPayload): Promise<void> {
    await this.updateReturnStatus(payload.returnId, 'rejected');
    await this.createCorrectionTask(payload.returnId, payload.data);
    await this.notifyPreparer(payload.returnId, 'correction_required');
  }
}
```

---

## 3. EPS Financial Integration

### 3.1 EPS Financial Overview
EPS Financial provides refund advance products and bank account verification services.

#### 3.1.1 Product Configuration
```typescript
interface EPSProduct {
  productCode: string;
  productName: string;
  maxAmount: number;
  minAmount: number;
  apr: number;
  fee: number;
  eligibilityCriteria: {
    minRefundAmount: number;
    maxAdvancePercentage: number;
    requiredDocuments: string[];
    creditCheckRequired: boolean;
  };
}

const EPS_PRODUCTS: EPSProduct[] = [
  {
    productCode: 'RA_500',
    productName: 'Refund Advance $500',
    maxAmount: 500,
    minAmount: 500,
    apr: 0,
    fee: 0,
    eligibilityCriteria: {
      minRefundAmount: 500,
      maxAdvancePercentage: 100,
      requiredDocuments: ['w2', 'id'],
      creditCheckRequired: false
    }
  },
  {
    productCode: 'RA_7000',
    productName: 'Refund Advance up to $7,000',
    maxAmount: 7000,
    minAmount: 1000,
    apr: 35.9,
    fee: 0,
    eligibilityCriteria: {
      minRefundAmount: 1000,
      maxAdvancePercentage: 85,
      requiredDocuments: ['w2', 'id', 'bank_statement'],
      creditCheckRequired: true
    }
  }
];
```

#### 3.1.2 Eligibility Check
```typescript
class EPSEligibilityService {
  async checkEligibility(
    taxReturn: TaxReturn,
    client: Client
  ): Promise<EPSEligibilityResult> {
    const eligibilityRequest = {
      taxpayerInfo: {
        firstName: client.firstName,
        lastName: client.lastName,
        ssn: client.ssn,
        dateOfBirth: client.dateOfBirth,
        address: client.address
      },
      returnInfo: {
        taxYear: taxReturn.taxYear,
        filingStatus: taxReturn.filingStatus,
        refundAmount: taxReturn.refundAmount,
        agi: taxReturn.calculations.agi,
        totalTax: taxReturn.calculations.totalTax
      },
      requestedProducts: EPS_PRODUCTS.map(p => p.productCode)
    };
    
    const response = await this.client.post('/eligibility/check', eligibilityRequest);
    
    return {
      eligible: response.data.eligible,
      eligibleProducts: response.data.eligibleProducts,
      reasons: response.data.reasons,
      requiredDocuments: response.data.requiredDocuments
    };
  }
  
  async prequalify(client: Client): Promise<PrequalificationResult> {
    // Soft credit check for prequalification
    const response = await this.client.post('/prequalify', {
      firstName: client.firstName,
      lastName: client.lastName,
      ssn: client.ssn,
      dateOfBirth: client.dateOfBirth,
      address: client.address
    });
    
    return response.data;
  }
}
```

#### 3.1.3 Application Process
```mermaid
sequenceDiagram
    participant Client
    participant Platform
    participant EPS
    participant Persona
    participant Bank
    
    Client->>Platform: Apply for Refund Advance
    Platform->>EPS: Check Eligibility
    EPS-->>Platform: Eligibility Result
    
    alt Eligible
        Platform->>Client: Show Product Options
        Client->>Platform: Select Product & Accept Terms
        
        Platform->>Persona: Initiate KYC
        Persona-->>Platform: KYC Complete
        
        Platform->>EPS: Submit Application
        EPS->>EPS: Underwriting Process
        EPS-->>Platform: Application Decision
        
        alt Approved
            EPS->>Bank: Fund Account
            Bank-->>EPS: Funding Confirmation
            EPS-->>Platform: Funding Complete
            Platform->>Client: Funds Available
        else Declined
            Platform->>Client: Application Declined
        end
    else Not Eligible
        Platform->>Client: Not Eligible
    end
```

#### 3.1.4 Application Implementation
```typescript
interface EPSApplication {
  productCode: string;
  requestedAmount: number;
  taxpayerInfo: {
    firstName: string;
    lastName: string;
    ssn: string;
    dateOfBirth: string;
    address: Address;
    phone: string;
    email: string;
  };
  bankInfo: {
    accountType: 'checking' | 'savings';
    routingNumber: string;
    accountNumber: string;
    bankName: string;
  };
  returnInfo: {
    taxYear: number;
    refundAmount: number;
    filingStatus: string;
  };
  disclosures: {
    termsAccepted: boolean;
    privacyPolicyAccepted: boolean;
    electronicConsentAccepted: boolean;
    acceptedAt: string;
    ipAddress: string;
  };
}

class EPSApplicationService {
  async submitApplication(application: EPSApplication): Promise<EPSApplicationResult> {
    try {
      // Validate application data
      await this.validateApplication(application);
      
      // Submit to EPS
      const response = await this.client.post('/applications', application);
      
      // Store application locally
      await this.storeApplication(response.data);
      
      // Start status monitoring workflow
      await this.startStatusMonitoring(response.data.applicationId);
      
      return response.data;
    } catch (error) {
      await this.handleApplicationError(error, application);
      throw error;
    }
  }
  
  async checkApplicationStatus(applicationId: string): Promise<EPSApplicationStatus> {
    const response = await this.client.get(`/applications/${applicationId}/status`);
    
    // Update local status
    await this.updateApplicationStatus(applicationId, response.data);
    
    // Handle status changes
    await this.handleStatusChange(applicationId, response.data);
    
    return response.data;
  }
  
  private async handleStatusChange(
    applicationId: string, 
    status: EPSApplicationStatus
  ): Promise<void> {
    switch (status.status) {
      case 'approved':
        await this.handleApproval(applicationId, status);
        break;
      case 'funded':
        await this.handleFunding(applicationId, status);
        break;
      case 'declined':
        await this.handleDecline(applicationId, status);
        break;
    }
  }
}
```

#### 3.1.5 Required Disclosures
```typescript
const EPS_DISCLOSURES = {
  refundAdvance: {
    title: 'Refund Advance Disclosure',
    content: `
      This is a loan secured by your tax refund. You are responsible for repayment 
      of the loan amount if your refund is less than expected or if your return is 
      rejected by the IRS. 
      
      APR: [INSERT APR]%
      Loan Amount: $[INSERT AMOUNT]
      Estimated Refund: $[INSERT REFUND]
      
      By accepting this loan, you authorize [INSERT LEGAL NAME] to deduct the loan 
      amount plus any applicable fees from your tax refund when received.
    `,
    version: '2025.1',
    required: true
  },
  bankAccountAuthorization: {
    title: 'Bank Account Authorization',
    content: `
      By providing your bank account information, you authorize EPS Financial to:
      1. Verify your account information
      2. Deposit approved loan funds
      3. Collect repayment from your tax refund
      
      This authorization will remain in effect until the loan is fully repaid.
    `,
    version: '2025.1',
    required: true
  }
};
```

---

## 4. Persona Identity Verification Integration

### 4.1 Persona Overview
Persona provides identity verification, KYC/AML compliance, and fraud prevention services.

#### 4.1.2 Identity Verification Flow
```mermaid
sequenceDiagram
    participant Client
    participant Platform
    participant Persona
    participant Database
    
    Client->>Platform: Request Bank Product
    Platform->>Persona: Create Inquiry
    Persona-->>Platform: Inquiry ID & URL
    
    Platform->>Client: Redirect to Persona
    Client->>Persona: Complete Verification
    
    Persona->>Persona: ID Document Scan
    Persona->>Persona: Liveness Check
    Persona->>Persona: Watchlist Screening
    
    Persona-->>Platform: Webhook Notification
    Platform->>Database: Store Verification Result
    Platform->>Client: Verification Complete
```

#### 4.1.3 Inquiry Creation
```typescript
interface PersonaInquiry {
  inquiryTemplateId: string;
  referenceId: string;
  fields: {
    nameFirst: string;
    nameLast: string;
    phoneNumber: string;
    emailAddress: string;
    addressStreet1: string;
    addressCity: string;
    addressSubdivision: string;
    addressPostalCode: string;
    birthdate: string;
  };
  redirectUri: string;
}

class PersonaIdentityService {
  async createInquiry(client: Client, purpose: string): Promise<PersonaInquiryResult> {
    const inquiry: PersonaInquiry = {
      inquiryTemplateId: this.getTemplateId(purpose),
      referenceId: `client_${client.id}`,
      fields: {
        nameFirst: client.firstName,
        nameLast: client.lastName,
        phoneNumber: client.phone,
        emailAddress: client.email,
        addressStreet1: client.address.street1,
        addressCity: client.address.city,
        addressSubdivision: client.address.state,
        addressPostalCode: client.address.zipCode,
        birthdate: client.dateOfBirth
      },
      redirectUri: `${process.env.APP_URL}/verification/complete`
    };
    
    const response = await this.client.post('/inquiries', inquiry);
    
    // Store inquiry locally
    await this.storeInquiry(client.id, response.data);
    
    return {
      inquiryId: response.data.id,
      url: response.data.attributes.url,
      status: response.data.attributes.status
    };
  }
  
  private getTemplateId(purpose: string): string {
    const templates = {
      'bank_product': process.env.PERSONA_BANK_PRODUCT_TEMPLATE,
      'high_risk_client': process.env.PERSONA_HIGH_RISK_TEMPLATE,
      'preparer_verification': process.env.PERSONA_PREPARER_TEMPLATE
    };
    
    return templates[purpose] || templates['bank_product'];
  }
}
```

#### 4.1.4 Webhook Processing
```typescript
interface PersonaWebhook {
  type: string;
  id: string;
  attributes: {
    name: string;
    status: string;
    referenceId: string;
    createdAt: string;
    completedAt?: string;
    fields: Record<string, any>;
    verifications: PersonaVerification[];
  };
}

interface PersonaVerification {
  type: string;
  status: 'passed' | 'failed' | 'requires_retry' | 'canceled';
  checks: PersonaCheck[];
}

class PersonaWebhookHandler {
  async handleWebhook(payload: PersonaWebhook): Promise<void> {
    // Verify webhook signature
    if (!this.verifySignature(payload)) {
      throw new Error('Invalid webhook signature');
    }
    
    switch (payload.attributes.name) {
      case 'inquiry.completed':
        await this.handleInquiryCompleted(payload);
        break;
      case 'inquiry.failed':
        await this.handleInquiryFailed(payload);
        break;
      case 'inquiry.expired':
        await this.handleInquiryExpired(payload);
        break;
    }
  }
  
  private async handleInquiryCompleted(payload: PersonaWebhook): Promise<void> {
    const clientId = this.extractClientId(payload.attributes.referenceId);
    
    // Extract verification results
    const verificationResult = {
      inquiryId: payload.id,
      status: payload.attributes.status,
      completedAt: payload.attributes.completedAt,
      identityVerified: this.checkIdentityVerification(payload.attributes.verifications),
      livenessVerified: this.checkLivenessVerification(payload.attributes.verifications),
      watchlistClear: this.checkWatchlistScreening(payload.attributes.verifications),
      riskScore: this.calculateRiskScore(payload.attributes.verifications)
    };
    
    // Store results
    await this.storeVerificationResult(clientId, verificationResult);
    
    // Continue with bank product application if applicable
    if (verificationResult.identityVerified && verificationResult.livenessVerified) {
      await this.continueBankProductApplication(clientId);
    } else {
      await this.handleVerificationFailure(clientId, verificationResult);
    }
  }
  
  private checkIdentityVerification(verifications: PersonaVerification[]): boolean {
    const idVerification = verifications.find(v => v.type === 'government-id');
    return idVerification?.status === 'passed';
  }
  
  private checkLivenessVerification(verifications: PersonaVerification[]): boolean {
    const livenessVerification = verifications.find(v => v.type === 'selfie');
    return livenessVerification?.status === 'passed';
  }
  
  private checkWatchlistScreening(verifications: PersonaVerification[]): boolean {
    const watchlistVerification = verifications.find(v => v.type === 'watchlist');
    return watchlistVerification?.status === 'passed';
  }
}
```

---

## 5. Stripe Payment Integration

### 5.1 Stripe Configuration
```typescript
interface StripeConfig {
  publishableKey: string;
  secretKey: string;
  webhookSecret: string;
  connectClientId: string;
  platformAccountId: string;
}

class StripeService {
  private stripe: Stripe;
  
  constructor(config: StripeConfig) {
    this.stripe = new Stripe(config.secretKey, {
      apiVersion: '2023-10-16',
      typescript: true
    });
  }
}
```

### 5.2 Payment Processing
```typescript
interface PaymentRequest {
  amount: number;
  currency: string;
  customerId?: string;
  paymentMethodId?: string;
  description: string;
  metadata: Record<string, string>;
  applicationFeeAmount?: number;
  transferData?: {
    destination: string;
    amount?: number;
  };
}

class StripePaymentService {
  async createPaymentIntent(request: PaymentRequest): Promise<Stripe.PaymentIntent> {
    const paymentIntent = await this.stripe.paymentIntents.create({
      amount: request.amount,
      currency: request.currency,
      customer: request.customerId,
      payment_method: request.paymentMethodId,
      description: request.description,
      metadata: request.metadata,
      application_fee_amount: request.applicationFeeAmount,
      transfer_data: request.transferData,
      confirm: true,
      return_url: `${process.env.APP_URL}/payment/complete`
    });
    
    return paymentIntent;
  }
  
  async processPaymentWithRevenueSplit(
    payment: PaymentRequest,
    tenant: Tenant
  ): Promise<PaymentResult> {
    const platformFee = Math.round(payment.amount * tenant.revenueShareRate);
    const resellerAmount = payment.amount - platformFee;
    
    const paymentIntent = await this.stripe.paymentIntents.create({
      amount: payment.amount,
      currency: payment.currency,
      application_fee_amount: platformFee,
      transfer_data: {
        destination: tenant.stripeConnectAccountId,
        amount: resellerAmount
      },
      metadata: {
        tenant_id: tenant.id,
        platform_fee: platformFee.toString(),
        reseller_amount: resellerAmount.toString()
      }
    });
    
    return {
      paymentIntent,
      platformFee,
      resellerAmount
    };
  }
}
```

### 5.3 Stripe Connect for White-Label
```typescript
interface ConnectAccountRequest {
  type: 'express' | 'standard' | 'custom';
  country: string;
  email: string;
  businessProfile: {
    name: string;
    productDescription: string;
    supportEmail: string;
    supportPhone: string;
    supportUrl: string;
  };
  capabilities: {
    card_payments: { requested: boolean };
    transfers: { requested: boolean };
  };
}

class StripeConnectService {
  async createConnectAccount(reseller: Reseller): Promise<Stripe.Account> {
    const account = await this.stripe.accounts.create({
      type: 'express',
      country: 'US',
      email: reseller.email,
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true }
      },
      business_profile: {
        name: reseller.businessName,
        product_description: 'Tax preparation services',
        support_email: reseller.supportEmail,
        support_phone: reseller.supportPhone,
        support_url: reseller.website
      },
      settings: {
        payouts: {
          schedule: {
            interval: 'weekly',
            weekly_anchor: 'friday'
          }
        }
      }
    });
    
    // Store account ID
    await this.updateResellerStripeAccount(reseller.id, account.id);
    
    return account;
  }
  
  async createAccountLink(accountId: string, refreshUrl: string, returnUrl: string): Promise<Stripe.AccountLink> {
    return await this.stripe.accountLinks.create({
      account: accountId,
      refresh_url: refreshUrl,
      return_url: returnUrl,
      type: 'account_onboarding'
    });
  }
  
  async getAccountStatus(accountId: string): Promise<AccountStatus> {
    const account = await this.stripe.accounts.retrieve(accountId);
    
    return {
      id: account.id,
      chargesEnabled: account.charges_enabled,
      payoutsEnabled: account.payouts_enabled,
      detailsSubmitted: account.details_submitted,
      requirements: account.requirements
    };
  }
}
```

### 5.4 Webhook Handling
```typescript
interface StripeWebhookEvent {
  id: string;
  type: string;
  data: {
    object: any;
    previous_attributes?: any;
  };
  created: number;
}

class StripeWebhookHandler {
  async handleWebhook(rawBody: string, signature: string): Promise<void> {
    let event: StripeWebhookEvent;
    
    try {
      event = this.stripe.webhooks.constructEvent(
        rawBody,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET!
      );
    } catch (err) {
      throw new Error(`Webhook signature verification failed: ${err.message}`);
    }
    
    switch (event.type) {
      case 'payment_intent.succeeded':
        await this.handlePaymentSucceeded(event);
        break;
      case 'payment_intent.payment_failed':
        await this.handlePaymentFailed(event);
        break;
      case 'account.updated':
        await this.handleAccountUpdated(event);
        break;
      case 'transfer.created':
        await this.handleTransferCreated(event);
        break;
    }
  }
  
  private async handlePaymentSucceeded(event: StripeWebhookEvent): Promise<void> {
    const paymentIntent = event.data.object as Stripe.PaymentIntent;
    
    // Update payment status
    await this.updatePaymentStatus(paymentIntent.id, 'succeeded');
    
    // Process revenue split
    if (paymentIntent.application_fee_amount) {
      await this.recordRevenueShare(paymentIntent);
    }
    
    // Continue tax return workflow
    const taxReturnId = paymentIntent.metadata.tax_return_id;
    if (taxReturnId) {
      await this.continueReturnProcessing(taxReturnId);
    }
  }
  
  private async handleAccountUpdated(event: StripeWebhookEvent): Promise<void> {
    const account = event.data.object as Stripe.Account;
    
    // Update reseller account status
    await this.updateResellerAccountStatus(account.id, {
      chargesEnabled: account.charges_enabled,
      payoutsEnabled: account.payouts_enabled,
      detailsSubmitted: account.details_submitted
    });
    
    // Notify reseller if onboarding complete
    if (account.charges_enabled && account.payouts_enabled) {
      await this.notifyResellerOnboardingComplete(account.id);
    }
  }
}
```

---

## 6. Communication Integrations

### 6.1 Twilio SMS Integration
```typescript
interface SMSMessage {
  to: string;
  from: string;
  body: string;
  mediaUrl?: string[];
}

class TwilioSMSService {
  private client: Twilio;
  
  constructor() {
    this.client = new Twilio(
      process.env.TWILIO_ACCOUNT_SID!,
      process.env.TWILIO_AUTH_TOKEN!
    );
  }
  
  async sendSMS(message: SMSMessage): Promise<MessageInstance> {
    try {
      const result = await this.client.messages.create({
        to: message.to,
        from: message.from,
        body: message.body,
        mediaUrl: message.mediaUrl
      });
      
      // Log message
      await this.logMessage(result);
      
      return result;
    } catch (error) {
      await this.handleSMSError(error, message);
      throw error;
    }
  }
  
  async sendOTP(phoneNumber: string, code: string): Promise<void> {
    const message = {
      to: phoneNumber,
      from: process.env.TWILIO_PHONE_NUMBER!,
      body: `Your Lawson Mobile Tax verification code is: ${code}. This code expires in 10 minutes.`
    };
    
    await this.sendSMS(message);
  }
  
  async sendStatusUpdate(phoneNumber: string, status: string, returnId: string): Promise<void> {
    const messages = {
      'documents_received': 'We\'ve received your tax documents and are processing your return.',
      'review_required': 'Your return requires additional review. We\'ll contact you within 24 hours.',
      'ready_for_signature': 'Your return is ready for e-signature. Check your email for the link.',
      'filed': 'Your return has been successfully filed with the IRS.',
      'accepted': 'Great news! The IRS has accepted your return.',
      'refund_processed': 'Your refund has been processed and should arrive within 21 days.'
    };
    
    const message = {
      to: phoneNumber,
      from: process.env.TWILIO_PHONE_NUMBER!,
      body: messages[status] || 'Your tax return status has been updated.'
    };
    
    await this.sendSMS(message);
  }
}
```

### 6.2 Customer.io Email Integration
```typescript
interface EmailCampaign {
  campaignId: string;
  customerId: string;
  data: Record<string, any>;
}

interface EmailTemplate {
  templateId: string;
  to: string;
  from: string;
  subject: string;
  data: Record<string, any>;
}

class CustomerIOService {
  private client: APIClient;
  
  constructor() {
    this.client = new APIClient(process.env.CUSTOMERIO_API_KEY!);
  }
  
  async identifyCustomer(customerId: string, attributes: Record<string, any>): Promise<void> {
    await this.client.identify({
      id: customerId,
      ...attributes
    });
  }
  
  async trackEvent(customerId: string, eventName: string, data: Record<string, any>): Promise<void> {
    await this.client.track(customerId, {
      name: eventName,
      data: data
    });
  }
  
  async sendTransactionalEmail(template: EmailTemplate): Promise<void> {
    await this.client.sendEmail({
      transactional_message_id: template.templateId,
      to: template.to,
      from: template.from,
      subject: template.subject,
      identifiers: {
        email: template.to
      },
      message_data: template.data
    });
  }
  
  async triggerCampaign(campaign: EmailCampaign): Promise<void> {
    await this.client.triggerBroadcast(campaign.campaignId, {
      recipients: [
        {
          id: campaign.customerId
        }
      ],
      data: campaign.data
    });
  }
}
```

---

## 7. Marketing Integrations

### 7.1 Segment Analytics Integration
```typescript
interface SegmentEvent {
  userId?: string;
  anonymousId?: string;
  event: string;
  properties: Record<string, any>;
  context?: {
    page?: {
      url: string;
      title: string;
      referrer: string;
    };
    userAgent?: string;
    ip?: string;
  };
  timestamp?: Date;
}

class SegmentService {
  private analytics: Analytics;
  
  constructor() {
    this.analytics = new Analytics({
      writeKey: process.env.SEGMENT_WRITE_KEY!
    });
  }
  
  async track(event: SegmentEvent): Promise<void> {
    this.analytics.track({
      userId: event.userId,
      anonymousId: event.anonymousId,
      event: event.event,
      properties: event.properties,
      context: event.context,
      timestamp: event.timestamp
    });
  }
  
  async identify(userId: string, traits: Record<string, any>): Promise<void> {
    this.analytics.identify({
      userId: userId,
      traits: traits
    });
  }
  
  async page(userId: string, name: string, properties: Record<string, any>): Promise<void> {
    this.analytics.page({
      userId: userId,
      name: name,
      properties: properties
    });
  }
  
  // Tax-specific event tracking
  async trackTaxEvent(userId: string, eventName: string, data: Record<string, any>): Promise<void> {
    const taxEvents = {
      'lead_captured': {
        category: 'Lead Generation',
        ...data
      },
      'intake_started': {
        category: 'Tax Preparation',
        ...data
      },
      'document_uploaded': {
        category: 'Document Processing',
        ...data
      },
      'payment_completed': {
        category: 'Revenue',
        revenue: data.amount,
        ...data
      },
      'return_filed': {
        category: 'Tax Filing',
        ...data
      }
    };
    
    await this.track({
      userId: userId,
      event: eventName,
      properties: taxEvents[eventName] || data
    });
  }
}
```

### 7.2 Meta Ads Integration (Optional)
```typescript
interface MetaAdCampaign {
  name: string;
  objective: string;
  status: string;
  dailyBudget: number;
  targeting: {
    ageMin: number;
    ageMax: number;
    genders: number[];
    interests: string[];
    locations: string[];
  };
  creative: {
    title: string;
    body: string;
    imageUrl: string;
    callToAction: string;
  };
}

class MetaAdsService {
  private client: FacebookAdsApi;
  
  constructor() {
    this.client = new FacebookAdsApi(process.env.META_ACCESS_TOKEN!);
  }
  
  async createCampaign(adAccountId: string, campaign: MetaAdCampaign): Promise<string> {
    const campaignData = {
      name: campaign.name,
      objective: campaign.objective,
      status: campaign.status,
      daily_budget: campaign.dailyBudget * 100, // Convert to cents
      targeting: {
        age_min: campaign.targeting.ageMin,
        age_max: campaign.targeting.ageMax,
        genders: campaign.targeting.genders,
        interests: campaign.targeting.interests.map(interest => ({ name: interest })),
        geo_locations: {
          countries: campaign.targeting.locations
        }
      }
    };
    
    const response = await this.client.call('POST', `/${adAccountId}/campaigns`, campaignData);
    return response.id;
  }
  
  async getCampaignMetrics(campaignId: string): Promise<CampaignMetrics> {
    const response = await this.client.call('GET', `/${campaignId}/insights`, {
      fields: 'impressions,clicks,ctr,cpc,spend,conversions,cost_per_conversion'
    });
    
    return response.data[0];
  }
}
```

---

## 8. Integration Error Handling

### 8.1 Circuit Breaker Pattern
```typescript
interface CircuitBreakerConfig {
  failureThreshold: number;
  resetTimeout: number;
  monitoringPeriod: number;
}

class CircuitBreaker {
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private failureCount = 0;
  private lastFailureTime?: Date;
  
  constructor(private config: CircuitBreakerConfig) {}
  
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (this.shouldAttemptReset()) {
        this.state = 'HALF_OPEN';
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }
    
    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
  
  private onSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }
  
  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = new Date();
    
    if (this.failureCount >= this.config.failureThreshold) {
      this.state = 'OPEN';
    }
  }
  
  private shouldAttemptReset(): boolean {
    if (!this.lastFailureTime) return false;
    
    const timeSinceLastFailure = Date.now() - this.lastFailureTime.getTime();
    return timeSinceLastFailure >= this.config.resetTimeout;
  }
}
```

### 8.2 Retry Logic with Exponential Backoff
```typescript
interface RetryConfig {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

class RetryHandler {
  constructor(private config: RetryConfig) {}
  
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    let lastError: Error;
    
    for (let attempt = 1; attempt <= this.config.maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        if (attempt === this.config.maxAttempts) {
          break;
        }
        
        if (!this.isRetryableError(error)) {
          throw error;
        }
        
        const delay = this.calculateDelay(attempt);
        await this.sleep(delay);
      }
    }
    
    throw lastError!;
  }
  
  private isRetryableError(error: any): boolean {
    // Retry on network errors, timeouts, and 5xx status codes
    return (
      error.code === 'ECONNRESET' ||
      error.code === 'ETIMEDOUT' ||
      error.code === 'ENOTFOUND' ||
      (error.response && error.response.status >= 500)
    );
  }
  
  private calculateDelay(attempt: number): number {
    const delay = this.config.baseDelay * Math.pow(this.config.backoffMultiplier, attempt - 1);
    return Math.min(delay, this.config.maxDelay);
  }
  
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

### 8.3 Integration Health Monitoring
```typescript
interface HealthCheck {
  service: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  responseTime: number;
  lastChecked: Date;
  error?: string;
}

class IntegrationHealthMonitor {
  private healthChecks = new Map<string, HealthCheck>();
  
  async checkHealth(serviceName: string, healthCheckFn: () => Promise<void>): Promise<HealthCheck> {
    const startTime = Date.now();
    let status: HealthCheck['status'] = 'healthy';
    let error: string | undefined;
    
    try {
      await healthCheckFn();
    } catch (err) {
      status = 'unhealthy';
      error = err.message;
    }
    
    const responseTime = Date.now() - startTime;
    
    // Determine if service is degraded based on response time
    if (status === 'healthy' && responseTime > 5000) {
      status = 'degraded';
    }
    
    const healthCheck: HealthCheck = {
      service: serviceName,
      status,
      responseTime,
      lastChecked: new Date(),
      error
    };
    
    this.healthChecks.set(serviceName, healthCheck);
    
    // Alert if service is unhealthy
    if (status === 'unhealthy') {
      await this.alertUnhealthyService(serviceName, error);
    }
    
    return healthCheck;
  }
  
  async checkAllServices(): Promise<Map<string, HealthCheck>> {
    const services = [
      { name: 'olt', check: () => this.oltService.healthCheck() },
      { name: 'eps', check: () => this.epsService.healthCheck() },
      { name: 'persona', check: () => this.personaService.healthCheck() },
      { name: 'stripe', check: () => this.stripeService.healthCheck() },
      { name: 'twilio', check: () => this.twilioService.healthCheck() },
      { name: 'customerio', check: () => this.customerIOService.healthCheck() }
    ];
    
    await Promise.all(
      services.map(service => 
        this.checkHealth(service.name, service.check)
      )
    );
    
    return this.healthChecks;
  }
  
  private async alertUnhealthyService(serviceName: string, error: string): Promise<void> {
    // Send alert to monitoring system
    await this.monitoringService.alert({
      severity: 'critical',
      message: `Integration service ${serviceName} is unhealthy: ${error}`,
      service: serviceName,
      timestamp: new Date()
    });
  }
}
```

---

## 9. Integration Testing

### 9.1 Integration Test Framework
```typescript
interface IntegrationTestConfig {
  service: string;
  environment: 'sandbox' | 'staging' | 'production';
  credentials: Record<string, string>;
}

class IntegrationTestSuite {
  async runTests(config: IntegrationTestConfig): Promise<TestResults> {
    const results: TestResults = {
      service: config.service,
      passed: 0,
      failed: 0,
      tests: []
    };
    
    switch (config.service) {
      case 'olt':
        await this.testOLTIntegration(config, results);
        break;
      case 'eps':
        await this.testEPSIntegration(config, results);
        break;
      case 'persona':
        await this.testPersonaIntegration(config, results);
        break;
      case 'stripe':
        await this.testStripeIntegration(config, results);
        break;
    }
    
    return results;
  }
  
  private async testOLTIntegration(config: IntegrationTestConfig, results: TestResults): Promise<void> {
    // Test authentication
    await this.runTest('OLT Authentication', async () => {
      const client = new OLTClient(config.credentials);
      await client.authenticate();
    }, results);
    
    // Test return creation
    await this.runTest('OLT Return Creation', async () => {
      const client = new OLTClient(config.credentials);
      const testReturn = this.createTestReturn();
      const result = await client.createReturn(testReturn);
      expect(result.id).toBeDefined();
    }, results);
    
    // Test tax calculation
    await this.runTest('OLT Tax Calculation', async () => {
      const client = new OLTClient(config.credentials);
      const testReturn = await client.createReturn(this.createTestReturn());
      const calculation = await client.calculateTax(testReturn.id);
      expect(calculation.totalTax).toBeGreaterThanOrEqual(0);
    }, results);
  }
  
  private async runTest(
    testName: string, 
    testFn: () => Promise<void>, 
    results: TestResults
  ): Promise<void> {
    try {
      await testFn();
      results.passed++;
      results.tests.push({ name: testName, status: 'passed' });
    } catch (error) {
      results.failed++;
      results.tests.push({ 
        name: testName, 
        status: 'failed', 
        error: error.message 
      });
    }
  }
}
```

---

*Document Version: 1.0*
*Last Updated: August 22, 2025*
*Next Review: September 22, 2025*

---

## Appendices

### Appendix A: API Rate Limits
[INSERT RATE LIMITING SPECIFICATIONS FOR EACH SERVICE]

### Appendix B: Error Code Mappings
[INSERT ERROR CODE TRANSLATIONS AND HANDLING]

### Appendix C: Webhook Security
[INSERT WEBHOOK SIGNATURE VERIFICATION DETAILS]

### Appendix D: Integration Monitoring Dashboards
[INSERT MONITORING AND ALERTING CONFIGURATIONS]

