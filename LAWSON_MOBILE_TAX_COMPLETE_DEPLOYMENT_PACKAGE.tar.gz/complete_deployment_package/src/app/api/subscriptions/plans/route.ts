

export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all available subscription plans
    const plans = await prisma.subscriptionPlan.findMany({
      where: {
        OR: [
          { tenantId: session.user.tenantId },
          { tenantId: null }, // Global plans
        ],
        isActive: true,
      },
      orderBy: [
        { tierLevel: 'asc' },
        { billingCycle: 'asc' },
      ],
    });

    // Updated mock plans with correct pricing
    const mockPlans = [
      {
        id: 'basic-tax-return',
        planName: 'Basic Tax Return',
        planType: 'individual',
        billingCycle: 'one-time',
        basePrice: 199,
        tierLevel: 'basic',
        features: [
          'Simple tax situations',
          'W-2 and basic forms',
          'Standard deduction optimization',
          'AI-powered accuracy check',
          'Expert review included',
          'E-filing included',
        ],
        limits: { maxTaxReturns: 1, maxUsers: 1, storageGB: 5 },
        trialPeriodDays: 0,
      },
      {
        id: 'premium-tax-return',
        planName: 'Premium Tax Return',
        planType: 'individual',
        billingCycle: 'one-time',
        basePrice: 649,
        tierLevel: 'premium',
        features: [
          'Complex tax situations',
          'Business income (Schedule C)',
          'Rental properties (Schedule E)',
          'Stock transactions (Schedule D)',
          'Multiple income sources',
          'State return included',
          'Priority support',
          'Advanced deduction discovery',
        ],
        limits: { maxTaxReturns: 1, maxUsers: 1, storageGB: 25 },
        trialPeriodDays: 0,
      },
      {
        id: 'business-tax-return',
        planName: 'Business Tax Return',
        planType: 'business',
        billingCycle: 'one-time',
        basePrice: 999,
        tierLevel: 'professional',
        features: [
          'Business tax returns',
          'Corporate filings',
          'Partnership returns',
          'Multi-entity structures',
          'Advanced business deductions',
          'Quarterly planning included',
          'Dedicated tax professional',
          'Same-day processing option',
        ],
        limits: { maxTaxReturns: 1, maxUsers: 3, storageGB: 100 },
        trialPeriodDays: 0,
      },
      {
        id: 'ultra-premium-concierge',
        planName: 'Ultra-Premium Concierge',
        planType: 'enterprise',
        billingCycle: 'one-time',
        basePrice: 1599,
        tierLevel: 'enterprise',
        features: [
          'White-glove service',
          'Dedicated CPA team',
          'Unlimited complexity',
          'Multi-year planning',
          'Investment optimization',
          'Estate planning coordination',
          'Audit representation included',
          '24/7 priority support',
        ],
        limits: { maxTaxReturns: -1, maxUsers: -1, storageGB: 500 },
        trialPeriodDays: 0,
      },
      {
        id: 'monthly-ai-advisor',
        planName: 'Monthly AI Financial Advisor',
        planType: 'subscription',
        billingCycle: 'monthly',
        basePrice: 29,
        tierLevel: 'basic',
        features: [
          'AI-powered financial insights',
          'Monthly tax planning',
          'Deduction tracking',
          'Financial goal setting',
          'Automated expense categorization',
          'Tax-saving recommendations',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 10 },
        trialPeriodDays: 7,
      },
      {
        id: 'premium-analytics',
        planName: 'Premium Analytics',
        planType: 'subscription',
        billingCycle: 'monthly',
        basePrice: 99,
        tierLevel: 'premium',
        features: [
          'Advanced financial analytics',
          'Tax optimization modeling',
          'Investment performance tracking',
          'Business expense analysis',
          'Custom reporting dashboard',
          'API access for integrations',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 3, storageGB: 50 },
        trialPeriodDays: 14,
      },
      {
        id: 'business-suite',
        planName: 'Business Suite',
        planType: 'subscription',
        billingCycle: 'monthly',
        basePrice: 299,
        tierLevel: 'professional',
        features: [
          'Complete business tax management',
          'Payroll tax automation',
          'Quarterly filing reminders',
          'Multi-entity management',
          'Advanced business analytics',
          'Dedicated account manager',
        ],
        limits: { maxTaxReturns: -1, maxUsers: 10, storageGB: 200 },
        trialPeriodDays: 30,
      },
      {
        id: 'enterprise-plan',
        planName: 'Enterprise',
        planType: 'subscription',
        billingCycle: 'monthly',
        basePrice: 999,
        tierLevel: 'enterprise',
        features: [
          'Enterprise-grade tax management',
          'Custom integrations',
          'White-label options',
          'Advanced compliance tools',
          'Unlimited users and entities',
          'Priority support and training',
        ],
        limits: { maxTaxReturns: -1, maxUsers: -1, storageGB: 1000 },
        trialPeriodDays: 30,
      },
    ];

    // Add-on services with updated pricing including Ask Melika GPT
    const addOnServices = [
      {
        id: 'ask-melika-gpt',
        planName: 'Ask Melika GPT',
        planType: 'addon',
        billingCycle: 'monthly',
        basePrice: 19.99,
        tierLevel: 'addon',
        features: [
          'AI tax assistant available 24/7',
          'Instant answers to tax questions',
          'Personalized tax guidance',
          'Document analysis and advice',
          'Tax planning recommendations',
          'Priority GPT response queue',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 0 },
        trialPeriodDays: 7,
      },
      {
        id: 'audit-protection',
        planName: 'Audit Protection',
        planType: 'addon',
        billingCycle: 'annual',
        basePrice: 99,
        tierLevel: 'addon',
        features: [
          'Full audit representation',
          'IRS correspondence handling',
          'Professional tax advocate',
          'Document preparation assistance',
          'Peace of mind guarantee',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 0 },
        trialPeriodDays: 0,
      },
      {
        id: 'tax-planning-session',
        planName: 'Tax Planning Session',
        planType: 'addon',
        billingCycle: 'one-time',
        basePrice: 299,
        tierLevel: 'addon',
        features: [
          '1-hour consultation with CPA',
          'Personalized tax strategy',
          'Year-round planning advice',
          'Deduction optimization review',
          'Written recommendations',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 0 },
        trialPeriodDays: 0,
      },
      {
        id: 'bookkeeping-basic',
        planName: 'Bookkeeping Basic',
        planType: 'addon',
        billingCycle: 'monthly',
        basePrice: 49,
        tierLevel: 'addon',
        features: [
          'Basic bookkeeping services',
          'Monthly financial reports',
          'Expense categorization',
          'Receipt scanning and storage',
          'Basic tax preparation support',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 10 },
        trialPeriodDays: 14,
      },
      {
        id: 'bookkeeping-premium',
        planName: 'Bookkeeping Premium',
        planType: 'addon',
        billingCycle: 'monthly',
        basePrice: 149,
        tierLevel: 'addon',
        features: [
          'Advanced bookkeeping services',
          'Weekly financial reports',
          'Cash flow analysis',
          'Accounts payable/receivable management',
          'Dedicated bookkeeper assigned',
          'Tax planning coordination',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 3, storageGB: 50 },
        trialPeriodDays: 14,
      },
      {
        id: 'investment-optimization',
        planName: 'Investment Optimization',
        planType: 'addon',
        billingCycle: 'annual',
        basePrice: 399,
        tierLevel: 'addon',
        features: [
          'Portfolio tax optimization',
          'Tax-loss harvesting guidance',
          'Asset allocation recommendations',
          'Quarterly investment reviews',
          'Tax-efficient investment strategies',
        ],
        limits: { maxTaxReturns: 0, maxUsers: 1, storageGB: 0 },
        trialPeriodDays: 0,
      },
    ];

    // Create annual versions for monthly subscription plans only
    const monthlyPlans = mockPlans.filter(plan => plan.billingCycle === 'monthly');
    const annualPlans = monthlyPlans.map(plan => ({
      ...plan,
      id: plan.id.replace('monthly', 'annual'),
      billingCycle: 'annual',
      basePrice: Math.round(plan.basePrice * 10), // Annual price (slight discount built in)
    }));

    const allPlans = [...mockPlans, ...annualPlans, ...addOnServices];

    return NextResponse.json({
      success: true,
      plans: plans.length > 0 ? plans : allPlans,
    });
  } catch (error: any) {
    console.error('Get subscription plans error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve subscription plans', details: error?.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user || !session.user.roles?.includes('admin')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      planName,
      planType,
      billingCycle,
      basePrice,
      tierLevel,
      features,
      limits,
      trialPeriodDays,
    } = await request.json();

    const plan = await prisma.subscriptionPlan.create({
      data: {
        tenantId: session.user.tenantId,
        planName,
        planType,
        billingCycle,
        basePrice,
        tierLevel,
        features,
        limits,
        trialPeriodDays: trialPeriodDays || 0,
        includedServices: [],
        addOnPricing: {},
      },
    });

    return NextResponse.json({
      success: true,
      plan,
    });
  } catch (error: any) {
    console.error('Create subscription plan error:', error);
    return NextResponse.json(
      { error: 'Failed to create subscription plan', details: error?.message },
      { status: 500 }
    );
  }
}
