
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bell, Calendar, FileText, DollarSign, TrendingUp, 
  CheckCircle, Clock, AlertCircle, Settings, User,
  Calculator, BookOpen, Award, Target, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ClientProfile, ClientPortal, PortalWidget, 
  ClientNotification, ClientDocument, ClientTask 
} from '@/lib/types/experience';

interface PersonalizedDashboardProps {
  clientProfile: ClientProfile;
  portal: ClientPortal;
  notifications: ClientNotification[];
  documents: ClientDocument[];
  tasks: ClientTask[];
  onUpdateWidget: (widgetId: string, updates: Partial<PortalWidget>) => void;
  onMarkNotificationRead: (notificationId: string) => void;
  onCompleteTask: (taskId: string) => void;
  onUploadDocument: (document: Partial<ClientDocument>) => void;
}

const WIDGET_TYPES = {
  tax_summary: {
    title: 'Tax Summary',
    icon: DollarSign,
    color: 'bg-green-100 text-green-800'
  },
  deadlines: {
    title: 'Important Deadlines',
    icon: Calendar,
    color: 'bg-red-100 text-red-800'
  },
  documents: {
    title: 'Documents',
    icon: FileText,
    color: 'bg-blue-100 text-blue-800'
  },
  progress: {
    title: 'Progress Tracker',
    icon: TrendingUp,
    color: 'bg-purple-100 text-purple-800'
  },
  recommendations: {
    title: 'Recommendations',
    icon: Target,
    color: 'bg-yellow-100 text-yellow-800'
  },
  calculator: {
    title: 'Quick Calculator',
    icon: Calculator,
    color: 'bg-indigo-100 text-indigo-800'
  }
};

const PRIORITY_COLORS = {
  low: 'text-gray-600 bg-gray-100',
  medium: 'text-yellow-600 bg-yellow-100',
  high: 'text-orange-600 bg-orange-100',
  urgent: 'text-red-600 bg-red-100'
};

const STATUS_COLORS = {
  pending: 'text-yellow-600 bg-yellow-100',
  in_progress: 'text-blue-600 bg-blue-100',
  completed: 'text-green-600 bg-green-100',
  overdue: 'text-red-600 bg-red-100',
  processing: 'text-purple-600 bg-purple-100',
  rejected: 'text-red-600 bg-red-100'
};

export default function PersonalizedDashboard({
  clientProfile,
  portal,
  notifications,
  documents,
  tasks,
  onUpdateWidget,
  onMarkNotificationRead,
  onCompleteTask,
  onUploadDocument
}: PersonalizedDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [unreadNotifications, setUnreadNotifications] = useState(
    notifications.filter(n => !n.isRead).length
  );

  const getGreeting = () => {
    const hour = new Date().getHours();
    const firstName = clientProfile.userId.split(' ')[0] || 'there';
    
    if (hour < 12) return `Good morning, ${firstName}!`;
    if (hour < 17) return `Good afternoon, ${firstName}!`;
    return `Good evening, ${firstName}!`;
  };

  const getPersonalizedMessage = () => {
    const persona = clientProfile.persona.name.toLowerCase();
    const currentMonth = new Date().getMonth();
    
    if (currentMonth >= 0 && currentMonth <= 3) {
      return `As a ${persona}, we've prepared special tax season resources just for you.`;
    } else if (currentMonth >= 9) {
      return `It's year-end planning time! Let's optimize your taxes for next year.`;
    }
    return `We're here to help with all your tax needs throughout the year.`;
  };

  const getCompletionStats = () => {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    
    return {
      total: totalTasks,
      completed: completedTasks,
      rate: Math.round(completionRate)
    };
  };

  const getUpcomingDeadlines = () => {
    const today = new Date();
    const thirtyDaysFromNow = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return tasks
      .filter(task => task.dueDate && new Date(task.dueDate) <= thirtyDaysFromNow)
      .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
      .slice(0, 5);
  };

  const getRecentDocuments = () => {
    return documents
      .sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
      .slice(0, 5);
  };

  const renderWidget = (widget: PortalWidget) => {
    const widgetType = WIDGET_TYPES[widget.type as keyof typeof WIDGET_TYPES];
    const IconComponent = widgetType.icon;

    switch (widget.type) {
      case 'tax_summary':
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-2">
                <IconComponent className="w-5 h-5 text-green-600" />
                <CardTitle className="text-lg">Tax Summary</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">$3,247</p>
                  <p className="text-sm text-gray-600">Expected Refund</p>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">85%</p>
                  <p className="text-sm text-gray-600">Return Complete</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Federal Return</span>
                  <Badge className="bg-green-100 text-green-800">Complete</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span>State Return</span>
                  <Badge className="bg-yellow-100 text-yellow-800">In Progress</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'deadlines':
        const upcomingDeadlines = getUpcomingDeadlines();
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-2">
                <IconComponent className="w-5 h-5 text-red-600" />
                <CardTitle className="text-lg">Upcoming Deadlines</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingDeadlines.length === 0 ? (
                  <p className="text-sm text-gray-600 text-center py-4">
                    No upcoming deadlines
                  </p>
                ) : (
                  upcomingDeadlines.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <div>
                        <p className="text-sm font-medium">{task.title}</p>
                        <p className="text-xs text-gray-600">
                          {task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'No due date'}
                        </p>
                      </div>
                      <Badge className={PRIORITY_COLORS[task.priority]}>
                        {task.priority}
                      </Badge>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        );

      case 'documents':
        const recentDocs = getRecentDocuments();
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <IconComponent className="w-5 h-5 text-blue-600" />
                  <CardTitle className="text-lg">Recent Documents</CardTitle>
                </div>
                <Button size="sm" variant="outline">
                  Upload
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentDocs.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-4 h-4 text-gray-600" />
                      <div>
                        <p className="text-sm font-medium">{doc.name}</p>
                        <p className="text-xs text-gray-600">
                          {new Date(doc.uploadDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={STATUS_COLORS[doc.status]}>
                      {doc.status.replace('_', ' ')}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'progress':
        const stats = getCompletionStats();
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-2">
                <IconComponent className="w-5 h-5 text-purple-600" />
                <CardTitle className="text-lg">Progress Tracker</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-600">{stats.rate}%</p>
                <p className="text-sm text-gray-600">Overall Completion</p>
              </div>
              <Progress value={stats.rate} className="h-3" />
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <p className="font-medium">{stats.completed}</p>
                  <p className="text-gray-600">Completed</p>
                </div>
                <div className="text-center">
                  <p className="font-medium">{stats.total - stats.completed}</p>
                  <p className="text-gray-600">Remaining</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'recommendations':
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-2">
                <IconComponent className="w-5 h-5 text-yellow-600" />
                <CardTitle className="text-lg">Recommendations</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <h4 className="font-medium text-yellow-800 mb-1">
                    💡 Tax Tip for {clientProfile.persona.name}s
                  </h4>
                  <p className="text-sm text-yellow-700">
                    Consider maximizing your retirement contributions before year-end to reduce taxable income.
                  </p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-1">
                    📚 Recommended Learning
                  </h4>
                  <p className="text-sm text-blue-700">
                    Complete the "Tax Deductions Masterclass" to discover potential savings.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'calculator':
        return (
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-2">
                <IconComponent className="w-5 h-5 text-indigo-600" />
                <CardTitle className="text-lg">Quick Calculator</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant="outline" className="text-xs">
                  Refund Estimator
                </Button>
                <Button size="sm" variant="outline" className="text-xs">
                  Tax Withholding
                </Button>
                <Button size="sm" variant="outline" className="text-xs">
                  Deduction Tracker
                </Button>
                <Button size="sm" variant="outline" className="text-xs">
                  Quarterly Taxes
                </Button>
              </div>
              <div className="text-center">
                <Button className="w-full">
                  Open Full Calculator
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      default:
        return (
          <Card className="h-full">
            <CardContent className="flex items-center justify-center h-32">
              <p className="text-gray-500">Widget not configured</p>
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">{getGreeting()}</h1>
            <p className="text-blue-100">{getPersonalizedMessage()}</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-center">
              <p className="text-2xl font-bold">{clientProfile.completionScore}%</p>
              <p className="text-sm text-blue-100">Profile Complete</p>
            </div>
            <div className="relative">
              <Button variant="secondary" size="sm">
                <Bell className="w-4 h-4" />
                {unreadNotifications > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs">
                    {unreadNotifications}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Widget Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {portal.widgets
              .filter(widget => widget.isVisible)
              .sort((a, b) => a.position.y - b.position.y || a.position.x - b.position.x)
              .map((widget) => (
                <motion.div
                  key={widget.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-80"
                >
                  {renderWidget(widget)}
                </motion.div>
              ))}
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Common tasks for {clientProfile.persona.name.toLowerCase()}s
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-20 flex flex-col space-y-2">
                  <FileText className="w-6 h-6" />
                  <span className="text-sm">Upload Documents</span>
                </Button>
                <Button variant="outline" className="h-20 flex flex-col space-y-2">
                  <Calculator className="w-6 h-6" />
                  <span className="text-sm">Tax Calculator</span>
                </Button>
                <Button variant="outline" className="h-20 flex flex-col space-y-2">
                  <BookOpen className="w-6 h-6" />
                  <span className="text-sm">Learning Hub</span>
                </Button>
                <Button variant="outline" className="h-20 flex flex-col space-y-2">
                  <User className="w-6 h-6" />
                  <span className="text-sm">Schedule Call</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Your Tasks</h3>
            <div className="flex space-x-2">
              <Badge variant="outline">{tasks.length} total</Badge>
              <Badge className="bg-green-100 text-green-800">
                {tasks.filter(t => t.status === 'completed').length} completed
              </Badge>
            </div>
          </div>

          <div className="space-y-4">
            {tasks.map((task) => (
              <Card key={task.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        task.status === 'completed' ? 'bg-green-600' : 'bg-gray-300'
                      }`}>
                        {task.status === 'completed' && (
                          <CheckCircle className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{task.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        {task.dueDate && (
                          <div className="flex items-center space-x-1 mt-2 text-xs text-gray-500">
                            <Clock className="w-3 h-3" />
                            <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={PRIORITY_COLORS[task.priority]}>
                        {task.priority}
                      </Badge>
                      <Badge className={STATUS_COLORS[task.status]}>
                        {task.status.replace('_', ' ')}
                      </Badge>
                      {task.status !== 'completed' && (
                        <Button
                          size="sm"
                          onClick={() => onCompleteTask(task.id)}
                        >
                          Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Your Documents</h3>
            <Button onClick={() => onUploadDocument({})}>
              <FileText className="w-4 h-4 mr-2" />
              Upload Document
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc) => (
              <Card key={doc.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-8 h-8 text-blue-600" />
                      <div>
                        <h4 className="font-medium text-gray-900">{doc.name}</h4>
                        <p className="text-sm text-gray-600">
                          {new Date(doc.uploadDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={STATUS_COLORS[doc.status]}>
                      {doc.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    {doc.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <Button variant="outline" size="sm" className="w-full">
                    View Document
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Notifications</h3>
            <Button variant="outline" size="sm">
              Mark All Read
            </Button>
          </div>

          <div className="space-y-4">
            {notifications.map((notification) => (
              <Card 
                key={notification.id} 
                className={`hover:shadow-lg transition-shadow ${
                  !notification.isRead ? 'border-blue-200 bg-blue-50' : ''
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        !notification.isRead ? 'bg-blue-600' : 'bg-gray-300'
                      }`} />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900">{notification.title}</h4>
                          <Badge className={PRIORITY_COLORS[notification.priority]}>
                            {notification.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(notification.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {notification.actionUrl && (
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                      )}
                      {!notification.isRead && (
                        <Button
                          size="sm"
                          onClick={() => onMarkNotificationRead(notification.id)}
                        >
                          Mark Read
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dashboard Preferences</CardTitle>
              <CardDescription>
                Customize your dashboard layout and notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-3">Theme</h4>
                <div className="flex space-x-4">
                  <Button 
                    variant={portal.theme === 'light' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Light
                  </Button>
                  <Button 
                    variant={portal.theme === 'dark' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Dark
                  </Button>
                  <Button 
                    variant={portal.theme === 'auto' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Auto
                  </Button>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Layout</h4>
                <div className="flex space-x-4">
                  <Button 
                    variant={portal.layout === 'dashboard' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Dashboard
                  </Button>
                  <Button 
                    variant={portal.layout === 'timeline' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Timeline
                  </Button>
                  <Button 
                    variant={portal.layout === 'cards' ? 'default' : 'outline'}
                    size="sm"
                  >
                    Cards
                  </Button>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Visible Widgets</h4>
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(WIDGET_TYPES).map(([type, config]) => {
                    const widget = portal.widgets.find(w => w.type === type);
                    return (
                      <div key={type} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={widget?.isVisible || false}
                          onChange={(e) => {
                            if (widget) {
                              onUpdateWidget(widget.id, { isVisible: e.target.checked });
                            }
                          }}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{config.title}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Communication Preferences</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Email notifications</span>
                    <input type="checkbox" defaultChecked className="rounded border-gray-300" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">SMS notifications</span>
                    <input type="checkbox" className="rounded border-gray-300" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Push notifications</span>
                    <input type="checkbox" defaultChecked className="rounded border-gray-300" />
                  </div>
                </div>
              </div>

              <Button className="w-full">
                Save Preferences
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
