
# Lawson Mobile Tax - Brand Guidelines

## Brand Overview

**Brand Name:** Lawson Mobile Tax  
**Tagline:** "Taxes Made Mobile. Refunds Made Maximum."  
**Mission:** To revolutionize tax preparation through mobile-first technology and professional expertise  
**Vision:** To make tax season stress-free for every American  
**Values:** Innovation, Accessibility, Expertise, Transparency, Trust  

---

## Brand Personality

### Primary Traits
- **Innovative:** Cutting-edge technology meets traditional expertise
- **Approachable:** Professional but friendly, never intimidating
- **Trustworthy:** Reliable, secure, and transparent in all dealings
- **Efficient:** Fast, streamlined, and respectful of client time
- **Expert:** Knowledgeable professionals with proven track record

### Voice & Tone
- **Conversational:** Speak like a knowledgeable friend, not a corporate entity
- **Confident:** Assured in our expertise without being arrogant
- **Clear:** Simple language that demystifies complex tax concepts
- **Supportive:** Encouraging and helpful throughout the process
- **Professional:** Maintain credibility while being accessible

### Communication Style
- Use "you" and "we" to create connection
- Avoid tax jargon; explain in plain English
- Lead with benefits, support with features
- Be specific with numbers and guarantees
- Always include clear next steps

---

## Color Palette

### Primary Colors

**Lawson Blue**
- Hex: #2563EB
- RGB: 37, 99, 235
- CMYK: 84, 58, 0, 8
- Usage: Primary brand color, CTAs, headers

**Lawson Navy**
- Hex: #1E40AF
- RGB: 30, 64, 175
- CMYK: 83, 63, 0, 31
- Usage: Text, secondary elements, depth

### Secondary Colors

**Success Green**
- Hex: #10B981
- RGB: 16, 185, 129
- CMYK: 91, 0, 30, 27
- Usage: Success states, positive messaging

**Warning Orange**
- Hex: #F59E0B
- RGB: 245, 158, 11
- CMYK: 0, 36, 95, 4
- Usage: Alerts, important notices

**Error Red**
- Hex: #EF4444
- RGB: 239, 68, 68
- CMYK: 0, 72, 72, 6
- Usage: Errors, urgent messaging

### Neutral Colors

**Charcoal**
- Hex: #374151
- RGB: 55, 65, 81
- CMYK: 32, 20, 0, 68
- Usage: Primary text, headings

**Medium Gray**
- Hex: #6B7280
- RGB: 107, 114, 128
- CMYK: 16, 11, 0, 50
- Usage: Secondary text, captions

**Light Gray**
- Hex: #F3F4F6
- RGB: 243, 244, 246
- CMYK: 1, 1, 0, 4
- Usage: Backgrounds, dividers

**Pure White**
- Hex: #FFFFFF
- RGB: 255, 255, 255
- CMYK: 0, 0, 0, 0
- Usage: Backgrounds, negative space

---

## Typography

### Primary Typeface: Inter
**Usage:** Headlines, UI elements, body text
**Characteristics:** Modern, clean, highly legible on screens
**Weights Available:** Light (300), Regular (400), Medium (500), Semibold (600), Bold (700)

**Headlines:** Inter Semibold (600) or Bold (700)
**Subheadings:** Inter Medium (500) or Semibold (600)
**Body Text:** Inter Regular (400)
**Captions:** Inter Regular (400) at smaller sizes
**UI Elements:** Inter Medium (500)

### Secondary Typeface: System Fonts
**Fallback Stack:** -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif
**Usage:** When Inter is unavailable

### Typography Scale
- **H1:** 48px / 3rem (Desktop), 36px / 2.25rem (Mobile)
- **H2:** 36px / 2.25rem (Desktop), 30px / 1.875rem (Mobile)
- **H3:** 30px / 1.875rem (Desktop), 24px / 1.5rem (Mobile)
- **H4:** 24px / 1.5rem (Desktop), 20px / 1.25rem (Mobile)
- **Body Large:** 18px / 1.125rem
- **Body Regular:** 16px / 1rem
- **Body Small:** 14px / 0.875rem
- **Caption:** 12px / 0.75rem

---

## Logo Guidelines

### Primary Logo
**Format:** Horizontal lockup with icon and wordmark
**Minimum Size:** 120px width (digital), 1 inch width (print)
**Clear Space:** Minimum 1x the height of the "L" in Lawson on all sides

### Logo Variations
1. **Full Color on White:** Primary usage
2. **Full Color on Dark:** For dark backgrounds
3. **White on Color:** For colored backgrounds
4. **Black on White:** Single color applications
5. **Icon Only:** When space is limited (minimum 32px)

### Logo Don'ts
- Don't stretch or distort the logo
- Don't change colors outside brand palette
- Don't add effects (shadows, gradients, etc.)
- Don't place on busy backgrounds without proper contrast
- Don't use outdated versions

---

## Iconography

### Style Guidelines
- **Style:** Outline icons with 2px stroke weight
- **Corner Radius:** 2px for consistency
- **Size:** 24px standard, scalable to 16px, 32px, 48px
- **Color:** Lawson Blue (#2563EB) or Charcoal (#374151)

### Core Icon Set
- Mobile phone (primary brand icon)
- Document/receipt
- Calculator
- Shield (security/protection)
- Checkmark (completion/success)
- Dollar sign (money/refunds)
- Clock (speed/efficiency)
- User (personal service)
- Upload/download arrows
- Star (quality/rating)

---

## Photography Style

### Style Direction
- **Authentic:** Real people in real situations
- **Diverse:** Represent our broad customer base
- **Mobile-Focused:** Show people using phones/tablets
- **Positive:** Happy, relaxed, confident expressions
- **Clean:** Uncluttered backgrounds, good lighting

### Color Treatment
- **Bright and Airy:** Well-lit, optimistic feeling
- **Color Grading:** Slightly warm tone, avoid oversaturation
- **Consistency:** Maintain consistent look across all images

### Subject Matter
- People using mobile devices
- Home office/remote work settings
- Families managing finances
- Small business owners
- Professional but approachable settings

---

## Illustration Style

### Characteristics
- **Modern:** Clean, contemporary aesthetic
- **Friendly:** Approachable and non-intimidating
- **Consistent:** Unified style across all illustrations
- **Purposeful:** Support messaging, don't distract

### Color Usage
- Primary: Lawson Blue and Navy
- Accents: Success Green, Light Gray
- Backgrounds: Light Gray, White

### Applications
- Process flows and diagrams
- Feature explanations
- Error states and empty states
- Onboarding illustrations

---

## UI/UX Guidelines

### Design Principles
1. **Mobile-First:** Design for mobile, enhance for desktop
2. **Accessibility:** WCAG 2.1 AA compliance minimum
3. **Clarity:** Clear hierarchy and intuitive navigation
4. **Efficiency:** Minimize steps and cognitive load
5. **Trust:** Professional appearance with security indicators

### Component Style
- **Buttons:** 8px border radius, medium font weight
- **Cards:** 12px border radius, subtle shadow
- **Forms:** Clear labels, helpful error messages
- **Navigation:** Simple, consistent patterns

### Spacing System
- **Base Unit:** 8px
- **Scale:** 8px, 16px, 24px, 32px, 48px, 64px, 96px
- **Consistent:** Use scale for all margins, padding, gaps

---

## Brand Applications

### Website
- Clean, modern design
- Mobile-responsive
- Fast loading times
- Clear conversion paths
- Trust indicators prominent

### Mobile App
- Native iOS/Android design patterns
- Consistent with brand colors
- Intuitive navigation
- Accessibility features
- Offline capabilities where appropriate

### Marketing Materials
- Consistent brand application
- Clear value propositions
- Professional photography
- Trust indicators
- Strong calls-to-action

### Email Communications
- Branded header/footer
- Consistent typography
- Mobile-optimized
- Clear hierarchy
- Professional tone

---

## Brand Voice Examples

### Headlines
✅ "Get Your Taxes Done Right, From Anywhere"
✅ "Maximum Refunds, Minimum Hassle"
✅ "Professional Tax Prep in Your Pocket"

❌ "Revolutionary Tax Solutions for the Modern Consumer"
❌ "Optimize Your Tax Strategy with Advanced Technology"
❌ "Comprehensive Tax Services for Discerning Clients"

### Body Copy
✅ "We know tax season can be stressful. That's why we've made it simple - just snap photos of your documents and we'll handle the rest."

❌ "Our proprietary algorithms leverage machine learning to optimize your tax preparation experience through streamlined workflows."

### Call-to-Actions
✅ "Start Your Tax Return"
✅ "Get Your Refund Faster"
✅ "See How Much You'll Save"

❌ "Initiate Tax Preparation Process"
❌ "Access Premium Tax Solutions"
❌ "Optimize Your Filing Strategy"

---

## Competitive Differentiation

### vs. TurboTax
- **Mobile-first** (not desktop-first)
- **Expert review included** (not optional)
- **Flat-rate pricing** (not tiered upselling)

### vs. H&R Block
- **Available 24/7** (not appointment-based)
- **Modern technology** (not outdated systems)
- **Transparent pricing** (not hidden fees)

### vs. Local CPAs
- **Affordable pricing** (not premium rates)
- **Instant availability** (not limited hours)
- **Modern experience** (not traditional office visits)

---

## Brand Guidelines Compliance

### Approval Process
1. All brand applications must be reviewed by marketing team
2. Major campaigns require brand manager approval
3. External vendors must receive brand guidelines
4. Regular audits to ensure compliance

### Common Mistakes to Avoid
- Using outdated logos or colors
- Inconsistent typography choices
- Poor contrast ratios
- Cluttered layouts
- Off-brand voice and tone

### Brand Asset Library
- Logos in all formats (SVG, PNG, PDF)
- Color swatches for design software
- Typography files and web fonts
- Icon library with usage guidelines
- Template library for common applications

---

## Contact Information

**Brand Manager:** [Name]  
**Email:** brand@lawsonmobiletax.com  
**Phone:** [Phone Number]  

**Asset Requests:** assets@lawsonmobiletax.com  
**Brand Questions:** brand@lawsonmobiletax.com  
**Partnership Inquiries:** partnerships@lawsonmobiletax.com  

---

*Brand Guidelines Version 1.0*  
*Last Updated: August 22, 2025*  
*© 2025 Lawson Mobile Tax. All rights reserved.*
