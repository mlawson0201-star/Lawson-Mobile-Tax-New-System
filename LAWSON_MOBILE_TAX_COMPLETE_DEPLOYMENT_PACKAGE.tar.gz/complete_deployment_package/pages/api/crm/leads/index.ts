
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { createSyncService } from '@/lib/gohighlevel/sync';
import { triggerLeadCreated, triggerLeadStatusChanged } from '@/lib/crm/automation';
import { LeadStatus, LeadSource } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'GET':
      return handleGetLeads(req, res, tenantId);
    case 'POST':
      return handleCreateLead(req, res, tenantId, session.user.id);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetLeads(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const {
      page = '1',
      limit = '20',
      status,
      source,
      assignedTo,
      search,
      sortBy = 'created_at',
      sortOrder = 'desc',
    } = req.query;

    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // Build where clause
    const where: any = { tenant_id: tenantId };
    
    if (status) where.status = status;
    if (source) where.source = source;
    if (assignedTo) where.assigned_to = assignedTo;
    
    if (search) {
      where.OR = [
        { first_name: { contains: search as string, mode: 'insensitive' } },
        { last_name: { contains: search as string, mode: 'insensitive' } },
        { email: { contains: search as string, mode: 'insensitive' } },
        { company: { contains: search as string, mode: 'insensitive' } },
      ];
    }

    const [leads, total] = await Promise.all([
      prisma.crm_leads.findMany({
        where,
        include: {
          assigned_user: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
          pipeline_stage: {
            select: { id: true, name: true, color: true, probability: true },
          },
          _count: {
            select: {
              communication_logs: true,
              tasks: true,
              appointments: true,
            },
          },
        },
        orderBy: { [sortBy as string]: sortOrder },
        skip: offset,
        take: limitNum,
      }),
      prisma.crm_leads.count({ where }),
    ]);

    const totalPages = Math.ceil(total / limitNum);

    res.status(200).json({
      leads,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1,
      },
    });
  } catch (error) {
    console.error('Error fetching leads:', error);
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
}

async function handleCreateLead(req: NextApiRequest, res: NextApiResponse, tenantId: string, userId: string) {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      company,
      jobTitle,
      source = LeadSource.WEBSITE,
      estimatedValue,
      expectedCloseDate,
      assignedTo,
      pipelineStageId,
      tags = [],
      customFields = {},
      notes,
      syncToGoHighLevel = true,
    } = req.body;

    // Validate required fields
    if (!firstName || !lastName || !email) {
      return res.status(400).json({ error: 'First name, last name, and email are required' });
    }

    // Check if lead with email already exists
    const existingLead = await prisma.crm_leads.findFirst({
      where: { tenant_id: tenantId, email },
    });

    if (existingLead) {
      return res.status(409).json({ error: 'Lead with this email already exists' });
    }

    // Get default pipeline stage if not provided
    let stageId = pipelineStageId;
    if (!stageId) {
      const defaultStage = await prisma.crm_pipeline_stages.findFirst({
        where: { tenant_id: tenantId, order_index: 1 },
      });
      stageId = defaultStage?.id;
    }

    // Create lead
    const lead = await prisma.crm_leads.create({
      data: {
        tenant_id: tenantId,
        first_name: firstName,
        last_name: lastName,
        email,
        phone,
        company,
        job_title: jobTitle,
        source,
        estimated_value: estimatedValue ? parseFloat(estimatedValue) : null,
        expected_close_date: expectedCloseDate ? new Date(expectedCloseDate) : null,
        assigned_to: assignedTo || userId,
        pipeline_stage_id: stageId,
        tags,
        custom_fields: customFields,
        notes,
        status: LeadStatus.NEW,
      },
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        pipeline_stage: {
          select: { id: true, name: true, color: true, probability: true },
        },
      },
    });

    // Sync to GoHighLevel if enabled
    if (syncToGoHighLevel) {
      try {
        const syncService = createSyncService(tenantId);
        await syncService.pushLeadToGoHighLevel(lead.id);
      } catch (error) {
        console.error('Error syncing lead to GoHighLevel:', error);
        // Don't fail the request if sync fails
      }
    }

    // Trigger automation
    try {
      await triggerLeadCreated(tenantId, lead.id);
    } catch (error) {
      console.error('Error triggering lead created automation:', error);
    }

    res.status(201).json({ lead });
  } catch (error) {
    console.error('Error creating lead:', error);
    res.status(500).json({ error: 'Failed to create lead' });
  }
}
