
export interface ClientPersona {
  id: string;
  type: 'w2_employee' | 'small_business' | 'investor' | 'retiree' | 'freelancer';
  name: string;
  description: string;
  painPoints: string[];
  preferences: {
    communicationChannel: 'email' | 'sms' | 'phone' | 'app';
    complexity: 'simple' | 'moderate' | 'advanced';
    timing: 'immediate' | 'scheduled' | 'flexible';
  };
  demographics: {
    ageRange: string;
    incomeRange: string;
    location: string;
  };
}

export interface LeadMagnet {
  id: string;
  title: string;
  description: string;
  type: 'checklist' | 'calculator' | 'guide' | 'template' | 'video';
  targetPersonas: string[];
  downloadUrl: string;
  conversionRate: number;
  createdAt: Date;
}

export interface LandingPageVariant {
  id: string;
  name: string;
  headline: string;
  subheadline: string;
  ctaText: string;
  ctaColor: string;
  heroImage: string;
  testimonials: Testimonial[];
  features: string[];
  conversionRate: number;
  isActive: boolean;
}

export interface ABTest {
  id: string;
  name: string;
  description: string;
  variants: LandingPageVariant[];
  trafficSplit: number[];
  startDate: Date;
  endDate?: Date;
  status: 'draft' | 'running' | 'completed' | 'paused';
  metrics: {
    visitors: number;
    conversions: number;
    conversionRate: number;
    confidenceLevel: number;
  };
}

export interface Testimonial {
  id: string;
  clientName: string;
  clientTitle?: string;
  content: string;
  rating: number;
  videoUrl?: string;
  imageUrl?: string;
  tags: string[];
  isVerified: boolean;
  createdAt: Date;
}

export interface ReferralProgram {
  id: string;
  name: string;
  description: string;
  rewardType: 'cash' | 'credit' | 'discount' | 'points';
  rewardAmount: number;
  referrerReward: number;
  refereeReward: number;
  minimumPurchase?: number;
  expirationDays?: number;
  isActive: boolean;
  rules: string[];
}

export interface Referral {
  id: string;
  referrerId: string;
  refereeId?: string;
  referralCode: string;
  status: 'pending' | 'completed' | 'rewarded' | 'expired';
  clickCount: number;
  conversionDate?: Date;
  rewardAmount: number;
  createdAt: Date;
}
