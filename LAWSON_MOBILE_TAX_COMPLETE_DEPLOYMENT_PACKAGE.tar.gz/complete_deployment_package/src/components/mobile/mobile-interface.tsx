
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Camera,
  Mic,
  MicOff,
  Upload,
  Send,
  FileText,
  CheckCircle,
  AlertCircle,
  Phone,
  MessageCircle,
  Bell,
  User,
  Home,
  Calculator,
  Settings,
  Menu,
  X,
} from 'lucide-react';

interface MobileInterfaceProps {
  user: any;
  onVoiceUpload?: (audioBlob: Blob) => void;
  onDocumentCapture?: (imageFile: File) => void;
  onStartChat?: () => void;
}

export function MobileInterface({ 
  user, 
  onVoiceUpload, 
  onDocumentCapture, 
  onStartChat 
}: MobileInterfaceProps) {
  const [activeTab, setActiveTab] = useState('home');
  const [isRecording, setIsRecording] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/mobile/push-notifications');
      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications?.slice(0, 5) || []);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        onVoiceUpload?.(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } // Use back camera
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setShowCamera(true);
      }
    } catch (error) {
      console.error('Error starting camera:', error);
    }
  };

  const captureDocument = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context?.drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], 'document-capture.jpg', { type: 'image/jpeg' });
          onDocumentCapture?.(file);
        }
      }, 'image/jpeg', 0.9);
      
      stopCamera();
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
  };

  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'documents', icon: FileText, label: 'Documents' },
    { id: 'calculator', icon: Calculator, label: 'Calculator' },
    { id: 'chat', icon: MessageCircle, label: 'Chat' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-4 py-3 flex items-center justify-between">
        <button 
          onClick={() => setSidebarOpen(true)}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <Menu className="h-6 w-6 text-gray-600" />
        </button>
        
        <h1 className="text-lg font-semibold text-gray-900">Lawson Mobile Tax</h1>
        
        <div className="relative">
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
            <Bell className="h-6 w-6 text-gray-600" />
            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {notifications.length}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {activeTab === 'home' && (
              <div className="p-4 space-y-6">
                {/* Welcome Section */}
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
                  <h2 className="text-xl font-bold mb-2">Welcome back, {user?.name?.split(' ')[0]}!</h2>
                  <p className="opacity-90">Your tax return is 75% complete</p>
                  <div className="w-full bg-white/20 rounded-full h-2 mt-3">
                    <div className="bg-white h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <motion.button
                      onClick={startCamera}
                      className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col items-center space-y-3 hover:shadow-md transition-shadow"
                      whileTap={{ scale: 0.95 }}
                    >
                      <Camera className="h-8 w-8 text-blue-600" />
                      <span className="font-medium text-gray-900">Scan Document</span>
                    </motion.button>

                    <motion.button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`p-6 rounded-xl shadow-sm border flex flex-col items-center space-y-3 hover:shadow-md transition-shadow ${
                        isRecording 
                          ? 'bg-red-50 border-red-200' 
                          : 'bg-white border-gray-200'
                      }`}
                      whileTap={{ scale: 0.95 }}
                    >
                      {isRecording ? (
                        <MicOff className="h-8 w-8 text-red-600" />
                      ) : (
                        <Mic className="h-8 w-8 text-green-600" />
                      )}
                      <span className="font-medium text-gray-900">
                        {isRecording ? 'Stop Recording' : 'Voice Note'}
                      </span>
                    </motion.button>

                    <motion.button
                      onClick={onStartChat}
                      className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col items-center space-y-3 hover:shadow-md transition-shadow"
                      whileTap={{ scale: 0.95 }}
                    >
                      <MessageCircle className="h-8 w-8 text-purple-600" />
                      <span className="font-medium text-gray-900">Live Chat</span>
                    </motion.button>

                    <motion.button
                      className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col items-center space-y-3 hover:shadow-md transition-shadow"
                      whileTap={{ scale: 0.95 }}
                    >
                      <Calculator className="h-8 w-8 text-orange-600" />
                      <span className="font-medium text-gray-900">Refund Calc</span>
                    </motion.button>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                  <div className="space-y-3">
                    {[
                      { icon: CheckCircle, text: 'W2 processed successfully', time: '2 hours ago', color: 'text-green-600' },
                      { icon: AlertCircle, text: 'Missing 1099 form', time: '1 day ago', color: 'text-orange-600' },
                      { icon: FileText, text: 'Tax return updated', time: '2 days ago', color: 'text-blue-600' },
                    ].map((activity, index) => (
                      <motion.div
                        key={index}
                        className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex items-center space-x-3"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <activity.icon className={`h-5 w-5 ${activity.color}`} />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{activity.text}</p>
                          <p className="text-sm text-gray-500">{activity.time}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'documents' && (
              <div className="p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Documents</h2>
                {/* Document management interface */}
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Document management interface</p>
                </div>
              </div>
            )}

            {activeTab === 'calculator' && (
              <div className="p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Refund Calculator</h2>
                {/* Calculator interface */}
                <div className="text-center py-12">
                  <Calculator className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Refund calculator interface</p>
                </div>
              </div>
            )}

            {activeTab === 'chat' && (
              <div className="p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Live Chat</h2>
                {/* Chat interface */}
                <div className="text-center py-12">
                  <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Live chat interface</p>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Profile</h2>
                {/* Profile interface */}
                <div className="text-center py-12">
                  <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Profile management interface</p>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Camera Modal */}
      <AnimatePresence>
        {showCamera && (
          <motion.div
            className="fixed inset-0 bg-black z-50 flex flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="flex-1 relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              <canvas ref={canvasRef} className="hidden" />
              
              <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
                <button
                  onClick={stopCamera}
                  className="p-3 bg-black/50 rounded-full backdrop-blur-sm"
                >
                  <X className="h-6 w-6 text-white" />
                </button>
                <div className="text-white font-medium">Position document in frame</div>
                <div></div>
              </div>
              
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
                <motion.button
                  onClick={captureDocument}
                  className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg"
                  whileTap={{ scale: 0.9 }}
                >
                  <Camera className="h-8 w-8 text-gray-900" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t px-2 py-1">
        <div className="flex items-center justify-around">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`p-3 rounded-lg flex flex-col items-center space-y-1 transition-colors ${
                activeTab === tab.id
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
            />
            <motion.div
              className="fixed top-0 left-0 h-full w-80 bg-white z-50 shadow-xl"
              initial={{ x: -320 }}
              animate={{ x: 0 }}
              exit={{ x: -320 }}
              transition={{ type: 'tween', duration: 0.3 }}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900">Menu</h2>
                  <button
                    onClick={() => setSidebarOpen(false)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <X className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium">
                        {user?.name?.charAt(0) || 'U'}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{user?.name}</p>
                      <p className="text-sm text-gray-500">{user?.email}</p>
                    </div>
                  </div>
                  
                  {/* Sidebar menu items would go here */}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
