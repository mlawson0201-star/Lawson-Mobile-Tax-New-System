
"""
LinkedIn adapter using Posts API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class LinkedInAdapter(BasePlatformAdapter):
    """Adapter for LinkedIn using Posts API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.person_id = credentials.get('person_id')  # LinkedIn person URN
        self.organization_id = credentials.get('organization_id')  # For company pages
        self.base_url = "https://api.linkedin.com"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            url = f"{self.base_url}/v2/userinfo"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                user_info = response.json()
                logger.info(f"Authenticated as: {user_info.get('name')}")
                return True
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post content to LinkedIn"""
        try:
            # Determine author (person or organization)
            is_company_post = kwargs.get('is_company_post', False)
            if is_company_post and self.organization_id:
                author_urn = f"urn:li:organization:{self.organization_id}"
            else:
                author_urn = f"urn:li:person:{self.person_id}"
            
            # Format content with hashtags
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content}\n\n{hashtag_text}"
            
            # LinkedIn allows up to 3000 characters
            full_content = self.validate_content_length(full_content, 3000)
            
            url = f"{self.base_url}/rest/posts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json',
                'LinkedIn-Version': '202506',
                'X-Restli-Protocol-Version': '2.0.0'
            }
            
            post_data = {
                "author": author_urn,
                "commentary": full_content,
                "visibility": "PUBLIC",
                "distribution": {
                    "feedDistribution": "MAIN_FEED"
                },
                "lifecycleState": "PUBLISHED"
            }
            
            # Handle media if provided
            if media_urls and len(media_urls) > 0:
                # For LinkedIn, we need to upload media first and get media URN
                # This is a simplified version - implement proper media upload
                media_urn = await self._upload_media(media_urls[0])
                if media_urn:
                    post_data["content"] = {
                        "media": {
                            "id": media_urn
                        }
                    }
            
            # Handle article sharing
            article_url = kwargs.get('article_url')
            if article_url:
                post_data["content"] = {
                    "article": {
                        "source": article_url,
                        "title": kwargs.get('article_title', ''),
                        "description": kwargs.get('article_description', '')
                    }
                }
            
            response = requests.post(url, headers=headers, json=post_data)
            
            if response.status_code == 201:
                # LinkedIn returns the post URN in the x-restli-id header
                post_urn = response.headers.get('x-restli-id')
                return {
                    "success": True,
                    "post_id": post_urn,
                    "platform_response": {"post_urn": post_urn}
                }
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('message', f'HTTP {response.status_code}')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            logger.error(f"Error posting to LinkedIn: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def _upload_media(self, media_url: str) -> Optional[str]:
        """Upload media to LinkedIn and return media URN"""
        try:
            # This is a placeholder - implement actual media upload
            # LinkedIn media upload involves multiple steps:
            # 1. Register upload
            # 2. Upload binary data
            # 3. Get media URN
            logger.warning("Media upload not fully implemented for LinkedIn")
            return None
            
        except Exception as e:
            logger.error(f"Media upload error: {str(e)}")
            return None
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a LinkedIn post"""
        try:
            # LinkedIn doesn't support native scheduling via API
            # This would need to be handled by our own scheduling system
            
            return {
                "success": True,
                "message": "LinkedIn post scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "LinkedIn API doesn't support native scheduling"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a LinkedIn post"""
        try:
            # Extract post URN from post_id if needed
            if not post_id.startswith('urn:li:'):
                post_urn = f"urn:li:share:{post_id}"
            else:
                post_urn = post_id
            
            # Get post details
            url = f"{self.base_url}/rest/posts/{post_urn}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'LinkedIn-Version': '202506',
                'X-Restli-Protocol-Version': '2.0.0'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                post_data = response.json()
                
                # Get social actions (likes, comments, shares)
                social_url = f"{self.base_url}/rest/socialActions/{post_urn}"
                social_response = requests.get(social_url, headers=headers)
                
                social_data = {}
                if social_response.status_code == 200:
                    social_data = social_response.json()
                
                analytics = {
                    "post_id": post_id,
                    "likes": social_data.get('likesSummary', {}).get('totalLikes', 0),
                    "comments": social_data.get('commentsSummary', {}).get('totalComments', 0),
                    "shares": social_data.get('sharesSummary', {}).get('totalShares', 0),
                    "created_time": post_data.get('createdAt'),
                    "commentary": post_data.get('commentary', '')
                }
                
                return {"success": True, "analytics": analytics}
            else:
                error_msg = f"Failed to get post analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a LinkedIn post"""
        try:
            if not post_id.startswith('urn:li:'):
                post_urn = f"urn:li:share:{post_id}"
            else:
                post_urn = post_id
            
            url = f"{self.base_url}/rest/posts/{post_urn}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'LinkedIn-Version': '202506',
                'X-Restli-Protocol-Version': '2.0.0'
            }
            
            response = requests.delete(url, headers=headers)
            return response.status_code == 204
            
        except Exception as e:
            logger.error(f"Error deleting LinkedIn post: {str(e)}")
            return False
    
    async def post_article(self, title: str, content: str, **kwargs) -> Dict[str, Any]:
        """Post a LinkedIn article"""
        try:
            # LinkedIn articles are posted differently than regular posts
            # This is a placeholder for article posting functionality
            
            return {
                "success": False,
                "error": "LinkedIn article posting not implemented yet",
                "note": "Use regular posts with article links instead"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
