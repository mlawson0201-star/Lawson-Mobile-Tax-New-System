
# UGC Video Scripts - Lawson Mobile Tax

## Video 1: "The Mobile Tax Revolution" (60 seconds)

### Hook (0-3 seconds)
**[Person looking frustrated at laptop with papers scattered]**
"Ugh, I hate tax season..."

### Problem Setup (3-15 seconds)
**[Quick cuts of traditional tax prep pain points]**
- Waiting in line at tax office
- Complicated software on computer
- Stack of receipts and forms
- Person looking confused and stressed

**Voiceover:** "Every year, the same nightmare. Complicated software, endless forms, and hours of my life I'll never get back."

### Solution Introduction (15-30 seconds)
**[Person picks up phone, opens Lawson Mobile Tax app]**
"Then I discovered Lawson Mobile Tax."

**[Screen recording of app in action]**
- Clean, simple interface
- Camera scanning W-2 form
- Information auto-populating
- Progress bar showing completion

**Voiceover:** "I literally did my entire tax return on my phone. Just snap photos of my documents, and their AI does the rest."

### Benefits Showcase (30-45 seconds)
**[Split screen: Traditional vs. Mobile]**

Traditional side:
- Person at desk for hours
- Frustrated expressions
- Piles of paperwork

Mobile side:
- Person on couch, relaxed
- Doing taxes during coffee break
- Smiling while using phone

**Voiceover:** "No more sitting at a desk for hours. I did mine during lunch breaks and finished in 20 minutes total."

### Results & CTA (45-60 seconds)
**[Person showing phone with refund amount]**
"And I got $800 more back than last year!"

**[App download screen]**
"Download Lawson Mobile Tax and join the mobile revolution. Your future self will thank you."

**Text overlay:** "Get Started - $485 | Maximum Refund Guaranteed"

---

## Video 2: "Real Client Success Story - Sarah" (45 seconds)

### Introduction (0-5 seconds)
**[Sarah speaking directly to camera in her home office]**
"Hi, I'm Sarah, and I want to tell you about my experience with Lawson Mobile Tax."

### Background (5-15 seconds)
**[B-roll of Sarah working, family photos]**
"I'm a working mom with two kids and a side business. Tax time used to be a nightmare."

### Previous Experience (15-25 seconds)
**[Recreated scenes of frustration]**
"I'd spend entire weekends trying to figure out TurboTax, missing deductions, and still worrying I did something wrong."

### Lawson Experience (25-35 seconds)
**[Sarah using the app on her phone]**
"With Lawson Mobile Tax, I literally did my taxes while my kids were at soccer practice. The app walked me through everything, and a real tax professional reviewed my return."

### Results (35-45 seconds)
**[Sarah smiling, showing phone screen]**
"I got $1,200 more back than last year, and it was filed the next day. This is the only way I'm doing taxes from now on."

**Text overlay:** "Try Lawson Mobile Tax - Maximum Refund Guaranteed"

---

## Video 3: "Business Owner Testimonial - Mike" (50 seconds)

### Hook (0-5 seconds)
**[Mike in his workshop/office]**
"As a small business owner, taxes used to terrify me."

### Problem (5-20 seconds)
**[B-roll of business operations, receipts, paperwork]**
"Between my W-2 job and my side business, I had receipts everywhere, multiple income sources, and no idea what I could deduct."

**[Mike looking stressed at computer]**
"I tried doing it myself and missed thousands in deductions. Then I tried a local CPA who charged me $800 and took three weeks."

### Solution (20-35 seconds)
**[Mike using Lawson Mobile Tax app]**
"Lawson Mobile Tax changed everything. I uploaded photos of all my receipts, answered some questions about my business, and their AI organized everything perfectly."

**[Screen showing business deductions being calculated]**
"They found deductions I didn't even know existed - home office, business meals, equipment depreciation."

### Results (35-50 seconds)
**[Mike smiling, showing results on phone]**
"I saved $2,400 in taxes and got my return filed in 24 hours. For $485, I got better service than my $800 CPA."

**Text overlay:** "Business Returns Starting at $634 | Expert Review Included"

---

## Video 4: "Speed Comparison" (30 seconds)

### Setup (0-5 seconds)
**[Split screen setup]**
"Let's see how fast you can really do your taxes."

### Traditional Method (5-15 seconds)
**[Left side: Person with TurboTax on computer]**
- Opening software
- Creating account
- Manually typing W-2 information
- Looking confused at questions
- Clock showing 2+ hours passing

**Text overlay:** "Traditional Software: 2+ Hours"

### Lawson Mobile Tax (15-25 seconds)
**[Right side: Person with Lawson app on phone]**
- Opening app
- Taking photo of W-2
- Information auto-populating
- Quick questions answered
- Return completed

**Text overlay:** "Lawson Mobile Tax: 15 Minutes"

### Results (25-30 seconds)
**[Both people showing completed returns]**
"Same accuracy, same refund, 8x faster."

**Text overlay:** "Start Your 15-Minute Tax Return"

---

## Video 5: "AI Document Processing Demo" (40 seconds)

### Hook (0-5 seconds)
**[Person holding stack of tax documents]**
"Tired of typing all this information manually?"

### Problem (5-15 seconds)
**[Time-lapse of person manually entering data]**
"The average person spends 2 hours just entering information from their tax documents."

### Solution Demo (15-30 seconds)
**[Close-up of phone camera scanning documents]**
"Watch this."

**[Screen recording showing:]**
- Camera pointing at W-2
- Information being extracted in real-time
- Fields auto-populating
- Multiple documents processed quickly

**Voiceover:** "Lawson Mobile Tax's AI reads your documents instantly. No typing, no mistakes, no hassle."

### Results (30-40 seconds)
**[Person relaxing while app works]**
"What used to take hours now takes minutes. That's the power of AI working for you."

**Text overlay:** "Experience AI-Powered Tax Prep"

---

## Video 6: "Expert Review Process" (45 seconds)

### Concern (0-10 seconds)
**[Person looking worried]**
"I love the convenience of mobile tax prep, but what about accuracy? What if I make a mistake?"

### Solution Introduction (10-20 seconds)
**[Professional tax office setting]**
"That's why every Lawson Mobile Tax return is reviewed by licensed tax professionals."

### Behind the Scenes (20-35 seconds)
**[B-roll of tax professionals working]**
- CPA reviewing returns on computer
- EA checking calculations
- Professional making notes
- Quality assurance process

**Voiceover:** "IRS-enrolled agents and CPAs with years of experience review every single return before it's filed."

### Guarantee (35-45 seconds)
**[Person smiling with phone showing filed return]**
"Mobile convenience with professional expertise. That's why we can guarantee maximum refunds and provide audit defense."

**Text overlay:** "Expert Review Included | 99.7% Accuracy Rate"

---

## Video 7: "Refund Comparison" (35 seconds)

### Setup (0-5 seconds)
**[Person holding two phones]**
"I did my taxes two different ways to see which got me more money back."

### Method 1 (5-15 seconds)
**[Using competitor app]**
"First, I used [Competitor] and got a $1,800 refund."

### Method 2 (15-25 seconds)
**[Using Lawson Mobile Tax]**
"Then I tried Lawson Mobile Tax with the same exact information."

### Results (25-35 seconds)
**[Showing both results side by side]**
"Lawson found $600 more in deductions I missed. That's $600 extra in my pocket!"

**Text overlay:** "Maximum Refund Guarantee | Find Money Others Miss"

---

## Video 8: "Audit Defense Story" (55 seconds)

### Hook (0-5 seconds)
**[Person looking worried, holding IRS letter]**
"Getting audited was my worst nightmare..."

### The Situation (5-20 seconds)
**[Recreated scene of receiving audit notice]**
"Two years ago, I got a letter from the IRS. They wanted to audit my 2022 return that I filed with Lawson Mobile Tax."

**[Person looking panicked]**
"I was terrified. I had no idea what to do."

### Lawson's Response (20-40 seconds)
**[Professional office setting, person on phone]**
"I called Lawson Mobile Tax, and they immediately assigned me a tax professional who specialized in audits."

**[B-roll of professional handling paperwork]**
"They handled everything - all the correspondence, gathered the documents, even represented me at the IRS meeting."

### Resolution (40-55 seconds)
**[Person smiling, relieved]**
"Not only did they resolve everything, but they actually got me an additional $300 refund the IRS owed me!"

**[Text overlay showing audit defense included]**
"The best part? This was all included at no extra cost. Audit defense comes with every return."

**Text overlay:** "Audit Defense Included | Full IRS Representation"

---

## Video 9: "Mobile vs. Desktop Experience" (40 seconds)

### Traditional Desktop (0-20 seconds)
**[Person hunched over laptop at desk]**
"This is how I used to do my taxes."

**[Showing frustrations:]**
- Squinting at small text
- Scrolling through long forms
- Getting up to find documents
- Looking tired and frustrated

**Voiceover:** "Stuck at my desk for hours, straining my eyes, and feeling overwhelmed."

### Mobile Experience (20-35 seconds)
**[Same person, now relaxed with phone]**
"This is how I do them now."

**[Showing mobile benefits:]**
- Doing taxes on couch
- Large, clear text on phone
- Easy photo capture
- Completing during commute

**Voiceover:** "Anywhere, anytime, on my terms."

### Conclusion (35-40 seconds)
**[Person smiling with completed return]**
"Same result, better experience. Why would I go back?"

**Text overlay:** "Mobile-First Tax Preparation"

---

## Video 10: "Price Comparison" (45 seconds)

### Setup (0-5 seconds)
**[Person with calculator and receipts]**
"Let me break down the real cost of tax preparation."

### Traditional CPA (5-15 seconds)
**[Professional office setting]**
"Local CPA: $600-$1,200 for a basic return, plus you have to take time off work for appointments."

### Big Box Store (15-25 seconds)
**[H&R Block storefront]**
"H&R Block: $300-$500, but with hidden fees and upselling. Plus waiting in line for hours."

### DIY Software (25-35 seconds)
**[Computer screen with TurboTax]**
"TurboTax: Starts at $60 but ends up costing $200+ with state filing and premium features. And you do all the work."

### Lawson Mobile Tax (35-45 seconds)
**[Phone showing Lawson app]**
"Lawson Mobile Tax: $485 flat rate. Everything included - expert review, audit defense, state filing, mobile convenience."

**Text overlay:** "Best Value | No Hidden Fees | Everything Included"

---

## Production Notes

### General Guidelines:
- **Vertical Format:** All videos optimized for mobile viewing (9:16 aspect ratio)
- **Captions:** Include closed captions for accessibility and silent viewing
- **Branding:** Consistent use of Lawson Mobile Tax colors and logo
- **Call-to-Action:** Clear, actionable CTAs in every video
- **Authenticity:** Use real clients when possible, authentic settings

### Technical Specs:
- **Resolution:** 1080x1920 (vertical)
- **Frame Rate:** 30fps
- **Audio:** Clear, professional audio with background music
- **Length:** 30-60 seconds for optimal engagement
- **File Format:** MP4 for universal compatibility

### Distribution Strategy:
- **Primary:** TikTok, Instagram Reels, YouTube Shorts
- **Secondary:** Facebook, Twitter, LinkedIn
- **Paid Promotion:** Boost top-performing videos with targeted ads
- **Organic:** Encourage clients to share their own experiences

### Performance Metrics:
- **Engagement Rate:** Target 5%+ engagement
- **Completion Rate:** Aim for 70%+ completion
- **Click-Through Rate:** Target 2%+ to landing page
- **Conversion Rate:** Track app downloads and sign-ups

---

*All scripts include provisions for A/B testing different hooks, CTAs, and messaging to optimize performance.*
