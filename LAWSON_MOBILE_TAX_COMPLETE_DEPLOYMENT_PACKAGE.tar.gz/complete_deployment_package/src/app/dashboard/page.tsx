
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { getCurrentTenant } from '@/lib/tenant';
import { DashboardLayout } from '@/components/dashboard/dashboard-layout';
import { SuperAdminDashboard } from '@/components/dashboard/super-admin-dashboard';
import { TenantAdminDashboard } from '@/components/dashboard/tenant-admin-dashboard';
import { EACPADashboard } from '@/components/dashboard/ea-cpa-dashboard';
import { PreparerDashboard } from '@/components/dashboard/preparer-dashboard';
import { ClientDashboard } from '@/components/dashboard/client-dashboard';
// Force dynamic rendering
export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/auth/signin');
  }

  const tenant = await getCurrentTenant();

  const renderDashboard = () => {
    switch (session.user.roles?.[0] || 'client') {
      case 'super_admin':
        return <SuperAdminDashboard />;
      case 'tenant_admin':
        return <TenantAdminDashboard />;
      case 'ea_cpa':
        return <EACPADashboard />;
      case 'preparer':
        return <PreparerDashboard />;
      case 'client':
        return <ClientDashboard />;
      default:
        return <ClientDashboard />;
    }
  };

  return (
    <DashboardLayout tenant={tenant}>
      {renderDashboard()}
    </DashboardLayout>
  );
}
