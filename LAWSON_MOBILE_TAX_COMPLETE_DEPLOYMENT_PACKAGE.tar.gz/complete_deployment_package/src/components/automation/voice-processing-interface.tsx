
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Mic, 
  Square, 
  Play, 
  Upload, 
  FileAudio, 
  Bot,
  CheckCircle,
  AlertCircle,
  Download,
  VolumeX
} from 'lucide-react';

interface VoiceProcessingResult {
  status: string;
  result?: any;
  processingMetrics?: {
    transcriptionLength: number;
    dataPointsExtracted: number;
    automationActionsCount: number;
    confidenceScore: number;
  };
}

export default function VoiceProcessingInterface() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const [processingResult, setProcessingResult] = useState<VoiceProcessingResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [clientId, setClientId] = useState('');
  const [documentType, setDocumentType] = useState('general');

  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const audioPlayer = useRef<HTMLAudioElement | null>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);

  const documentTypes = [
    { value: 'general', label: 'General Tax Discussion' },
    { value: 'w2_review', label: 'W-2 Form Review' },
    { value: 'business_expenses', label: 'Business Expense Discussion' },
    { value: 'deduction_interview', label: 'Deduction Interview' },
    { value: 'client_intake', label: 'Client Intake Interview' },
    { value: 'tax_planning', label: 'Tax Planning Session' },
    { value: 'document_explanation', label: 'Document Explanation' }
  ];

  useEffect(() => {
    return () => {
      if (recordingInterval.current) {
        clearInterval(recordingInterval.current);
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];

      mediaRecorder.current.ondataavailable = (event) => {
        audioChunks.current.push(event.data);
      };

      mediaRecorder.current.onstop = () => {
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/wav' });
        setRecordedAudio(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.current.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      recordingInterval.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder.current && isRecording) {
      mediaRecorder.current.stop();
      setIsRecording(false);
      if (recordingInterval.current) {
        clearInterval(recordingInterval.current);
      }
    }
  };

  const playRecording = () => {
    if (recordedAudio && audioPlayer.current) {
      if (isPlaying) {
        audioPlayer.current.pause();
        setIsPlaying(false);
      } else {
        const audioUrl = URL.createObjectURL(recordedAudio);
        audioPlayer.current.src = audioUrl;
        audioPlayer.current.play();
        setIsPlaying(true);
        
        audioPlayer.current.onended = () => {
          setIsPlaying(false);
          URL.revokeObjectURL(audioUrl);
        };
      }
    }
  };

  const processVoiceData = async () => {
    if (!recordedAudio || !clientId) return;

    setIsProcessing(true);
    
    const formData = new FormData();
    formData.append('audio', recordedAudio, 'recording.wav');
    formData.append('clientId', clientId);
    formData.append('documentType', documentType);
    formData.append('processingType', 'full_analysis');

    try {
      const response = await fetch('/api/automation/voice-document-processing', {
        method: 'POST',
        body: formData,
      });

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let partialRead = '';

      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined };
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        let lines = partialRead.split('\n');
        partialRead = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.status === 'completed') {
                setProcessingResult(parsed);
                setIsProcessing(false);
                return;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Voice processing error:', error);
      setIsProcessing(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      setRecordedAudio(file);
      setRecordingTime(0);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <Mic className="h-12 w-12 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Voice-Activated Tax Processing</h1>
        <p className="text-lg text-gray-600 mt-2">
          AI-powered speech-to-text tax data extraction and client interaction
        </p>
      </div>

      {/* Settings */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Processing Settings</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Client ID
            </label>
            <input
              type="text"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              placeholder="Enter client ID"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Document Type
            </label>
            <select
              value={documentType}
              onChange={(e) => setDocumentType(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {documentTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Recording Interface */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div className="text-center space-y-6">
          <h2 className="text-xl font-semibold text-gray-900">Voice Recording</h2>
          
          {/* Recording Controls */}
          <div className="flex items-center justify-center space-x-6">
            {!isRecording ? (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={startRecording}
                className="flex items-center justify-center w-16 h-16 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
              >
                <Mic className="h-6 w-6" />
              </motion.button>
            ) : (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={stopRecording}
                className="flex items-center justify-center w-16 h-16 bg-gray-500 text-white rounded-full hover:bg-gray-600 transition-colors animate-pulse"
              >
                <Square className="h-6 w-6" />
              </motion.button>
            )}

            {recordedAudio && !isRecording && (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={playRecording}
                className="flex items-center justify-center w-12 h-12 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors"
              >
                {isPlaying ? (
                  <VolumeX className="h-5 w-5" />
                ) : (
                  <Play className="h-5 w-5" />
                )}
              </motion.button>
            )}
          </div>

          {/* Recording Status */}
          <div className="space-y-2">
            {isRecording && (
              <div className="flex items-center justify-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-red-600 font-medium">
                  Recording... {formatTime(recordingTime)}
                </span>
              </div>
            )}
            
            {recordedAudio && !isRecording && (
              <div className="flex items-center justify-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm text-green-600">
                  Recording complete ({formatTime(recordingTime)})
                </span>
              </div>
            )}
          </div>

          {/* File Upload Option */}
          <div className="border-t pt-6">
            <p className="text-sm text-gray-600 mb-4">Or upload an audio file</p>
            <label className="cursor-pointer inline-flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Upload className="h-4 w-4" />
              <span>Upload Audio File</span>
              <input
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Process Button */}
          {recordedAudio && clientId && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={processVoiceData}
              disabled={isProcessing}
              className="flex items-center space-x-2 px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-lg font-medium"
            >
              <Bot className="h-5 w-5" />
              <span>{isProcessing ? 'Processing...' : 'Process Voice Data'}</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* Processing Results */}
      {isProcessing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Processing Voice Data
          </h2>
          <p className="text-gray-600">
            Converting speech to text and extracting tax information...
          </p>
        </motion.div>
      )}

      {processingResult && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Results Header */}
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div>
                <h2 className="text-xl font-semibold text-green-900">
                  Voice Processing Complete
                </h2>
                <p className="text-green-700">
                  Confidence: {((processingResult.processingMetrics?.confidenceScore || 0) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          </div>

          {/* Processing Metrics */}
          {processingResult.processingMetrics && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Processing Metrics</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {processingResult.processingMetrics.transcriptionLength}
                  </div>
                  <div className="text-sm text-gray-600">Characters Transcribed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {processingResult.processingMetrics.dataPointsExtracted}
                  </div>
                  <div className="text-sm text-gray-600">Data Points Extracted</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {processingResult.processingMetrics.automationActionsCount}
                  </div>
                  <div className="text-sm text-gray-600">Automation Actions</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {(processingResult.processingMetrics.confidenceScore * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Confidence Score</div>
                </div>
              </div>
            </div>
          )}

          {/* Results Content */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <div className="space-y-6">
              {processingResult.result && (
                <>
                  {/* Transcript */}
                  {processingResult.result.transcript && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Transcript</h3>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="text-gray-700">{processingResult.result.transcript}</p>
                      </div>
                    </div>
                  )}

                  {/* Extracted Tax Data */}
                  {processingResult.result.extractedTaxData && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Extracted Tax Information</h3>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <pre className="text-sm text-blue-800">
                          {JSON.stringify(processingResult.result.extractedTaxData, null, 2)}
                        </pre>
                      </div>
                    </div>
                  )}

                  {/* Suggested Actions */}
                  {processingResult.result.suggestedActions && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Automation Actions</h3>
                      <div className="space-y-3">
                        {processingResult.result.suggestedActions.map((action: any, index: number) => (
                          <div key={index} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                            <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                            <p className="text-yellow-800">{action.description || action}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-wrap gap-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="h-4 w-4" />
                <span>Export Results</span>
              </button>
              
              <button 
                onClick={() => {
                  setProcessingResult(null);
                  setRecordedAudio(null);
                  setRecordingTime(0);
                }}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Process New Recording
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Hidden Audio Player */}
      <audio ref={audioPlayer} style={{ display: 'none' }} />
    </div>
  );
}
