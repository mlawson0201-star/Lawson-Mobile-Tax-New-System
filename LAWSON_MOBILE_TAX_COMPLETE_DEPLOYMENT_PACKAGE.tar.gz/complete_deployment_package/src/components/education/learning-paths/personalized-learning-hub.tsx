
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BookOpen, Play, CheckCircle, Clock, Star, TrendingUp,
  Award, Target, Brain, Lightbulb, Users, BarChart3
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import { LearningPath, LearningModule } from '@/lib/types/education';
import { ClientProfile } from '@/lib/types/experience';

interface PersonalizedLearningHubProps {
  clientProfile: ClientProfile;
  learningPaths: LearningPath[];
  userProgress: Record<string, {
    completedModules: string[];
    currentModule?: string;
    completionPercentage: number;
    timeSpent: number;
    lastAccessed: Date;
  }>;
  onStartPath: (pathId: string) => void;
  onCompleteModule: (pathId: string, moduleId: string) => void;
  onUpdateProgress: (pathId: string, progress: any) => void;
}

const DIFFICULTY_COLORS = {
  beginner: 'bg-green-100 text-green-800',
  intermediate: 'bg-yellow-100 text-yellow-800',
  advanced: 'bg-red-100 text-red-800'
};

const DIFFICULTY_ICONS = {
  beginner: '🌱',
  intermediate: '🌿',
  advanced: '🌳'
};

export default function PersonalizedLearningHub({
  clientProfile,
  learningPaths,
  userProgress,
  onStartPath,
  onCompleteModule,
  onUpdateProgress
}: PersonalizedLearningHubProps) {
  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);
  const [activeTab, setActiveTab] = useState('recommended');
  const [showCelebration, setShowCelebration] = useState(false);
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  // Filter paths based on client profile
  const recommendedPaths = learningPaths.filter(path => 
    path.targetPersona === clientProfile.persona.type ||
    path.difficulty === getDifficultyForComplexity(clientProfile.taxComplexity)
  );

  const inProgressPaths = learningPaths.filter(path => 
    userProgress[path.id] && userProgress[path.id].completionPercentage > 0 && userProgress[path.id].completionPercentage < 100
  );

  const completedPaths = learningPaths.filter(path => 
    userProgress[path.id] && userProgress[path.id].completionPercentage === 100
  );

  function getDifficultyForComplexity(complexity: string): 'beginner' | 'intermediate' | 'advanced' {
    switch (complexity) {
      case 'simple': return 'beginner';
      case 'moderate': return 'intermediate';
      case 'complex': return 'advanced';
      default: return 'beginner';
    }
  }

  const handleStartPath = (path: LearningPath) => {
    onStartPath(path.id);
    setSelectedPath(path);
  };

  const handleCompleteModule = (pathId: string, moduleId: string) => {
    onCompleteModule(pathId, moduleId);
    confettiReward();
    
    // Check if path is completed
    const progress = userProgress[pathId];
    const path = learningPaths.find(p => p.id === pathId);
    if (path && progress && progress.completedModules.length + 1 === path.modules.length) {
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 3000);
    }
  };

  const calculateOverallProgress = () => {
    if (learningPaths.length === 0) return 0;
    const totalProgress = Object.values(userProgress).reduce((sum, progress) => sum + progress.completionPercentage, 0);
    return Math.round(totalProgress / learningPaths.length);
  };

  const getTotalTimeSpent = () => {
    return Object.values(userProgress).reduce((sum, progress) => sum + progress.timeSpent, 0);
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}h ${remainingMinutes}m`;
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Your Personalized Learning Hub
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Master tax concepts with learning paths tailored specifically for {clientProfile.persona.name.toLowerCase()}s
        </p>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Overall Progress</p>
                <p className="text-2xl font-bold text-blue-600">{calculateOverallProgress()}%</p>
              </div>
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Paths Completed</p>
                <p className="text-2xl font-bold text-green-600">{completedPaths.length}</p>
              </div>
              <Award className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Time Spent</p>
                <p className="text-2xl font-bold text-purple-600">{formatTime(getTotalTimeSpent())}</p>
              </div>
              <Clock className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Progress</p>
                <p className="text-2xl font-bold text-yellow-600">{inProgressPaths.length}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="all">All Paths</TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Recommended for You
            </h3>
            <p className="text-gray-600">
              Based on your profile as a {clientProfile.persona.name.toLowerCase()} with {clientProfile.taxComplexity} tax needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedPaths.map((path) => {
              const progress = userProgress[path.id];
              return (
                <motion.div
                  key={path.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="group"
                >
                  <Card className="h-full hover:shadow-lg transition-shadow duration-200 cursor-pointer">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2">{path.title}</CardTitle>
                          <CardDescription className="text-sm line-clamp-2">
                            {path.description}
                          </CardDescription>
                        </div>
                        <div className="ml-2">
                          <Badge className={DIFFICULTY_COLORS[path.difficulty]}>
                            {DIFFICULTY_ICONS[path.difficulty]} {path.difficulty}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <BookOpen className="w-4 h-4" />
                          <span>{path.modules.length} modules</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{formatTime(path.estimatedTime)}</span>
                        </div>
                      </div>

                      {progress && progress.completionPercentage > 0 ? (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{progress.completionPercentage}%</span>
                          </div>
                          <Progress value={progress.completionPercentage} className="h-2" />
                          <Button
                            className="w-full"
                            onClick={() => setSelectedPath(path)}
                          >
                            Continue Learning
                          </Button>
                        </div>
                      ) : (
                        <Button
                          className="w-full"
                          onClick={() => handleStartPath(path)}
                        >
                          Start Learning
                        </Button>
                      )}

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Users className="w-3 h-3" />
                          <span>{Math.round(path.completionRate)}% completion rate</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Target className="w-3 h-3" />
                          <span>Perfect match</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="in-progress" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Continue Your Learning
            </h3>
            <p className="text-gray-600">
              Pick up where you left off
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {inProgressPaths.map((path) => {
              const progress = userProgress[path.id];
              const currentModuleIndex = progress.completedModules.length;
              const currentModule = path.modules[currentModuleIndex];
              
              return (
                <Card key={path.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{path.title}</CardTitle>
                        <CardDescription>
                          Module {currentModuleIndex + 1} of {path.modules.length}
                        </CardDescription>
                      </div>
                      <Badge className={DIFFICULTY_COLORS[path.difficulty]}>
                        {progress.completionPercentage}% complete
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Overall Progress</span>
                        <span>{progress.completionPercentage}%</span>
                      </div>
                      <Progress value={progress.completionPercentage} className="h-2" />
                    </div>

                    {currentModule && (
                      <div className="bg-blue-50 rounded-lg p-4">
                        <h4 className="font-medium text-blue-900 mb-1">
                          Next: {currentModule.title}
                        </h4>
                        <p className="text-sm text-blue-700 mb-2">
                          {currentModule.description}
                        </p>
                        <div className="flex items-center text-xs text-blue-600">
                          <Clock className="w-3 h-3 mr-1" />
                          <span>{formatTime(currentModule.duration)}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>Last accessed: {new Date(progress.lastAccessed).toLocaleDateString()}</span>
                      <span>Time spent: {formatTime(progress.timeSpent)}</span>
                    </div>

                    <Button
                      className="w-full"
                      onClick={() => setSelectedPath(path)}
                    >
                      Continue Learning
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Completed Paths
            </h3>
            <p className="text-gray-600">
              Great job! You've mastered these topics
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {completedPaths.map((path) => {
              const progress = userProgress[path.id];
              return (
                <Card key={path.id} className="border-green-200 bg-green-50">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg flex items-center space-x-2">
                          <span>{path.title}</span>
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        </CardTitle>
                        <CardDescription>{path.description}</CardDescription>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        Completed
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Completed on:</span>
                      <span className="font-medium">
                        {new Date(progress.lastAccessed).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Time spent:</span>
                      <span className="font-medium">{formatTime(progress.timeSpent)}</span>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => setSelectedPath(path)}
                    >
                      Review Content
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="all" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {learningPaths.map((path) => {
              const progress = userProgress[path.id];
              const isRecommended = recommendedPaths.includes(path);
              
              return (
                <Card key={path.id} className={`hover:shadow-lg transition-shadow ${isRecommended ? 'ring-2 ring-blue-200' : ''}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{path.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {path.description}
                        </CardDescription>
                      </div>
                      <div className="flex flex-col space-y-1">
                        <Badge className={DIFFICULTY_COLORS[path.difficulty]}>
                          {path.difficulty}
                        </Badge>
                        {isRecommended && (
                          <Badge variant="outline" className="text-blue-600 border-blue-600">
                            Recommended
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <BookOpen className="w-4 h-4" />
                        <span>{path.modules.length} modules</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{formatTime(path.estimatedTime)}</span>
                      </div>
                    </div>

                    {progress && progress.completionPercentage > 0 && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{progress.completionPercentage}%</span>
                        </div>
                        <Progress value={progress.completionPercentage} className="h-2" />
                      </div>
                    )}

                    <Button
                      className="w-full"
                      variant={progress && progress.completionPercentage > 0 ? "default" : "outline"}
                      onClick={() => progress && progress.completionPercentage > 0 ? setSelectedPath(path) : handleStartPath(path)}
                    >
                      {progress && progress.completionPercentage > 0 ? 'Continue' : 'Start'} Learning
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Path Detail Modal */}
      <AnimatePresence>
        {selectedPath && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedPath(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{selectedPath.title}</h3>
                    <p className="text-gray-600 mt-2">{selectedPath.description}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedPath(null)}>
                    ✕
                  </Button>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <BookOpen className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <p className="text-lg font-bold text-blue-600">{selectedPath.modules.length}</p>
                      <p className="text-sm text-gray-600">Modules</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <p className="text-lg font-bold text-green-600">{formatTime(selectedPath.estimatedTime)}</p>
                      <p className="text-sm text-gray-600">Est. Time</p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Star className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <p className="text-lg font-bold text-purple-600">{selectedPath.completionRate}%</p>
                      <p className="text-sm text-gray-600">Completion Rate</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold mb-4">Course Modules</h4>
                    <div className="space-y-3">
                      {selectedPath.modules.map((module, index) => {
                        const progress = userProgress[selectedPath.id];
                        const isCompleted = progress?.completedModules.includes(module.id);
                        const isCurrent = progress?.currentModule === module.id;
                        
                        return (
                          <div
                            key={module.id}
                            className={`border rounded-lg p-4 ${
                              isCompleted ? 'bg-green-50 border-green-200' :
                              isCurrent ? 'bg-blue-50 border-blue-200' :
                              'bg-white border-gray-200'
                            }`}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-start space-x-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                  isCompleted ? 'bg-green-600 text-white' :
                                  isCurrent ? 'bg-blue-600 text-white' :
                                  'bg-gray-200 text-gray-600'
                                }`}>
                                  {isCompleted ? <CheckCircle className="w-4 h-4" /> : index + 1}
                                </div>
                                <div className="flex-1">
                                  <h5 className="font-medium text-gray-900">{module.title}</h5>
                                  <p className="text-sm text-gray-600 mt-1">{module.description}</p>
                                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                    <span className="flex items-center space-x-1">
                                      <Clock className="w-3 h-3" />
                                      <span>{formatTime(module.duration)}</span>
                                    </span>
                                    <Badge variant="outline" className="text-xs">
                                      {module.type}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                              {!isCompleted && (
                                <Button
                                  size="sm"
                                  onClick={() => handleCompleteModule(selectedPath.id, module.id)}
                                  disabled={index > 0 && !progress?.completedModules.includes(selectedPath.modules[index - 1].id)}
                                >
                                  {isCurrent ? 'Continue' : 'Start'}
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Completion Celebration */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.8, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 50 }}
              className="bg-white rounded-lg p-8 max-w-md mx-4 text-center"
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Congratulations!
              </h3>
              <p className="text-gray-600 mb-4">
                You've completed a learning path! Your tax knowledge is growing stronger.
              </p>
              <Button onClick={() => setShowCelebration(false)}>
                Continue Learning
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <span id="confetti" />
    </div>
  );
}
