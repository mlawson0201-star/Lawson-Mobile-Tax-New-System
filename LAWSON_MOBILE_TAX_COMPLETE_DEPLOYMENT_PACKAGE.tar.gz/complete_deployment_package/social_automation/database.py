
"""
Database models and setup for social media automation
"""
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
from config import settings

engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class SocialAccount(Base):
    __tablename__ = "social_accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    platform = Column(String(50), nullable=False)
    account_name = Column(String(100), nullable=False)
    account_id = Column(String(100), nullable=False)
    access_token = Column(Text)
    refresh_token = Column(Text)
    token_expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    posts = relationship("Post", back_populates="account")

class ContentTemplate(Base):
    __tablename__ = "content_templates"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)  # tax_tips, promotional, seasonal, etc.
    template_text = Column(Text, nullable=False)
    platforms = Column(JSON)  # List of platforms this template is for
    hashtags = Column(JSON)  # Platform-specific hashtags
    media_requirements = Column(JSON)  # Image/video requirements
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Post(Base):
    __tablename__ = "posts"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("social_accounts.id"))
    platform = Column(String(50), nullable=False)
    content = Column(Text, nullable=False)
    media_urls = Column(JSON)  # List of media URLs
    hashtags = Column(JSON)  # List of hashtags
    scheduled_time = Column(DateTime)
    posted_time = Column(DateTime)
    status = Column(String(20), default="draft")  # draft, scheduled, posted, failed
    platform_post_id = Column(String(100))
    engagement_metrics = Column(JSON)  # likes, shares, comments, etc.
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    account = relationship("SocialAccount", back_populates="posts")

class Campaign(Base):
    __tablename__ = "campaigns"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime)
    platforms = Column(JSON)  # List of platforms
    content_templates = Column(JSON)  # List of template IDs
    posting_schedule = Column(JSON)  # Schedule configuration
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Analytics(Base):
    __tablename__ = "analytics"
    
    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("posts.id"))
    platform = Column(String(50), nullable=False)
    metric_name = Column(String(50), nullable=False)  # likes, shares, comments, reach, etc.
    metric_value = Column(Integer, default=0)
    recorded_at = Column(DateTime, default=datetime.utcnow)

# Create tables
Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
