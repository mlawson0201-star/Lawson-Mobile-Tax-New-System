
# Brand Guidelines
## Lawson Mobile Tax + Formality Tax

---

## 1. Lawson Mobile Tax Brand Identity

### 1.1 Brand Positioning
**Tagline:** "Tax Made Simple, Results Made Certain"

**Brand Promise:** Professional tax preparation with AI-powered accuracy and human expertise, delivered with transparency and care.

**Brand Personality:**
- **Trustworthy**: Reliable, secure, compliant
- **Approachable**: Friendly, helpful, accessible
- **Professional**: Expert, accurate, thorough
- **Innovative**: Modern, efficient, tech-forward

### 1.2 Visual Identity

#### Color Palette
**Primary Colors:**
- **Lawson Purple**: #6B46C1 (Primary brand color)
- **Trust Blue**: #1E40AF (Secondary, for trust elements)
- **Success Green**: #059669 (For positive actions, refunds)

**Secondary Colors:**
- **Warm Gray**: #6B7280 (Text, backgrounds)
- **Light Gray**: #F3F4F6 (Backgrounds, cards)
- **White**: #FFFFFF (Primary background)

**Accent Colors:**
- **Warning Orange**: #F59E0B (Alerts, important notices)
- **Error Red**: #DC2626 (Errors, urgent items)

#### Typography
**Primary Font:** Inter (Web), SF Pro (iOS), Roboto (Android)
- **Headings**: Inter Bold (700)
- **Subheadings**: Inter SemiBold (600)
- **Body Text**: Inter Regular (400)
- **Captions**: Inter Medium (500)

**Secondary Font:** Georgia (For formal documents, legal text)

#### Logo Usage
- Minimum size: 120px width for digital, 1 inch for print
- Clear space: Equal to the height of the "L" in Lawson
- Available formats: SVG (web), PNG (digital), EPS (print)

### 1.3 Voice & Tone

#### Brand Voice Characteristics
- **Clear & Direct**: No jargon, plain English explanations
- **Confident**: Knowledgeable without being condescending
- **Supportive**: Helpful, encouraging, reassuring
- **Professional**: Appropriate for financial services

#### Tone Variations by Context
- **Marketing**: Friendly, confident, benefit-focused
- **Educational**: Helpful, clear, informative
- **Transactional**: Professional, clear, efficient
- **Support**: Empathetic, solution-focused, patient

---

## 2. Formality Tax (White-Label) Brand

### 2.1 Brand Positioning
**Tagline:** "Professional Tax Solutions, Your Brand"

**Value Proposition:** Complete white-label tax platform enabling tax professionals to scale their practice with enterprise-grade technology.

### 2.2 Visual Identity

#### Color Palette
**Primary Colors:**
- **Professional Navy**: #1E3A8A (Primary brand color)
- **Platinum Gray**: #64748B (Secondary)
- **Clean White**: #FFFFFF (Background)

**Accent Colors:**
- **Success Green**: #10B981 (Positive metrics)
- **Growth Blue**: #3B82F6 (Analytics, growth)
- **Premium Gold**: #F59E0B (Premium features)

#### Typography
**Primary Font:** Inter (Professional, clean)
**Secondary Font:** Source Code Pro (For technical documentation)

---

## 3. Marketing Materials

### 3.1 Website Design Principles
- **Mobile-First**: Responsive design optimized for mobile
- **Trust Signals**: Security badges, testimonials, certifications
- **Clear CTAs**: Prominent, action-oriented buttons
- **Progressive Disclosure**: Information revealed as needed

### 3.2 Content Guidelines

#### Headlines
- **Benefit-Focused**: Lead with customer benefit
- **Action-Oriented**: Use active voice
- **Specific**: Include numbers, timeframes when possible
- **Emotional**: Connect with customer pain points

**Examples:**
- "Get Your Maximum Refund in 48 Hours"
- "Professional Tax Prep Starting at $485"
- "AI-Powered Accuracy, Human-Verified Results"

#### Body Copy
- **Scannable**: Use bullet points, short paragraphs
- **Conversational**: Write like you're talking to a friend
- **Benefit-Heavy**: Focus on what's in it for the customer
- **Proof-Driven**: Include testimonials, guarantees, stats

### 3.3 Photography Style
- **Authentic**: Real people, not stock photos when possible
- **Diverse**: Represent our diverse customer base
- **Professional**: Clean, well-lit, high-quality
- **Contextual**: Show people in relevant tax/financial situations

---

## 4. Digital Brand Applications

### 4.1 Website Elements
- **Header**: Logo, navigation, CTA button
- **Hero Section**: Value proposition, primary CTA
- **Trust Bar**: Security, certifications, testimonials
- **Features**: Benefits with icons and descriptions
- **Social Proof**: Customer testimonials, reviews
- **Footer**: Links, contact info, legal disclaimers

### 4.2 Email Design
- **Header**: Logo and navigation
- **Content**: Clear hierarchy, scannable format
- **CTA**: Single, prominent call-to-action
- **Footer**: Unsubscribe, contact info, legal

### 4.3 Social Media
- **Profile Images**: Consistent logo usage
- **Cover Images**: Brand messaging and visuals
- **Post Templates**: Consistent visual style
- **Hashtags**: #LawsonMobileTax #TaxMadeSimple

---

## 5. Compliance & Legal Considerations

### 5.1 Required Disclaimers
- **Tax Advice**: "Consult a tax professional for advice specific to your situation"
- **Refund Amounts**: "Actual refund may vary based on individual circumstances"
- **Service Guarantees**: Include limitations and conditions

### 5.2 Regulatory Compliance
- **GLBA Compliance**: Privacy notices, opt-out mechanisms
- **State Regulations**: Appropriate licensing disclosures
- **IRS Requirements**: ERO identification, e-filing disclosures

---

## 6. Brand Asset Library

### 6.1 Logo Files
- `lawson-logo-primary.svg`
- `lawson-logo-white.svg`
- `lawson-logo-horizontal.svg`
- `formality-logo-primary.svg`

### 6.2 Color Swatches
- `brand-colors.ase` (Adobe Swatch Exchange)
- `brand-colors.scss` (Sass variables)
- `brand-colors.css` (CSS custom properties)

### 6.3 Typography
- `Inter-VariableFont.woff2`
- `typography-styles.css`

### 6.4 Templates
- Email templates (HTML/CSS)
- Social media templates (Figma/Sketch)
- Presentation templates (PowerPoint/Keynote)
- Marketing materials (Canva templates)

---

*Brand Guidelines Version: 1.0*
*Last Updated: August 22, 2025*
*Brand Manager: [INSERT NAME]*

