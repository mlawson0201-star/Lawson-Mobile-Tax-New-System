
import BusinessFormationWizard from '@/components/automation/business-formation-wizard';

export const dynamic = 'force-dynamic';

export default function BusinessFormationPage() {
  return (
    <div className="space-y-8">
      <BusinessFormationWizard />
    </div>
  );
}
