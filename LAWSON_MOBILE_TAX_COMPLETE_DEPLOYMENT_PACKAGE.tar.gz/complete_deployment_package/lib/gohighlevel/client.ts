
import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { prisma } from '@/lib/prisma';

export interface GoHighLevelConfig {
  apiKey?: string;
  locationId?: string;
  baseURL?: string;
  timeout?: number;
  retries?: number;
}

export interface GoHighLevelContact {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address1?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  source?: string;
  tags?: string[];
  customFields?: Record<string, any>;
  locationId?: string;
}

export interface GoHighLevelAppointment {
  id?: string;
  contactId: string;
  calendarId: string;
  title: string;
  startTime: string;
  endTime: string;
  appointmentStatus?: string;
  notes?: string;
}

export interface GoHighLevelMessage {
  contactId: string;
  type: 'SMS' | 'Email';
  message: string;
  subject?: string;
  templateId?: string;
}

export interface GoHighLevelWebhookEvent {
  type: string;
  locationId: string;
  contactId?: string;
  appointmentId?: string;
  data: Record<string, any>;
  timestamp: string;
}

export class GoHighLevelClient {
  private client: AxiosInstance;
  private config: GoHighLevelConfig;
  private tenantId: string;

  constructor(tenantId: string, config: GoHighLevelConfig) {
    this.tenantId = tenantId;
    this.config = {
      baseURL: 'https://rest.gohighlevel.com/v1',
      timeout: 30000,
      retries: 3,
      ...config,
    };

    this.client = axios.create({
      baseURL: this.config.baseURL,
      timeout: this.config.timeout,
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // Request interceptor for logging and rate limiting
    this.client.interceptors.request.use(
      (config) => {
        console.log(`[GoHighLevel API] ${config.method?.toUpperCase()} ${config.url}`);
        return config;
      },
      (error) => {
        console.error('[GoHighLevel API] Request error:', error);
        return Promise.reject(error);
      }
    );

    // Response interceptor for error handling and retries
    this.client.interceptors.response.use(
      (response) => {
        return response;
      },
      async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 429 && !originalRequest._retry) {
          originalRequest._retry = true;
          const retryAfter = error.response.headers['retry-after'] || 1;
          await this.delay(retryAfter * 1000);
          return this.client(originalRequest);
        }

        if (error.response?.status >= 500 && originalRequest._retryCount < (this.config.retries || 3)) {
          originalRequest._retryCount = (originalRequest._retryCount || 0) + 1;
          await this.delay(Math.pow(2, originalRequest._retryCount) * 1000);
          return this.client(originalRequest);
        }

        console.error('[GoHighLevel API] Response error:', {
          status: error.response?.status,
          data: error.response?.data,
          url: error.config?.url,
        });

        return Promise.reject(error);
      }
    );
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Contact Management
  async createContact(contact: GoHighLevelContact): Promise<GoHighLevelContact> {
    try {
      const response = await this.client.post('/contacts/', {
        ...contact,
        locationId: contact.locationId || this.config.locationId,
      });
      return response.data.contact;
    } catch (error) {
      console.error('Error creating contact:', error);
      throw error;
    }
  }

  async updateContact(contactId: string, updates: Partial<GoHighLevelContact>): Promise<GoHighLevelContact> {
    try {
      const response = await this.client.put(`/contacts/${contactId}`, updates);
      return response.data.contact;
    } catch (error) {
      console.error('Error updating contact:', error);
      throw error;
    }
  }

  async getContact(contactId: string): Promise<GoHighLevelContact> {
    try {
      const response = await this.client.get(`/contacts/${contactId}`);
      return response.data.contact;
    } catch (error) {
      console.error('Error getting contact:', error);
      throw error;
    }
  }

  async searchContacts(query: string, limit: number = 20): Promise<GoHighLevelContact[]> {
    try {
      const response = await this.client.get('/contacts/search', {
        params: { query, limit, locationId: this.config.locationId },
      });
      return response.data.contacts || [];
    } catch (error) {
      console.error('Error searching contacts:', error);
      throw error;
    }
  }

  async deleteContact(contactId: string): Promise<void> {
    try {
      await this.client.delete(`/contacts/${contactId}`);
    } catch (error) {
      console.error('Error deleting contact:', error);
      throw error;
    }
  }

  // Appointment Management
  async createAppointment(appointment: GoHighLevelAppointment): Promise<GoHighLevelAppointment> {
    try {
      const response = await this.client.post('/appointments/', appointment);
      return response.data.appointment;
    } catch (error) {
      console.error('Error creating appointment:', error);
      throw error;
    }
  }

  async updateAppointment(appointmentId: string, updates: Partial<GoHighLevelAppointment>): Promise<GoHighLevelAppointment> {
    try {
      const response = await this.client.put(`/appointments/${appointmentId}`, updates);
      return response.data.appointment;
    } catch (error) {
      console.error('Error updating appointment:', error);
      throw error;
    }
  }

  async getAppointments(contactId?: string, startDate?: string, endDate?: string): Promise<GoHighLevelAppointment[]> {
    try {
      const params: any = { locationId: this.config.locationId };
      if (contactId) params.contactId = contactId;
      if (startDate) params.startDate = startDate;
      if (endDate) params.endDate = endDate;

      const response = await this.client.get('/appointments/', { params });
      return response.data.appointments || [];
    } catch (error) {
      console.error('Error getting appointments:', error);
      throw error;
    }
  }

  // Messaging
  async sendSMS(message: GoHighLevelMessage): Promise<any> {
    try {
      const response = await this.client.post('/conversations/messages', {
        type: 'SMS',
        contactId: message.contactId,
        message: message.message,
        locationId: this.config.locationId,
      });
      return response.data;
    } catch (error) {
      console.error('Error sending SMS:', error);
      throw error;
    }
  }

  async sendEmail(message: GoHighLevelMessage): Promise<any> {
    try {
      const response = await this.client.post('/conversations/messages', {
        type: 'Email',
        contactId: message.contactId,
        subject: message.subject,
        html: message.message,
        locationId: this.config.locationId,
      });
      return response.data;
    } catch (error) {
      console.error('Error sending email:', error);
      throw error;
    }
  }

  // Pipeline Management
  async getOpportunities(contactId?: string): Promise<any[]> {
    try {
      const params: any = { locationId: this.config.locationId };
      if (contactId) params.contactId = contactId;

      const response = await this.client.get('/opportunities/', { params });
      return response.data.opportunities || [];
    } catch (error) {
      console.error('Error getting opportunities:', error);
      throw error;
    }
  }

  async createOpportunity(opportunity: any): Promise<any> {
    try {
      const response = await this.client.post('/opportunities/', {
        ...opportunity,
        locationId: this.config.locationId,
      });
      return response.data.opportunity;
    } catch (error) {
      console.error('Error creating opportunity:', error);
      throw error;
    }
  }

  async updateOpportunity(opportunityId: string, updates: any): Promise<any> {
    try {
      const response = await this.client.put(`/opportunities/${opportunityId}`, updates);
      return response.data.opportunity;
    } catch (error) {
      console.error('Error updating opportunity:', error);
      throw error;
    }
  }

  // Webhook Verification
  static verifyWebhookSignature(payload: string, signature: string, secret: string): boolean {
    const crypto = require('crypto');
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex');
    
    return crypto.timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(expectedSignature, 'hex')
    );
  }

  // Utility Methods
  async testConnection(): Promise<boolean> {
    try {
      await this.client.get('/locations/');
      return true;
    } catch (error) {
      console.error('GoHighLevel connection test failed:', error);
      return false;
    }
  }

  async getLocationInfo(): Promise<any> {
    try {
      const response = await this.client.get(`/locations/${this.config.locationId}`);
      return response.data.location;
    } catch (error) {
      console.error('Error getting location info:', error);
      throw error;
    }
  }
}

// Factory function to create GoHighLevel client for a tenant
export async function createGoHighLevelClient(tenantId: string): Promise<GoHighLevelClient | null> {
  try {
    const settings = await prisma.gohighlevel_settings.findUnique({
      where: { tenant_id: tenantId },
    });

    if (!settings || !settings.api_key) {
      console.warn(`No GoHighLevel settings found for tenant ${tenantId}`);
      return null;
    }

    const config: GoHighLevelConfig = {
      apiKey: settings.api_key,
      locationId: settings.location_id || undefined,
    };

    return new GoHighLevelClient(tenantId, config);
  } catch (error) {
    console.error('Error creating GoHighLevel client:', error);
    return null;
  }
}
