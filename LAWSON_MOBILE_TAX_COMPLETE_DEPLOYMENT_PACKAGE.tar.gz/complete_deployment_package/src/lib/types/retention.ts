
export interface ClientLifecycleStage {
  id: string;
  name: string;
  description: string;
  order: number;
  triggers: LifecycleTrigger[];
  actions: LifecycleAction[];
  duration: number; // in days
  successMetrics: string[];
}

export interface LifecycleTrigger {
  id: string;
  type: 'time_based' | 'behavior_based' | 'event_based';
  condition: string;
  value: any;
  operator: 'equals' | 'greater_than' | 'less_than' | 'contains';
}

export interface LifecycleAction {
  id: string;
  type: 'email' | 'sms' | 'notification' | 'task' | 'discount' | 'content';
  template: string;
  delay: number; // in hours
  conditions: string[];
  personalization: Record<string, string>;
}

export interface ValueAddedService {
  id: string;
  name: string;
  description: string;
  category: 'financial_planning' | 'business_consulting' | 'audit_protection' | 'bookkeeping' | 'other';
  price: number;
  billingCycle: 'one_time' | 'monthly' | 'quarterly' | 'annually';
  features: string[];
  targetPersonas: string[];
  isActive: boolean;
  uptakeRate: number;
  churnRate: number;
}

export interface LoyaltyProgram {
  id: string;
  name: string;
  description: string;
  pointsPerDollar: number;
  tiers: LoyaltyTier[];
  rewards: LoyaltyReward[];
  rules: string[];
  isActive: boolean;
  memberCount: number;
}

export interface LoyaltyTier {
  id: string;
  name: string;
  minPoints: number;
  benefits: string[];
  multiplier: number;
  color: string;
  icon: string;
}

export interface LoyaltyReward {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  type: 'discount' | 'service' | 'gift' | 'experience';
  value: number;
  isAvailable: boolean;
  expirationDate?: Date;
  redemptionCount: number;
  maxRedemptions?: number;
}

export interface ClientPoints {
  clientId: string;
  totalPoints: number;
  availablePoints: number;
  lifetimePoints: number;
  currentTier: string;
  nextTierPoints: number;
  pointsHistory: PointsTransaction[];
  lastUpdated: Date;
}

export interface PointsTransaction {
  id: string;
  clientId: string;
  type: 'earned' | 'redeemed' | 'expired' | 'bonus';
  points: number;
  description: string;
  referenceId?: string;
  createdAt: Date;
}

export interface AdvisoryBoardMember {
  clientId: string;
  joinDate: Date;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  contributions: number;
  lastActivity: Date;
  benefits: string[];
  exclusiveAccess: string[];
  votingPower: number;
}

export interface ChurnPrediction {
  clientId: string;
  riskScore: number; // 0-100
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  factors: ChurnFactor[];
  recommendations: string[];
  lastCalculated: Date;
  interventionStatus: 'none' | 'scheduled' | 'in_progress' | 'completed';
}

export interface ChurnFactor {
  factor: string;
  weight: number;
  value: number;
  impact: 'positive' | 'negative';
  description: string;
}

export interface RetentionCampaign {
  id: string;
  name: string;
  description: string;
  targetSegment: string;
  triggerConditions: string[];
  actions: LifecycleAction[];
  startDate: Date;
  endDate?: Date;
  isActive: boolean;
  metrics: {
    targeted: number;
    reached: number;
    engaged: number;
    retained: number;
    cost: number;
    roi: number;
  };
}
