
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const clientId = searchParams.get('clientId');

    if (!clientId) {
      return NextResponse.json({ error: 'Client ID required' }, { status: 400 });
    }

    // Get current subscription
    const subscription = await prisma.subscriptionEnhanced.findFirst({
      where: {
        tenantId: session.user.tenantId,
        clientId,
        status: { in: ['trial', 'active'] },
      },
      include: {
        plan: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Mock subscription if none exists
    if (!subscription) {
      const mockSubscription = {
        id: 'mock-subscription',
        status: 'trial',
        currentPeriodStart: new Date().toISOString(),
        currentPeriodEnd: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        trialEnd: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        autoRenew: true,
        usageMetrics: {
          taxReturnsUsed: 1,
          storageUsed: 2048, // MB
          aiProcessingUsed: 5,
        },
        plan: {
          id: 'basic-monthly',
          planName: 'Basic Trial',
          planType: 'individual',
          billingCycle: 'monthly',
          basePrice: 29.99,
          tierLevel: 'basic',
          limits: {
            maxTaxReturns: 1,
            maxUsers: 1,
            storageGB: 5,
          },
          features: [
            'Up to 1 tax return',
            'Basic deduction scanning',
            'Email support',
            'Standard processing time',
            'Basic document storage (5 GB)',
            'Mobile app access',
          ],
        },
      };

      return NextResponse.json({
        success: true,
        subscription: mockSubscription,
        isMock: true,
      });
    }

    return NextResponse.json({
      success: true,
      subscription,
    });
  } catch (error: any) {
    console.error('Get current subscription error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve current subscription', details: error?.message },
      { status: 500 }
    );
  }
}
