
# CRM and GoHighLevel Integration Guide

## Overview

The Lawson Mobile Tax platform now includes comprehensive CRM functionality with seamless GoHighLevel integration. This integration provides:

- **Lead Management System** - Capture, track, and nurture leads through the entire sales funnel
- **Client Communication Hub** - Track all interactions, emails, calls, and meetings
- **Automated Follow-up Sequences** - Email and SMS automation based on client actions
- **Sales Pipeline Management** - Visual pipeline with stages and conversion tracking
- **Contact Management** - Comprehensive client profiles with history and preferences
- **Task and Appointment Scheduling** - Calendar integration and reminder systems
- **Reporting and Analytics** - Lead conversion, client lifetime value, and performance metrics
- **GoHighLevel Sync** - Bi-directional synchronization with GoHighLevel CRM

## Architecture

### Database Schema

The CRM system uses the following main tables:

- `crm_leads` - Core lead information and status
- `crm_pipeline_stages` - Customizable pipeline stages
- `crm_communication_logs` - All communication history
- `crm_tasks` - Task management and reminders
- `crm_appointments` - Calendar and scheduling
- `crm_automation_rules` - Workflow automation rules
- `gohighlevel_settings` - Integration configuration
- `gohighlevel_webhook_events` - Webhook event logging

### API Endpoints

#### Lead Management
- `GET /api/crm/leads` - List leads with filtering and pagination
- `POST /api/crm/leads` - Create new lead
- `GET /api/crm/leads/[id]` - Get lead details
- `PUT /api/crm/leads/[id]` - Update lead
- `DELETE /api/crm/leads/[id]` - Delete lead

#### Task Management
- `GET /api/crm/tasks` - List tasks
- `POST /api/crm/tasks` - Create task
- `PUT /api/crm/tasks/[id]` - Update task
- `DELETE /api/crm/tasks/[id]` - Delete task

#### Appointments
- `GET /api/crm/appointments` - List appointments
- `POST /api/crm/appointments` - Schedule appointment
- `PUT /api/crm/appointments/[id]` - Update appointment
- `DELETE /api/crm/appointments/[id]` - Cancel appointment

#### Analytics
- `GET /api/crm/analytics` - Get CRM analytics and reports

#### GoHighLevel Integration
- `GET /api/gohighlevel/settings` - Get integration settings
- `POST /api/gohighlevel/settings` - Update integration settings
- `POST /api/gohighlevel/sync` - Manual sync with GoHighLevel
- `POST /api/gohighlevel/webhook` - Webhook endpoint for GoHighLevel

#### Automation
- `GET /api/crm/automation/rules` - List automation rules
- `POST /api/crm/automation/rules` - Create automation rule
- `PUT /api/crm/automation/rules/[id]` - Update automation rule
- `DELETE /api/crm/automation/rules/[id]` - Delete automation rule

## Setup Instructions

### 1. Environment Variables

Add the following variables to your `.env` file:

```env
# GoHighLevel Integration
GOHIGHLEVEL_API_KEY="your-gohighlevel-api-key"
GOHIGHLEVEL_LOCATION_ID="your-gohighlevel-location-id"
GOHIGHLEVEL_WEBHOOK_SECRET="your-webhook-secret"

# CRM Settings
CRM_DEFAULT_PIPELINE_STAGE="new-lead"
CRM_AUTO_ASSIGN_LEADS="true"
CRM_LEAD_SCORING_ENABLED="true"

# Job Queue Settings
JOB_QUEUE_ENABLED="true"
JOB_QUEUE_REDIS_URL="redis://localhost:6379"
JOB_QUEUE_CONCURRENCY="5"

# Feature Flags
ENABLE_CRM="true"
ENABLE_GOHIGHLEVEL="true"
ENABLE_AUTOMATION="true"
```

### 2. Database Migration

Run the database migration to create the CRM tables:

```bash
npx prisma db push
```

### 3. GoHighLevel Configuration

1. **Get API Key**: Log into GoHighLevel → Settings → API Keys → Create new key
2. **Find Location ID**: Settings → Business Profile → Location ID
3. **Configure Webhook**: Use the generated webhook URL in GoHighLevel settings

### 4. Start Job Processing

The system includes background job processing for automation. Start it with:

```javascript
import { startJobProcessing } from '@/lib/jobs/queue';
startJobProcessing();
```

## Features

### Lead Management

- **Lead Capture**: Multiple sources (website, referrals, ads, GoHighLevel)
- **Lead Scoring**: Automatic scoring based on engagement and profile
- **Pipeline Stages**: Customizable stages with probability tracking
- **Assignment**: Automatic or manual lead assignment to team members
- **Tags and Custom Fields**: Flexible categorization and data storage

### Communication Tracking

- **Multi-Channel**: Email, SMS, phone calls, meetings, notes
- **Direction Tracking**: Inbound vs outbound communications
- **Integration**: Automatic logging from GoHighLevel
- **Templates**: Reusable communication templates

### Task Management

- **Priority Levels**: Low, Medium, High, Urgent
- **Due Dates**: Deadline tracking with reminders
- **Assignment**: Task assignment to team members
- **Status Tracking**: Pending, In Progress, Completed, Cancelled

### Appointment Scheduling

- **Meeting Types**: In-person, phone, video, online
- **Calendar Integration**: Sync with GoHighLevel calendars
- **Reminders**: Automatic reminder notifications
- **Status Tracking**: Scheduled, confirmed, completed, cancelled

### Automation Engine

The automation engine supports various triggers and actions:

#### Triggers
- Lead created
- Lead status changed
- Task completed
- Email opened
- SMS replied
- Appointment booked
- Payment received

#### Actions
- Send email
- Send SMS
- Create task
- Update lead status
- Schedule follow-up
- Assign to user
- Add tag
- Webhook call

### Analytics and Reporting

- **Lead Metrics**: Total leads, conversion rates, pipeline value
- **Source Analysis**: Performance by lead source
- **User Performance**: Individual team member metrics
- **Trend Analysis**: Historical performance tracking
- **Pipeline Reports**: Stage distribution and velocity

## GoHighLevel Integration

### Bi-Directional Sync

The integration provides real-time synchronization:

- **Contacts**: Leads sync as contacts in GoHighLevel
- **Appointments**: Calendar events sync both ways
- **Communications**: Messages and emails are logged
- **Custom Fields**: Additional data syncs as custom fields

### Webhook Events

Supported webhook events from GoHighLevel:

- `ContactCreate` - New contact added
- `ContactUpdate` - Contact information changed
- `AppointmentCreate` - New appointment scheduled
- `AppointmentUpdate` - Appointment modified
- `InboundMessage` - Message received
- `OutboundMessage` - Message sent
- `OpportunityCreate` - New opportunity
- `OpportunityUpdate` - Opportunity changed

### Field Mapping

Configure how fields map between systems:

```json
{
  "firstName": "first_name",
  "lastName": "last_name",
  "email": "email",
  "phone": "phone",
  "company": "company_name",
  "customFields": {
    "leadScore": "lead_score",
    "source": "lead_source",
    "status": "lead_status"
  }
}
```

## Usage Examples

### Creating a Lead

```javascript
const lead = await fetch('/api/crm/leads', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    phone: '+1234567890',
    source: 'WEBSITE',
    estimatedValue: 5000,
    syncToGoHighLevel: true
  })
});
```

### Setting Up Automation

```javascript
const rule = await fetch('/api/crm/automation/rules', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Welcome New Leads',
    triggerType: 'LEAD_CREATED',
    triggerConditions: {
      source: 'WEBSITE'
    },
    actions: [
      {
        type: 'SEND_EMAIL',
        config: {
          subject: 'Welcome to Lawson Mobile Tax',
          message: 'Thank you for your interest...',
          delay: 5 // minutes
        }
      },
      {
        type: 'CREATE_TASK',
        config: {
          title: 'Follow up with new lead',
          priority: 'HIGH',
          dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
        }
      }
    ]
  })
});
```

### Manual Sync

```javascript
const syncResult = await fetch('/api/gohighlevel/sync', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ type: 'all' })
});
```

## Best Practices

### Lead Management
1. **Consistent Data Entry**: Use standardized formats for phone numbers, addresses
2. **Regular Cleanup**: Remove duplicate leads and outdated information
3. **Lead Scoring**: Regularly review and adjust scoring criteria
4. **Pipeline Management**: Keep pipeline stages relevant and up-to-date

### Automation
1. **Start Simple**: Begin with basic automations and add complexity gradually
2. **Test Thoroughly**: Always test automation rules before activating
3. **Monitor Performance**: Track automation execution and success rates
4. **Avoid Over-Automation**: Balance automation with personal touch

### GoHighLevel Integration
1. **Webhook Security**: Always use webhook secrets for security
2. **Rate Limiting**: Respect API rate limits (100 requests per 10 seconds)
3. **Error Handling**: Implement proper error handling and retry logic
4. **Data Validation**: Validate data before syncing between systems

## Troubleshooting

### Common Issues

1. **Sync Failures**
   - Check API credentials
   - Verify webhook URL is accessible
   - Review rate limiting

2. **Automation Not Triggering**
   - Verify trigger conditions
   - Check automation rule is active
   - Review execution logs

3. **Webhook Issues**
   - Verify webhook URL in GoHighLevel
   - Check webhook secret configuration
   - Review webhook event logs

### Debugging

Enable debug logging by setting:

```env
DEBUG=crm:*,gohighlevel:*
```

Check logs in:
- `crm_automation_executions` table
- `gohighlevel_webhook_events` table
- Application logs

## Security Considerations

1. **API Keys**: Store securely, rotate regularly
2. **Webhook Security**: Use webhook secrets and signature verification
3. **Data Encryption**: Sensitive data encrypted at rest and in transit
4. **Access Control**: Role-based access to CRM features
5. **Audit Logging**: All actions logged for compliance

## Performance Optimization

1. **Database Indexing**: Proper indexes on frequently queried fields
2. **Caching**: Redis caching for frequently accessed data
3. **Background Jobs**: Async processing for heavy operations
4. **Pagination**: Implement pagination for large datasets
5. **Rate Limiting**: Respect external API limits

## Support and Maintenance

### Regular Tasks
- Monitor sync status and resolve failures
- Review automation performance and adjust rules
- Clean up old webhook events and logs
- Update API credentials as needed
- Review and optimize database performance

### Monitoring
- Set up alerts for sync failures
- Monitor API usage and rate limits
- Track automation execution success rates
- Monitor webhook delivery success

For additional support, refer to:
- GoHighLevel API Documentation
- Platform logs and error messages
- Database query performance metrics
