
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get('tenantId') || 'default';

    // Get recent automation errors
    const automationErrors = await prisma.automationError.findMany({
      where: {
        tenantId,
        resolved: false,
        createdAt: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });

    // Get system notifications
    const systemNotifications = await prisma.notification.findMany({
      where: {
        tenantId,
        type: { in: ['system_alert', 'automation_warning', 'performance_issue'] },
        status: 'pending',
        createdAt: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });

    // Generate alerts from automation errors
    const errorAlerts = automationErrors.map(error => ({
      id: `error_${error.id}`,
      type: error.severity === 'high' ? 'error' : 'warning',
      title: `${error.errorType} Error`,
      message: error.errorMessage,
      timestamp: error.createdAt.toISOString(),
      module: error.errorSource,
    }));

    // Generate alerts from system notifications
    const notificationAlerts = systemNotifications.map(notification => ({
      id: `notification_${notification.id}`,
      type: notification.type === 'system_alert' ? 'error' : 
            notification.type === 'automation_warning' ? 'warning' : 'info',
      title: notification.subject || 'System Notification',
      message: notification.content,
      timestamp: notification.createdAt.toISOString(),
      module: 'system',
    }));

    // Generate performance alerts
    const performanceAlerts = await generatePerformanceAlerts(tenantId);

    // Generate capacity alerts
    const capacityAlerts = await generateCapacityAlerts(tenantId);

    // Combine all alerts
    const allAlerts = [
      ...errorAlerts,
      ...notificationAlerts,
      ...performanceAlerts,
      ...capacityAlerts,
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return NextResponse.json({
      alerts: allAlerts.slice(0, 20), // Return top 20 alerts
      summary: {
        total: allAlerts.length,
        errors: allAlerts.filter(a => a.type === 'error').length,
        warnings: allAlerts.filter(a => a.type === 'warning').length,
        info: allAlerts.filter(a => a.type === 'info').length,
      }
    });

  } catch (error) {
    console.error('Dashboard Alerts Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve dashboard alerts' },
      { status: 500 }
    );
  }
}

async function generatePerformanceAlerts(tenantId: string): Promise<any[]> {
  const alerts = [];

  // Check voice processing performance
  const recentVoiceJobs = await prisma.voiceProcessingJob.findMany({
    where: {
      tenantId,
      createdAt: {
        gte: new Date(Date.now() - 60 * 60 * 1000) // Last hour
      }
    }
  });

  const failedVoiceJobs = recentVoiceJobs.filter(job => job.status === 'failed');
  if (failedVoiceJobs.length > 5) {
    alerts.push({
      id: `perf_voice_${Date.now()}`,
      type: 'warning',
      title: 'Voice Processing Issues',
      message: `${failedVoiceJobs.length} voice processing jobs failed in the last hour`,
      timestamp: new Date().toISOString(),
      module: 'voice_processing',
    });
  }

  // Check workflow execution performance
  const recentWorkflowExecutions = await prisma.workflowExecution.findMany({
    where: {
      rule: { tenantId },
      executedAt: {
        gte: new Date(Date.now() - 60 * 60 * 1000)
      }
    }
  });

  const failedExecutions = recentWorkflowExecutions.filter(exec => exec.status === 'failed');
  if (failedExecutions.length > 3) {
    alerts.push({
      id: `perf_workflow_${Date.now()}`,
      type: 'warning',
      title: 'Workflow Execution Issues',
      message: `${failedExecutions.length} workflow executions failed in the last hour`,
      timestamp: new Date().toISOString(),
      module: 'workflow_routing',
    });
  }

  // Check deduction prediction accuracy
  const recentPredictions = await prisma.deductionPrediction.findMany({
    where: {
      tenantId,
      createdAt: {
        gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
      }
    }
  });

  if (recentPredictions.length > 0) {
    const avgConfidence = recentPredictions.reduce((sum, p) => sum + Number(p.confidenceScore), 0) / recentPredictions.length;
    if (avgConfidence < 0.7) {
      alerts.push({
        id: `perf_deduction_${Date.now()}`,
        type: 'warning',
        title: 'Low Deduction Confidence',
        message: `Average deduction prediction confidence dropped to ${(avgConfidence * 100).toFixed(1)}%`,
        timestamp: new Date().toISOString(),
        module: 'deduction_engine',
      });
    }
  }

  return alerts;
}

async function generateCapacityAlerts(tenantId: string): Promise<any[]> {
  const alerts = [];

  // Check processing queue sizes
  const queuedVoiceJobs = await prisma.voiceProcessingJob.count({
    where: {
      tenantId,
      status: 'queued'
    }
  });

  if (queuedVoiceJobs > 50) {
    alerts.push({
      id: `capacity_voice_${Date.now()}`,
      type: 'warning',
      title: 'Voice Processing Queue Full',
      message: `${queuedVoiceJobs} voice processing jobs queued. Consider scaling resources.`,
      timestamp: new Date().toISOString(),
      module: 'voice_processing',
    });
  }

  // Check active audit cases
  const activeCases = await prisma.auditDefenseCase.count({
    where: {
      tenantId,
      caseStatus: 'active'
    }
  });

  if (activeCases > 100) {
    alerts.push({
      id: `capacity_audit_${Date.now()}`,
      type: 'info',
      title: 'High Audit Case Volume',
      message: `${activeCases} active audit defense cases. Monitor resource allocation.`,
      timestamp: new Date().toISOString(),
      module: 'audit_defense',
    });
  }

  // Check business formation requests
  const pendingFormations = await prisma.businessFormationRequest.count({
    where: {
      tenantId,
      status: { in: ['initiated', 'processing'] }
    }
  });

  if (pendingFormations > 25) {
    alerts.push({
      id: `capacity_formation_${Date.now()}`,
      type: 'info',
      title: 'High Formation Volume',
      message: `${pendingFormations} business formation requests in progress.`,
      timestamp: new Date().toISOString(),
      module: 'business_formation',
    });
  }

  return alerts;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { alertId, action } = body;

    if (action === 'dismiss') {
      // Handle alert dismissal
      if (alertId.startsWith('error_')) {
        const errorId = alertId.replace('error_', '');
        await prisma.automationError.update({
          where: { id: errorId },
          data: { resolved: true, resolvedAt: new Date() }
        });
      } else if (alertId.startsWith('notification_')) {
        const notificationId = alertId.replace('notification_', '');
        await prisma.notification.update({
          where: { id: notificationId },
          data: { status: 'read' }
        });
      }

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Alert Action Error:', error);
    return NextResponse.json(
      { error: 'Failed to process alert action' },
      { status: 500 }
    );
  }
}
