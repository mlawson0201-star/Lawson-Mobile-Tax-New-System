
'use client';

import { CheckCircle, AlertCircle, AlertTriangle } from 'lucide-react';

interface Service {
  name: string;
  status: 'operational' | 'degraded' | 'outage';
  uptime: string;
}

interface SystemStatusProps {
  services: Service[];
}

export function SystemStatus({ services }: SystemStatusProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'degraded':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'outage':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <CheckCircle className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational':
        return 'text-green-600 bg-green-50';
      case 'degraded':
        return 'text-yellow-600 bg-yellow-50';
      case 'outage':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'operational':
        return 'Operational';
      case 'degraded':
        return 'Degraded';
      case 'outage':
        return 'Outage';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="p-6">
      <div className="space-y-4">
        {services.map((service) => (
          <div key={service.name} className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {getStatusIcon(service.status)}
              <span className="text-sm font-medium text-gray-900">{service.name}</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-xs text-gray-500">{service.uptime} uptime</span>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(service.status)}`}>
                {getStatusText(service.status)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
