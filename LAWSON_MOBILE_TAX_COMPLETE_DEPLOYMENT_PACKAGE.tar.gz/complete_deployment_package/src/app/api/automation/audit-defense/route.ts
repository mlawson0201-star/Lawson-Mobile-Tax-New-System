
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { noticeType, clientId, taxReturnId, noticeContent, noticeDate } = await request.json();

    if (!clientId || !noticeType) {
      return NextResponse.json({ error: 'Client ID and notice type required' }, { status: 400 });
    }

    // Get client and tax return data
    const client = await prisma.client.findUnique({
      where: { id: clientId },
      include: {
        taxReturns: {
          where: taxReturnId ? { id: taxReturnId } : {},
          include: {
            documents: true,
            deductionSuggestions: true,
          },
          orderBy: { taxYear: 'desc' },
        },
      },
    });

    if (!client) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{
          role: 'user',
          content: `You are an expert tax professional providing automated audit defense. Analyze this IRS notice and provide a comprehensive response strategy.

Notice Type: ${noticeType}
Notice Date: ${noticeDate}
Client: ${client.firstName} ${client.lastName}

Notice Content: ${noticeContent}

Tax Return Data: ${JSON.stringify(client.taxReturns?.[0]?.formData || {})}

Provide a detailed response including:
1. Notice classification and severity level
2. Required documentation to gather
3. Step-by-step response strategy
4. Draft response letter template
5. Deadline calculations and important dates
6. Escalation triggers (when to involve human)
7. Success probability assessment

Format as JSON with structured response.`
        }],
        stream: true,
        max_tokens: 4000,
        response_format: { type: "json_object" }
      }),
    });

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = '';
        let partialRead = '';

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            let lines = partialRead.split('\n');
            partialRead = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  try {
                    const finalResult = JSON.parse(buffer);
                    
                    // Save audit defense record to database
                    await prisma.auditLog.create({
                      data: {
                        tenantId: session.user.tenantId,
                        userId: session.user.id,
                        action: 'audit_defense_generated',
                        resourceType: 'client',
                        resourceId: clientId,
                        changes: {
                          noticeType,
                          noticeDate,
                          aiResponse: finalResult,
                          automationLevel: 'advanced'
                        },
                      },
                    });

                    const finalData = JSON.stringify({
                      status: 'completed',
                      result: finalResult,
                      automationConfidence: finalResult.successProbability || 0.8
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                    return;
                  } catch (e) {
                    controller.error(e);
                    return;
                  }
                }
                try {
                  const parsed = JSON.parse(data);
                  buffer += parsed.choices?.[0]?.delta?.content || '';
                  const progressData = JSON.stringify({
                    status: 'processing',
                    message: 'Analyzing audit notice and generating defense strategy...'
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Audit defense stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Audit defense error:', error);
    return NextResponse.json(
      { error: 'Failed to generate audit defense strategy' },
      { status: 500 }
    );
  }
}
