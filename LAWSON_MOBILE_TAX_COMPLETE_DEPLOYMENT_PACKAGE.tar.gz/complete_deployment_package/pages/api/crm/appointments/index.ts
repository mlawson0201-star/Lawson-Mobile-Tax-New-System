
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { createGoHighLevelClient } from '@/lib/gohighlevel/client';
import { triggerAppointmentBooked } from '@/lib/crm/automation';
import { enqueueJob } from '@/lib/jobs/queue';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'GET':
      return handleGetAppointments(req, res, tenantId);
    case 'POST':
      return handleCreateAppointment(req, res, tenantId, session.user.id);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetAppointments(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const {
      page = '1',
      limit = '20',
      userId,
      leadId,
      status,
      startDate,
      endDate,
      sortBy = 'start_time',
      sortOrder = 'asc',
    } = req.query;

    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    const where: any = { tenant_id: tenantId };
    
    if (userId) where.user_id = userId;
    if (leadId) where.lead_id = leadId;
    if (status) where.status = status;
    
    if (startDate || endDate) {
      where.start_time = {};
      if (startDate) where.start_time.gte = new Date(startDate as string);
      if (endDate) where.start_time.lte = new Date(endDate as string);
    }

    const [appointments, total] = await Promise.all([
      prisma.crm_appointments.findMany({
        where,
        include: {
          user: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
          lead: {
            select: { id: true, first_name: true, last_name: true, email: true, phone: true },
          },
        },
        orderBy: { [sortBy as string]: sortOrder },
        skip: offset,
        take: limitNum,
      }),
      prisma.crm_appointments.count({ where }),
    ]);

    const totalPages = Math.ceil(total / limitNum);

    res.status(200).json({
      appointments,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1,
      },
    });
  } catch (error) {
    console.error('Error fetching appointments:', error);
    res.status(500).json({ error: 'Failed to fetch appointments' });
  }
}

async function handleCreateAppointment(req: NextApiRequest, res: NextApiResponse, tenantId: string, userId: string) {
  try {
    const {
      title,
      description,
      leadId,
      startTime,
      endTime,
      location,
      meetingType = 'IN_PERSON',
      meetingUrl,
      reminderMinutes = 15,
      syncToGoHighLevel = true,
    } = req.body;

    if (!title || !startTime || !endTime) {
      return res.status(400).json({ error: 'Title, start time, and end time are required' });
    }

    const appointment = await prisma.crm_appointments.create({
      data: {
        tenant_id: tenantId,
        title,
        description,
        lead_id: leadId,
        user_id: userId,
        start_time: new Date(startTime),
        end_time: new Date(endTime),
        location,
        meeting_type: meetingType,
        meeting_url: meetingUrl,
        status: 'SCHEDULED',
      },
      include: {
        user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        lead: {
          select: { id: true, first_name: true, last_name: true, email: true, phone: true, gohighlevel_contact_id: true },
        },
      },
    });

    // Sync to GoHighLevel if enabled and lead has contact ID
    if (syncToGoHighLevel && appointment.lead?.gohighlevel_contact_id) {
      try {
        const client = await createGoHighLevelClient(tenantId);
        if (client) {
          const ghlAppointment = await client.createAppointment({
            contactId: appointment.lead.gohighlevel_contact_id,
            calendarId: 'default', // You might want to make this configurable
            title: appointment.title,
            startTime: appointment.start_time.toISOString(),
            endTime: appointment.end_time.toISOString(),
            notes: appointment.description || undefined,
          });

          // Update appointment with GoHighLevel ID
          await prisma.crm_appointments.update({
            where: { id: appointment.id },
            data: { gohighlevel_appointment_id: ghlAppointment.id },
          });
        }
      } catch (error) {
        console.error('Error syncing appointment to GoHighLevel:', error);
      }
    }

    // Schedule reminder
    if (reminderMinutes > 0) {
      const reminderTime = new Date(appointment.start_time);
      reminderTime.setMinutes(reminderTime.getMinutes() - reminderMinutes);
      const delay = reminderTime.getTime() - Date.now();
      
      if (delay > 0) {
        await enqueueJob('crm.appointment.reminder', { appointmentId: appointment.id }, {
          delay,
          tenantId,
        });
      }
    }

    // Trigger automation
    try {
      await triggerAppointmentBooked(tenantId, appointment.id, leadId);
    } catch (error) {
      console.error('Error triggering appointment booked automation:', error);
    }

    res.status(201).json({ appointment });
  } catch (error) {
    console.error('Error creating appointment:', error);
    res.status(500).json({ error: 'Failed to create appointment' });
  }
}
