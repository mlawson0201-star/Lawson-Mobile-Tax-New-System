
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { AIDashboard } from '@/components/ai/ai-dashboard';

export const dynamic = "force-dynamic";

export default async function AIIntelligencePage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    redirect('/auth/signin');
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AIDashboard 
        tenantId={session.user.tenantId}
        userRole={session.user.roles?.[0] || 'client'}
      />
    </div>
  );
}
