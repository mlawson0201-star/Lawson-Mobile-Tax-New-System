
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { mlClient } from '@/lib/ml-client';
import { z } from 'zod';

const TaxPlanningRequestSchema = z.object({
  clientId: z.string(),
  taxYear: z.string(),
  quarter: z.number().min(1).max(4).optional(),
  planningType: z.enum(['quarterly', 'annual', 'multi_year']),
  optimizationGoals: z.array(z.string()),
  currentFinancialData: z.record(z.any()),
  projectedChanges: z.record(z.any()).optional(),
});

const ScenarioAnalysisRequestSchema = z.object({
  clientId: z.string(),
  baseScenario: z.record(z.any()),
  alternativeScenarios: z.array(z.record(z.any())),
  analysisType: z.enum(['tax_impact', 'cash_flow', 'comprehensive']),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;

    if (action === 'create_plan') {
      return await createTaxPlan(body);
    } else if (action === 'analyze_scenarios') {
      return await analyzeScenarios(body);
    } else if (action === 'generate_quarterly_recommendations') {
      return await generateQuarterlyRecommendations(body);
    } else if (action === 'optimize_timing') {
      return await optimizeTransactionTiming(body);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Predictive Tax Planning Error:', error);
    return NextResponse.json(
      { error: 'Tax planning operation failed', details: error.message },
      { status: 500 }
    );
  }
}

async function createTaxPlan(body: any) {
  const { clientId, taxYear, quarter, planningType, optimizationGoals, currentFinancialData, projectedChanges } = 
    TaxPlanningRequestSchema.parse(body);

  // Get client information and historical data
  const client = await prisma.client.findUnique({
    where: { id: clientId },
    include: {
      taxReturns: {
        orderBy: { taxYear: 'desc' },
        take: 3
      }
    }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  // Prepare data for ML optimization
  const entityStructure = {
    type: currentFinancialData.entityType || 'individual',
    entities: currentFinancialData.entities || [],
    ownership: currentFinancialData.ownership || {},
  };

  const financialData = {
    total_income: currentFinancialData.totalIncome || 0,
    business_income: currentFinancialData.businessIncome || 0,
    investment_income: currentFinancialData.investmentIncome || 0,
    rental_income: currentFinancialData.rentalIncome || 0,
    total_deductions: currentFinancialData.totalDeductions || 0,
    retirement_contributions: currentFinancialData.retirementContributions || 0,
    estimated_tax_payments: currentFinancialData.estimatedTaxPayments || 0,
    ...projectedChanges,
  };

  // Get ML-powered tax optimization strategies
  const optimizationResult = await mlClient.optimizeTaxStrategy({
    client_id: clientId,
    entity_structure: entityStructure,
    financial_data: financialData,
    goals: optimizationGoals,
  });

  // Calculate current and projected tax liability
  const currentLiability = calculateTaxLiability(financialData, taxYear);
  const projectedSavings = Object.values(optimizationResult.projected_savings)
    .reduce((sum, savings) => sum + (savings || 0), 0);

  // Create tax planning scenario
  const scenario = await prisma.taxPlanningScenario.create({
    data: {
      tenantId: client.tenantId,
      clientId,
      scenarioName: `${planningType.toUpperCase()} Tax Plan ${taxYear}${quarter ? ` Q${quarter}` : ''}`,
      taxYear,
      quarter,
      scenarioData: {
        currentFinancialData,
        projectedChanges: projectedChanges || {},
        optimizationGoals,
        planningType,
      },
      projectedLiability: currentLiability - projectedSavings,
      optimizationSuggestions: optimizationResult.strategies,
      confidenceScore: calculatePlanConfidence(optimizationResult),
    }
  });

  // Generate quarterly recommendations if applicable
  let quarterlyRecommendations = [];
  if (planningType === 'quarterly' || planningType === 'annual') {
    quarterlyRecommendations = await generateQuarterlyRecommendationsForPlan(
      client, scenario, optimizationResult
    );
  }

  // Create comprehensive tax plan
  const taxPlan = {
    scenario,
    currentProjections: {
      estimatedLiability: currentLiability,
      projectedSavings,
      effectiveTaxRate: (currentLiability - projectedSavings) / financialData.total_income,
      marginalTaxRate: calculateMarginalRate(financialData.total_income),
    },
    optimizationStrategies: optimizationResult.strategies.map((strategy: any) => ({
      ...strategy,
      priority: calculateStrategyPriority(strategy, optimizationGoals),
      implementationSteps: generateImplementationSteps(strategy),
      deadlines: calculateImplementationDeadlines(strategy, taxYear, quarter),
    })),
    quarterlyRecommendations,
    riskAssessment: await assessPlanningRisks(scenario, client),
    monitoringPlan: generateMonitoringPlan(planningType, optimizationGoals),
  };

  return NextResponse.json({
    success: true,
    taxPlan,
    summary: {
      totalStrategies: optimizationResult.strategies.length,
      projectedSavings,
      implementationComplexity: calculateOverallComplexity(optimizationResult.complexity_scores),
      timeToImplement: estimateImplementationTime(optimizationResult.implementation_timeline),
    }
  });
}

async function analyzeScenarios(body: any) {
  const { clientId, baseScenario, alternativeScenarios, analysisType } = 
    ScenarioAnalysisRequestSchema.parse(body);

  const client = await prisma.client.findUnique({
    where: { id: clientId }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  // Analyze base scenario
  const baseAnalysis = await analyzeScenario(baseScenario, analysisType);

  // Analyze alternative scenarios
  const alternativeAnalyses = await Promise.all(
    alternativeScenarios.map(scenario => analyzeScenario(scenario, analysisType))
  );

  // Compare scenarios
  const comparison = compareScenarios(baseAnalysis, alternativeAnalyses, analysisType);

  // Generate recommendations
  const recommendations = generateScenarioRecommendations(comparison, analysisType);

  return NextResponse.json({
    success: true,
    baseScenario: baseAnalysis,
    alternativeScenarios: alternativeAnalyses,
    comparison,
    recommendations,
    optimalScenario: findOptimalScenario([baseAnalysis, ...alternativeAnalyses]),
  });
}

async function generateQuarterlyRecommendations(body: any) {
  const { clientId, taxYear, quarter } = body;

  const client = await prisma.client.findUnique({
    where: { id: clientId },
    include: {
      taxReturns: {
        where: { taxYear },
        include: { documents: true }
      }
    }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  // Get current year-to-date information
  const ytdData = await calculateYTDFinancials(client, taxYear, quarter);

  // Project full-year results
  const projectedAnnual = projectAnnualResults(ytdData, quarter);

  // Generate quarter-specific recommendations
  const recommendations = await generateQuarterSpecificRecommendations(
    client, ytdData, projectedAnnual, quarter
  );

  // Save recommendations to database
  const savedRecommendations = await Promise.all(
    recommendations.map(rec => 
      prisma.quarterlyRecommendation.create({
        data: {
          tenantId: client.tenantId,
          clientId,
          taxYear,
          quarter,
          recommendationType: rec.type,
          description: rec.description,
          potentialSavings: rec.potentialSavings || 0,
          implementationDeadline: rec.deadline ? new Date(rec.deadline) : null,
          status: 'pending',
        }
      })
    )
  );

  return NextResponse.json({
    success: true,
    quarter,
    ytdSummary: ytdData,
    projectedAnnual,
    recommendations: savedRecommendations,
    implementationPlan: generateQuarterlyImplementationPlan(recommendations, quarter),
  });
}

async function optimizeTransactionTiming(body: any) {
  const { clientId, transactions, taxYear, optimizationGoals } = body;

  const client = await prisma.client.findUnique({
    where: { id: clientId }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  // Analyze timing options for each transaction
  const timingAnalysis = await Promise.all(
    transactions.map((transaction: any) => 
      analyzeTransactionTiming(transaction, taxYear, optimizationGoals)
    )
  );

  // Find optimal timing combination
  const optimalTiming = findOptimalTimingCombination(timingAnalysis, optimizationGoals);

  // Calculate impact of optimal timing
  const timingImpact = calculateTimingImpact(optimalTiming, transactions);

  return NextResponse.json({
    success: true,
    timingAnalysis,
    optimalTiming,
    impact: timingImpact,
    recommendations: generateTimingRecommendations(optimalTiming),
  });
}

// Helper functions
function calculateTaxLiability(financialData: any, taxYear: string): number {
  const income = financialData.total_income || 0;
  const deductions = financialData.total_deductions || 0;
  const taxableIncome = Math.max(0, income - deductions);

  // Simplified tax calculation - would use actual tax tables
  const taxBrackets2024 = [
    { min: 0, max: 11000, rate: 0.10 },
    { min: 11000, max: 44725, rate: 0.12 },
    { min: 44725, max: 95375, rate: 0.22 },
    { min: 95375, max: 182050, rate: 0.24 },
    { min: 182050, max: 231250, rate: 0.32 },
    { min: 231250, max: 578125, rate: 0.35 },
    { min: 578125, max: Infinity, rate: 0.37 },
  ];

  let tax = 0;
  let remainingIncome = taxableIncome;

  for (const bracket of taxBrackets2024) {
    if (remainingIncome <= 0) break;
    
    const taxableAtBracket = Math.min(remainingIncome, bracket.max - bracket.min);
    tax += taxableAtBracket * bracket.rate;
    remainingIncome -= taxableAtBracket;
  }

  return tax;
}

function calculateMarginalRate(income: number): number {
  const taxBrackets2024 = [
    { min: 0, max: 11000, rate: 0.10 },
    { min: 11000, max: 44725, rate: 0.12 },
    { min: 44725, max: 95375, rate: 0.22 },
    { min: 95375, max: 182050, rate: 0.24 },
    { min: 182050, max: 231250, rate: 0.32 },
    { min: 231250, max: 578125, rate: 0.35 },
    { min: 578125, max: Infinity, rate: 0.37 },
  ];

  for (const bracket of taxBrackets2024) {
    if (income >= bracket.min && income < bracket.max) {
      return bracket.rate;
    }
  }

  return 0.37; // Highest bracket
}

function calculatePlanConfidence(optimizationResult: any): number {
  const complexityScores = Object.values(optimizationResult.complexity_scores || {});
  if (complexityScores.length === 0) return 0.8;

  // Higher complexity = lower confidence
  const avgComplexity = complexityScores.reduce((sum: number, score: any) => sum + score, 0) / complexityScores.length;
  return Math.max(0.5, 1 - avgComplexity * 0.3);
}

async function generateQuarterlyRecommendationsForPlan(client: any, scenario: any, optimizationResult: any): Promise<any[]> {
  const recommendations = [];
  const currentQuarter = Math.ceil(new Date().getMonth() / 3);

  for (let q = currentQuarter; q <= 4; q++) {
    const quarterRecs = optimizationResult.strategies
      .filter((strategy: any) => canImplementInQuarter(strategy, q))
      .map((strategy: any) => ({
        quarter: q,
        type: strategy.name,
        description: `Q${q}: ${strategy.description}`,
        potentialSavings: optimizationResult.projected_savings[strategy.name] || 0,
        deadline: getQuarterEndDate(scenario.taxYear, q),
        priority: calculateStrategyPriority(strategy, scenario.scenarioData.optimizationGoals),
      }));

    recommendations.push(...quarterRecs);
  }

  return recommendations;
}

function calculateStrategyPriority(strategy: any, goals: string[]): number {
  let priority = 0.5; // Base priority

  // Increase priority based on savings potential
  if (strategy.estimated_savings > 5000) priority += 0.3;
  else if (strategy.estimated_savings > 1000) priority += 0.2;

  // Increase priority if aligns with goals
  const strategyKeywords = strategy.name.toLowerCase().split('_');
  const goalMatches = goals.filter(goal => 
    strategyKeywords.some(keyword => goal.toLowerCase().includes(keyword))
  ).length;
  priority += goalMatches * 0.1;

  // Decrease priority based on complexity
  if (strategy.implementation_difficulty === 'high') priority -= 0.2;
  else if (strategy.implementation_difficulty === 'medium') priority -= 0.1;

  return Math.max(0, Math.min(1, priority));
}

function generateImplementationSteps(strategy: any): string[] {
  const baseSteps = strategy.actions || [];
  const additionalSteps = [
    'Review current situation and gather necessary information',
    'Consult with relevant professionals if needed',
    'Execute implementation plan',
    'Monitor results and adjust as necessary',
  ];

  return [...baseSteps, ...additionalSteps];
}

function calculateImplementationDeadlines(strategy: any, taxYear: string, quarter?: number): any {
  const yearEnd = new Date(`${taxYear}-12-31`);
  const currentDate = new Date();
  
  let recommendedDeadline;
  
  switch (strategy.implementation_difficulty) {
    case 'low':
      recommendedDeadline = new Date(currentDate.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days
      break;
    case 'medium':
      recommendedDeadline = new Date(currentDate.getTime() + 90 * 24 * 60 * 60 * 1000); // 90 days
      break;
    case 'high':
      recommendedDeadline = new Date(currentDate.getTime() + 180 * 24 * 60 * 60 * 1000); // 180 days
      break;
    default:
      recommendedDeadline = new Date(currentDate.getTime() + 60 * 24 * 60 * 60 * 1000); // 60 days
  }

  // Ensure deadline is before year-end for tax benefits
  if (recommendedDeadline > yearEnd) {
    recommendedDeadline = new Date(yearEnd.getTime() - 30 * 24 * 60 * 60 * 1000);
  }

  return {
    recommended: recommendedDeadline,
    latest: yearEnd,
    quarter: quarter ? getQuarterEndDate(taxYear, quarter) : null,
  };
}

async function assessPlanningRisks(scenario: any, client: any): Promise<any> {
  return {
    implementationRisks: [
      'Market conditions may change affecting projections',
      'Tax law changes could impact strategy effectiveness',
      'Client circumstances may change during implementation',
    ],
    complianceRisks: [
      'Ensure all strategies comply with current tax regulations',
      'Document business purpose for all transactions',
      'Maintain proper records for audit defense',
    ],
    financialRisks: [
      'Cash flow impact of timing strategies',
      'Opportunity cost of deferred income',
      'Potential penalties for underpayment',
    ],
    mitigationStrategies: [
      'Regular monitoring and plan adjustments',
      'Conservative estimates in projections',
      'Professional review of complex strategies',
    ],
  };
}

function generateMonitoringPlan(planningType: string, goals: string[]): any {
  const basePlan = {
    frequency: planningType === 'quarterly' ? 'monthly' : 'quarterly',
    keyMetrics: [
      'Actual vs projected income',
      'Deduction utilization rates',
      'Tax liability progression',
      'Strategy implementation status',
    ],
    reviewTriggers: [
      'Significant income changes (>20%)',
      'New tax law changes',
      'Major life events',
      'Business structure changes',
    ],
    reportingSchedule: generateReportingSchedule(planningType),
  };

  // Customize based on goals
  if (goals.includes('minimize_current_tax')) {
    basePlan.keyMetrics.push('Current year tax savings');
  }
  if (goals.includes('retirement_planning')) {
    basePlan.keyMetrics.push('Retirement contribution utilization');
  }

  return basePlan;
}

function calculateOverallComplexity(complexityScores: Record<string, number>): string {
  const scores = Object.values(complexityScores);
  if (scores.length === 0) return 'medium';

  const avgComplexity = scores.reduce((sum, score) => sum + score, 0) / scores.length;
  
  if (avgComplexity < 0.4) return 'low';
  if (avgComplexity < 0.7) return 'medium';
  return 'high';
}

function estimateImplementationTime(timeline: Record<string, string>): string {
  const timeframes = Object.values(timeline);
  if (timeframes.length === 0) return '3-6 months';

  // Find the longest timeframe
  const maxMonths = Math.max(...timeframes.map(tf => {
    if (tf.includes('1-2')) return 2;
    if (tf.includes('3-6')) return 6;
    if (tf.includes('6-12')) return 12;
    return 6;
  }));

  if (maxMonths <= 2) return '1-2 months';
  if (maxMonths <= 6) return '3-6 months';
  return '6-12 months';
}

async function analyzeScenario(scenario: any, analysisType: string): Promise<any> {
  const analysis = {
    taxLiability: calculateTaxLiability(scenario, '2024'),
    cashFlowImpact: calculateCashFlowImpact(scenario),
    riskLevel: assessScenarioRisk(scenario),
    implementationComplexity: assessImplementationComplexity(scenario),
  };

  if (analysisType === 'comprehensive') {
    analysis['detailedBreakdown'] = generateDetailedBreakdown(scenario);
    analysis['sensitivityAnalysis'] = performSensitivityAnalysis(scenario);
  }

  return analysis;
}

function compareScenarios(baseAnalysis: any, alternativeAnalyses: any[], analysisType: string): any {
  const comparison = {
    taxSavings: alternativeAnalyses.map(alt => baseAnalysis.taxLiability - alt.taxLiability),
    cashFlowImpact: alternativeAnalyses.map(alt => alt.cashFlowImpact - baseAnalysis.cashFlowImpact),
    riskComparison: alternativeAnalyses.map(alt => ({
      base: baseAnalysis.riskLevel,
      alternative: alt.riskLevel,
      riskChange: alt.riskLevel - baseAnalysis.riskLevel,
    })),
  };

  return comparison;
}

function generateScenarioRecommendations(comparison: any, analysisType: string): string[] {
  const recommendations = [];

  // Find best tax savings scenario
  const maxSavingsIndex = comparison.taxSavings.indexOf(Math.max(...comparison.taxSavings));
  if (comparison.taxSavings[maxSavingsIndex] > 1000) {
    recommendations.push(`Scenario ${maxSavingsIndex + 1} offers the highest tax savings of $${comparison.taxSavings[maxSavingsIndex].toFixed(2)}`);
  }

  // Check for cash flow concerns
  const negativeCashFlow = comparison.cashFlowImpact.filter(impact => impact < -5000);
  if (negativeCashFlow.length > 0) {
    recommendations.push('Consider cash flow implications of scenarios with significant negative impact');
  }

  // Risk assessment
  const highRiskScenarios = comparison.riskComparison.filter(risk => risk.alternative > 0.7);
  if (highRiskScenarios.length > 0) {
    recommendations.push('High-risk scenarios require additional due diligence and professional review');
  }

  return recommendations;
}

function findOptimalScenario(analyses: any[]): any {
  // Score each scenario based on multiple factors
  const scores = analyses.map(analysis => {
    let score = 0;
    
    // Lower tax liability is better
    score += (100000 - analysis.taxLiability) / 1000;
    
    // Positive cash flow is better
    score += Math.max(0, analysis.cashFlowImpact) / 1000;
    
    // Lower risk is better
    score += (1 - analysis.riskLevel) * 10;
    
    // Lower complexity is better
    score += (1 - analysis.implementationComplexity) * 5;
    
    return score;
  });

  const maxScoreIndex = scores.indexOf(Math.max(...scores));
  return {
    index: maxScoreIndex,
    analysis: analyses[maxScoreIndex],
    score: scores[maxScoreIndex],
    reasoning: generateOptimalScenarioReasoning(analyses[maxScoreIndex]),
  };
}

// Additional helper functions would continue here...
// Due to length constraints, I'm providing the core structure

function calculateCashFlowImpact(scenario: any): number {
  // Simplified cash flow calculation
  return (scenario.income_changes || 0) - (scenario.expense_changes || 0);
}

function assessScenarioRisk(scenario: any): number {
  // Risk assessment based on scenario characteristics
  let risk = 0.3; // Base risk
  
  if (scenario.aggressive_strategies) risk += 0.3;
  if (scenario.new_entity_structures) risk += 0.2;
  if (scenario.timing_strategies) risk += 0.1;
  
  return Math.min(1, risk);
}

function assessImplementationComplexity(scenario: any): number {
  // Complexity assessment
  let complexity = 0.2; // Base complexity
  
  if (scenario.multiple_entities) complexity += 0.3;
  if (scenario.international_elements) complexity += 0.4;
  if (scenario.complex_transactions) complexity += 0.2;
  
  return Math.min(1, complexity);
}

function generateDetailedBreakdown(scenario: any): any {
  return {
    incomeBreakdown: scenario.income_sources || {},
    deductionBreakdown: scenario.deduction_categories || {},
    creditBreakdown: scenario.tax_credits || {},
    timingImpacts: scenario.timing_effects || {},
  };
}

function performSensitivityAnalysis(scenario: any): any {
  return {
    incomeVariations: [-10, -5, 0, 5, 10].map(pct => ({
      change: pct,
      taxImpact: calculateTaxLiability({
        ...scenario,
        total_income: scenario.total_income * (1 + pct / 100)
      }, '2024')
    })),
    deductionVariations: [-20, -10, 0, 10, 20].map(pct => ({
      change: pct,
      taxImpact: calculateTaxLiability({
        ...scenario,
        total_deductions: scenario.total_deductions * (1 + pct / 100)
      }, '2024')
    })),
  };
}

function generateOptimalScenarioReasoning(analysis: any): string[] {
  const reasons = [];
  
  if (analysis.taxLiability < 50000) {
    reasons.push('Achieves significant tax liability reduction');
  }
  
  if (analysis.cashFlowImpact > 0) {
    reasons.push('Maintains positive cash flow impact');
  }
  
  if (analysis.riskLevel < 0.5) {
    reasons.push('Maintains acceptable risk level');
  }
  
  if (analysis.implementationComplexity < 0.6) {
    reasons.push('Reasonable implementation complexity');
  }
  
  return reasons;
}

async function calculateYTDFinancials(client: any, taxYear: string, quarter: number): Promise<any> {
  // This would integrate with accounting systems or client-provided data
  return {
    ytdIncome: 0,
    ytdDeductions: 0,
    ytdTaxPayments: 0,
    quarterlyBreakdown: [],
  };
}

function projectAnnualResults(ytdData: any, quarter: number): any {
  const multiplier = 4 / quarter; // Simple projection
  
  return {
    projectedIncome: ytdData.ytdIncome * multiplier,
    projectedDeductions: ytdData.ytdDeductions * multiplier,
    projectedTaxLiability: 0, // Would calculate based on projections
    estimatedRefund: 0,
  };
}

async function generateQuarterSpecificRecommendations(client: any, ytdData: any, projectedAnnual: any, quarter: number): Promise<any[]> {
  const recommendations = [];
  
  // Quarter-specific recommendations based on timing
  switch (quarter) {
    case 1:
      recommendations.push({
        type: 'retirement_contribution',
        description: 'Maximize Q1 retirement contributions for tax benefits',
        potentialSavings: 2000,
        deadline: `${new Date().getFullYear()}-03-31`,
      });
      break;
    case 2:
      recommendations.push({
        type: 'estimated_tax_payment',
        description: 'Review and adjust Q2 estimated tax payments',
        potentialSavings: 0,
        deadline: `${new Date().getFullYear()}-06-15`,
      });
      break;
    case 3:
      recommendations.push({
        type: 'tax_loss_harvesting',
        description: 'Consider tax loss harvesting before year-end',
        potentialSavings: 1500,
        deadline: `${new Date().getFullYear()}-12-31`,
      });
      break;
    case 4:
      recommendations.push({
        type: 'year_end_planning',
        description: 'Execute year-end tax planning strategies',
        potentialSavings: 3000,
        deadline: `${new Date().getFullYear()}-12-31`,
      });
      break;
  }
  
  return recommendations;
}

function generateQuarterlyImplementationPlan(recommendations: any[], quarter: number): any {
  return {
    currentQuarter: quarter,
    immediateActions: recommendations.filter(r => r.priority > 0.7),
    upcomingActions: recommendations.filter(r => r.priority <= 0.7 && r.priority > 0.4),
    futureActions: recommendations.filter(r => r.priority <= 0.4),
    timeline: generateImplementationTimeline(recommendations),
  };
}

function generateImplementationTimeline(recommendations: any[]): any[] {
  return recommendations
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .map(rec => ({
      action: rec.description,
      deadline: rec.deadline,
      priority: rec.priority,
      estimatedTime: '2-4 hours', // Would be more sophisticated
    }));
}

async function analyzeTransactionTiming(transaction: any, taxYear: string, goals: string[]): Promise<any> {
  const timingOptions = ['current_year', 'next_year', 'installment'];
  
  const analysis = await Promise.all(
    timingOptions.map(async timing => {
      const impact = await calculateTimingImpact({ ...transaction, timing }, [transaction]);
      return {
        timing,
        taxImpact: impact.taxSavings,
        cashFlowImpact: impact.cashFlowImpact,
        riskLevel: assessTimingRisk(transaction, timing),
      };
    })
  );

  return {
    transaction: transaction.id,
    timingOptions: analysis,
    recommendation: findOptimalTiming(analysis, goals),
  };
}

function findOptimalTimingCombination(timingAnalyses: any[], goals: string[]): any {
  // This would use optimization algorithms to find the best combination
  // For now, returning a simplified version
  
  return timingAnalyses.map(analysis => ({
    transactionId: analysis.transaction,
    optimalTiming: analysis.recommendation,
    reasoning: `Best timing based on ${goals.join(', ')} goals`,
  }));
}

function calculateTimingImpact(optimalTiming: any, transactions: any[]): any {
  return {
    taxSavings: 5000, // Simplified calculation
    cashFlowImpact: 2000,
    implementationComplexity: 0.6,
    riskLevel: 0.4,
  };
}

function generateTimingRecommendations(optimalTiming: any): string[] {
  return [
    'Execute transactions according to optimal timing schedule',
    'Monitor market conditions that may affect timing decisions',
    'Prepare documentation for all timed transactions',
    'Consider cash flow implications of timing decisions',
  ];
}

function canImplementInQuarter(strategy: any, quarter: number): boolean {
  // Determine if strategy can be implemented in given quarter
  const currentQuarter = Math.ceil(new Date().getMonth() / 3);
  
  if (quarter < currentQuarter) return false;
  
  const timeRequired = strategy.implementation_difficulty === 'high' ? 2 : 1; // quarters
  return (quarter - currentQuarter) >= timeRequired - 1;
}

function getQuarterEndDate(taxYear: string, quarter: number): string {
  const quarterEndMonths = [3, 6, 9, 12];
  const month = quarterEndMonths[quarter - 1];
  const lastDay = new Date(parseInt(taxYear), month, 0).getDate();
  
  return `${taxYear}-${month.toString().padStart(2, '0')}-${lastDay}`;
}

function generateReportingSchedule(planningType: string): any[] {
  const schedule = [];
  
  if (planningType === 'quarterly') {
    for (let q = 1; q <= 4; q++) {
      schedule.push({
        quarter: q,
        reportType: 'Quarterly Tax Planning Review',
        dueDate: getQuarterEndDate('2024', q),
        keyMetrics: ['YTD performance', 'Quarterly projections', 'Strategy adjustments'],
      });
    }
  } else {
    schedule.push({
      period: 'Annual',
      reportType: 'Annual Tax Planning Review',
      dueDate: '2024-12-31',
      keyMetrics: ['Annual performance', 'Strategy effectiveness', 'Next year planning'],
    });
  }
  
  return schedule;
}

function assessTimingRisk(transaction: any, timing: string): number {
  let risk = 0.3; // Base risk
  
  if (timing === 'installment') risk += 0.2;
  if (transaction.amount > 100000) risk += 0.1;
  if (transaction.type === 'business_sale') risk += 0.2;
  
  return Math.min(1, risk);
}

function findOptimalTiming(analysis: any[], goals: string[]): any {
  // Score each timing option
  const scores = analysis.map(option => {
    let score = 0;
    
    if (goals.includes('minimize_current_tax')) {
      score += option.taxImpact > 0 ? option.taxImpact / 1000 : 0;
    }
    
    if (goals.includes('maximize_cash_flow')) {
      score += Math.max(0, option.cashFlowImpact) / 1000;
    }
    
    // Penalize high risk
    score -= option.riskLevel * 5;
    
    return score;
  });

  const maxScoreIndex = scores.indexOf(Math.max(...scores));
  return analysis[maxScoreIndex];
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const clientId = searchParams.get('clientId');
    const tenantId = searchParams.get('tenantId');
    const taxYear = searchParams.get('taxYear');

    if (!clientId && !tenantId) {
      return NextResponse.json({ error: 'clientId or tenantId required' }, { status: 400 });
    }

    let whereClause: any = {};
    
    if (clientId) {
      whereClause.clientId = clientId;
    } else {
      whereClause.tenantId = tenantId;
    }
    
    if (taxYear) {
      whereClause.taxYear = taxYear;
    }

    const scenarios = await prisma.taxPlanningScenario.findMany({
      where: whereClause,
      include: {
        client: {
          select: { firstName: true, lastName: true, email: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const recommendations = await prisma.quarterlyRecommendation.findMany({
      where: clientId ? { clientId } : { tenantId },
      orderBy: { createdAt: 'desc' },
      take: 20
    });

    return NextResponse.json({
      scenarios,
      recommendations,
      summary: {
        totalScenarios: scenarios.length,
        totalProjectedSavings: scenarios.reduce((sum, s) => sum + (s.projectedLiability || 0), 0),
        pendingRecommendations: recommendations.filter(r => r.status === 'pending').length,
        averageConfidence: scenarios.reduce((sum, s) => sum + (s.confidenceScore || 0), 0) / scenarios.length,
      }
    });

  } catch (error) {
    console.error('Get Tax Planning Data Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve tax planning data' },
      { status: 500 }
    );
  }
}
