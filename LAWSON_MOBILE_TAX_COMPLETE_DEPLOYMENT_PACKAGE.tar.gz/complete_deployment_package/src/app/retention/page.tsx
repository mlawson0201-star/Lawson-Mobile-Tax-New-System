
'use client';

import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, AlertTriangle, TrendingUp, Users } from 'lucide-react';

// Import our new components
import LoyaltyDashboard from '@/components/retention/loyalty-program/loyalty-dashboard';
import ChurnPredictionDashboard from '@/components/retention/churn-prevention/churn-prediction-dashboard';

// Mock data
const mockLoyaltyProgram = {
  id: '1',
  name: 'Lawson Rewards Program',
  description: 'Earn points for every interaction and redeem for valuable rewards',
  pointsPerDollar: 10,
  tiers: [
    {
      id: 'bronze',
      name: 'Bronze',
      minPoints: 0,
      benefits: ['Basic rewards', 'Email support', 'Standard processing'],
      multiplier: 1.0,
      color: '#CD7F32',
      icon: 'trophy'
    },
    {
      id: 'silver',
      name: 'Silver',
      minPoints: 1000,
      benefits: ['20% bonus rewards', 'Priority support', 'Exclusive content', 'Early access'],
      multiplier: 1.2,
      color: '#C0C0C0',
      icon: 'star'
    },
    {
      id: 'gold',
      name: 'Gold',
      minPoints: 5000,
      benefits: ['50% bonus rewards', 'Dedicated support', 'VIP events', 'Custom solutions'],
      multiplier: 1.5,
      color: '#FFD700',
      icon: 'crown'
    },
    {
      id: 'platinum',
      name: 'Platinum',
      minPoints: 15000,
      benefits: ['100% bonus rewards', 'Personal account manager', 'Exclusive perks', 'Beta access'],
      multiplier: 2.0,
      color: '#E5E4E2',
      icon: 'sparkles'
    }
  ],
  rewards: [
    {
      id: '1',
      name: '$25 Account Credit',
      description: 'Credit applied to your next tax service',
      pointsCost: 2500,
      type: 'discount' as const,
      value: 25,
      isAvailable: true,
      redemptionCount: 45,
      maxRedemptions: 100
    },
    {
      id: '2',
      name: 'Free State Return',
      description: 'Complimentary state tax return filing',
      pointsCost: 7900,
      type: 'service' as const,
      value: 79,
      isAvailable: true,
      redemptionCount: 23,
      maxRedemptions: 50
    },
    {
      id: '3',
      name: 'Tax Planning Session',
      description: '30-minute consultation with a tax professional',
      pointsCost: 15000,
      type: 'service' as const,
      value: 150,
      isAvailable: true,
      redemptionCount: 8,
      maxRedemptions: 20
    },
    {
      id: '4',
      name: 'Amazon Gift Card',
      description: '$50 Amazon gift card',
      pointsCost: 5000,
      type: 'gift' as const,
      value: 50,
      isAvailable: true,
      redemptionCount: 67,
      maxRedemptions: 200
    }
  ],
  rules: [
    'Points expire after 24 months of inactivity',
    'Minimum redemption is 500 points',
    'Points cannot be transferred between accounts',
    'Bonus points may take up to 48 hours to appear'
  ],
  isActive: true,
  memberCount: 12847
};

const mockClientPoints = {
  clientId: 'client123',
  totalPoints: 3750,
  availablePoints: 3250,
  lifetimePoints: 8900,
  currentTier: 'silver',
  nextTierPoints: 1250,
  pointsHistory: [
    {
      id: '1',
      clientId: 'client123',
      type: 'earned' as const,
      points: 500,
      description: 'Completed tax return',
      createdAt: new Date('2024-03-15')
    },
    {
      id: '2',
      clientId: 'client123',
      type: 'earned' as const,
      points: 1000,
      description: 'Referred a friend',
      createdAt: new Date('2024-03-10')
    },
    {
      id: '3',
      clientId: 'client123',
      type: 'redeemed' as const,
      points: -500,
      description: 'Redeemed $25 account credit',
      referenceId: 'reward-1',
      createdAt: new Date('2024-03-08')
    },
    {
      id: '4',
      clientId: 'client123',
      type: 'earned' as const,
      points: 250,
      description: 'Completed learning module',
      createdAt: new Date('2024-03-05')
    },
    {
      id: '5',
      clientId: 'client123',
      type: 'bonus' as const,
      points: 200,
      description: 'Silver tier bonus points',
      createdAt: new Date('2024-03-01')
    }
  ],
  lastUpdated: new Date()
};

const mockChurnPredictions = [
  {
    clientId: 'client001',
    riskScore: 85,
    riskLevel: 'critical' as const,
    factors: [
      {
        factor: 'Login Frequency',
        weight: 0.25,
        value: 15,
        impact: 'negative' as const,
        description: 'Last login was 45 days ago'
      },
      {
        factor: 'Support Issues',
        weight: 0.20,
        value: 20,
        impact: 'negative' as const,
        description: '5 support tickets in last 30 days'
      },
      {
        factor: 'Task Completion',
        weight: 0.20,
        value: 30,
        impact: 'negative' as const,
        description: '30% task completion rate'
      },
      {
        factor: 'Payment History',
        weight: 0.15,
        value: 60,
        impact: 'negative' as const,
        description: '2 late payments in history'
      }
    ],
    recommendations: [
      'Schedule immediate personal outreach call',
      'Offer exclusive discount or service upgrade',
      'Assign dedicated success manager'
    ],
    lastCalculated: new Date('2024-03-20'),
    interventionStatus: 'none' as const
  },
  {
    clientId: 'client002',
    riskScore: 65,
    riskLevel: 'high' as const,
    factors: [
      {
        factor: 'Engagement Score',
        weight: 0.25,
        value: 40,
        impact: 'negative' as const,
        description: 'Overall engagement score of 40%'
      },
      {
        factor: 'Login Frequency',
        weight: 0.20,
        value: 70,
        impact: 'positive' as const,
        description: 'Last login was 7 days ago'
      }
    ],
    recommendations: [
      'Send personalized re-engagement email',
      'Provide additional onboarding support',
      'Offer value demonstration session'
    ],
    lastCalculated: new Date('2024-03-19'),
    interventionStatus: 'scheduled' as const
  },
  {
    clientId: 'client003',
    riskScore: 35,
    riskLevel: 'medium' as const,
    factors: [
      {
        factor: 'Task Completion',
        weight: 0.20,
        value: 75,
        impact: 'positive' as const,
        description: '75% task completion rate'
      }
    ],
    recommendations: [
      'Send check-in email',
      'Provide educational content'
    ],
    lastCalculated: new Date('2024-03-18'),
    interventionStatus: 'none' as const
  }
];

const mockRetentionCampaigns = [
  {
    id: '1',
    name: 'Win-Back Campaign Q1',
    description: 'Re-engage clients who haven\'t logged in for 30+ days',
    targetSegment: 'Inactive clients',
    triggerConditions: ['No login for 30 days', 'No task completion in 45 days'],
    actions: [],
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-03-31'),
    isActive: true,
    metrics: {
      targeted: 245,
      reached: 198,
      engaged: 87,
      retained: 34,
      cost: 1250,
      roi: 2.8
    }
  },
  {
    id: '2',
    name: 'High-Value Client Retention',
    description: 'Proactive outreach to high-value clients showing churn signals',
    targetSegment: 'High-value at-risk',
    triggerConditions: ['LTV > $1000', 'Churn risk > 60%'],
    actions: [],
    startDate: new Date('2024-02-01'),
    isActive: true,
    metrics: {
      targeted: 67,
      reached: 64,
      engaged: 52,
      retained: 41,
      cost: 2100,
      roi: 4.2
    }
  }
];

export default function RetentionPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const handleRedeemReward = (rewardId: string) => {
    console.log('Redeem reward:', rewardId);
  };

  const handleEarnPoints = (points: number, description: string) => {
    console.log('Earn points:', { points, description });
  };

  const handleCreateCampaign = (prediction: any) => {
    console.log('Create campaign for prediction:', prediction);
  };

  const handleUpdateIntervention = (clientId: string, status: string) => {
    console.log('Update intervention:', { clientId, status });
  };

  const handleScheduleOutreach = (clientId: string, method: string) => {
    console.log('Schedule outreach:', { clientId, method });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Client Retention Hub
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl">
          Build lasting relationships with comprehensive retention strategies, loyalty programs, 
          and AI-powered churn prevention that keeps clients engaged year-round.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Client Retention Rate</p>
                <p className="text-2xl font-bold text-green-600">94.2%</p>
                <p className="text-xs text-green-600">↑ 2.1% from last year</p>
              </div>
              <Users className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Loyalty Members</p>
                <p className="text-2xl font-bold text-blue-600">12,847</p>
                <p className="text-xs text-blue-600">↑ 847 this month</p>
              </div>
              <Trophy className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">At-Risk Clients</p>
                <p className="text-2xl font-bold text-red-600">127</p>
                <p className="text-xs text-red-600">↓ 23 from last month</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg. Client LTV</p>
                <p className="text-2xl font-bold text-purple-600">$1,847</p>
                <p className="text-xs text-purple-600">↑ $127 from last quarter</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="loyalty">Loyalty Program</TabsTrigger>
          <TabsTrigger value="churn-prevention">Churn Prevention</TabsTrigger>
          <TabsTrigger value="campaigns">Retention Campaigns</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Retention Performance</CardTitle>
                <CardDescription>
                  Key metrics showing client retention success
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-green-900">12-Month Retention</p>
                      <p className="text-sm text-green-700">Clients retained after 1 year</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">94.2%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-blue-900">Loyalty Participation</p>
                      <p className="text-sm text-blue-700">Clients in loyalty program</p>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">78.5%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <p className="font-medium text-purple-900">Upsell Success Rate</p>
                      <p className="text-sm text-purple-700">Additional services sold</p>
                    </div>
                    <Badge className="bg-purple-100 text-purple-800">34.7%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium text-orange-900">Referral Rate</p>
                      <p className="text-sm text-orange-700">Clients who refer others</p>
                    </div>
                    <Badge className="bg-orange-100 text-orange-800">23.1%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Retention Strategies</CardTitle>
                <CardDescription>
                  Active strategies driving client retention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">Loyalty Rewards Program</h4>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Points-based system with tier benefits and exclusive rewards
                    </p>
                    <div className="text-xs text-gray-500">
                      12,847 members • 78.5% participation rate
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">AI Churn Prevention</h4>
                      <Badge className="bg-blue-100 text-blue-800">Active</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Predictive analytics to identify and prevent client churn
                    </p>
                    <div className="text-xs text-gray-500">
                      127 at-risk clients • 73% intervention success rate
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">Value-Added Services</h4>
                      <Badge className="bg-purple-100 text-purple-800">Active</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      Additional services that create stickiness and increase LTV
                    </p>
                    <div className="text-xs text-gray-500">
                      8 service offerings • 34.7% uptake rate
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Retention Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Retention Insights</CardTitle>
              <CardDescription>
                Key insights and trends in client retention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Trophy className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Loyalty Impact</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Loyalty program members have 2.3x higher retention rates and 40% higher LTV
                  </p>
                  <Badge variant="outline">+130% LTV increase</Badge>
                </div>
                
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Early Intervention</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    AI-powered churn prediction allows intervention 60 days before typical churn
                  </p>
                  <Badge variant="outline">73% success rate</Badge>
                </div>
                
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Personalization</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Personalized experiences increase retention by 25% and satisfaction by 35%
                  </p>
                  <Badge variant="outline">+25% retention</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="loyalty">
          <LoyaltyDashboard
            program={mockLoyaltyProgram}
            clientPoints={mockClientPoints}
            availableRewards={mockLoyaltyProgram.rewards}
            pointsHistory={mockClientPoints.pointsHistory}
            onRedeemReward={handleRedeemReward}
            onEarnPoints={handleEarnPoints}
          />
        </TabsContent>

        <TabsContent value="churn-prevention">
          <ChurnPredictionDashboard
            predictions={mockChurnPredictions}
            campaigns={mockRetentionCampaigns}
            onCreateCampaign={handleCreateCampaign}
            onUpdateIntervention={handleUpdateIntervention}
            onScheduleOutreach={handleScheduleOutreach}
          />
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900">Retention Campaigns</h3>
              <p className="text-gray-600 mt-2">
                Automated campaigns designed to retain and re-engage clients
              </p>
            </div>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Create Campaign
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mockRetentionCampaigns.map((campaign) => (
              <Card key={campaign.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{campaign.name}</CardTitle>
                      <CardDescription>{campaign.description}</CardDescription>
                    </div>
                    <Badge className={campaign.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {campaign.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Target Segment</p>
                      <p className="font-medium">{campaign.targetSegment}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Duration</p>
                      <p className="font-medium">
                        {new Date(campaign.startDate).toLocaleDateString()} - 
                        {campaign.endDate ? new Date(campaign.endDate).toLocaleDateString() : 'Ongoing'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-medium text-gray-900">Performance Metrics</h5>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="text-center p-2 bg-blue-50 rounded">
                        <p className="font-bold text-blue-600">{campaign.metrics.targeted}</p>
                        <p className="text-gray-600">Targeted</p>
                      </div>
                      <div className="text-center p-2 bg-green-50 rounded">
                        <p className="font-bold text-green-600">{campaign.metrics.retained}</p>
                        <p className="text-gray-600">Retained</p>
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-purple-600">
                        {campaign.metrics.targeted > 0 
                          ? ((campaign.metrics.retained / campaign.metrics.targeted) * 100).toFixed(1)
                          : 0
                        }%
                      </p>
                      <p className="text-sm text-gray-600">Success Rate</p>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <button className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50">
                      View Details
                    </button>
                    <button className="flex-1 px-3 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700">
                      {campaign.isActive ? 'Pause' : 'Activate'}
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
