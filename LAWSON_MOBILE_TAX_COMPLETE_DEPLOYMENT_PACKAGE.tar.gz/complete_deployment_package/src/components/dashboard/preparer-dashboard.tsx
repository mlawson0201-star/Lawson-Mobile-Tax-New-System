
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  User,
  Calendar,
  TrendingUp
} from 'lucide-react';
import { MetricCard } from '@/components/ui/metric-card';
import { formatDate, getStatusColor } from '@/lib/utils';

export function PreparerDashboard() {
  const { data: session } = useSession() || {};
  const [metrics, setMetrics] = useState({
    assignedReturns: 0,
    completedToday: 0,
    totalCompleted: 0,
    avgCompletionTime: 0
  });
  
  const [assignedReturns, setAssignedReturns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading preparer data
    const timer = setTimeout(() => {
      setMetrics({
        assignedReturns: 15,
        completedToday: 4,
        totalCompleted: 78,
        avgCompletionTime: 180
      });
      
      setAssignedReturns([
        {
          id: '1',
          clientName: 'Jennifer Smith',
          taxYear: '2024',
          status: 'in_progress',
          assignedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          complexity: 'standard'
        },
        {
          id: '2',
          clientName: 'Robert Johnson',
          taxYear: '2024',
          status: 'documents_pending',
          assignedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
          complexity: 'simple'
        },
        {
          id: '3',
          clientName: 'Maria Garcia',
          taxYear: '2024',
          status: 'ready_to_file',
          assignedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
          dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
          complexity: 'complex'
        }
      ]);
      
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'simple':
        return 'bg-green-100 text-green-800';
      case 'standard':
        return 'bg-blue-100 text-blue-800';
      case 'complex':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="h-8 bg-gray-200 rounded w-64 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-96 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="h-6 bg-gray-200 rounded w-32 mb-4 animate-pulse"></div>
              <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          Welcome, {session?.user?.name?.split(' ')[0]}!
        </h1>
        <p className="mt-2 text-gray-600">
          Manage your assigned tax returns and track your progress
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Assigned Returns"
          value={metrics.assignedReturns}
          icon={FileText}
          description="Active assignments"
          className="border-l-4 border-blue-500"
        />
        <MetricCard
          title="Completed Today"
          value={metrics.completedToday}
          icon={CheckCircle}
          trend={{ value: 14.2, isPositive: true }}
          description="Returns finished today"
          className="border-l-4 border-green-500"
        />
        <MetricCard
          title="Total Completed"
          value={metrics.totalCompleted}
          icon={User}
          trend={{ value: 8.7, isPositive: true }}
          description="This season's total"
        />
        <MetricCard
          title="Avg Completion"
          value={`${Math.round(metrics.avgCompletionTime / 60)}h`}
          icon={Clock}
          description="Per return"
        />
      </div>

      {/* Today's Schedule */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-100 rounded-lg p-6 mb-8">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Today's Goals
            </h2>
            <p className="text-gray-600 mb-4">
              Complete {6 - metrics.completedToday} more returns to reach your daily goal.
            </p>
            <div className="w-full bg-white rounded-full h-3 mb-4">
              <div 
                className="bg-green-600 h-3 rounded-full transition-all duration-300" 
                style={{ width: `${(metrics.completedToday / 6) * 100}%` }}
              ></div>
            </div>
            <div className="text-sm text-gray-600">
              {metrics.completedToday}/6 returns completed
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">
              {Math.round((metrics.completedToday / 6) * 100)}%
            </div>
            <div className="text-sm text-gray-500">Daily Progress</div>
          </div>
        </div>
      </div>

      {/* Assigned Returns */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Assigned Tax Returns</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Complexity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Assigned
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {assignedReturns.map((returnItem) => (
                <tr key={returnItem.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{returnItem.clientName}</div>
                      <div className="text-sm text-gray-500">{returnItem.taxYear} Tax Return</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(returnItem.status)}`}>
                      {returnItem.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getComplexityColor(returnItem.complexity)}`}>
                      {returnItem.complexity}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(returnItem.assignedAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className={returnItem.dueDate < new Date() ? 'text-red-600 font-medium' : ''}>
                      {formatDate(returnItem.dueDate)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors">
                      Work on Return
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center">
            <TrendingUp className="h-5 w-5 text-gray-400 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Your Performance</h2>
          </div>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">4.8/5</div>
              <div className="text-sm text-gray-600 mt-1">Quality Rating</div>
              <div className="text-xs text-gray-500">Based on reviews</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">15.2</div>
              <div className="text-sm text-gray-600 mt-1">Returns/Week</div>
              <div className="text-xs text-gray-500">Above average</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">97%</div>
              <div className="text-sm text-gray-600 mt-1">Accuracy Rate</div>
              <div className="text-xs text-gray-500">No errors found</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="flex items-center justify-center px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
              <FileText className="h-5 w-5 mr-2" />
              Start New Return
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors">
              <Calendar className="h-5 w-5 mr-2" />
              View Schedule
            </button>
            <button className="flex items-center justify-center px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors">
              <TrendingUp className="h-5 w-5 mr-2" />
              View Reports
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
