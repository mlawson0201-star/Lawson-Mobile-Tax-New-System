
# Lawson Mobile Tax - Landing Page Copy

## Hero Section

### Primary Headline
**"Get Your Taxes Done Right, From Anywhere"**

### Secondary Headline
**"Professional tax preparation with maximum refunds guaranteed. Mobile-first, AI-powered, and trusted by thousands."**

### Value Proposition
- ✅ **Maximum Refund Guarantee** - We find every deduction you deserve
- ✅ **Mobile-First Experience** - Complete your taxes on any device
- ✅ **AI-Powered Accuracy** - Advanced technology ensures precision
- ✅ **Expert Review** - Every return reviewed by licensed professionals
- ✅ **Audit Defense Included** - Full protection and representation

### Call-to-Action
**"Start Your Tax Return - $485"**
*"No hidden fees. Pay only when satisfied."*

---

## Problem/Solution Section

### The Problem
**"Traditional tax preparation is broken"**

- Expensive office visits during limited hours
- Long wait times and rushed service
- Hidden fees and upselling tactics
- One-size-fits-all approach
- No guarantee on accuracy or refunds

### Our Solution
**"Modern tax preparation designed for your life"**

- Complete your taxes anytime, anywhere
- AI extracts data from your documents instantly
- Transparent, flat-rate pricing
- Personalized service with dedicated support
- Maximum refund and accuracy guarantees

---

## Features & Benefits

### 🤖 AI-Powered Document Processing
**"Upload. Extract. Done."**
Simply photograph or upload your tax documents. Our AI instantly extracts all relevant information, eliminating manual data entry and reducing errors.

### 📱 Mobile-First Design
**"Tax prep that fits your schedule"**
Start on your phone during lunch, continue on your tablet at home, finish on your laptop. Your progress syncs seamlessly across all devices.

### 👨‍💼 Expert Professional Review
**"Licensed professionals, not software"**
Every return is reviewed by IRS-enrolled agents and CPAs with years of experience. Get the expertise of a high-end firm at an affordable price.

### 💰 Maximum Refund Guarantee
**"We find money others miss"**
Our tax professionals and AI work together to identify every possible deduction and credit. If you find a larger refund elsewhere, we'll match it plus $100.

### 🛡️ Audit Defense Protection
**"Sleep easy knowing you're covered"**
Full audit support and representation included at no extra cost. If the IRS comes knocking, we'll handle everything.

### ⚡ Fast E-Filing
**"Filed in 24 hours or less"**
Most returns are reviewed and e-filed within 24 hours. Get your refund faster with direct deposit setup included.

---

## Pricing Section

### Individual Returns
**Starting at $485**
*Everything you need for a complete tax return*

**What's Included:**
- Complete Form 1040 preparation
- State return (additional $79)
- Unlimited support and revisions
- Expert professional review
- E-filing with IRS and state
- Audit defense protection
- Maximum refund guarantee
- Direct deposit setup

### Add-On Services
- **Schedule C (Business):** +$149
- **Investment Income:** +$99 (up to 50 trades)
- **Rental Properties:** +$129 (first property)
- **Additional State Returns:** $79 each
- **Rush Processing:** +$99 (same-day filing)

### Business Services
- **Monthly Bookkeeping:** Starting at $249/month
- **Quarterly Tax Planning:** $99/quarter
- **Tax Resolution Services:** $250 retainer + 10% of resolved balance

---

## Social Proof Section

### Customer Testimonials

**"Best tax service I've ever used!"**
*"The mobile app made everything so easy. I completed my entire return during my commute and got a $3,200 refund - $400 more than last year!"*
— Sarah M., Marketing Manager

**"Found deductions I never knew existed"**
*"Their tax professional found business deductions worth $1,800 that TurboTax completely missed. The audit protection gives me peace of mind."*
— Mike R., Small Business Owner

**"Incredibly fast and professional"**
*"Uploaded my documents on Monday, return was filed by Tuesday afternoon. Got my refund in 8 days. Will definitely use again!"*
— Jennifer L., Teacher

### Trust Indicators
- ⭐⭐⭐⭐⭐ **4.9/5 stars** from 2,847 reviews
- 🏆 **#1 Rated** mobile tax service
- 🔒 **Bank-level security** with 256-bit encryption
- 📊 **$47M in refunds** processed this year
- 🎯 **99.7% accuracy rate** on filed returns

---

## FAQ Section

### How does the mobile tax preparation work?
Simply download our app or visit our website, create an account, and follow our step-by-step process. Upload photos of your tax documents, answer a few questions, and our AI will prepare your return. A licensed professional reviews everything before filing.

### What if I have complex taxes?
Our platform handles everything from simple W-2s to complex business returns, rental properties, investments, and more. If your situation is too complex for our platform, we'll refer you to a specialist at no charge.

### How do you guarantee maximum refunds?
Our combination of AI technology and expert review ensures we find every deduction and credit you're entitled to. If another service finds a larger legitimate refund, we'll match it plus pay you $100.

### Is my information secure?
Yes. We use bank-level 256-bit encryption, multi-factor authentication, and are fully compliant with IRS security standards. Your data is never shared or sold.

### What happens if I get audited?
Audit defense is included with every return. If the IRS selects your return for audit, we'll represent you at no additional cost, including correspondence and in-person meetings.

### Can I speak with a real person?
Absolutely. Every client gets access to their dedicated tax professional via phone, email, or chat. Our support team is available 7 days a week during tax season.

---

## Call-to-Action Section

### Final CTA
**"Join thousands of satisfied customers"**

**"Start Your Tax Return Today"**
*Simple. Fast. Guaranteed.*

**[Get Started - $485]**

*✅ No hidden fees*
*✅ Maximum refund guarantee*
*✅ Audit defense included*
*✅ Money-back guarantee*

### Contact Information
- **Phone:** 1-800-LAWSON-TAX
- **Email:** support@lawsonmobiletax.com
- **Live Chat:** Available 7 days a week
- **Office Hours:** Mon-Fri 8AM-8PM EST, Weekends 10AM-6PM EST

---

## Trust & Security Footer

### Credentials
- IRS Authorized e-file Provider
- Licensed in all 50 states
- A+ Rating with Better Business Bureau
- Member of National Association of Tax Professionals

### Security & Privacy
- SOC 2 Type II Certified
- GLBA Compliant
- 256-bit SSL encryption
- Annual security audits
- Zero data sharing policy

### Guarantees
- Maximum refund guarantee
- 100% accuracy guarantee
- Audit defense protection
- 30-day money-back guarantee
- Same-day filing available

---

*Last Updated: August 22, 2025*
*© 2025 Lawson Mobile Tax. All rights reserved.*
