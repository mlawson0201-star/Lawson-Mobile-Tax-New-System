
import ComplexReturnProcessor from '@/components/automation/complex-return-processor';

export const dynamic = 'force-dynamic';

export default function ComplexReturnsPage() {
  return (
    <div className="space-y-8">
      <ComplexReturnProcessor />
    </div>
  );
}
