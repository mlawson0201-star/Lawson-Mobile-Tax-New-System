
"""
Lawson Mobile Tax - Social Media Automation Platform
Comprehensive social media posting and automation system for all major platforms
"""

__version__ = "1.0.0"
__author__ = "Lawson Mobile Tax"
