
"""
Global Expansion Capabilities
International tax support and localization features
"""

from .multi_country_engine import MultiCountryTaxEngine
from .currency_converter import CurrencyConversionEngine
from .treaty_optimizer import InternationalTreatyOptimizer
from .expat_services import ExpatTaxServices
from .multi_language import MultiLanguageSupport
from .professional_network import LocalProfessionalNetwork
from .business_compliance import CrossBorderBusinessCompliance
from .investment_reporter import InternationalInvestmentReporter
from .payroll_integrator import GlobalPayrollIntegrator
from .transfer_pricing import TransferPricingDocumentation

__version__ = "1.0.0"
__all__ = [
    "MultiCountryTaxEngine",
    "CurrencyConversionEngine",
    "InternationalTreatyOptimizer",
    "ExpatTaxServices",
    "MultiLanguageSupport",
    "LocalProfessionalNetwork",
    "CrossBorderBusinessCompliance",
    "InternationalInvestmentReporter",
    "GlobalPayrollIntegrator",
    "TransferPricingDocumentation"
]
