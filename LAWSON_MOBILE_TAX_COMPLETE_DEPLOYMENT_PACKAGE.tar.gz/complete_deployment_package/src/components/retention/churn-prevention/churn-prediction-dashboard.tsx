
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  AlertTriangle, TrendingDown, Users, Target, 
  Mail, Phone, Gift, Calendar, Activity, 
  CheckCircle, Clock, ArrowUp, ArrowDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Area, AreaChart
} from 'recharts';
import { ChurnPrediction, RetentionCampaign } from '@/lib/types/retention';

interface ChurnPredictionDashboardProps {
  predictions: ChurnPrediction[];
  campaigns: RetentionCampaign[];
  onCreateCampaign: (prediction: ChurnPrediction) => void;
  onUpdateIntervention: (clientId: string, status: string) => void;
  onScheduleOutreach: (clientId: string, method: string) => void;
}

const RISK_COLORS = {
  low: 'text-green-600 bg-green-100',
  medium: 'text-yellow-600 bg-yellow-100',
  high: 'text-orange-600 bg-orange-100',
  critical: 'text-red-600 bg-red-100'
};

const RISK_THRESHOLDS = {
  low: { min: 0, max: 25 },
  medium: { min: 25, max: 50 },
  high: { min: 50, max: 75 },
  critical: { min: 75, max: 100 }
};

const COLORS = ['#10B981', '#F59E0B', '#F97316', '#EF4444'];

const INTERVENTION_STRATEGIES = {
  critical: [
    { type: 'personal_call', label: 'Personal Call', icon: Phone, urgency: 'immediate' },
    { type: 'executive_outreach', label: 'Executive Outreach', icon: Users, urgency: 'immediate' },
    { type: 'special_offer', label: 'Special Retention Offer', icon: Gift, urgency: 'immediate' }
  ],
  high: [
    { type: 'account_manager', label: 'Account Manager Call', icon: Phone, urgency: 'within_24h' },
    { type: 'personalized_email', label: 'Personalized Email', icon: Mail, urgency: 'within_24h' },
    { type: 'value_demonstration', label: 'Value Demonstration', icon: Target, urgency: 'within_48h' }
  ],
  medium: [
    { type: 'check_in_email', label: 'Check-in Email', icon: Mail, urgency: 'within_week' },
    { type: 'educational_content', label: 'Educational Content', icon: Activity, urgency: 'within_week' },
    { type: 'survey_feedback', label: 'Feedback Survey', icon: CheckCircle, urgency: 'within_week' }
  ],
  low: [
    { type: 'newsletter', label: 'Newsletter Inclusion', icon: Mail, urgency: 'monthly' },
    { type: 'tips_content', label: 'Helpful Tips', icon: Activity, urgency: 'monthly' }
  ]
};

export default function ChurnPredictionDashboard({
  predictions,
  campaigns,
  onCreateCampaign,
  onUpdateIntervention,
  onScheduleOutreach
}: ChurnPredictionDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedRiskLevel, setSelectedRiskLevel] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'risk' | 'lastCalculated'>('risk');

  // Calculate risk distribution
  const riskDistribution = Object.keys(RISK_COLORS).map(level => ({
    name: level.charAt(0).toUpperCase() + level.slice(1),
    value: predictions.filter(p => p.riskLevel === level).length,
    color: COLORS[Object.keys(RISK_COLORS).indexOf(level)]
  }));

  // Filter and sort predictions
  const filteredPredictions = predictions
    .filter(p => selectedRiskLevel === 'all' || p.riskLevel === selectedRiskLevel)
    .sort((a, b) => {
      if (sortBy === 'risk') {
        return b.riskScore - a.riskScore;
      }
      return new Date(b.lastCalculated).getTime() - new Date(a.lastCalculated).getTime();
    });

  // Calculate metrics
  const totalAtRisk = predictions.filter(p => p.riskLevel === 'high' || p.riskLevel === 'critical').length;
  const averageRiskScore = predictions.reduce((sum, p) => sum + p.riskScore, 0) / predictions.length;
  const interventionsNeeded = predictions.filter(p => p.interventionStatus === 'none' && p.riskLevel !== 'low').length;

  // Trend data (mock)
  const trendData = [
    { month: 'Jan', atRisk: 12, retained: 8 },
    { month: 'Feb', atRisk: 15, retained: 11 },
    { month: 'Mar', atRisk: 18, retained: 14 },
    { month: 'Apr', atRisk: 14, retained: 16 },
    { month: 'May', atRisk: 11, retained: 18 },
    { month: 'Jun', atRisk: 9, retained: 20 }
  ];

  const handleInterventionAction = (prediction: ChurnPrediction, actionType: string) => {
    switch (actionType) {
      case 'personal_call':
      case 'account_manager':
        onScheduleOutreach(prediction.clientId, 'phone');
        break;
      case 'personalized_email':
      case 'check_in_email':
        onScheduleOutreach(prediction.clientId, 'email');
        break;
      case 'special_offer':
        onCreateCampaign(prediction);
        break;
      default:
        onUpdateIntervention(prediction.clientId, 'scheduled');
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'immediate': return 'text-red-600 bg-red-100';
      case 'within_24h': return 'text-orange-600 bg-orange-100';
      case 'within_48h': return 'text-yellow-600 bg-yellow-100';
      case 'within_week': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getInterventionStatusColor = (status: string) => {
    switch (status) {
      case 'none': return 'text-red-600 bg-red-100';
      case 'scheduled': return 'text-yellow-600 bg-yellow-100';
      case 'in_progress': return 'text-blue-600 bg-blue-100';
      case 'completed': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Churn Prevention Dashboard</h2>
          <p className="text-gray-600 mt-2">
            AI-powered client retention insights and intervention strategies
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => window.location.reload()}>
            Refresh Predictions
          </Button>
          <Button>
            Create Campaign
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Clients</p>
                <p className="text-2xl font-bold text-gray-900">{predictions.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">At Risk</p>
                <p className="text-2xl font-bold text-red-600">{totalAtRisk}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Risk Score</p>
                <p className="text-2xl font-bold text-orange-600">{averageRiskScore.toFixed(1)}</p>
              </div>
              <TrendingDown className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Need Intervention</p>
                <p className="text-2xl font-bold text-purple-600">{interventionsNeeded}</p>
              </div>
              <Target className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="interventions">Interventions</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Risk Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Distribution</CardTitle>
                <CardDescription>
                  Current client risk levels across your portfolio
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Retention Trends</CardTitle>
                <CardDescription>
                  Monthly at-risk vs retained clients
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="atRisk" stackId="1" stroke="#EF4444" fill="#FEE2E2" />
                    <Area type="monotone" dataKey="retained" stackId="1" stroke="#10B981" fill="#D1FAE5" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* High Priority Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <span>High Priority Alerts</span>
              </CardTitle>
              <CardDescription>
                Clients requiring immediate attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictions
                  .filter(p => p.riskLevel === 'critical')
                  .slice(0, 5)
                  .map((prediction) => (
                    <div key={prediction.clientId} className="flex items-center justify-between p-4 border border-red-200 bg-red-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                          <AlertTriangle className="w-6 h-6 text-red-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">Client #{prediction.clientId}</h4>
                          <p className="text-sm text-gray-600">
                            Risk Score: {prediction.riskScore}% • Last updated: {new Date(prediction.lastCalculated).toLocaleDateString()}
                          </p>
                          <div className="flex space-x-2 mt-1">
                            {prediction.factors.slice(0, 2).map((factor, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {factor.factor}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          Take Action
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions" className="space-y-6">
          {/* Filters */}
          <div className="flex justify-between items-center">
            <div className="flex space-x-4">
              <select
                value={selectedRiskLevel}
                onChange={(e) => setSelectedRiskLevel(e.target.value)}
                className="border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="all">All Risk Levels</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'risk' | 'lastCalculated')}
                className="border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="risk">Sort by Risk Score</option>
                <option value="lastCalculated">Sort by Last Updated</option>
              </select>
            </div>
            <Badge variant="outline">
              {filteredPredictions.length} clients
            </Badge>
          </div>

          {/* Predictions List */}
          <div className="space-y-4">
            {filteredPredictions.map((prediction) => (
              <Card key={prediction.clientId} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-gray-600" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900">Client #{prediction.clientId}</h4>
                          <div className="flex items-center space-x-3 mt-1">
                            <Badge className={RISK_COLORS[prediction.riskLevel]}>
                              {prediction.riskLevel.toUpperCase()} RISK
                            </Badge>
                            <Badge className={getInterventionStatusColor(prediction.interventionStatus)}>
                              {prediction.interventionStatus.replace('_', ' ')}
                            </Badge>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h5 className="font-medium text-gray-900 mb-2">Risk Score</h5>
                          <div className="flex items-center space-x-3">
                            <Progress value={prediction.riskScore} className="flex-1 h-3" />
                            <span className="text-lg font-bold text-red-600">{prediction.riskScore}%</span>
                          </div>
                        </div>

                        <div>
                          <h5 className="font-medium text-gray-900 mb-2">Key Risk Factors</h5>
                          <div className="space-y-1">
                            {prediction.factors.slice(0, 3).map((factor, index) => (
                              <div key={index} className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">{factor.factor}</span>
                                <div className="flex items-center space-x-2">
                                  <span className={factor.impact === 'negative' ? 'text-red-600' : 'text-green-600'}>
                                    {factor.impact === 'negative' ? <ArrowDown className="w-3 h-3" /> : <ArrowUp className="w-3 h-3" />}
                                  </span>
                                  <span className="font-medium">{factor.value}%</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="mt-4">
                        <h5 className="font-medium text-gray-900 mb-2">Recommended Actions</h5>
                        <div className="flex flex-wrap gap-2">
                          {prediction.recommendations.slice(0, 3).map((rec, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {rec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="ml-6 text-right">
                      <p className="text-sm text-gray-600 mb-2">
                        Last updated: {new Date(prediction.lastCalculated).toLocaleDateString()}
                      </p>
                      <div className="space-y-2">
                        <Button size="sm" variant="outline">
                          View Full Analysis
                        </Button>
                        <Button 
                          size="sm" 
                          className={prediction.riskLevel === 'critical' ? 'bg-red-600 hover:bg-red-700' : ''}
                        >
                          Create Intervention
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="interventions" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Intervention Strategies
            </h3>
            <p className="text-gray-600">
              Recommended actions based on client risk levels
            </p>
          </div>

          {Object.entries(INTERVENTION_STRATEGIES).map(([riskLevel, strategies]) => (
            <Card key={riskLevel}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Badge className={RISK_COLORS[riskLevel as keyof typeof RISK_COLORS]}>
                    {riskLevel.toUpperCase()} RISK
                  </Badge>
                  <span>Intervention Strategies</span>
                </CardTitle>
                <CardDescription>
                  {predictions.filter(p => p.riskLevel === riskLevel).length} clients in this category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {strategies.map((strategy, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <strategy.icon className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{strategy.label}</h4>
                          <Badge className={getUrgencyColor(strategy.urgency)} variant="outline">
                            {strategy.urgency.replace('_', ' ')}
                          </Badge>
                          <div className="mt-3">
                            <Button 
                              size="sm" 
                              className="w-full"
                              onClick={() => {
                                // Find a client with this risk level for demo
                                const client = predictions.find(p => p.riskLevel === riskLevel);
                                if (client) {
                                  handleInterventionAction(client, strategy.type);
                                }
                              }}
                            >
                              Execute Strategy
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-900">Retention Campaigns</h3>
            <Button>
              Create New Campaign
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {campaigns.map((campaign) => (
              <Card key={campaign.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{campaign.name}</CardTitle>
                      <CardDescription>{campaign.description}</CardDescription>
                    </div>
                    <Badge className={campaign.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {campaign.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Target Segment</p>
                      <p className="font-medium">{campaign.targetSegment}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Duration</p>
                      <p className="font-medium">
                        {new Date(campaign.startDate).toLocaleDateString()} - 
                        {campaign.endDate ? new Date(campaign.endDate).toLocaleDateString() : 'Ongoing'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-medium text-gray-900">Performance Metrics</h5>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="text-center p-2 bg-blue-50 rounded">
                        <p className="font-bold text-blue-600">{campaign.metrics.targeted}</p>
                        <p className="text-gray-600">Targeted</p>
                      </div>
                      <div className="text-center p-2 bg-green-50 rounded">
                        <p className="font-bold text-green-600">{campaign.metrics.retained}</p>
                        <p className="text-gray-600">Retained</p>
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-purple-600">
                        {campaign.metrics.targeted > 0 
                          ? ((campaign.metrics.retained / campaign.metrics.targeted) * 100).toFixed(1)
                          : 0
                        }%
                      </p>
                      <p className="text-sm text-gray-600">Success Rate</p>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      View Details
                    </Button>
                    <Button size="sm" className="flex-1">
                      {campaign.isActive ? 'Pause' : 'Activate'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
