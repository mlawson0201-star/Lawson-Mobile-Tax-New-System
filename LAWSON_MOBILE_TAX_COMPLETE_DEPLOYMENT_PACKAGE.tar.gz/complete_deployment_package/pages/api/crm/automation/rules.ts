
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { AutomationTrigger, AutomationAction } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'GET':
      return handleGetRules(req, res, tenantId);
    case 'POST':
      return handleCreateRule(req, res, tenantId, session.user.id);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetRules(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const { active, triggerType } = req.query;

    const where: any = { tenant_id: tenantId };
    if (active !== undefined) where.is_active = active === 'true';
    if (triggerType) where.trigger_type = triggerType;

    const rules = await prisma.crm_automation_rules.findMany({
      where,
      include: {
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        _count: {
          select: { executions: true },
        },
      },
      orderBy: { created_at: 'desc' },
    });

    res.status(200).json({ rules });
  } catch (error) {
    console.error('Error fetching automation rules:', error);
    res.status(500).json({ error: 'Failed to fetch automation rules' });
  }
}

async function handleCreateRule(req: NextApiRequest, res: NextApiResponse, tenantId: string, userId: string) {
  try {
    const {
      name,
      description,
      triggerType,
      triggerConditions = {},
      actions,
      isActive = true,
    } = req.body;

    if (!name || !triggerType || !actions || !Array.isArray(actions)) {
      return res.status(400).json({ error: 'Name, trigger type, and actions are required' });
    }

    // Validate trigger type
    if (!Object.values(AutomationTrigger).includes(triggerType)) {
      return res.status(400).json({ error: 'Invalid trigger type' });
    }

    // Validate actions
    for (const action of actions) {
      if (!action.type || !Object.values(AutomationAction).includes(action.type)) {
        return res.status(400).json({ error: 'Invalid action type' });
      }
    }

    const rule = await prisma.crm_automation_rules.create({
      data: {
        tenant_id: tenantId,
        name,
        description,
        trigger_type: triggerType,
        trigger_conditions: triggerConditions,
        actions,
        is_active: isActive,
        created_by: userId,
      },
      include: {
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
      },
    });

    res.status(201).json({ rule });
  } catch (error) {
    console.error('Error creating automation rule:', error);
    res.status(500).json({ error: 'Failed to create automation rule' });
  }
}
