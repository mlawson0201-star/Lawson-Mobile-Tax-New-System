
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Settings, 
  Zap, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Copy, 
  ExternalLink,
  AlertTriangle,
  Info
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface GoHighLevelSettingsProps {
  tenantId: string;
}

export function GoHighLevelSettings({ tenantId }: GoHighLevelSettingsProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [settings, setSettings] = useState({
    configured: false,
    locationId: '',
    syncEnabled: false,
    syncContacts: true,
    syncAppointments: true,
    syncMessages: true,
    autoCreateLeads: true,
    webhookUrl: '',
    lastSyncAt: null,
  });
  
  const [formData, setFormData] = useState({
    apiKey: '',
    locationId: '',
    webhookSecret: '',
    syncEnabled: false,
    syncContacts: true,
    syncAppointments: true,
    syncMessages: true,
    autoCreateLeads: true,
  });

  const [syncStatus, setSyncStatus] = useState({
    configured: false,
    syncEnabled: false,
    lastSyncAt: null,
  });

  useEffect(() => {
    fetchSettings();
    fetchSyncStatus();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/gohighlevel/settings');
      if (response.ok) {
        const data = await response.json();
        setSettings(data.settings);
        setFormData({
          apiKey: '', // Don't populate API key for security
          locationId: data.settings.locationId || '',
          webhookSecret: '',
          syncEnabled: data.settings.syncEnabled,
          syncContacts: data.settings.syncContacts,
          syncAppointments: data.settings.syncAppointments,
          syncMessages: data.settings.syncMessages,
          autoCreateLeads: data.settings.autoCreateLeads,
        });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const fetchSyncStatus = async () => {
    try {
      const response = await fetch('/api/gohighlevel/sync');
      if (response.ok) {
        const data = await response.json();
        setSyncStatus(data.syncStatus);
      }
    } catch (error) {
      console.error('Error fetching sync status:', error);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = async () => {
    if (!formData.apiKey && !settings.configured) {
      toast({
        title: 'Error',
        description: 'API key is required',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/gohighlevel/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setSettings(prev => ({ ...prev, ...data.settings }));
        toast({
          title: 'Settings Saved',
          description: 'GoHighLevel settings have been updated successfully.',
        });
      } else {
        throw new Error(data.error || 'Failed to save settings');
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save settings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    if (!formData.apiKey && !settings.configured) {
      toast({
        title: 'Error',
        description: 'Please enter an API key first',
        variant: 'destructive',
      });
      return;
    }

    setTesting(true);
    try {
      // Test connection by trying to save settings
      const response = await fetch('/api/gohighlevel/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, testOnly: true }),
      });

      if (response.ok) {
        toast({
          title: 'Connection Successful',
          description: 'Successfully connected to GoHighLevel API.',
        });
      } else {
        const data = await response.json();
        throw new Error(data.error || 'Connection failed');
      }
    } catch (error) {
      console.error('Error testing connection:', error);
      toast({
        title: 'Connection Failed',
        description: error instanceof Error ? error.message : 'Failed to connect to GoHighLevel',
        variant: 'destructive',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const response = await fetch('/api/gohighlevel/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'all' }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: 'Sync Completed',
          description: `Synced ${data.result.contactsSynced} contacts and ${data.result.appointmentsSynced} appointments.`,
        });
        fetchSyncStatus();
      } else {
        throw new Error(data.error || 'Sync failed');
      }
    } catch (error) {
      console.error('Error syncing:', error);
      toast({
        title: 'Sync Failed',
        description: error instanceof Error ? error.message : 'Failed to sync with GoHighLevel',
        variant: 'destructive',
      });
    } finally {
      setSyncing(false);
    }
  };

  const copyWebhookUrl = () => {
    if (settings.webhookUrl) {
      navigator.clipboard.writeText(settings.webhookUrl);
      toast({
        title: 'Copied',
        description: 'Webhook URL copied to clipboard',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">GoHighLevel Integration</h1>
          <p className="text-muted-foreground">
            Configure your GoHighLevel integration for seamless CRM synchronization
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {settings.configured ? (
            <Badge variant="default" className="bg-green-100 text-green-800">
              <CheckCircle className="mr-1 h-3 w-3" />
              Connected
            </Badge>
          ) : (
            <Badge variant="secondary" className="bg-red-100 text-red-800">
              <XCircle className="mr-1 h-3 w-3" />
              Not Connected
            </Badge>
          )}
        </div>
      </div>

      {/* Status Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Connection Status</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {settings.configured ? 'Connected' : 'Disconnected'}
            </div>
            <p className="text-xs text-muted-foreground">
              {settings.configured ? 'API integration active' : 'Setup required'}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sync Status</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {settings.syncEnabled ? 'Enabled' : 'Disabled'}
            </div>
            <p className="text-xs text-muted-foreground">
              {settings.lastSyncAt 
                ? `Last sync: ${new Date(settings.lastSyncAt).toLocaleDateString()}`
                : 'Never synced'
              }
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Location ID</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {settings.locationId ? '✓' : '✗'}
            </div>
            <p className="text-xs text-muted-foreground">
              {settings.locationId ? 'Configured' : 'Not set'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="settings" className="space-y-4">
        <TabsList>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="sync">Sync & Webhooks</TabsTrigger>
          <TabsTrigger value="help">Setup Guide</TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API Configuration</CardTitle>
              <CardDescription>
                Configure your GoHighLevel API credentials and basic settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="apiKey">API Key *</Label>
                  <Input
                    id="apiKey"
                    type="password"
                    placeholder={settings.configured ? "••••••••••••••••" : "Enter your GoHighLevel API key"}
                    value={formData.apiKey}
                    onChange={(e) => handleInputChange('apiKey', e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Your GoHighLevel API key (keep this secure)
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="locationId">Location ID *</Label>
                  <Input
                    id="locationId"
                    placeholder="Enter your GoHighLevel Location ID"
                    value={formData.locationId}
                    onChange={(e) => handleInputChange('locationId', e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Found in your GoHighLevel settings
                  </p>
                </div>
              </div>
              
              <div>
                <Label htmlFor="webhookSecret">Webhook Secret (Optional)</Label>
                <Input
                  id="webhookSecret"
                  type="password"
                  placeholder="Enter webhook secret for security"
                  value={formData.webhookSecret}
                  onChange={(e) => handleInputChange('webhookSecret', e.target.value)}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Used to verify webhook authenticity (recommended)
                </p>
              </div>
              
              <div className="flex space-x-2">
                <Button onClick={handleSaveSettings} disabled={loading}>
                  {loading ? 'Saving...' : 'Save Settings'}
                </Button>
                <Button variant="outline" onClick={handleTestConnection} disabled={testing}>
                  {testing ? 'Testing...' : 'Test Connection'}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sync Options</CardTitle>
              <CardDescription>
                Configure what data should be synchronized between systems
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="syncEnabled">Enable Synchronization</Label>
                  <p className="text-sm text-muted-foreground">
                    Master switch for all GoHighLevel synchronization
                  </p>
                </div>
                <Switch
                  id="syncEnabled"
                  checked={formData.syncEnabled}
                  onCheckedChange={(checked) => handleInputChange('syncEnabled', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="syncContacts">Sync Contacts</Label>
                  <p className="text-sm text-muted-foreground">
                    Synchronize contacts/leads between systems
                  </p>
                </div>
                <Switch
                  id="syncContacts"
                  checked={formData.syncContacts}
                  onCheckedChange={(checked) => handleInputChange('syncContacts', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="syncAppointments">Sync Appointments</Label>
                  <p className="text-sm text-muted-foreground">
                    Synchronize appointments and calendar events
                  </p>
                </div>
                <Switch
                  id="syncAppointments"
                  checked={formData.syncAppointments}
                  onCheckedChange={(checked) => handleInputChange('syncAppointments', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="syncMessages">Sync Messages</Label>
                  <p className="text-sm text-muted-foreground">
                    Synchronize SMS and email communications
                  </p>
                </div>
                <Switch
                  id="syncMessages"
                  checked={formData.syncMessages}
                  onCheckedChange={(checked) => handleInputChange('syncMessages', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="autoCreateLeads">Auto-Create Leads</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically create leads from GoHighLevel contacts
                  </p>
                </div>
                <Switch
                  id="autoCreateLeads"
                  checked={formData.autoCreateLeads}
                  onCheckedChange={(checked) => handleInputChange('autoCreateLeads', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Manual Sync</CardTitle>
              <CardDescription>
                Manually trigger synchronization with GoHighLevel
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!settings.configured && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Please configure your API settings first before attempting to sync.
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Full Synchronization</h4>
                  <p className="text-sm text-muted-foreground">
                    Sync all contacts, appointments, and messages
                  </p>
                </div>
                <Button 
                  onClick={handleSync} 
                  disabled={syncing || !settings.configured}
                >
                  {syncing ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Syncing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Sync Now
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Webhook Configuration</CardTitle>
              <CardDescription>
                Set up webhooks in GoHighLevel for real-time synchronization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {settings.webhookUrl ? (
                <div>
                  <Label>Webhook URL</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Input
                      value={settings.webhookUrl}
                      readOnly
                      className="font-mono text-sm"
                    />
                    <Button variant="outline" size="sm" onClick={copyWebhookUrl}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Add this URL to your GoHighLevel webhook settings
                  </p>
                </div>
              ) : (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Save your API settings first to generate a webhook URL.
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <h4 className="font-medium">Recommended Webhook Events</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• ContactCreate - When new contacts are added</li>
                  <li>• ContactUpdate - When contact information changes</li>
                  <li>• AppointmentCreate - When appointments are scheduled</li>
                  <li>• AppointmentUpdate - When appointments are modified</li>
                  <li>• InboundMessage - When messages are received</li>
                  <li>• OutboundMessage - When messages are sent</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="help" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Setup Guide</CardTitle>
              <CardDescription>
                Step-by-step instructions to set up your GoHighLevel integration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    1
                  </div>
                  <div>
                    <h4 className="font-medium">Get Your API Key</h4>
                    <p className="text-sm text-muted-foreground">
                      Log into your GoHighLevel account and navigate to Settings → API Keys. 
                      Create a new API key with the necessary permissions.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    2
                  </div>
                  <div>
                    <h4 className="font-medium">Find Your Location ID</h4>
                    <p className="text-sm text-muted-foreground">
                      In GoHighLevel, go to Settings → Business Profile. 
                      Your Location ID is displayed in the URL or settings page.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    3
                  </div>
                  <div>
                    <h4 className="font-medium">Configure Settings</h4>
                    <p className="text-sm text-muted-foreground">
                      Enter your API key and Location ID in the Settings tab above, 
                      then test the connection to ensure everything works.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    4
                  </div>
                  <div>
                    <h4 className="font-medium">Set Up Webhooks</h4>
                    <p className="text-sm text-muted-foreground">
                      Copy the webhook URL from the Sync tab and add it to your 
                      GoHighLevel webhook settings for real-time synchronization.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                    5
                  </div>
                  <div>
                    <h4 className="font-medium">Enable Sync</h4>
                    <p className="text-sm text-muted-foreground">
                      Turn on synchronization and perform an initial sync to 
                      import your existing GoHighLevel data.
                    </p>
                  </div>
                </div>
              </div>
              
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Need help?</strong> Check the GoHighLevel API documentation or 
                  contact support if you encounter any issues during setup.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
