
'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { IntakeForm } from '@/components/tax-prep/intake-form'
import { DocumentUpload } from '@/components/tax-prep/document-upload'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, FileText, Upload, CreditCard } from 'lucide-react'
import { toast } from 'react-hot-toast'
// Force dynamic rendering
export const dynamic = 'force-dynamic';

const STEPS = [
  { id: 'intake', name: 'Client Intake', icon: FileText },
  { id: 'documents', name: 'Document Upload', icon: Upload },
  { id: 'review', name: 'Review & Payment', icon: CreditCard },
  { id: 'complete', name: 'Complete', icon: CheckCircle },
]

export default function TaxPrepPage() {
  const { data: session } = useSession()
  const [currentStep, setCurrentStep] = useState('intake')
  const [taxReturnId, setTaxReturnId] = useState<string | null>(null)
  const [clientData, setClientData] = useState<any>(null)

  const handleIntakeSubmit = async (data: any) => {
    try {
      // Create client first
      const clientResponse = await fetch('/api/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })

      if (!clientResponse.ok) {
        throw new Error('Failed to create client')
      }

      const client = await clientResponse.json()

      // Create tax return
      const taxReturnResponse = await fetch('/api/tax-returns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId: client.id,
          taxYear: 2024,
          filingStatus: data.filingStatus,
          returnType: 'INDIVIDUAL',
        }),
      })

      if (!taxReturnResponse.ok) {
        throw new Error('Failed to create tax return')
      }

      const taxReturn = await taxReturnResponse.json()
      
      setClientData(client)
      setTaxReturnId(taxReturn.id)
      setCurrentStep('documents')
      toast.success('Client intake completed successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to create tax return. Please try again.')
    }
  }

  const handleDocumentUploadComplete = () => {
    setCurrentStep('review')
    toast.success('Documents uploaded successfully!')
  }

  const handlePayment = async () => {
    if (!taxReturnId) return

    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taxReturnId,
          amount: 48500, // $485.00 in cents
          description: 'Tax preparation service',
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to create payment')
      }

      const { payment, clientSecret } = await response.json()
      
      // In a real app, you would integrate with Stripe Elements here
      // For now, we'll simulate payment completion
      setTimeout(() => {
        setCurrentStep('complete')
        toast.success('Payment processed successfully!')
      }, 2000)
    } catch (error) {
      console.error('Error:', error)
      toast.error('Payment failed. Please try again.')
    }
  }

  const getCurrentStepIndex = () => {
    return STEPS.findIndex(step => step.id === currentStep)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => {
              const Icon = step.icon
              const isActive = step.id === currentStep
              const isCompleted = index < getCurrentStepIndex()
              
              return (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                      isCompleted
                        ? 'bg-green-500 border-green-500 text-white'
                        : isActive
                        ? 'bg-blue-500 border-blue-500 text-white'
                        : 'bg-white border-gray-300 text-gray-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span
                    className={`ml-2 text-sm font-medium ${
                      isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                    }`}
                  >
                    {step.name}
                  </span>
                  {index < STEPS.length - 1 && (
                    <div
                      className={`w-16 h-0.5 mx-4 ${
                        isCompleted ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                    />
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 'intake' && (
          <IntakeForm onSubmit={handleIntakeSubmit} />
        )}

        {currentStep === 'documents' && taxReturnId && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload Your Tax Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Please upload all relevant tax documents for {clientData?.firstName} {clientData?.lastName}.
                  Our AI will automatically extract and organize the information.
                </p>
              </CardContent>
            </Card>
            
            <DocumentUpload
              taxReturnId={taxReturnId}
              onUploadComplete={handleDocumentUploadComplete}
            />
            
            <div className="flex justify-end">
              <Button onClick={handleDocumentUploadComplete}>
                Continue to Review
              </Button>
            </div>
          </div>
        )}

        {currentStep === 'review' && (
          <Card>
            <CardHeader>
              <CardTitle>Review & Payment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Service Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Individual Tax Return (1040)</span>
                    <span>$485.00</span>
                  </div>
                  <div className="border-t pt-2 font-semibold">
                    <div className="flex justify-between">
                      <span>Total</span>
                      <span>$485.00</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">What's Included</h3>
                <ul className="text-blue-700 space-y-1">
                  <li>• Complete tax return preparation</li>
                  <li>• Electronic filing with IRS</li>
                  <li>• Maximum refund guarantee</li>
                  <li>• Audit support protection</li>
                  <li>• Direct deposit setup</li>
                </ul>
              </div>

              <Button onClick={handlePayment} className="w-full" size="lg">
                Process Payment - $485.00
              </Button>
            </CardContent>
          </Card>
        )}

        {currentStep === 'complete' && (
          <Card>
            <CardHeader>
              <CardTitle className="text-center text-green-600">
                Tax Return Submitted Successfully!
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <p className="text-gray-600">
                Your tax return has been submitted and payment processed. 
                You'll receive email updates on the status of your return.
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Next Steps</h3>
                <ul className="text-left space-y-1">
                  <li>• Your return will be reviewed by our tax professionals</li>
                  <li>• E-filing typically occurs within 24-48 hours</li>
                  <li>• Refunds are usually processed in 8-21 days</li>
                  <li>• You'll receive copies of all filed documents</li>
                </ul>
              </div>
              <Button onClick={() => window.location.href = '/dashboard'}>
                Go to Dashboard
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
