
"""
FastAPI main application for social media automation
"""
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import json
import logging
from sqlalchemy.orm import Session

from config import settings, PLATFORM_CONFIGS
from database import get_db, Post, SocialAccount, Campaign, ContentTemplate, Analytics
from platform_adapters import PlatformAdapterFactory
from scheduler import SocialMediaScheduler, post_to_platform, generate_content
from ai_content import AIContentGenerator
from analytics import AnalyticsCollector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Lawson Mobile Tax - Social Media Automation",
    description="Comprehensive social media automation platform for all major platforms",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Initialize components
scheduler = SocialMediaScheduler()
ai_generator = AIContentGenerator()
analytics_collector = AnalyticsCollector()

# Pydantic models
class PostCreate(BaseModel):
    content: str
    platforms: List[str]
    hashtags: Optional[List[str]] = []
    media_urls: Optional[List[str]] = []
    scheduled_time: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = {}

class CampaignCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    start_date: datetime
    end_date: Optional[datetime] = None
    platforms: List[str]
    content_templates: Optional[List[int]] = []
    posting_schedule: Optional[Dict[str, Any]] = {}

class ContentTemplateCreate(BaseModel):
    name: str
    category: str
    template_text: str
    platforms: List[str]
    hashtags: Optional[Dict[str, List[str]]] = {}
    media_requirements: Optional[Dict[str, Any]] = {}

class SocialAccountCreate(BaseModel):
    platform: str
    account_name: str
    account_id: str
    access_token: str
    refresh_token: Optional[str] = None
    token_expires_at: Optional[datetime] = None

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Initialize the application"""
    try:
        await scheduler.start()
        logger.info("Social media automation platform started successfully")
    except Exception as e:
        logger.error(f"Error starting application: {str(e)}")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    try:
        await scheduler.stop()
        logger.info("Social media automation platform stopped")
    except Exception as e:
        logger.error(f"Error stopping application: {str(e)}")

# Web interface routes
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """Main dashboard"""
    try:
        # Get dashboard statistics
        total_posts = db.query(Post).count()
        active_accounts = db.query(SocialAccount).filter(SocialAccount.is_active == True).count()
        active_campaigns = db.query(Campaign).filter(Campaign.is_active == True).count()
        
        # Get recent posts
        recent_posts = db.query(Post).order_by(Post.created_at.desc()).limit(10).all()
        
        # Get platform statistics
        platform_stats = {}
        for platform in PLATFORM_CONFIGS.keys():
            platform_posts = db.query(Post).filter(Post.platform == platform).count()
            platform_stats[platform] = platform_posts
        
        return templates.TemplateResponse("dashboard.html", {
            "request": request,
            "total_posts": total_posts,
            "active_accounts": active_accounts,
            "active_campaigns": active_campaigns,
            "recent_posts": recent_posts,
            "platform_stats": platform_stats,
            "platform_configs": PLATFORM_CONFIGS
        })
        
    except Exception as e:
        logger.error(f"Error loading dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail="Error loading dashboard")

@app.get("/posts", response_class=HTMLResponse)
async def posts_page(request: Request, db: Session = Depends(get_db)):
    """Posts management page"""
    try:
        posts = db.query(Post).order_by(Post.created_at.desc()).all()
        accounts = db.query(SocialAccount).filter(SocialAccount.is_active == True).all()
        
        return templates.TemplateResponse("posts.html", {
            "request": request,
            "posts": posts,
            "accounts": accounts,
            "platform_configs": PLATFORM_CONFIGS
        })
        
    except Exception as e:
        logger.error(f"Error loading posts page: {str(e)}")
        raise HTTPException(status_code=500, detail="Error loading posts page")

@app.get("/campaigns", response_class=HTMLResponse)
async def campaigns_page(request: Request, db: Session = Depends(get_db)):
    """Campaigns management page"""
    try:
        campaigns = db.query(Campaign).order_by(Campaign.created_at.desc()).all()
        templates_list = db.query(ContentTemplate).filter(ContentTemplate.is_active == True).all()
        
        return templates.TemplateResponse("campaigns.html", {
            "request": request,
            "campaigns": campaigns,
            "templates": templates_list,
            "platform_configs": PLATFORM_CONFIGS
        })
        
    except Exception as e:
        logger.error(f"Error loading campaigns page: {str(e)}")
        raise HTTPException(status_code=500, detail="Error loading campaigns page")

@app.get("/analytics", response_class=HTMLResponse)
async def analytics_page(request: Request, db: Session = Depends(get_db)):
    """Analytics page"""
    try:
        accounts = db.query(SocialAccount).filter(SocialAccount.is_active == True).all()
        campaigns = db.query(Campaign).all()
        
        return templates.TemplateResponse("analytics.html", {
            "request": request,
            "accounts": accounts,
            "campaigns": campaigns,
            "platform_configs": PLATFORM_CONFIGS
        })
        
    except Exception as e:
        logger.error(f"Error loading analytics page: {str(e)}")
        raise HTTPException(status_code=500, detail="Error loading analytics page")

# API Routes

# Posts API
@app.post("/api/posts")
async def create_post(post_data: PostCreate, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """Create and optionally schedule a post"""
    try:
        results = []
        
        for platform in post_data.platforms:
            # Get active accounts for this platform
            accounts = db.query(SocialAccount).filter(
                SocialAccount.platform == platform,
                SocialAccount.is_active == True
            ).all()
            
            if not accounts:
                results.append({
                    "platform": platform,
                    "success": False,
                    "error": f"No active accounts found for {platform}"
                })
                continue
            
            for account in accounts:
                # Create post record
                post_record = Post(
                    account_id=account.id,
                    platform=platform,
                    content=post_data.content,
                    media_urls=post_data.media_urls or [],
                    hashtags=post_data.hashtags or [],
                    scheduled_time=post_data.scheduled_time,
                    status="scheduled" if post_data.scheduled_time else "draft"
                )
                
                db.add(post_record)
                db.commit()
                db.refresh(post_record)
                
                if post_data.scheduled_time:
                    # Schedule the post
                    post_job_data = {
                        'post_id': post_record.id,
                        'account_id': account.id,
                        'platform': platform,
                        'content': post_data.content,
                        'hashtags': post_data.hashtags or [],
                        'media_urls': post_data.media_urls or [],
                        'scheduled_time': post_data.scheduled_time,
                        'metadata': post_data.metadata
                    }
                    
                    job_id = await scheduler.schedule_post(post_job_data)
                    
                    results.append({
                        "platform": platform,
                        "account": account.account_name,
                        "success": True,
                        "post_id": post_record.id,
                        "job_id": job_id,
                        "scheduled_time": post_data.scheduled_time.isoformat()
                    })
                else:
                    # Post immediately
                    background_tasks.add_task(post_to_platform.delay, {
                        'post_id': post_record.id,
                        'account_id': account.id,
                        'platform': platform,
                        'content': post_data.content,
                        'hashtags': post_data.hashtags or [],
                        'media_urls': post_data.media_urls or [],
                        'metadata': post_data.metadata
                    })
                    
                    results.append({
                        "platform": platform,
                        "account": account.account_name,
                        "success": True,
                        "post_id": post_record.id,
                        "status": "posting"
                    })
        
        return {"success": True, "results": results}
        
    except Exception as e:
        logger.error(f"Error creating post: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/posts")
async def get_posts(skip: int = 0, limit: int = 100, platform: Optional[str] = None, db: Session = Depends(get_db)):
    """Get posts with optional filtering"""
    try:
        query = db.query(Post)
        
        if platform:
            query = query.filter(Post.platform == platform)
        
        posts = query.order_by(Post.created_at.desc()).offset(skip).limit(limit).all()
        
        return {
            "success": True,
            "posts": [
                {
                    "id": post.id,
                    "platform": post.platform,
                    "content": post.content,
                    "hashtags": post.hashtags,
                    "media_urls": post.media_urls,
                    "scheduled_time": post.scheduled_time.isoformat() if post.scheduled_time else None,
                    "posted_time": post.posted_time.isoformat() if post.posted_time else None,
                    "status": post.status,
                    "engagement_metrics": post.engagement_metrics,
                    "created_at": post.created_at.isoformat()
                }
                for post in posts
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting posts: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/posts/{post_id}")
async def delete_post(post_id: int, db: Session = Depends(get_db)):
    """Delete a post"""
    try:
        post = db.query(Post).filter(Post.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")
        
        # Cancel scheduled job if exists
        if post.status == "scheduled":
            await scheduler.cancel_scheduled_post(str(post_id))
        
        # Delete from platform if posted
        if post.status == "posted" and post.platform_post_id:
            account = db.query(SocialAccount).filter(SocialAccount.id == post.account_id).first()
            if account:
                try:
                    credentials = {'access_token': account.access_token}
                    adapter = PlatformAdapterFactory.create_adapter(account.platform, credentials)
                    await adapter.authenticate()
                    await adapter.delete_post(post.platform_post_id)
                except Exception as e:
                    logger.warning(f"Could not delete post from platform: {str(e)}")
        
        db.delete(post)
        db.commit()
        
        return {"success": True, "message": "Post deleted successfully"}
        
    except Exception as e:
        logger.error(f"Error deleting post: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Campaigns API
@app.post("/api/campaigns")
async def create_campaign(campaign_data: CampaignCreate, db: Session = Depends(get_db)):
    """Create a new campaign"""
    try:
        campaign = Campaign(
            name=campaign_data.name,
            description=campaign_data.description,
            start_date=campaign_data.start_date,
            end_date=campaign_data.end_date,
            platforms=campaign_data.platforms,
            content_templates=campaign_data.content_templates,
            posting_schedule=campaign_data.posting_schedule
        )
        
        db.add(campaign)
        db.commit()
        db.refresh(campaign)
        
        # Schedule campaign posts
        job_ids = await scheduler.schedule_campaign(campaign.id)
        
        return {
            "success": True,
            "campaign_id": campaign.id,
            "scheduled_jobs": len(job_ids),
            "job_ids": job_ids
        }
        
    except Exception as e:
        logger.error(f"Error creating campaign: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/campaigns")
async def get_campaigns(db: Session = Depends(get_db)):
    """Get all campaigns"""
    try:
        campaigns = db.query(Campaign).order_by(Campaign.created_at.desc()).all()
        
        return {
            "success": True,
            "campaigns": [
                {
                    "id": campaign.id,
                    "name": campaign.name,
                    "description": campaign.description,
                    "start_date": campaign.start_date.isoformat(),
                    "end_date": campaign.end_date.isoformat() if campaign.end_date else None,
                    "platforms": campaign.platforms,
                    "is_active": campaign.is_active,
                    "created_at": campaign.created_at.isoformat()
                }
                for campaign in campaigns
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting campaigns: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Content Templates API
@app.post("/api/templates")
async def create_template(template_data: ContentTemplateCreate, db: Session = Depends(get_db)):
    """Create a content template"""
    try:
        template = ContentTemplate(
            name=template_data.name,
            category=template_data.category,
            template_text=template_data.template_text,
            platforms=template_data.platforms,
            hashtags=template_data.hashtags,
            media_requirements=template_data.media_requirements
        )
        
        db.add(template)
        db.commit()
        db.refresh(template)
        
        return {
            "success": True,
            "template_id": template.id,
            "name": template.name
        }
        
    except Exception as e:
        logger.error(f"Error creating template: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/templates")
async def get_templates(db: Session = Depends(get_db)):
    """Get all content templates"""
    try:
        templates = db.query(ContentTemplate).filter(ContentTemplate.is_active == True).all()
        
        return {
            "success": True,
            "templates": [
                {
                    "id": template.id,
                    "name": template.name,
                    "category": template.category,
                    "template_text": template.template_text,
                    "platforms": template.platforms,
                    "hashtags": template.hashtags,
                    "created_at": template.created_at.isoformat()
                }
                for template in templates
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting templates: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# AI Content Generation API
@app.post("/api/generate-content")
async def generate_ai_content(
    template_id: Optional[int] = None,
    platform: str = "facebook",
    context: Optional[Dict[str, Any]] = None,
    background_tasks: BackgroundTasks = None
):
    """Generate AI content"""
    try:
        if template_id:
            result = await ai_generator.generate_content_from_template(
                template_id, platform, context or {}
            )
        else:
            # Generate generic content
            result = {
                "success": False,
                "error": "Template ID is required for content generation"
            }
        
        return result
        
    except Exception as e:
        logger.error(f"Error generating AI content: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Analytics API
@app.get("/api/analytics/report")
async def get_analytics_report(
    account_id: Optional[int] = None,
    campaign_id: Optional[int] = None,
    days: int = 30
):
    """Get analytics report"""
    try:
        report = await analytics_collector.generate_analytics_report(
            account_id=account_id,
            campaign_id=campaign_id,
            days=days
        )
        
        return report
        
    except Exception as e:
        logger.error(f"Error getting analytics report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/analytics/trends")
async def get_engagement_trends(account_id: Optional[int] = None, days: int = 30):
    """Get engagement trends"""
    try:
        trends = await analytics_collector.get_engagement_trends(
            account_id=account_id,
            days=days
        )
        
        return trends
        
    except Exception as e:
        logger.error(f"Error getting engagement trends: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Social Accounts API
@app.post("/api/accounts")
async def create_social_account(account_data: SocialAccountCreate, db: Session = Depends(get_db)):
    """Add a social media account"""
    try:
        account = SocialAccount(
            platform=account_data.platform,
            account_name=account_data.account_name,
            account_id=account_data.account_id,
            access_token=account_data.access_token,
            refresh_token=account_data.refresh_token,
            token_expires_at=account_data.token_expires_at
        )
        
        db.add(account)
        db.commit()
        db.refresh(account)
        
        # Test authentication
        try:
            credentials = {'access_token': account.access_token}
            adapter = PlatformAdapterFactory.create_adapter(account.platform, credentials)
            auth_success = await adapter.authenticate()
            
            if not auth_success:
                account.is_active = False
                db.commit()
                
            return {
                "success": True,
                "account_id": account.id,
                "authenticated": auth_success
            }
            
        except Exception as e:
            logger.warning(f"Authentication test failed: {str(e)}")
            return {
                "success": True,
                "account_id": account.id,
                "authenticated": False,
                "warning": "Account created but authentication failed"
            }
        
    except Exception as e:
        logger.error(f"Error creating social account: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/accounts")
async def get_social_accounts(db: Session = Depends(get_db)):
    """Get all social media accounts"""
    try:
        accounts = db.query(SocialAccount).all()
        
        return {
            "success": True,
            "accounts": [
                {
                    "id": account.id,
                    "platform": account.platform,
                    "account_name": account.account_name,
                    "account_id": account.account_id,
                    "is_active": account.is_active,
                    "created_at": account.created_at.isoformat()
                }
                for account in accounts
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting social accounts: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Platform Configuration API
@app.get("/api/platforms")
async def get_platform_configs():
    """Get platform configurations"""
    return {
        "success": True,
        "platforms": PLATFORM_CONFIGS
    }

# Scheduler API
@app.get("/api/scheduler/jobs")
async def get_scheduled_jobs():
    """Get all scheduled jobs"""
    try:
        jobs = await scheduler.get_scheduled_posts()
        return {
            "success": True,
            "jobs": jobs
        }
        
    except Exception as e:
        logger.error(f"Error getting scheduled jobs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/scheduler/jobs/{job_id}")
async def cancel_scheduled_job(job_id: str):
    """Cancel a scheduled job"""
    try:
        success = await scheduler.cancel_scheduled_post(job_id.replace('post_', ''))
        
        if success:
            return {"success": True, "message": "Job cancelled successfully"}
        else:
            raise HTTPException(status_code=404, detail="Job not found")
            
    except Exception as e:
        logger.error(f"Error cancelling scheduled job: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
