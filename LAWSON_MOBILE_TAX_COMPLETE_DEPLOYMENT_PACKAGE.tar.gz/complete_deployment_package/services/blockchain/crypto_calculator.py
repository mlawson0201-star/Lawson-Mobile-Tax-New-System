"""
Cryptocurrency Tax Calculator
Advanced crypto tax calculation with DeFi, NFT, and multi-chain support
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
import json
import aiohttp
from web3 import Web3
from stellar_sdk import Server, Keypair
import ccxt

logger = logging.getLogger(__name__)

class TransactionType(Enum):
    """Cryptocurrency transaction types"""
    BUY = "buy"
    SELL = "sell"
    TRADE = "trade"
    TRANSFER_IN = "transfer_in"
    TRANSFER_OUT = "transfer_out"
    MINING = "mining"
    STAKING = "staking"
    AIRDROP = "airdrop"
    FORK = "fork"
    DEFI_SWAP = "defi_swap"
    DEFI_LIQUIDITY = "defi_liquidity"
    DEFI_YIELD = "defi_yield"
    NFT_PURCHASE = "nft_purchase"
    NFT_SALE = "nft_sale"
    NFT_MINT = "nft_mint"

class TaxMethod(Enum):
    """Tax calculation methods"""
    FIFO = "fifo"  # First In, First Out
    LIFO = "lifo"  # Last In, First Out
    HIFO = "hifo"  # Highest In, First Out
    SPECIFIC_ID = "specific_id"  # Specific Identification

@dataclass
class CryptoTransaction:
    """Cryptocurrency transaction record"""
    id: str
    timestamp: datetime
    transaction_type: TransactionType
    base_asset: str
    quote_asset: Optional[str]
    quantity: Decimal
    price_usd: Decimal
    fee_usd: Decimal
    exchange: str
    wallet_address: Optional[str]
    transaction_hash: Optional[str]
    notes: Optional[str]
    
    @property
    def total_value_usd(self) -> Decimal:
        """Calculate total USD value including fees"""
        return (self.quantity * self.price_usd) + self.fee_usd

@dataclass
class TaxLot:
    """Tax lot for cost basis tracking"""
    asset: str
    quantity: Decimal
    cost_basis_usd: Decimal
    acquisition_date: datetime
    transaction_id: str
    
    @property
    def cost_per_unit(self) -> Decimal:
        """Cost per unit in USD"""
        if self.quantity == 0:
            return Decimal('0')
        return self.cost_basis_usd / self.quantity

@dataclass
class TaxEvent:
    """Taxable event calculation result"""
    transaction_id: str
    event_type: str
    asset: str
    quantity: Decimal
    proceeds: Decimal
    cost_basis: Decimal
    gain_loss: Decimal
    holding_period_days: int
    is_long_term: bool
    tax_lots_used: List[TaxLot]

@dataclass
class TaxSummary:
    """Tax summary for a tax year"""
    tax_year: int
    short_term_gain_loss: Decimal
    long_term_gain_loss: Decimal
    total_gain_loss: Decimal
    ordinary_income: Decimal
    total_proceeds: Decimal
    total_cost_basis: Decimal
    events_count: int
    assets_traded: List[str]

class CryptocurrencyTaxCalculator:
    """
    Advanced Cryptocurrency Tax Calculator
    
    Features:
    - Multi-chain transaction tracking (Bitcoin, Ethereum, Stellar, etc.)
    - DeFi protocol integration and yield farming calculations
    - NFT transaction tracking and tax implications
    - Multiple cost basis methods (FIFO, LIFO, HIFO, Specific ID)
    - Real-time price data integration
    - Cross-chain transaction analysis
    - Staking rewards and mining income calculation
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.web3_providers = self._initialize_web3_providers()
        self.stellar_server = Server("https://horizon.stellar.org")
        self.exchanges = self._initialize_exchanges()
        self.price_cache = {}
        self.tax_lots = {}  # asset -> List[TaxLot]
        
    async def calculate_taxes(
        self,
        transactions: List[CryptoTransaction],
        tax_year: int,
        tax_method: TaxMethod = TaxMethod.FIFO,
        user_country: str = "US"
    ) -> TaxSummary:
        """
        Calculate cryptocurrency taxes for a given year
        
        Args:
            transactions: List of crypto transactions
            tax_year: Tax year to calculate
            tax_method: Cost basis calculation method
            user_country: User's country for tax rules
            
        Returns:
            Complete tax summary
        """
        try:
            # Filter transactions for tax year
            year_transactions = [
                tx for tx in transactions 
                if tx.timestamp.year == tax_year
            ]
            
            # Sort transactions by timestamp
            year_transactions.sort(key=lambda x: x.timestamp)
            
            # Initialize tax lots from previous years
            await self._initialize_tax_lots(transactions, tax_year)
            
            # Process each transaction
            tax_events = []
            for transaction in year_transactions:
                events = await self._process_transaction(transaction, tax_method)
                tax_events.extend(events)
            
            # Calculate summary
            summary = await self._calculate_tax_summary(tax_events, tax_year)
            
            logger.info(f"Tax calculation completed for {tax_year}: {len(tax_events)} events processed")
            return summary
            
        except Exception as e:
            logger.error(f"Error calculating crypto taxes: {str(e)}")
            raise
    
    async def track_defi_transactions(
        self,
        wallet_addresses: List[str],
        protocols: List[str],
        start_date: datetime,
        end_date: datetime
    ) -> List[CryptoTransaction]:
        """
        Track DeFi transactions across multiple protocols
        
        Args:
            wallet_addresses: List of wallet addresses to track
            protocols: List of DeFi protocols to monitor
            start_date: Start date for tracking
            end_date: End date for tracking
            
        Returns:
            List of DeFi transactions
        """
        try:
            defi_transactions = []
            
            for address in wallet_addresses:
                # Track Ethereum DeFi
                if any(protocol in ['uniswap', 'compound', 'aave'] for protocol in protocols):
                    eth_transactions = await self._track_ethereum_defi(
                        address, protocols, start_date, end_date
                    )
                    defi_transactions.extend(eth_transactions)
                
                # Track other chains as needed
                # BSC, Polygon, Avalanche, etc.
            
            logger.info(f"Tracked {len(defi_transactions)} DeFi transactions")
            return defi_transactions
            
        except Exception as e:
            logger.error(f"Error tracking DeFi transactions: {str(e)}")
            raise
    
    async def calculate_staking_rewards(
        self,
        validator_addresses: List[str],
        networks: List[str],
        tax_year: int
    ) -> List[CryptoTransaction]:
        """
        Calculate staking rewards for tax purposes
        
        Args:
            validator_addresses: List of validator addresses
            networks: List of blockchain networks
            tax_year: Tax year for calculation
            
        Returns:
            List of staking reward transactions
        """
        try:
            staking_transactions = []
            
            for network in networks:
                if network == "ethereum":
                    rewards = await self._calculate_eth_staking_rewards(
                        validator_addresses, tax_year
                    )
                elif network == "cardano":
                    rewards = await self._calculate_ada_staking_rewards(
                        validator_addresses, tax_year
                    )
                elif network == "solana":
                    rewards = await self._calculate_sol_staking_rewards(
                        validator_addresses, tax_year
                    )
                
                staking_transactions.extend(rewards)
            
            logger.info(f"Calculated {len(staking_transactions)} staking reward transactions")
            return staking_transactions
            
        except Exception as e:
            logger.error(f"Error calculating staking rewards: {str(e)}")
            raise
    
    async def track_nft_transactions(
        self,
        wallet_addresses: List[str],
        marketplaces: List[str],
        tax_year: int
    ) -> List[CryptoTransaction]:
        """
        Track NFT transactions for tax purposes
        
        Args:
            wallet_addresses: List of wallet addresses
            marketplaces: List of NFT marketplaces
            tax_year: Tax year for tracking
            
        Returns:
            List of NFT transactions
        """
        try:
            nft_transactions = []
            
            for address in wallet_addresses:
                # Track OpenSea transactions
                if "opensea" in marketplaces:
                    opensea_txs = await self._track_opensea_transactions(address, tax_year)
                    nft_transactions.extend(opensea_txs)
                
                # Track other marketplaces
                if "rarible" in marketplaces:
                    rarible_txs = await self._track_rarible_transactions(address, tax_year)
                    nft_transactions.extend(rarible_txs)
                
                # Track direct contract interactions
                direct_txs = await self._track_direct_nft_transactions(address, tax_year)
                nft_transactions.extend(direct_txs)
            
            logger.info(f"Tracked {len(nft_transactions)} NFT transactions")
            return nft_transactions
            
        except Exception as e:
            logger.error(f"Error tracking NFT transactions: {str(e)}")
            raise
    
    async def optimize_tax_strategy(
        self,
        current_holdings: Dict[str, Decimal],
        unrealized_gains: Dict[str, Decimal],
        tax_year: int
    ) -> Dict[str, Any]:
        """
        Optimize tax strategy through tax loss harvesting and timing
        
        Args:
            current_holdings: Current crypto holdings
            unrealized_gains: Unrealized gains/losses by asset
            tax_year: Current tax year
            
        Returns:
            Tax optimization recommendations
        """
        try:
            recommendations = {
                "tax_loss_harvesting": [],
                "gain_realization": [],
                "holding_period_optimization": [],
                "estimated_savings": Decimal('0')
            }
            
            # Identify tax loss harvesting opportunities
            for asset, gain_loss in unrealized_gains.items():
                if gain_loss < 0:  # Unrealized loss
                    holding_quantity = current_holdings.get(asset, Decimal('0'))
                    if holding_quantity > 0:
                        recommendations["tax_loss_harvesting"].append({
                            "asset": asset,
                            "quantity": holding_quantity,
                            "unrealized_loss": abs(gain_loss),
                            "recommendation": f"Consider selling {asset} to realize ${abs(gain_loss):.2f} loss"
                        })
            
            # Identify gain realization opportunities
            for asset, gain_loss in unrealized_gains.items():
                if gain_loss > 0:  # Unrealized gain
                    tax_lots = self.tax_lots.get(asset, [])
                    long_term_lots = [
                        lot for lot in tax_lots
                        if (datetime.now(timezone.utc) - lot.acquisition_date).days > 365
                    ]
                    
                    if long_term_lots:
                        recommendations["gain_realization"].append({
                            "asset": asset,
                            "long_term_quantity": sum(lot.quantity for lot in long_term_lots),
                            "unrealized_gain": gain_loss,
                            "recommendation": f"Consider realizing long-term gains on {asset}"
                        })
            
            # Calculate estimated tax savings
            total_losses = sum(
                item["unrealized_loss"] 
                for item in recommendations["tax_loss_harvesting"]
            )
            recommendations["estimated_savings"] = total_losses * Decimal('0.25')  # Assume 25% tax rate
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error optimizing tax strategy: {str(e)}")
            raise
    
    # Private helper methods
    
    def _initialize_web3_providers(self) -> Dict[str, Web3]:
        """Initialize Web3 providers for different chains"""
        providers = {}
        
        if "ethereum_rpc" in self.config:
            providers["ethereum"] = Web3(Web3.HTTPProvider(self.config["ethereum_rpc"]))
        
        if "polygon_rpc" in self.config:
            providers["polygon"] = Web3(Web3.HTTPProvider(self.config["polygon_rpc"]))
        
        if "bsc_rpc" in self.config:
            providers["bsc"] = Web3(Web3.HTTPProvider(self.config["bsc_rpc"]))
        
        return providers
    
    def _initialize_exchanges(self) -> Dict[str, ccxt.Exchange]:
        """Initialize exchange connections"""
        exchanges = {}
        
        # Initialize major exchanges
        if "binance_api_key" in self.config:
            exchanges["binance"] = ccxt.binance({
                'apiKey': self.config["binance_api_key"],
                'secret': self.config["binance_secret"],
                'sandbox': self.config.get("sandbox", False)
            })
        
        if "coinbase_api_key" in self.config:
            exchanges["coinbase"] = ccxt.coinbasepro({
                'apiKey': self.config["coinbase_api_key"],
                'secret': self.config["coinbase_secret"],
                'passphrase': self.config["coinbase_passphrase"],
                'sandbox': self.config.get("sandbox", False)
            })
        
        return exchanges
    
    async def _initialize_tax_lots(
        self,
        all_transactions: List[CryptoTransaction],
        tax_year: int
    ):
        """Initialize tax lots from transactions before tax year"""
        self.tax_lots = {}
        
        # Process transactions before tax year to build tax lots
        prior_transactions = [
            tx for tx in all_transactions 
            if tx.timestamp.year < tax_year
        ]
        
        prior_transactions.sort(key=lambda x: x.timestamp)
        
        for transaction in prior_transactions:
            await self._process_transaction(transaction, TaxMethod.FIFO, build_lots_only=True)
    
    async def _process_transaction(
        self,
        transaction: CryptoTransaction,
        tax_method: TaxMethod,
        build_lots_only: bool = False
    ) -> List[TaxEvent]:
        """Process a single transaction for tax implications"""
        tax_events = []
        
        if transaction.transaction_type in [TransactionType.BUY, TransactionType.MINING, 
                                          TransactionType.STAKING, TransactionType.AIRDROP]:
            # Acquisition - create tax lot
            await self._create_tax_lot(transaction)
            
            # Mining, staking, airdrops are taxable income
            if transaction.transaction_type in [TransactionType.MINING, TransactionType.STAKING, 
                                              TransactionType.AIRDROP] and not build_lots_only:
                tax_events.append(TaxEvent(
                    transaction_id=transaction.id,
                    event_type="ordinary_income",
                    asset=transaction.base_asset,
                    quantity=transaction.quantity,
                    proceeds=transaction.total_value_usd,
                    cost_basis=Decimal('0'),
                    gain_loss=transaction.total_value_usd,
                    holding_period_days=0,
                    is_long_term=False,
                    tax_lots_used=[]
                ))
        
        elif transaction.transaction_type in [TransactionType.SELL, TransactionType.TRADE]:
            # Disposition - calculate gain/loss
            if not build_lots_only:
                tax_event = await self._calculate_disposition(transaction, tax_method)
                if tax_event:
                    tax_events.append(tax_event)
        
        elif transaction.transaction_type in [TransactionType.DEFI_SWAP, TransactionType.NFT_SALE]:
            # DeFi swaps and NFT sales are taxable dispositions
            if not build_lots_only:
                tax_event = await self._calculate_disposition(transaction, tax_method)
                if tax_event:
                    tax_events.append(tax_event)
        
        return tax_events
    
    async def _create_tax_lot(self, transaction: CryptoTransaction):
        """Create a tax lot for an acquisition"""
        if transaction.base_asset not in self.tax_lots:
            self.tax_lots[transaction.base_asset] = []
        
        tax_lot = TaxLot(
            asset=transaction.base_asset,
            quantity=transaction.quantity,
            cost_basis_usd=transaction.total_value_usd,
            acquisition_date=transaction.timestamp,
            transaction_id=transaction.id
        )
        
        self.tax_lots[transaction.base_asset].append(tax_lot)
    
    async def _calculate_disposition(
        self,
        transaction: CryptoTransaction,
        tax_method: TaxMethod
    ) -> Optional[TaxEvent]:
        """Calculate tax event for a disposition"""
        asset = transaction.base_asset
        quantity_to_dispose = transaction.quantity
        
        if asset not in self.tax_lots or not self.tax_lots[asset]:
            # No tax lots available - this shouldn't happen in normal circumstances
            logger.warning(f"No tax lots available for {asset} disposition")
            return None
        
        # Select tax lots based on method
        lots_to_use = self._select_tax_lots(asset, quantity_to_dispose, tax_method)
        
        if not lots_to_use:
            return None
        
        # Calculate total cost basis
        total_cost_basis = sum(lot.cost_basis_usd for lot in lots_to_use)
        proceeds = transaction.total_value_usd
        gain_loss = proceeds - total_cost_basis
        
        # Calculate holding period (use shortest for mixed lots)
        holding_periods = [
            (transaction.timestamp - lot.acquisition_date).days
            for lot in lots_to_use
        ]
        min_holding_period = min(holding_periods)
        is_long_term = min_holding_period > 365
        
        # Remove used lots from inventory
        for lot in lots_to_use:
            self.tax_lots[asset].remove(lot)
        
        return TaxEvent(
            transaction_id=transaction.id,
            event_type="capital_gain_loss",
            asset=asset,
            quantity=quantity_to_dispose,
            proceeds=proceeds,
            cost_basis=total_cost_basis,
            gain_loss=gain_loss,
            holding_period_days=min_holding_period,
            is_long_term=is_long_term,
            tax_lots_used=lots_to_use
        )
    
    def _select_tax_lots(
        self,
        asset: str,
        quantity_needed: Decimal,
        tax_method: TaxMethod
    ) -> List[TaxLot]:
        """Select tax lots based on the specified method"""
        available_lots = self.tax_lots[asset].copy()
        
        if tax_method == TaxMethod.FIFO:
            available_lots.sort(key=lambda x: x.acquisition_date)
        elif tax_method == TaxMethod.LIFO:
            available_lots.sort(key=lambda x: x.acquisition_date, reverse=True)
        elif tax_method == TaxMethod.HIFO:
            available_lots.sort(key=lambda x: x.cost_per_unit, reverse=True)
        
        selected_lots = []
        remaining_quantity = quantity_needed
        
        for lot in available_lots:
            if remaining_quantity <= 0:
                break
            
            if lot.quantity <= remaining_quantity:
                # Use entire lot
                selected_lots.append(lot)
                remaining_quantity -= lot.quantity
            else:
                # Partial lot usage
                partial_lot = TaxLot(
                    asset=lot.asset,
                    quantity=remaining_quantity,
                    cost_basis_usd=(lot.cost_basis_usd * remaining_quantity / lot.quantity),
                    acquisition_date=lot.acquisition_date,
                    transaction_id=lot.transaction_id
                )
                selected_lots.append(partial_lot)
                
                # Update original lot
                lot.quantity -= remaining_quantity
                lot.cost_basis_usd -= partial_lot.cost_basis_usd
                remaining_quantity = Decimal('0')
        
        return selected_lots
    
    async def _calculate_tax_summary(
        self,
        tax_events: List[TaxEvent],
        tax_year: int
    ) -> TaxSummary:
        """Calculate tax summary from tax events"""
        short_term_gain_loss = Decimal('0')
        long_term_gain_loss = Decimal('0')
        ordinary_income = Decimal('0')
        total_proceeds = Decimal('0')
        total_cost_basis = Decimal('0')
        assets_traded = set()
        
        for event in tax_events:
            assets_traded.add(event.asset)
            
            if event.event_type == "ordinary_income":
                ordinary_income += event.gain_loss
            elif event.event_type == "capital_gain_loss":
                total_proceeds += event.proceeds
                total_cost_basis += event.cost_basis
                
                if event.is_long_term:
                    long_term_gain_loss += event.gain_loss
                else:
                    short_term_gain_loss += event.gain_loss
        
        total_gain_loss = short_term_gain_loss + long_term_gain_loss
        
        return TaxSummary(
            tax_year=tax_year,
            short_term_gain_loss=short_term_gain_loss,
            long_term_gain_loss=long_term_gain_loss,
            total_gain_loss=total_gain_loss,
            ordinary_income=ordinary_income,
            total_proceeds=total_proceeds,
            total_cost_basis=total_cost_basis,
            events_count=len(tax_events),
            assets_traded=list(assets_traded)
        )
    
    # Placeholder methods for specific blockchain tracking
    
    async def _track_ethereum_defi(
        self,
        address: str,
        protocols: List[str],
        start_date: datetime,
        end_date: datetime
    ) -> List[CryptoTransaction]:
        """Track Ethereum DeFi transactions"""
        # This would implement actual DeFi tracking
        return []
    
    async def _calculate_eth_staking_rewards(
        self,
        validator_addresses: List[str],
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Calculate Ethereum staking rewards"""
        # This would implement actual staking reward calculation
        return []
    
    async def _calculate_ada_staking_rewards(
        self,
        validator_addresses: List[str],
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Calculate Cardano staking rewards"""
        return []
    
    async def _calculate_sol_staking_rewards(
        self,
        validator_addresses: List[str],
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Calculate Solana staking rewards"""
        return []
    
    async def _track_opensea_transactions(
        self,
        address: str,
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Track OpenSea NFT transactions"""
        return []
    
    async def _track_rarible_transactions(
        self,
        address: str,
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Track Rarible NFT transactions"""
        return []
    
    async def _track_direct_nft_transactions(
        self,
        address: str,
        tax_year: int
    ) -> List[CryptoTransaction]:
        """Track direct NFT contract transactions"""
        return []
