
# Lawson Mobile Tax + Formality Tax Platform

## 🏢 Project Overview

**Lawson Mobile Tax** is a production-ready, multi-tenant, white-label tax preparation platform that automates the entire tax workflow from client acquisition to e-filing. **Formality Tax** provides white-label capabilities for tax professionals and firms.

### Key Features
- 🤖 AI-powered document OCR and tax reasoning
- 📱 Multi-tenant architecture with white-label capabilities
- 🔐 Enterprise-grade security and GLBA compliance
- 💰 Integrated payments, refund advances, and revenue sharing
- 📊 Comprehensive analytics and KPI dashboards
- 🔄 Temporal workflow orchestration
- 🎯 Marketing automation and brand management

### Platform Components
- **Consumer Platform**: lawsonmobiletax.com
- **White-Label Platform**: Formality Tax with custom subdomains
- **ERO Services**: Full Electronic Return Originator capabilities
- **Bank Products**: Refund advances up to $7,000 via EPS Financial

---

## 📋 Documentation Index

### Core Documentation
- [📖 Product Requirements Document (PRD) v1](./docs/prd/v1_prd.md)
- [🏗️ Technical Architecture](./docs/architecture/tech_architecture.md)
- [🗄️ Data Models & ERD](./docs/data/erd.md)
- [🔌 Integration Specifications](./docs/integrations/specs.md)
- [📡 API Documentation](./docs/api/api_docs.md)

### Security & Compliance
- [🔒 Security & Compliance Framework](./docs/security/security_compliance.md)
- [⚖️ Legal Documentation](./docs/legal/legal_docs.md)
- [🛡️ Privacy & Data Protection](./docs/security/privacy_framework.md)

### Operations & Workflows
- [⚡ Temporal Workflow Definitions](./docs/workflows/temporal_workflows.md)
- [🤖 AI Components & Specifications](./docs/ai/ai_components.md)
- [📊 KPI Dashboards & Analytics](./docs/kpi/kpi_dashboards.md)
- [🎯 Marketing & GTM Strategy](./docs/marketing/gtm_strategy.md)

### Brand & Design
- [🎨 Brand Guidelines](./docs/brand/brand_guidelines.md)
- [🏷️ White-Label Brand Kit](./docs/brand/white_label_kit.md)
- [📱 UI/UX Specifications](./docs/design/ui_specifications.md)

### Implementation
- [🚀 Deployment Strategy](./docs/deployment/deployment_strategy.md)
- [📅 Sprint Planning](./docs/implementation/sprint_plan.md)
- [🧪 Testing Strategy](./docs/testing/testing_strategy.md)

---

## 🏗️ Technical Stack

### Frontend
- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS + Headless UI
- **State Management**: Zustand + React Query
- **Forms**: React Hook Form + Zod validation

### Backend
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js with GraphQL (Apollo Server)
- **Database**: PostgreSQL (AWS RDS)
- **Cache**: Redis (AWS ElastiCache)
- **Search**: OpenSearch (AWS)
- **File Storage**: AWS S3

### Infrastructure
- **Cloud**: AWS (ECS Fargate/EKS)
- **Orchestration**: Temporal.io
- **Auth**: AWS Cognito + Custom RBAC
- **Messaging**: AWS SNS/SQS
- **Monitoring**: CloudWatch + Datadog
- **Analytics**: Segment → BigQuery + Metabase

### Integrations
- **Tax Engine**: OLT Pro/Partner APIs
- **Bank Products**: EPS Financial
- **Identity/KYC**: Persona
- **Payments**: Stripe + Stripe Connect
- **Communications**: Twilio (SMS), Customer.io (Email)
- **Marketing**: Meta/Google Ads APIs

---

## 💰 Pricing Structure

### Consumer Pricing (Lawson Mobile Tax)
- **Base 1040**: $485
- **State Returns**: $79 each
- **Schedule C (Simple)**: +$149
- **Investments**: +$99 (≤50 trades), +$199 (heavy trading)
- **Rental Properties**: +$129 (first), +$79 (additional)
- **Audit Defense**: $59.99
- **Rush Processing**: +$99

### Business Services
- **Bookkeeping**: $249/$449/$799 per month
- **Tax Planning**: $99/quarter (basic), $399/quarter (pro)
- **Resolution Services**: $250 retainer + 10% of resolved balance

### White-Label (Formality Tax)
- **Revenue Share Model**: 30% platform fee on reseller's gross
- **SaaS + Usage Model**: $299/month/firm + $12/return + 1.5% payment fee

---

## 🎯 Success Metrics

### Key Performance Indicators
1. **Lead Generation**: Monthly lead volume and sources
2. **Conversion Funnel**: Lead-to-Intake, Intake-to-Complete, Paid Conversion %
3. **Revenue Metrics**: AOV, ARPU, Monthly Recurring Revenue
4. **Operational Excellence**: E-file acceptance rate, turnaround time
5. **Quality Assurance**: Correction cycle time, EA backlog
6. **Customer Satisfaction**: NPS, CSAT scores
7. **Marketing Performance**: CAC, ROAS, LTV

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- Redis 6+
- AWS Account with appropriate permissions
- Temporal.io cluster
- Third-party API credentials (OLT, EPS, Persona, Stripe)

### Quick Start
```bash
# Clone the repository
git clone https://github.com/lawson-mobile-tax/platform.git
cd platform

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Fill in your API keys and configuration

# Run database migrations
npm run db:migrate

# Start development servers
npm run dev:all
```

### Environment Setup
```bash
# Core services
npm run dev:api          # GraphQL API server
npm run dev:web          # Next.js web application
npm run dev:admin        # Admin dashboard
npm run dev:workflows    # Temporal workers

# Supporting services
npm run dev:ocr          # Document processing service
npm run dev:ai           # AI reasoning service
npm run dev:notifications # Communication service
```

---

## 📞 Support & Contact

### Business Information
- **Legal Entity**: [INSERT LEGAL NAME]
- **EIN**: [INSERT EIN]
- **Address**: [INSERT REGISTERED ADDRESS]
- **Phone**: [INSERT SUPPORT PHONE]
- **Email**: [INSERT SUPPORT EMAIL]

### Technical Support
- **Documentation**: [docs.lawsonmobiletax.com](https://docs.lawsonmobiletax.com)
- **API Status**: [status.lawsonmobiletax.com](https://status.lawsonmobiletax.com)
- **Developer Portal**: [developers.formalitytax.com](https://developers.formalitytax.com)

---

## 📄 License & Compliance

This platform is built with enterprise-grade security and compliance:
- ✅ GLBA (Gramm-Leach-Bliley Act) compliant
- ✅ IRS Publication 4557 aligned
- ✅ SOC 2 Type I ready (6-month target)
- ✅ 7-year data retention policy
- ✅ End-to-end encryption (at rest and in transit)

---

## 🤝 Contributing

This is a proprietary platform. For internal development guidelines, see:
- [Development Workflow](./docs/development/workflow.md)
- [Code Standards](./docs/development/standards.md)
- [Security Guidelines](./docs/development/security.md)

---

*Last Updated: August 22, 2025*
*Version: 1.0.0*

