
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Download, Eye, TrendingUp, Users, FileText, Calculator, Video, CheckSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import { ClientPersona, LeadMagnet } from '@/lib/types/client-acquisition';

interface LeadMagnetGeneratorProps {
  personas: ClientPersona[];
  onGenerate: (magnet: Partial<LeadMagnet>) => void;
  onDownload: (magnetId: string) => void;
}

const LEAD_MAGNET_TEMPLATES = {
  w2_employee: [
    {
      type: 'checklist' as const,
      title: 'Maximum Refund Checklist',
      description: 'Complete checklist to ensure you claim every deduction and credit',
      icon: CheckSquare,
      estimatedValue: 850,
      conversionRate: 0.15
    },
    {
      type: 'calculator' as const,
      title: 'Refund Estimator Calculator',
      description: 'Calculate your expected tax refund in minutes',
      icon: Calculator,
      estimatedValue: 1200,
      conversionRate: 0.22
    },
    {
      type: 'guide' as const,
      title: 'Hidden Deduction Finder',
      description: 'Discover 15 commonly missed tax deductions',
      icon: FileText,
      estimatedValue: 650,
      conversionRate: 0.18
    }
  ],
  small_business: [
    {
      type: 'guide' as const,
      title: 'Business Deduction Masterclass',
      description: 'Complete guide to maximizing business tax deductions',
      icon: FileText,
      estimatedValue: 2400,
      conversionRate: 0.28
    },
    {
      type: 'calculator' as const,
      title: 'Quarterly Tax Calculator',
      description: 'Calculate and plan your quarterly tax payments',
      icon: Calculator,
      estimatedValue: 1800,
      conversionRate: 0.25
    },
    {
      type: 'template' as const,
      title: 'Expense Tracking Template',
      description: 'Professional spreadsheet for tracking business expenses',
      icon: CheckSquare,
      estimatedValue: 950,
      conversionRate: 0.20
    }
  ],
  investor: [
    {
      type: 'guide' as const,
      title: 'Investment Tax Strategy Guide',
      description: 'Advanced strategies for minimizing investment taxes',
      icon: FileText,
      estimatedValue: 3200,
      conversionRate: 0.32
    },
    {
      type: 'calculator' as const,
      title: 'Tax Loss Harvesting Calculator',
      description: 'Optimize your portfolio for tax efficiency',
      icon: Calculator,
      estimatedValue: 2800,
      conversionRate: 0.30
    },
    {
      type: 'video' as const,
      title: 'Capital Gains Masterclass',
      description: '45-minute video course on capital gains optimization',
      icon: Video,
      estimatedValue: 2100,
      conversionRate: 0.26
    }
  ],
  retiree: [
    {
      type: 'guide' as const,
      title: 'Retirement Tax Optimization Guide',
      description: 'Navigate retirement taxes and maximize your income',
      icon: FileText,
      estimatedValue: 1800,
      conversionRate: 0.24
    },
    {
      type: 'calculator' as const,
      title: 'Social Security Tax Calculator',
      description: 'Calculate taxes on your Social Security benefits',
      icon: Calculator,
      estimatedValue: 1400,
      conversionRate: 0.21
    },
    {
      type: 'checklist' as const,
      title: 'RMD Planning Checklist',
      description: 'Required Minimum Distribution planning made simple',
      icon: CheckSquare,
      estimatedValue: 1100,
      conversionRate: 0.19
    }
  ],
  freelancer: [
    {
      type: 'guide' as const,
      title: 'Freelancer Tax Survival Kit',
      description: 'Everything freelancers need to know about taxes',
      icon: FileText,
      estimatedValue: 1600,
      conversionRate: 0.26
    },
    {
      type: 'template' as const,
      title: 'Expense Tracking Template',
      description: 'Track deductible expenses throughout the year',
      icon: CheckSquare,
      estimatedValue: 800,
      conversionRate: 0.23
    },
    {
      type: 'calculator' as const,
      title: 'Self-Employment Tax Calculator',
      description: 'Calculate your self-employment tax obligations',
      icon: Calculator,
      estimatedValue: 1200,
      conversionRate: 0.20
    }
  ]
};

export default function LeadMagnetGenerator({ personas, onGenerate, onDownload }: LeadMagnetGeneratorProps) {
  const [selectedPersona, setSelectedPersona] = useState<ClientPersona | null>(null);
  const [generatedMagnets, setGeneratedMagnets] = useState<LeadMagnet[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  const generateMagnetsForPersona = async (persona: ClientPersona) => {
    setIsGenerating(true);
    setSelectedPersona(persona);

    // Simulate AI generation process
    await new Promise(resolve => setTimeout(resolve, 2000));

    const templates = LEAD_MAGNET_TEMPLATES[persona.type as keyof typeof LEAD_MAGNET_TEMPLATES] || [];
    const magnets: LeadMagnet[] = templates.map((template, index) => ({
      id: `${persona.type}-${template.type}-${index}`,
      title: template.title,
      description: template.description,
      type: template.type,
      targetPersonas: [persona.id],
      downloadUrl: `/lead-magnets/${persona.type}/${template.type}`,
      conversionRate: template.conversionRate + (Math.random() * 0.05 - 0.025), // Add some variance
      createdAt: new Date()
    }));

    setGeneratedMagnets(magnets);
    setIsGenerating(false);
    confettiReward();
  };

  const handleGenerateMagnet = (magnet: LeadMagnet) => {
    onGenerate(magnet);
    confettiReward();
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case 'checklist': return CheckSquare;
      case 'calculator': return Calculator;
      case 'guide': return FileText;
      case 'template': return CheckSquare;
      case 'video': return Video;
      default: return FileText;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          AI-Powered Lead Magnet Generator
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Create personalized lead magnets for each client persona using our AI-powered generator.
          Each magnet is optimized for maximum conversion and engagement.
        </p>
      </div>

      {/* Persona Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {personas.map((persona) => (
          <motion.div
            key={persona.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card 
              className={`cursor-pointer transition-all duration-200 ${
                selectedPersona?.id === persona.id 
                  ? 'ring-2 ring-blue-500 bg-blue-50' 
                  : 'hover:shadow-lg'
              }`}
              onClick={() => generateMagnetsForPersona(persona)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{persona.name}</CardTitle>
                  <Badge variant="outline">{persona.type.replace('_', ' ')}</Badge>
                </div>
                <CardDescription className="text-sm">
                  {persona.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="w-4 h-4 mr-2" />
                    {persona.demographics.ageRange}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    {persona.demographics.incomeRange}
                  </div>
                </div>
                <Button 
                  className="w-full mt-4" 
                  variant={selectedPersona?.id === persona.id ? "default" : "outline"}
                  disabled={isGenerating}
                >
                  {isGenerating && selectedPersona?.id === persona.id 
                    ? 'Generating...' 
                    : 'Generate Lead Magnets'
                  }
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Generation Progress */}
      <AnimatePresence>
        {isGenerating && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="text-center py-8"
          >
            <div className="max-w-md mx-auto">
              <div className="mb-4">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              </div>
              <h3 className="text-lg font-semibold mb-2">
                Generating Lead Magnets for {selectedPersona?.name}
              </h3>
              <p className="text-gray-600 mb-4">
                Our AI is analyzing persona data and creating optimized lead magnets...
              </p>
              <Progress value={75} className="w-full" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Generated Magnets */}
      <AnimatePresence>
        {generatedMagnets.length > 0 && !isGenerating && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Generated Lead Magnets for {selectedPersona?.name}
              </h3>
              <p className="text-gray-600">
                Each magnet is optimized for your target persona's specific needs and preferences.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {generatedMagnets.map((magnet, index) => {
                const IconComponent = getIconForType(magnet.type);
                const template = LEAD_MAGNET_TEMPLATES[selectedPersona?.type as keyof typeof LEAD_MAGNET_TEMPLATES]?.[index];
                
                return (
                  <motion.div
                    key={magnet.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-lg transition-shadow duration-200">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              <IconComponent className="w-6 h-6 text-blue-600" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{magnet.title}</CardTitle>
                              <Badge variant="secondary" className="mt-1">
                                {magnet.type.replace('_', ' ')}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-gray-600">{magnet.description}</p>
                        
                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-500">Conversion Rate</span>
                            <span className="font-semibold text-green-600">
                              {(magnet.conversionRate * 100).toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-500">Est. Value</span>
                            <span className="font-semibold text-blue-600">
                              ${template?.estimatedValue.toLocaleString()}
                            </span>
                          </div>
                          <Progress 
                            value={magnet.conversionRate * 100} 
                            className="h-2"
                          />
                        </div>

                        <div className="flex space-x-2">
                          <Button
                            onClick={() => handleGenerateMagnet(magnet)}
                            className="flex-1"
                            size="sm"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Preview
                          </Button>
                          <Button
                            onClick={() => onDownload(magnet.id)}
                            variant="outline"
                            size="sm"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            <div className="text-center pt-6">
              <span id="confetti" />
              <Button
                onClick={() => {
                  setGeneratedMagnets([]);
                  setSelectedPersona(null);
                }}
                variant="outline"
                size="lg"
              >
                Generate for Another Persona
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
