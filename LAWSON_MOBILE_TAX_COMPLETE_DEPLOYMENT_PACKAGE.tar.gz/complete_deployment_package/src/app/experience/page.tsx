
'use client';

import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Settings, Bell, Activity } from 'lucide-react';

// Import our new components
import PersonalizedDashboard from '@/components/experience/client-portals/personalized-dashboard';
import WhiteGloveOnboarding from '@/components/experience/onboarding/white-glove-onboarding';

// Mock data
const mockClientProfile = {
  id: '1',
  userId: 'John Smith',
  persona: {
    id: '1',
    type: 'small_business' as const,
    name: 'Small Business Owner',
    description: 'Entrepreneurs needing comprehensive business tax solutions',
    painPoints: ['Complex deductions', 'Quarterly taxes', 'Business/personal separation'],
    preferences: {
      communicationChannel: 'phone' as const,
      complexity: 'advanced' as const,
      timing: 'scheduled' as const
    },
    demographics: {
      ageRange: '30-55',
      incomeRange: '$60K-$200K',
      location: 'Mixed'
    }
  },
  financialGoals: ['Minimize tax liability', 'Business growth', 'Retirement planning'],
  riskTolerance: 'moderate' as const,
  lifeStage: 'family' as const,
  taxComplexity: 'complex' as const,
  preferredCommunication: 'email' as const,
  communicationFrequency: 'monthly' as const,
  timezone: 'America/New_York',
  lastUpdated: new Date(),
  completionScore: 85
};

const mockPortal = {
  id: '1',
  clientId: '1',
  theme: 'light' as const,
  layout: 'dashboard' as const,
  widgets: [
    {
      id: 'w1',
      type: 'tax_summary' as const,
      title: 'Tax Summary',
      position: { x: 0, y: 0 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    },
    {
      id: 'w2',
      type: 'deadlines' as const,
      title: 'Important Deadlines',
      position: { x: 1, y: 0 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    },
    {
      id: 'w3',
      type: 'documents' as const,
      title: 'Documents',
      position: { x: 2, y: 0 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    },
    {
      id: 'w4',
      type: 'progress' as const,
      title: 'Progress Tracker',
      position: { x: 0, y: 1 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    },
    {
      id: 'w5',
      type: 'recommendations' as const,
      title: 'Recommendations',
      position: { x: 1, y: 1 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    },
    {
      id: 'w6',
      type: 'calculator' as const,
      title: 'Quick Calculator',
      position: { x: 2, y: 1 },
      size: { width: 1, height: 1 },
      isVisible: true,
      config: {}
    }
  ],
  notifications: [],
  documents: [],
  tasks: [],
  lastLogin: new Date(),
  customizations: {}
};

const mockNotifications = [
  {
    id: '1',
    clientId: '1',
    type: 'deadline' as const,
    title: 'Quarterly Tax Payment Due',
    message: 'Your Q1 estimated tax payment is due on April 15th. Don\'t forget to make your payment to avoid penalties.',
    priority: 'high' as const,
    isRead: false,
    actionUrl: '/payments/quarterly',
    scheduledDate: new Date('2024-04-10'),
    createdAt: new Date('2024-04-01')
  },
  {
    id: '2',
    clientId: '1',
    type: 'document_request' as const,
    title: 'Missing W-2 Form',
    message: 'We need your W-2 form to complete your tax return. Please upload it when convenient.',
    priority: 'medium' as const,
    isRead: false,
    actionUrl: '/documents/upload',
    createdAt: new Date('2024-03-28')
  },
  {
    id: '3',
    clientId: '1',
    type: 'tax_tip' as const,
    title: 'Business Expense Tip',
    message: 'Did you know you can deduct home office expenses? Learn more about maximizing your business deductions.',
    priority: 'low' as const,
    isRead: true,
    actionUrl: '/education/business-deductions',
    createdAt: new Date('2024-03-25')
  }
];

const mockDocuments = [
  {
    id: '1',
    clientId: '1',
    name: 'W-2 Form - ABC Company',
    type: 'w2' as const,
    fileUrl: '/documents/w2-abc-company.pdf',
    uploadDate: new Date('2024-02-15'),
    status: 'completed' as const,
    extractedData: {
      employer: 'ABC Company',
      wages: 75000,
      federalTaxWithheld: 12500
    },
    tags: ['w2', '2024', 'primary_employer']
  },
  {
    id: '2',
    clientId: '1',
    name: '1099-NEC - Freelance Work',
    type: '1099' as const,
    fileUrl: '/documents/1099-nec-freelance.pdf',
    uploadDate: new Date('2024-02-20'),
    status: 'processing' as const,
    tags: ['1099', 'freelance', 'side_income']
  },
  {
    id: '3',
    clientId: '1',
    name: 'Business Receipts - Q1',
    type: 'receipt' as const,
    fileUrl: '/documents/receipts-q1.pdf',
    uploadDate: new Date('2024-03-01'),
    status: 'pending' as const,
    tags: ['receipts', 'business', 'q1']
  }
];

const mockTasks = [
  {
    id: '1',
    clientId: '1',
    title: 'Upload Missing W-2 Forms',
    description: 'Please upload any remaining W-2 forms from your employers',
    type: 'document_upload' as const,
    priority: 'high' as const,
    status: 'pending' as const,
    dueDate: new Date('2024-04-10'),
    assignedTo: 'client',
    dependencies: []
  },
  {
    id: '2',
    clientId: '1',
    title: 'Review Business Deductions',
    description: 'Review and confirm your business deduction categories',
    type: 'review' as const,
    priority: 'medium' as const,
    status: 'in_progress' as const,
    dueDate: new Date('2024-04-15'),
    assignedTo: 'client',
    dependencies: []
  },
  {
    id: '3',
    clientId: '1',
    title: 'Schedule Tax Review Call',
    description: 'Schedule a call with your tax professional to review your return',
    type: 'other' as const,
    priority: 'medium' as const,
    status: 'pending' as const,
    dueDate: new Date('2024-04-20'),
    assignedTo: 'client',
    dependencies: ['1', '2']
  },
  {
    id: '4',
    clientId: '1',
    title: 'Complete Tax Return',
    description: 'Finalize and submit your 2024 tax return',
    type: 'form_completion' as const,
    priority: 'high' as const,
    status: 'completed' as const,
    completedDate: new Date('2024-03-15'),
    assignedTo: 'preparer',
    dependencies: []
  }
];

const mockOnboardingSteps = [
  {
    id: '1',
    title: 'Welcome to Lawson Mobile Tax',
    description: 'Get started with your personalized tax experience',
    type: 'welcome' as const,
    order: 1,
    isRequired: true,
    estimatedTime: 2,
    completionRate: 95,
    dropoffRate: 5,
    component: 'WelcomeStep'
  },
  {
    id: '2',
    title: 'Build Your Tax Profile',
    description: 'Tell us about your tax situation for personalized recommendations',
    type: 'profile' as const,
    order: 2,
    isRequired: true,
    estimatedTime: 5,
    completionRate: 87,
    dropoffRate: 13,
    component: 'ProfileStep'
  },
  {
    id: '3',
    title: 'Set Your Preferences',
    description: 'Choose how you want to receive updates and communications',
    type: 'preferences' as const,
    order: 3,
    isRequired: true,
    estimatedTime: 3,
    completionRate: 92,
    dropoffRate: 8,
    component: 'PreferencesStep'
  },
  {
    id: '4',
    title: 'Complete Setup',
    description: 'You\'re all set! Welcome to your personalized tax experience',
    type: 'completion' as const,
    order: 4,
    isRequired: true,
    estimatedTime: 1,
    completionRate: 98,
    dropoffRate: 2,
    component: 'CompletionStep'
  }
];

const mockPersonas = [
  {
    id: '1',
    type: 'w2_employee' as const,
    name: 'W-2 Employee',
    description: 'Individuals with traditional employment seeking simple tax filing',
    painPoints: ['Time constraints', 'Fear of mistakes', 'Want maximum refund'],
    preferences: {
      communicationChannel: 'email' as const,
      complexity: 'simple' as const,
      timing: 'immediate' as const
    },
    demographics: {
      ageRange: '25-45',
      incomeRange: '$40K-$80K',
      location: 'Urban/Suburban'
    }
  },
  {
    id: '2',
    type: 'small_business' as const,
    name: 'Small Business Owner',
    description: 'Entrepreneurs needing comprehensive business tax solutions',
    painPoints: ['Complex deductions', 'Quarterly taxes', 'Business/personal separation'],
    preferences: {
      communicationChannel: 'phone' as const,
      complexity: 'advanced' as const,
      timing: 'scheduled' as const
    },
    demographics: {
      ageRange: '30-55',
      incomeRange: '$60K-$200K',
      location: 'Mixed'
    }
  }
];

export default function ExperiencePage() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showOnboarding, setShowOnboarding] = useState(false);

  const handleUpdateWidget = (widgetId: string, updates: any) => {
    console.log('Update widget:', { widgetId, updates });
  };

  const handleMarkNotificationRead = (notificationId: string) => {
    console.log('Mark notification read:', notificationId);
  };

  const handleCompleteTask = (taskId: string) => {
    console.log('Complete task:', taskId);
  };

  const handleUploadDocument = (document: any) => {
    console.log('Upload document:', document);
  };

  const handleCompleteOnboarding = (profile: any) => {
    console.log('Complete onboarding:', profile);
    setShowOnboarding(false);
  };

  const handleStepComplete = (stepId: string, data: any) => {
    console.log('Step complete:', { stepId, data });
  };

  const handleSkipStep = (stepId: string) => {
    console.log('Skip step:', stepId);
  };

  if (showOnboarding) {
    return (
      <WhiteGloveOnboarding
        steps={mockOnboardingSteps}
        personas={mockPersonas}
        onComplete={handleCompleteOnboarding}
        onStepComplete={handleStepComplete}
        onSkipStep={handleSkipStep}
      />
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Client Experience Hub
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl">
              Deliver exceptional, personalized experiences that make every client feel valued, 
              educated, and empowered throughout their tax journey.
            </p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => setShowOnboarding(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Preview Onboarding
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Client Satisfaction</p>
                <p className="text-2xl font-bold text-green-600">4.9/5</p>
                <p className="text-xs text-green-600">↑ 0.2 from last month</p>
              </div>
              <User className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Onboarding Completion</p>
                <p className="text-2xl font-bold text-blue-600">92%</p>
                <p className="text-xs text-blue-600">↑ 5% from last month</p>
              </div>
              <Settings className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Engagement Score</p>
                <p className="text-2xl font-bold text-purple-600">87%</p>
                <p className="text-xs text-purple-600">↑ 3% from last month</p>
              </div>
              <Activity className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Support Response</p>
                <p className="text-2xl font-bold text-orange-600">< 2h</p>
                <p className="text-xs text-orange-600">↓ 30min from last month</p>
              </div>
              <Bell className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="dashboard">Client Dashboard</TabsTrigger>
          <TabsTrigger value="onboarding">Onboarding Flow</TabsTrigger>
          <TabsTrigger value="analytics">Experience Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Experience Journey</CardTitle>
                <CardDescription>
                  How clients progress through their tax experience
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium">Onboarding</p>
                      <p className="text-sm text-gray-600">Welcome & profile setup</p>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">92% completion</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium">Document Collection</p>
                      <p className="text-sm text-gray-600">Upload tax documents</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">87% completion</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <p className="font-medium">Tax Preparation</p>
                      <p className="text-sm text-gray-600">Review & finalize return</p>
                    </div>
                    <Badge className="bg-purple-100 text-purple-800">94% completion</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium">Follow-up</p>
                      <p className="text-sm text-gray-600">Year-round support</p>
                    </div>
                    <Badge className="bg-orange-100 text-orange-800">78% engagement</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Client Feedback</CardTitle>
                <CardDescription>
                  Recent feedback and testimonials from clients
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="flex space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className="text-yellow-400">★</span>
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">Sarah M.</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      "The personalized dashboard made everything so easy to track. 
                      I always knew exactly what I needed to do next."
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="flex space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className="text-yellow-400">★</span>
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">Mike C.</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      "The onboarding process was incredibly smooth. 
                      It felt like the platform was built just for my business needs."
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="flex space-x-1">
                        {[...Array(4)].map((_, i) => (
                          <span key={i} className="text-yellow-400">★</span>
                        ))}
                        <span className="text-gray-300">★</span>
                      </div>
                      <span className="text-sm text-gray-600">Jennifer L.</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      "Great experience overall. The educational content helped me 
                      understand my taxes better than ever before."
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Experience Highlights */}
          <Card>
            <CardHeader>
              <CardTitle>Experience Highlights</CardTitle>
              <CardDescription>
                Key features that make our client experience exceptional
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Personalized Dashboards</h3>
                  <p className="text-sm text-gray-600">
                    Custom dashboards tailored to each client's specific tax situation and preferences
                  </p>
                </div>
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Settings className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">White-Glove Onboarding</h3>
                  <p className="text-sm text-gray-600">
                    Guided setup process that educates clients and builds confidence from day one
                  </p>
                </div>
                <div className="text-center p-6 border rounded-lg">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Bell className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Proactive Communication</h3>
                  <p className="text-sm text-gray-600">
                    Smart notifications and reminders that keep clients informed and on track
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dashboard">
          <PersonalizedDashboard
            clientProfile={mockClientProfile}
            portal={mockPortal}
            notifications={mockNotifications}
            documents={mockDocuments}
            tasks={mockTasks}
            onUpdateWidget={handleUpdateWidget}
            onMarkNotificationRead={handleMarkNotificationRead}
            onCompleteTask={handleCompleteTask}
            onUploadDocument={handleUploadDocument}
          />
        </TabsContent>

        <TabsContent value="onboarding" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              White-Glove Onboarding Experience
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our onboarding process is designed to educate, engage, and empower clients 
              from their very first interaction with our platform.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Onboarding Flow</CardTitle>
                <CardDescription>
                  Step-by-step journey that personalizes the experience
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockOnboardingSteps.map((step, index) => (
                    <div key={step.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-medium text-blue-600">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{step.title}</h4>
                        <p className="text-sm text-gray-600">{step.description}</p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                          <span>~{step.estimatedTime} min</span>
                          <span>{step.completionRate}% completion rate</span>
                        </div>
                      </div>
                      <Badge variant="outline">
                        {step.isRequired ? 'Required' : 'Optional'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Onboarding Metrics</CardTitle>
                <CardDescription>
                  Performance metrics for our onboarding process
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Overall Completion Rate</span>
                      <span className="text-sm font-bold text-green-600">92%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Average Time to Complete</span>
                      <span className="text-sm font-bold text-blue-600">11 minutes</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: '73%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Client Satisfaction</span>
                      <span className="text-sm font-bold text-purple-600">4.8/5</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{ width: '96%' }}></div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <h5 className="font-medium text-gray-900 mb-3">Key Benefits</h5>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <span className="text-green-600">✓</span>
                        <span>67% reduction in support tickets</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-green-600">✓</span>
                        <span>45% increase in feature adoption</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-green-600">✓</span>
                        <span>38% improvement in client retention</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <button
              onClick={() => setShowOnboarding(true)}
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-lg font-medium"
            >
              Experience the Onboarding Flow
            </button>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Experience Metrics</CardTitle>
                <CardDescription>
                  Key performance indicators for client experience
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-green-900">Net Promoter Score</p>
                      <p className="text-sm text-green-700">Client advocacy measure</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">72</p>
                      <p className="text-xs text-green-600">↑ 8 from last quarter</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-blue-900">Customer Effort Score</p>
                      <p className="text-sm text-blue-700">Ease of experience</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-600">4.6/5</p>
                      <p className="text-xs text-blue-600">↑ 0.3 from last quarter</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <p className="font-medium text-purple-900">Task Completion Rate</p>
                      <p className="text-sm text-purple-700">Client action completion</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-purple-600">89%</p>
                      <p className="text-xs text-purple-600">↑ 5% from last quarter</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Support Metrics</CardTitle>
                <CardDescription>
                  Client support and satisfaction metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium text-orange-900">First Response Time</p>
                      <p className="text-sm text-orange-700">Average initial response</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-orange-600">1.8h</p>
                      <p className="text-xs text-orange-600">↓ 0.5h from last month</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <p className="font-medium text-red-900">Resolution Time</p>
                      <p className="text-sm text-red-700">Average time to resolve</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-red-600">4.2h</p>
                      <p className="text-xs text-red-600">↓ 1.1h from last month</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium text-green-900">Support Satisfaction</p>
                      <p className="text-sm text-green-700">Client support rating</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">4.9/5</p>
                      <p className="text-xs text-green-600">↑ 0.1 from last month</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Experience Improvement Opportunities</CardTitle>
              <CardDescription>
                Areas identified for enhancing client experience
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">High Impact Improvements</h4>
                  <div className="space-y-3">
                    <div className="p-3 border border-red-200 bg-red-50 rounded-lg">
                      <h5 className="font-medium text-red-900">Mobile Experience</h5>
                      <p className="text-sm text-red-700">
                        23% of clients report difficulty with mobile document upload
                      </p>
                    </div>
                    <div className="p-3 border border-yellow-200 bg-yellow-50 rounded-lg">
                      <h5 className="font-medium text-yellow-900">Notification Timing</h5>
                      <p className="text-sm text-yellow-700">
                        Optimize reminder timing to reduce notification fatigue
                      </p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Quick Wins</h4>
                  <div className="space-y-3">
                    <div className="p-3 border border-green-200 bg-green-50 rounded-lg">
                      <h5 className="font-medium text-green-900">Tutorial Videos</h5>
                      <p className="text-sm text-green-700">
                        Add short tutorial videos for complex features
                      </p>
                    </div>
                    <div className="p-3 border border-blue-200 bg-blue-50 rounded-lg">
                      <h5 className="font-medium text-blue-900">Progress Indicators</h5>
                      <p className="text-sm text-blue-700">
                        Show completion progress more prominently
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

