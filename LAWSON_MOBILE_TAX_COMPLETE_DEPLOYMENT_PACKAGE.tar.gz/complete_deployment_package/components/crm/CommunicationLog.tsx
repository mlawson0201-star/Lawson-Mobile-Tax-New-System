
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Mail, 
  MessageSquare, 
  Phone, 
  Calendar, 
  FileText, 
  Plus,
  Send,
  ArrowUpRight,
  ArrowDownLeft
} from 'lucide-react';
import { CommunicationForm } from './CommunicationForm';

interface Communication {
  id: string;
  type: string;
  subject?: string;
  content: string;
  direction: 'INBOUND' | 'OUTBOUND';
  status: string;
  created_at: string;
  user?: {
    id: string;
    firstName: string;
    lastName: string;
  };
}

interface CommunicationLogProps {
  leadId: string;
  communications: Communication[];
}

export function CommunicationLog({ leadId, communications }: CommunicationLogProps) {
  const [showCommunicationForm, setShowCommunicationForm] = useState(false);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'EMAIL':
        return <Mail className="h-4 w-4" />;
      case 'SMS':
        return <MessageSquare className="h-4 w-4" />;
      case 'PHONE_CALL':
        return <Phone className="h-4 w-4" />;
      case 'MEETING':
        return <Calendar className="h-4 w-4" />;
      case 'NOTE':
        return <FileText className="h-4 w-4" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    const colors = {
      EMAIL: 'bg-blue-100 text-blue-800',
      SMS: 'bg-green-100 text-green-800',
      PHONE_CALL: 'bg-purple-100 text-purple-800',
      MEETING: 'bg-orange-100 text-orange-800',
      NOTE: 'bg-gray-100 text-gray-800',
      TASK: 'bg-yellow-100 text-yellow-800',
      FOLLOW_UP: 'bg-red-100 text-red-800',
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Communication History</h3>
        <Dialog open={showCommunicationForm} onOpenChange={setShowCommunicationForm}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Communication
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log Communication</DialogTitle>
              <DialogDescription>
                Record a communication with this lead
              </DialogDescription>
            </DialogHeader>
            <CommunicationForm
              leadId={leadId}
              onSuccess={() => {
                setShowCommunicationForm(false);
                // Refresh communications
              }}
              onCancel={() => setShowCommunicationForm(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {communications.map((comm) => (
          <Card key={comm.id} className="relative">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className={`p-2 rounded-full ${getTypeColor(comm.type)}`}>
                    {getTypeIcon(comm.type)}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge className={getTypeColor(comm.type)}>
                        {comm.type.replace('_', ' ')}
                      </Badge>
                      <div className="flex items-center text-sm text-muted-foreground">
                        {comm.direction === 'OUTBOUND' ? (
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                        ) : (
                          <ArrowDownLeft className="h-3 w-3 mr-1" />
                        )}
                        {comm.direction}
                      </div>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {formatDate(comm.created_at)}
                    </span>
                  </div>
                  
                  {comm.subject && (
                    <h4 className="font-medium mt-1">{comm.subject}</h4>
                  )}
                  
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-3">
                    {comm.content}
                  </p>
                  
                  {comm.user && (
                    <div className="flex items-center space-x-2 mt-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs">
                          {comm.user.firstName[0]}{comm.user.lastName[0]}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">
                        {comm.user.firstName} {comm.user.lastName}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {communications.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No communications recorded yet.</p>
              <p className="text-sm text-muted-foreground mt-1">
                Start by logging your first interaction with this lead.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
