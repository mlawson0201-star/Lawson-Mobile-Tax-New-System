
"""
Blockchain Technology
Decentralized features and cryptocurrency integration
"""

from .document_verification import BlockchainDocumentVerifier
from .smart_contracts import TaxComplianceSmartContracts
from .crypto_calculator import CryptocurrencyTaxCalculator
from .nft_tracker import NFTTransactionTracker
from .defi_integrator import DeFiProtocolIntegrator
from .audit_trail import ImmutableAuditTrail
from .identity_verifier import DecentralizedIdentityVerifier
from .cross_border_compliance import CrossBorderTaxCompliance
from .tokenized_credits import TokenizedTaxCredits
from .secure_sharing import BlockchainSecureSharing

__version__ = "1.0.0"
__all__ = [
    "BlockchainDocumentVerifier",
    "TaxComplianceSmartContracts",
    "CryptocurrencyTaxCalculator",
    "NFTTransactionTracker",
    "DeFiProtocolIntegrator", 
    "ImmutableAuditTrail",
    "DecentralizedIdentityVerifier",
    "CrossBorderTaxCompliance",
    "TokenizedTaxCredits",
    "BlockchainSecureSharing"
]
