
import { ClientProfile, ClientSuccessScore } from '../types/experience';
import { ChurnPrediction, ChurnFactor } from '../types/retention';
import { PointsTransaction } from '../types/retention';

export class PredictiveAnalytics {
  private static instance: PredictiveAnalytics;

  public static getInstance(): PredictiveAnalytics {
    if (!PredictiveAnalytics.instance) {
      PredictiveAnalytics.instance = new PredictiveAnalytics();
    }
    return PredictiveAnalytics.instance;
  }

  /**
   * Predict client churn risk using multiple factors
   */
  async predictChurnRisk(
    clientId: string,
    profile: ClientProfile,
    successScore: ClientSuccessScore,
    recentActivity: {
      lastLogin: Date;
      taskCompletionRate: number;
      supportTickets: number;
      paymentHistory: string[];
      engagementScore: number;
    }
  ): Promise<ChurnPrediction> {
    const factors = await this.calculateChurnFactors(profile, successScore, recentActivity);
    const riskScore = this.calculateOverallRiskScore(factors);
    const riskLevel = this.determineRiskLevel(riskScore);
    const recommendations = this.generateRetentionRecommendations(factors, riskLevel);

    return {
      clientId,
      riskScore,
      riskLevel,
      factors,
      recommendations,
      lastCalculated: new Date(),
      interventionStatus: 'none'
    };
  }

  /**
   * Predict client lifetime value
   */
  async predictLifetimeValue(
    profile: ClientProfile,
    historicalData: {
      totalSpent: number;
      serviceUsage: Record<string, number>;
      referrals: number;
      tenure: number; // in months
    }
  ): Promise<{
    predictedLTV: number;
    confidence: number;
    factors: Array<{ factor: string; impact: number; description: string }>;
    timeframe: number; // in months
  }> {
    const baseValue = historicalData.totalSpent;
    const monthlyAverage = baseValue / Math.max(historicalData.tenure, 1);
    
    // Calculate multipliers based on various factors
    const personaMultiplier = this.getPersonaLTVMultiplier(profile.persona.type);
    const engagementMultiplier = this.getEngagementMultiplier(profile.completionScore);
    const referralMultiplier = this.getReferralMultiplier(historicalData.referrals);
    const complexityMultiplier = this.getComplexityMultiplier(profile.taxComplexity);

    const predictedMonthlyValue = monthlyAverage * personaMultiplier * engagementMultiplier * referralMultiplier * complexityMultiplier;
    const predictedLTV = predictedMonthlyValue * 36; // 3-year prediction

    const factors = [
      {
        factor: 'Client Persona',
        impact: personaMultiplier,
        description: `${profile.persona.name} clients typically have ${personaMultiplier > 1 ? 'higher' : 'lower'} lifetime value`
      },
      {
        factor: 'Engagement Level',
        impact: engagementMultiplier,
        description: `Profile completion of ${profile.completionScore}% indicates ${engagementMultiplier > 1 ? 'high' : 'low'} engagement`
      },
      {
        factor: 'Referral Activity',
        impact: referralMultiplier,
        description: `${historicalData.referrals} referrals indicate ${referralMultiplier > 1 ? 'strong' : 'weak'} advocacy`
      },
      {
        factor: 'Tax Complexity',
        impact: complexityMultiplier,
        description: `${profile.taxComplexity} tax situation affects service needs`
      }
    ];

    const confidence = this.calculateLTVConfidence(historicalData, profile);

    return {
      predictedLTV,
      confidence,
      factors,
      timeframe: 36
    };
  }

  /**
   * Predict optimal communication timing
   */
  async predictOptimalTiming(
    clientId: string,
    communicationHistory: Array<{
      sentAt: Date;
      type: string;
      opened: boolean;
      clicked: boolean;
      responseTime?: number;
    }>,
    timezone: string
  ): Promise<{
    bestDayOfWeek: string;
    bestTimeOfDay: string;
    frequency: 'daily' | 'weekly' | 'biweekly' | 'monthly';
    confidence: number;
    insights: string[];
  }> {
    // Analyze historical engagement patterns
    const dayAnalysis = this.analyzeDayPatterns(communicationHistory);
    const timeAnalysis = this.analyzeTimePatterns(communicationHistory);
    const frequencyAnalysis = this.analyzeFrequencyPatterns(communicationHistory);

    return {
      bestDayOfWeek: dayAnalysis.bestDay,
      bestTimeOfDay: timeAnalysis.bestTime,
      frequency: frequencyAnalysis.optimalFrequency,
      confidence: (dayAnalysis.confidence + timeAnalysis.confidence + frequencyAnalysis.confidence) / 3,
      insights: [
        `${dayAnalysis.bestDay}s show ${dayAnalysis.engagementRate}% higher engagement`,
        `${timeAnalysis.bestTime} has the highest open rates`,
        `${frequencyAnalysis.optimalFrequency} communication prevents fatigue`
      ]
    };
  }

  /**
   * Predict service recommendations
   */
  async predictServiceRecommendations(
    profile: ClientProfile,
    currentServices: string[],
    usage: Record<string, number>
  ): Promise<Array<{
    serviceId: string;
    serviceName: string;
    probability: number;
    reasoning: string;
    expectedValue: number;
    priority: 'high' | 'medium' | 'low';
  }>> {
    const recommendations = [];

    // Business consulting for small business owners
    if (profile.persona.type === 'small_business' && !currentServices.includes('business_consulting')) {
      recommendations.push({
        serviceId: 'business_consulting',
        serviceName: 'Business Tax Consulting',
        probability: 0.75,
        reasoning: 'Small business owners typically benefit from ongoing tax consulting',
        expectedValue: 2400,
        priority: 'high' as const
      });
    }

    // Audit protection for high-value clients
    if (profile.taxComplexity === 'complex' && !currentServices.includes('audit_protection')) {
      recommendations.push({
        serviceId: 'audit_protection',
        serviceName: 'Audit Defense Protection',
        probability: 0.65,
        reasoning: 'Complex tax situations have higher audit risk',
        expectedValue: 299,
        priority: 'medium' as const
      });
    }

    // Financial planning for investors
    if (profile.persona.type === 'investor' && !currentServices.includes('financial_planning')) {
      recommendations.push({
        serviceId: 'financial_planning',
        serviceName: 'Investment Tax Planning',
        probability: 0.80,
        reasoning: 'Investors need ongoing tax optimization strategies',
        expectedValue: 1800,
        priority: 'high' as const
      });
    }

    // Bookkeeping for freelancers
    if (profile.persona.type === 'freelancer' && !currentServices.includes('bookkeeping')) {
      recommendations.push({
        serviceId: 'bookkeeping',
        serviceName: 'Monthly Bookkeeping',
        probability: 0.55,
        reasoning: 'Freelancers often struggle with expense tracking',
        expectedValue: 1200,
        priority: 'medium' as const
      });
    }

    return recommendations.sort((a, b) => b.probability * b.expectedValue - a.probability * a.expectedValue);
  }

  private async calculateChurnFactors(
    profile: ClientProfile,
    successScore: ClientSuccessScore,
    activity: any
  ): Promise<ChurnFactor[]> {
    const factors: ChurnFactor[] = [];

    // Login frequency factor
    const daysSinceLastLogin = Math.floor((Date.now() - activity.lastLogin.getTime()) / (1000 * 60 * 60 * 24));
    factors.push({
      factor: 'Login Frequency',
      weight: 0.25,
      value: Math.max(0, 100 - daysSinceLastLogin * 2),
      impact: daysSinceLastLogin > 30 ? 'negative' : 'positive',
      description: `Last login was ${daysSinceLastLogin} days ago`
    });

    // Task completion factor
    factors.push({
      factor: 'Task Completion',
      weight: 0.20,
      value: activity.taskCompletionRate,
      impact: activity.taskCompletionRate > 70 ? 'positive' : 'negative',
      description: `${activity.taskCompletionRate}% task completion rate`
    });

    // Support tickets factor
    factors.push({
      factor: 'Support Issues',
      weight: 0.15,
      value: Math.max(0, 100 - activity.supportTickets * 10),
      impact: activity.supportTickets > 3 ? 'negative' : 'positive',
      description: `${activity.supportTickets} support tickets in last 30 days`
    });

    // Engagement score factor
    factors.push({
      factor: 'Engagement Score',
      weight: 0.20,
      value: activity.engagementScore,
      impact: activity.engagementScore > 60 ? 'positive' : 'negative',
      description: `Overall engagement score of ${activity.engagementScore}%`
    });

    // Payment history factor
    const latePayments = activity.paymentHistory.filter(p => p === 'late').length;
    factors.push({
      factor: 'Payment History',
      weight: 0.20,
      value: Math.max(0, 100 - latePayments * 20),
      impact: latePayments > 1 ? 'negative' : 'positive',
      description: `${latePayments} late payments in history`
    });

    return factors;
  }

  private calculateOverallRiskScore(factors: ChurnFactor[]): number {
    let weightedSum = 0;
    let totalWeight = 0;

    factors.forEach(factor => {
      const adjustedValue = factor.impact === 'negative' ? 100 - factor.value : factor.value;
      weightedSum += adjustedValue * factor.weight;
      totalWeight += factor.weight;
    });

    return Math.round((1 - weightedSum / (totalWeight * 100)) * 100);
  }

  private determineRiskLevel(riskScore: number): 'low' | 'medium' | 'high' | 'critical' {
    if (riskScore >= 80) return 'critical';
    if (riskScore >= 60) return 'high';
    if (riskScore >= 40) return 'medium';
    return 'low';
  }

  private generateRetentionRecommendations(factors: ChurnFactor[], riskLevel: string): string[] {
    const recommendations = [];

    if (riskLevel === 'critical' || riskLevel === 'high') {
      recommendations.push('Schedule immediate personal outreach call');
      recommendations.push('Offer exclusive discount or service upgrade');
    }

    factors.forEach(factor => {
      if (factor.impact === 'negative') {
        switch (factor.factor) {
          case 'Login Frequency':
            recommendations.push('Send re-engagement email campaign');
            break;
          case 'Task Completion':
            recommendations.push('Provide additional onboarding support');
            break;
          case 'Support Issues':
            recommendations.push('Assign dedicated success manager');
            break;
          case 'Engagement Score':
            recommendations.push('Personalize content recommendations');
            break;
          case 'Payment History':
            recommendations.push('Offer flexible payment options');
            break;
        }
      }
    });

    return [...new Set(recommendations)]; // Remove duplicates
  }

  private getPersonaLTVMultiplier(personaType: string): number {
    const multipliers = {
      'w2_employee': 1.0,
      'small_business': 2.5,
      'investor': 3.0,
      'retiree': 1.5,
      'freelancer': 1.8
    };
    return multipliers[personaType as keyof typeof multipliers] || 1.0;
  }

  private getEngagementMultiplier(completionScore: number): number {
    if (completionScore >= 90) return 1.5;
    if (completionScore >= 70) return 1.2;
    if (completionScore >= 50) return 1.0;
    return 0.8;
  }

  private getReferralMultiplier(referrals: number): number {
    if (referrals >= 5) return 1.4;
    if (referrals >= 2) return 1.2;
    if (referrals >= 1) return 1.1;
    return 1.0;
  }

  private getComplexityMultiplier(complexity: string): number {
    const multipliers = {
      'simple': 1.0,
      'moderate': 1.3,
      'complex': 1.8
    };
    return multipliers[complexity as keyof typeof multipliers] || 1.0;
  }

  private calculateLTVConfidence(historicalData: any, profile: ClientProfile): number {
    let confidence = 0.5; // Base confidence

    // More data = higher confidence
    if (historicalData.tenure > 12) confidence += 0.2;
    else if (historicalData.tenure > 6) confidence += 0.1;

    // Profile completeness
    if (profile.completionScore > 80) confidence += 0.2;
    else if (profile.completionScore > 60) confidence += 0.1;

    // Service usage diversity
    const serviceCount = Object.keys(historicalData.serviceUsage).length;
    if (serviceCount > 3) confidence += 0.1;

    return Math.min(confidence, 1.0);
  }

  private analyzeDayPatterns(history: any[]): { bestDay: string; confidence: number; engagementRate: number } {
    const dayStats = {
      'Monday': { opens: 0, total: 0 },
      'Tuesday': { opens: 0, total: 0 },
      'Wednesday': { opens: 0, total: 0 },
      'Thursday': { opens: 0, total: 0 },
      'Friday': { opens: 0, total: 0 },
      'Saturday': { opens: 0, total: 0 },
      'Sunday': { opens: 0, total: 0 }
    };

    history.forEach(comm => {
      const day = comm.sentAt.toLocaleDateString('en-US', { weekday: 'long' });
      if (dayStats[day as keyof typeof dayStats]) {
        dayStats[day as keyof typeof dayStats].total++;
        if (comm.opened) dayStats[day as keyof typeof dayStats].opens++;
      }
    });

    let bestDay = 'Tuesday';
    let bestRate = 0;

    Object.entries(dayStats).forEach(([day, stats]) => {
      if (stats.total > 0) {
        const rate = stats.opens / stats.total;
        if (rate > bestRate) {
          bestRate = rate;
          bestDay = day;
        }
      }
    });

    return {
      bestDay,
      confidence: history.length > 20 ? 0.8 : 0.5,
      engagementRate: Math.round(bestRate * 100)
    };
  }

  private analyzeTimePatterns(history: any[]): { bestTime: string; confidence: number } {
    // Simplified time analysis
    const timeSlots = {
      'Morning (9-11 AM)': { opens: 0, total: 0 },
      'Midday (11 AM-2 PM)': { opens: 0, total: 0 },
      'Afternoon (2-5 PM)': { opens: 0, total: 0 },
      'Evening (5-8 PM)': { opens: 0, total: 0 }
    };

    history.forEach(comm => {
      const hour = comm.sentAt.getHours();
      let slot = 'Morning (9-11 AM)';
      if (hour >= 11 && hour < 14) slot = 'Midday (11 AM-2 PM)';
      else if (hour >= 14 && hour < 17) slot = 'Afternoon (2-5 PM)';
      else if (hour >= 17 && hour < 20) slot = 'Evening (5-8 PM)';

      timeSlots[slot as keyof typeof timeSlots].total++;
      if (comm.opened) timeSlots[slot as keyof typeof timeSlots].opens++;
    });

    let bestTime = 'Morning (9-11 AM)';
    let bestRate = 0;

    Object.entries(timeSlots).forEach(([time, stats]) => {
      if (stats.total > 0) {
        const rate = stats.opens / stats.total;
        if (rate > bestRate) {
          bestRate = rate;
          bestTime = time;
        }
      }
    });

    return {
      bestTime,
      confidence: history.length > 15 ? 0.7 : 0.4
    };
  }

  private analyzeFrequencyPatterns(history: any[]): { optimalFrequency: 'daily' | 'weekly' | 'biweekly' | 'monthly'; confidence: number } {
    // Simplified frequency analysis based on engagement patterns
    if (history.length < 10) {
      return { optimalFrequency: 'weekly', confidence: 0.3 };
    }

    const avgEngagement = history.reduce((sum, comm) => sum + (comm.opened ? 1 : 0), 0) / history.length;

    if (avgEngagement > 0.7) return { optimalFrequency: 'weekly', confidence: 0.8 };
    if (avgEngagement > 0.4) return { optimalFrequency: 'biweekly', confidence: 0.7 };
    return { optimalFrequency: 'monthly', confidence: 0.6 };
  }
}

export default PredictiveAnalytics;
