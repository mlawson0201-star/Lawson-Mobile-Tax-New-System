
import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount / 100)
}

export function formatDate(date: Date | string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(date))
}

export function formatDateTime(date: Date | string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export function calculateTaxAmount(income: number, filingStatus: string): number {
  // Simplified tax calculation - replace with actual tax engine
  const standardDeduction = filingStatus === 'MARRIED_FILING_JOINTLY' ? 27700 : 13850
  const taxableIncome = Math.max(0, income - standardDeduction)
  
  // 2024 tax brackets (simplified)
  if (taxableIncome <= 22000) {
    return taxableIncome * 0.10
  } else if (taxableIncome <= 89450) {
    return 2200 + (taxableIncome - 22000) * 0.12
  } else if (taxableIncome <= 190750) {
    return 10294 + (taxableIncome - 89450) * 0.22
  } else {
    return 32580 + (taxableIncome - 190750) * 0.24
  }
}

export function validateEIN(ein: string): boolean {
  const einRegex = /^\d{2}-\d{7}$/
  return einRegex.test(ein)
}

export function validateSSN(ssn: string): boolean {
  const ssnRegex = /^\d{3}-\d{2}-\d{4}$/
  return ssnRegex.test(ssn)
}

export function maskSSN(ssn: string): string {
  return ssn.replace(/\d(?=\d{4})/g, '*')
}

export function maskEIN(ein: string): string {
  return ein.replace(/\d(?=\d{4})/g, '*')
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'INTAKE': return 'bg-blue-100 text-blue-800'
    case 'IN_PROGRESS': return 'bg-yellow-100 text-yellow-800'
    case 'REVIEW': return 'bg-orange-100 text-orange-800'
    case 'COMPLETED': return 'bg-green-100 text-green-800'
    case 'FILED': return 'bg-purple-100 text-purple-800'
    case 'PAID': return 'bg-emerald-100 text-emerald-800'
    case 'PENDING': return 'bg-gray-100 text-gray-800'
    case 'FAILED': return 'bg-red-100 text-red-800'
    default: return 'bg-gray-100 text-gray-800'
  }
}

export function getInitials(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

export function getRoleDisplayName(role: string): string {
  switch (role) {
    case 'SUPER_ADMIN': return 'Super Admin'
    case 'TENANT_ADMIN': return 'Admin'
    case 'EA_CPA': return 'Tax Professional'
    case 'PREPARER': return 'Preparer'
    case 'CLIENT': return 'Client'
    default: return role
  }
}
