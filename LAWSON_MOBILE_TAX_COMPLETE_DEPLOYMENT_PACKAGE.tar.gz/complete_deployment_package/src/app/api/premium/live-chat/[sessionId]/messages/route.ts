
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(
  request: NextRequest,
  { params }: { params: { sessionId: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { sessionId } = params;
    const { message, messageType, attachments } = await request.json();

    if (!message && !attachments?.length) {
      return NextResponse.json({ error: 'Message or attachments required' }, { status: 400 });
    }

    // Verify session exists and user has access
    const chatSession = await prisma.liveChatSession.findFirst({
      where: {
        id: sessionId,
        tenantId: session.user.tenantId,
        OR: [
          { clientId: session.user.roles?.includes('client') ? session.user.id : undefined },
          { eaCpaUserId: session.user.roles?.includes('ea_cpa') ? session.user.id : undefined },
        ],
      },
    });

    if (!chatSession) {
      return NextResponse.json({ error: 'Chat session not found' }, { status: 404 });
    }

    // Determine sender type based on user role
    const senderType = session.user.roles?.includes('ea_cpa') ? 'ea_cpa' : 'client';

    // Create message
    const chatMessage = await prisma.chatMessage.create({
      data: {
        sessionId,
        senderId: session.user.id,
        senderType,
        message: message || '',
        messageType: messageType || 'text',
        attachments: attachments || [],
      },
    });

    // Update session status if it's the first EA message
    if (senderType === 'ea_cpa' && chatSession.status === 'waiting') {
      await prisma.liveChatSession.update({
        where: { id: sessionId },
        data: {
          status: 'active',
          connectedAt: new Date(),
          waitTime: Math.round((Date.now() - new Date(chatSession.startedAt).getTime()) / 1000),
        },
      });
    }

    // Send notification to the other participant
    const notificationTargetId = senderType === 'ea_cpa' ? chatSession.clientId : chatSession.eaCpaUserId;
    
    if (notificationTargetId) {
      await prisma.pushNotification.create({
        data: {
          tenantId: session.user.tenantId,
          userId: senderType === 'client' ? notificationTargetId : undefined,
          clientId: senderType === 'ea_cpa' ? notificationTargetId : undefined,
          title: 'New Chat Message',
          message: message ? (message.length > 50 ? `${message.substring(0, 50)}...` : message) : 'Attachment received',
          notificationType: 'chat_message',
          priority: 'normal',
          payload: {
            sessionId,
            messageId: chatMessage.id,
            senderName: `${session.user.name}`,
          },
          deviceTokens: [`${senderType === 'client' ? 'user' : 'client'}_${notificationTargetId}_token`],
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: chatMessage,
    });

  } catch (error: any) {
    console.error('Send chat message error:', error);
    return NextResponse.json(
      { error: 'Failed to send message', details: error?.message },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { sessionId: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { sessionId } = params;
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const before = searchParams.get('before'); // Message ID for pagination

    // Verify session access
    const chatSession = await prisma.liveChatSession.findFirst({
      where: {
        id: sessionId,
        tenantId: session.user.tenantId,
      },
    });

    if (!chatSession) {
      return NextResponse.json({ error: 'Chat session not found' }, { status: 404 });
    }

    const messages = await prisma.chatMessage.findMany({
      where: {
        sessionId,
        ...(before && {
          createdAt: {
            lt: new Date(before),
          },
        }),
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    // Mark messages as read
    await prisma.chatMessage.updateMany({
      where: {
        sessionId,
        senderId: { not: session.user.id },
        isRead: false,
      },
      data: {
        isRead: true,
        readAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      messages: messages.reverse(), // Return in chronological order
      hasMore: messages.length === limit,
    });

  } catch (error: any) {
    console.error('Get chat messages error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve messages', details: error?.message },
      { status: 500 }
    );
  }
}
