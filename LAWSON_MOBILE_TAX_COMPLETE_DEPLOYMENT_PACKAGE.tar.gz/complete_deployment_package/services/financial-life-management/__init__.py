
"""
Comprehensive Financial Life Management
Holistic financial platform and advanced analytics
"""

from .financial_dashboard import PersonalFinancialDashboard
from .budget_planner import BudgetPlanningEngine
from .investment_optimizer import InvestmentPortfolioOptimizer
from .retirement_planner import RetirementPlanningEngine
from .insurance_analyzer import InsuranceNeedsAnalyzer
from .estate_planner import EstatePlanningIntegration
from .education_funding import EducationFundingStrategies
from .debt_optimizer import DebtOptimizationManager
from .credit_monitor import CreditScoreMonitor
from .goal_tracker import FinancialGoalTracker

__version__ = "1.0.0"
__all__ = [
    "PersonalFinancialDashboard",
    "BudgetPlanningEngine",
    "InvestmentPortfolioOptimizer",
    "RetirementPlanningEngine",
    "InsuranceNeedsAnalyzer",
    "EstatePlanningIntegration",
    "EducationFundingStrategies",
    "DebtOptimizationManager",
    "CreditScoreMonitor",
    "FinancialGoalTracker"
]
