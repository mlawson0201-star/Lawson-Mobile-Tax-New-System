
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { taxReturnId, clientData, previousReturns } = await request.json();

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID required' }, { status: 400 });
    }

    // Get tax return details
    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: {
        client: true,
        documents: {
          include: {
            ocrProcessing: true,
          },
        },
      },
    });

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
    }

    // Collect all extracted document data
    const documentData = taxReturn.documents
      .flatMap(doc => doc.ocrProcessing)
      .filter(ocr => ocr?.structuredData)
      .map(ocr => ocr?.structuredData);

    // Create comprehensive analysis prompt
    const analysisPrompt = `
      Analyze the following tax situation and discover all possible deductions and credits:

      Client Information:
      - Filing Status: ${(taxReturn.formData as any)?.filingStatus || 'single'}
      - Income: ${JSON.stringify(clientData?.income || {})}
      - Expenses: ${JSON.stringify(clientData?.expenses || {})}

      Document Data:
      ${JSON.stringify(documentData, null, 2)}

      Previous Returns (for comparison):
      ${JSON.stringify(previousReturns || [], null, 2)}

      Please analyze and return a JSON response with:
      {
        "deductions": [
          {
            "category": "business_expense | medical | charitable | etc",
            "subcategory": "specific type",
            "amount": number,
            "confidence": 0.0-1.0,
            "justification": "explanation",
            "evidence": "supporting data reference",
            "potentialSavings": number,
            "riskLevel": "low|medium|high",
            "irs_reference": "relevant IRS publication/form",
            "requirements": ["list of requirements to claim"]
          }
        ],
        "credits": [
          {
            "creditType": "child_tax_credit | eic | etc",
            "amount": number,
            "confidence": 0.0-1.0,
            "eligibility": "requirements check",
            "potentialSavings": number
          }
        ],
        "missed_opportunities": [
          {
            "opportunity": "description",
            "potential_value": number,
            "next_steps": "what client should do"
          }
        ],
        "optimization_suggestions": [
          {
            "strategy": "description",
            "impact": "estimated benefit",
            "timeline": "when to implement"
          }
        ]
      }

      Focus on maximizing legitimate deductions while maintaining compliance.
    `;

    const response = await fetch(`${process.env.ABACUSAI_BASE_URL || 'https://apps.abacus.ai'}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{ role: 'user', content: analysisPrompt }],
        response_format: { type: "json_object" },
        max_tokens: 4000,
      }),
    });

    if (!response.ok) {
      throw new Error(`AI analysis failed: ${response.statusText}`);
    }

    const aiResult = await response.json();
    const analysis = JSON.parse(aiResult.choices[0].message.content);

    // Get or create AI model record
    let aiModel = await prisma.aIModelData.findFirst({
      where: {
        tenantId: session.user.tenantId,
        modelType: 'deduction_discovery',
        isActive: true,
      },
    });

    if (!aiModel) {
      aiModel = await prisma.aIModelData.create({
        data: {
          tenantId: session.user.tenantId,
          modelType: 'deduction_discovery',
          modelVersion: '1.0.0',
          trainingData: {},
          accuracyMetrics: { initial: true },
          isActive: true,
          trainedAt: new Date(),
        },
      });
    }

    // Create deduction suggestions
    const deductionPromises = analysis.deductions?.map(async (deduction: any) => {
      return prisma.deductionSuggestion.create({
        data: {
          tenantId: session.user.tenantId,
          taxReturnId,
          aiModelId: aiModel!.id,
          deductionCategory: deduction.category,
          deductionAmount: parseFloat(deduction.amount || 0),
          confidenceScore: parseFloat(deduction.confidence || 0),
          evidenceData: {
            evidence: deduction.evidence,
            requirements: deduction.requirements,
            irs_reference: deduction.irs_reference,
            subcategory: deduction.subcategory,
          },
          justification: deduction.justification,
          potentialSavings: parseFloat(deduction.potentialSavings || 0),
          riskLevel: deduction.riskLevel || 'low',
        },
      });
    }) || [];

    const createdDeductions = await Promise.all(deductionPromises);

    // Log AI processing
    await prisma.aIProcessingLog.create({
      data: {
        tenantId: session.user.tenantId,
        modelId: aiModel.id,
        inputData: {
          taxReturnId,
          clientData,
          documentCount: documentData.length,
        },
        outputData: analysis,
        processingTime: Date.now(),
        confidenceScore: analysis.deductions?.reduce((avg: number, d: any) => 
          avg + (parseFloat(d.confidence) || 0), 0) / (analysis.deductions?.length || 1),
      },
    });

    return NextResponse.json({
      success: true,
      analysis,
      deductionsCreated: createdDeductions.length,
      totalPotentialSavings: analysis.deductions?.reduce((total: number, d: any) => 
        total + (parseFloat(d.potentialSavings) || 0), 0) || 0,
    });
  } catch (error: any) {
    console.error('Deduction discovery error:', error);
    return NextResponse.json(
      { error: 'Deduction discovery failed', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve deduction suggestions
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const taxReturnId = searchParams.get('taxReturnId');
    const status = searchParams.get('status') || undefined;

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID required' }, { status: 400 });
    }

    const deductions = await prisma.deductionSuggestion.findMany({
      where: {
        tenantId: session.user.tenantId,
        taxReturnId,
        ...(status && { status }),
      },
      include: {
        aiModel: {
          select: {
            modelType: true,
            modelVersion: true,
            accuracyMetrics: true,
          },
        },
      },
      orderBy: [
        { potentialSavings: 'desc' },
        { confidenceScore: 'desc' },
      ],
    });

    const summary = {
      totalSuggestions: deductions.length,
      totalPotentialSavings: deductions.reduce((sum, d) => sum + parseFloat(d.deductionAmount.toString()), 0),
      highConfidenceCount: deductions.filter(d => parseFloat(d.confidenceScore.toString()) > 0.8).length,
      statusBreakdown: deductions.reduce((acc, d) => {
        acc[d.status] = (acc[d.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
    };

    return NextResponse.json({
      success: true,
      deductions,
      summary,
    });
  } catch (error: any) {
    console.error('Get deductions error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve deductions', details: error?.message },
      { status: 500 }
    );
  }
}
