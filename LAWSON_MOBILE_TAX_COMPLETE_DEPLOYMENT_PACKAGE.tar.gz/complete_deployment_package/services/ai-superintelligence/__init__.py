
"""
AI Superintelligence Service
Advanced neural tax reasoning engine with GPT-4o integration
"""

from .neural_engine import NeuralTaxEngine
from .document_processor import MultiModalProcessor
from .optimization_engine import TaxOptimizationEngine
from .audit_risk_analyzer import AuditRiskAnalyzer
from .form_autocomplete import IntelligentFormFiller
from .nlp_processor import TaxQueryProcessor
from .vision_processor import DocumentVisionProcessor
from .anomaly_detector import TaxAnomalyDetector
from .research_engine import TaxLawResearchEngine
from .strategy_recommender import PersonalizedTaxStrategy

__version__ = "1.0.0"
__all__ = [
    "NeuralTaxEngine",
    "MultiModalProcessor", 
    "TaxOptimizationEngine",
    "AuditRiskAnalyzer",
    "IntelligentFormFiller",
    "TaxQueryProcessor",
    "DocumentVisionProcessor",
    "TaxAnomalyDetector",
    "TaxLawResearchEngine",
    "PersonalizedTaxStrategy"
]
