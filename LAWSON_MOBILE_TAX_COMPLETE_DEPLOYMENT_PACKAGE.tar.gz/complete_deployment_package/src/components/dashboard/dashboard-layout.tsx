
'use client';

import { useState } from 'react';
import { useSession, signOut } from 'next-auth/react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  CreditCard, 
  Settings, 
  LogOut,
  Menu,
  X,
  Building2,
  UserCheck,
  FileCheck,
  TrendingUp,
  Bell,
  Search,
  HelpCircle,
  Shield,
  Bot,
  Mic,
  Building,
  Gavel,
  Brain,
  Zap
} from 'lucide-react';
import { cn, getRoleDisplayName, getInitials } from '@/lib/utils';
import { TenantInfo } from '@/lib/tenant';

interface DashboardLayoutProps {
  children: React.ReactNode;
  tenant: TenantInfo | null;
}

interface NavItem {
  name: string;
  href: string;
  icon: any;
  roles: string[];
  badge?: string;
}

const navigation: NavItem[] = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer', 'client', 'support']
  },
  {
    name: 'Tax Returns',
    href: '/dashboard/tax-returns',
    icon: FileText,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer', 'client']
  },
  {
    name: 'Advanced Automation',
    href: '/dashboard/automation',
    icon: Zap,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer'],
    badge: '95%'
  },
  {
    name: 'Complex Returns',
    href: '/dashboard/automation/complex-returns',
    icon: Brain,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer']
  },
  {
    name: 'Audit Defense',
    href: '/dashboard/automation/audit-defense',
    icon: Shield,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa']
  },
  {
    name: 'Voice Processing',
    href: '/dashboard/automation/voice-processing',
    icon: Mic,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer']
  },
  {
    name: 'Business Formation',
    href: '/dashboard/automation/business-formation',
    icon: Building,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa']
  },
  {
    name: 'Clients',
    href: '/dashboard/clients',
    icon: Users,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'support']
  },
  {
    name: 'Review Queue',
    href: '/dashboard/review',
    icon: UserCheck,
    roles: ['ea_cpa'],
    badge: '3'
  },
  {
    name: 'E-Filing',
    href: '/dashboard/efile',
    icon: FileCheck,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa']
  },
  {
    name: 'Payments',
    href: '/dashboard/payments',
    icon: CreditCard,
    roles: ['super_admin', 'tenant_admin', 'client']
  },
  {
    name: 'Documents',
    href: '/dashboard/documents',
    icon: FileText,
    roles: ['client']
  },
  {
    name: 'Reports',
    href: '/dashboard/reports',
    icon: TrendingUp,
    roles: ['super_admin', 'tenant_admin']
  },
  {
    name: 'Tenants',
    href: '/dashboard/tenants',
    icon: Building2,
    roles: ['super_admin']
  },
  {
    name: 'System',
    href: '/dashboard/system',
    icon: Gavel,
    roles: ['super_admin']
  },
  {
    name: 'Settings',
    href: '/dashboard/settings',
    icon: Settings,
    roles: ['super_admin', 'tenant_admin', 'ea_cpa', 'preparer', 'client', 'support']
  },
];

export function DashboardLayout({ children, tenant }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { data: session } = useSession() || {};
  const pathname = usePathname();

  const userRole = session?.user?.roles?.[0] || 'client';
  const filteredNavigation = navigation.filter(item => 
    item.roles.includes(userRole)
  );

  const tenantName = tenant?.name || 'Lawson Mobile Tax';
  const primaryColor = tenant?.brandingConfig?.primaryColor || '#6a0dad';

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 flex z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        >
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75" />
        </div>
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 flex flex-col w-64 bg-white border-r border-gray-200 z-40 transform transition-transform duration-300 ease-in-out md:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Sidebar header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <div className="flex items-center">
            {tenant?.brandingConfig?.logo ? (
              <img src={tenant.brandingConfig.logo} alt={tenantName} className="h-8 w-auto" />
            ) : (
              <div className="h-8 w-8 bg-gradient-to-br from-purple-600 to-purple-800 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xs">LMT</span>
              </div>
            )}
            <span className="ml-3 text-lg font-semibold text-gray-900 truncate">{tenantName}</span>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden text-gray-400 hover:text-gray-600"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {filteredNavigation.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200",
                  isActive
                    ? "bg-purple-50 text-purple-700 border-r-2 border-purple-600"
                    : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                )}
                style={isActive ? { 
                  backgroundColor: `${primaryColor}10`,
                  color: primaryColor,
                  borderColor: primaryColor 
                } : undefined}
              >
                <item.icon className={cn(
                  "mr-3 h-5 w-5 flex-shrink-0",
                  isActive ? "text-current" : "text-gray-400 group-hover:text-gray-500"
                )} />
                {item.name}
                {item.badge && (
                  <span className="ml-auto bg-red-100 text-red-600 text-xs font-medium px-2 py-1 rounded-full">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User menu */}
        <div className="border-t border-gray-200 px-4 py-4">
          <div className="flex items-center">
            <div className="h-10 w-10 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center">
              <span className="text-white font-medium text-sm">
                {session?.user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
              </span>
            </div>
            <div className="ml-3 flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {session?.user?.name}
              </p>
              <p className="text-xs text-gray-500 truncate">
                {userRole?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </p>
            </div>
            <button
              onClick={() => signOut()}
              className="ml-2 p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 md:pl-64">
        {/* Top navigation */}
        <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(true)}
                className="md:hidden p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                <Menu className="h-6 w-6" />
              </button>
              
              <div className="ml-4 md:ml-0">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Search..."
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition-colors duration-200 relative">
                <Bell className="h-6 w-6" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                  3
                </span>
              </button>
              
              <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                <HelpCircle className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-gray-50">
          <div className="py-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
