
"""
Analytics collection and reporting for social media automation
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging
from sqlalchemy.orm import Session
from sqlalchemy import func, and_

from database import get_db, Post, SocialAccount, Analytics, Campaign
from platform_adapters import PlatformAdapterFactory

logger = logging.getLogger(__name__)

class AnalyticsCollector:
    """Collect and analyze social media metrics"""
    
    def __init__(self):
        self.metric_mappings = {
            "facebook": {
                "engagement": ["likes", "comments", "shares"],
                "reach": ["impressions"],
                "clicks": ["link_clicks"]
            },
            "instagram": {
                "engagement": ["likes", "comments", "saves"],
                "reach": ["impressions", "reach"],
                "clicks": ["profile_visits"]
            },
            "twitter": {
                "engagement": ["likes", "retweets", "replies", "quotes"],
                "reach": ["impressions"],
                "clicks": ["url_clicks", "profile_clicks"]
            },
            "linkedin": {
                "engagement": ["likes", "comments", "shares"],
                "reach": ["impressions"],
                "clicks": ["clicks"]
            },
            "tiktok": {
                "engagement": ["likes", "comments", "shares"],
                "reach": ["views"],
                "clicks": ["profile_views"]
            },
            "youtube": {
                "engagement": ["likes", "comments", "favorites"],
                "reach": ["views"],
                "clicks": ["subscribers_gained"]
            },
            "pinterest": {
                "engagement": ["saves", "clicks"],
                "reach": ["impressions"],
                "clicks": ["outbound_clicks"]
            },
            "reddit": {
                "engagement": ["upvotes", "comments", "awards"],
                "reach": ["views"],
                "clicks": ["profile_views"]
            }
        }
    
    async def collect_post_analytics(self, post_id: int) -> Dict[str, Any]:
        """Collect analytics for a specific post"""
        try:
            db = next(get_db())
            
            post = db.query(Post).filter(Post.id == post_id).first()
            if not post:
                return {"success": False, "error": "Post not found"}
            
            account = db.query(SocialAccount).filter(SocialAccount.id == post.account_id).first()
            if not account:
                return {"success": False, "error": "Account not found"}
            
            # Create platform adapter
            credentials = {
                'access_token': account.access_token,
                'refresh_token': account.refresh_token,
            }
            
            adapter = PlatformAdapterFactory.create_adapter(account.platform, credentials)
            
            # Authenticate
            auth_success = await adapter.authenticate()
            if not auth_success:
                return {"success": False, "error": f"Authentication failed for {account.platform}"}
            
            # Get analytics from platform
            analytics_result = await adapter.get_post_analytics(post.platform_post_id)
            
            if analytics_result.get('success'):
                analytics_data = analytics_result.get('analytics', {})
                
                # Store analytics in database
                await self._store_analytics(post_id, account.platform, analytics_data, db)
                
                # Update post engagement metrics
                post.engagement_metrics = analytics_data
                db.commit()
                
                return {
                    "success": True,
                    "post_id": post_id,
                    "platform": account.platform,
                    "analytics": analytics_data
                }
            else:
                return analytics_result
                
        except Exception as e:
            logger.error(f"Error collecting post analytics: {str(e)}")
            return {"success": False, "error": str(e)}
        finally:
            db.close()
    
    async def _store_analytics(self, post_id: int, platform: str, analytics_data: Dict[str, Any], db: Session):
        """Store analytics data in the database"""
        try:
            # Get metric mappings for the platform
            platform_metrics = self.metric_mappings.get(platform, {})
            
            for metric_name, metric_value in analytics_data.items():
                if isinstance(metric_value, (int, float)):
                    # Store individual metric
                    analytics_record = Analytics(
                        post_id=post_id,
                        platform=platform,
                        metric_name=metric_name,
                        metric_value=int(metric_value),
                        recorded_at=datetime.utcnow()
                    )
                    db.add(analytics_record)
            
            db.commit()
            
        except Exception as e:
            logger.error(f"Error storing analytics: {str(e)}")
            db.rollback()
    
    async def collect_account_analytics(self, account_id: int, days: int = 30) -> Dict[str, Any]:
        """Collect analytics for all posts from an account"""
        try:
            db = next(get_db())
            
            account = db.query(SocialAccount).filter(SocialAccount.id == account_id).first()
            if not account:
                return {"success": False, "error": "Account not found"}
            
            # Get posts from the last N days
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            posts = db.query(Post).filter(
                and_(
                    Post.account_id == account_id,
                    Post.posted_time >= cutoff_date,
                    Post.status == 'posted'
                )
            ).all()
            
            results = []
            for post in posts:
                result = await self.collect_post_analytics(post.id)
                results.append(result)
            
            return {
                "success": True,
                "account_id": account_id,
                "platform": account.platform,
                "posts_analyzed": len(results),
                "results": results
            }
            
        except Exception as e:
            logger.error(f"Error collecting account analytics: {str(e)}")
            return {"success": False, "error": str(e)}
        finally:
            db.close()
    
    async def generate_analytics_report(self, account_id: Optional[int] = None, 
                                      campaign_id: Optional[int] = None,
                                      days: int = 30) -> Dict[str, Any]:
        """Generate comprehensive analytics report"""
        try:
            db = next(get_db())
            
            # Build query based on filters
            query = db.query(Post).filter(Post.status == 'posted')
            
            if account_id:
                query = query.filter(Post.account_id == account_id)
            
            # For campaign filtering, we'd need to add campaign_id to Post model
            # This is a placeholder for now
            
            # Filter by date range
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            query = query.filter(Post.posted_time >= cutoff_date)
            
            posts = query.all()
            
            if not posts:
                return {
                    "success": True,
                    "message": "No posts found for the specified criteria",
                    "total_posts": 0
                }
            
            # Aggregate analytics
            report = await self._generate_aggregated_report(posts, db)
            
            return {
                "success": True,
                "report": report,
                "period_days": days,
                "total_posts": len(posts),
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error generating analytics report: {str(e)}")
            return {"success": False, "error": str(e)}
        finally:
            db.close()
    
    async def _generate_aggregated_report(self, posts: List[Post], db: Session) -> Dict[str, Any]:
        """Generate aggregated analytics report"""
        try:
            # Initialize report structure
            report = {
                "overview": {
                    "total_posts": len(posts),
                    "platforms": {},
                    "total_engagement": 0,
                    "total_reach": 0,
                    "average_engagement_rate": 0
                },
                "platform_breakdown": {},
                "top_performing_posts": [],
                "engagement_trends": [],
                "best_posting_times": {},
                "content_performance": {}
            }
            
            # Platform breakdown
            platform_stats = {}
            all_engagement = []
            all_reach = []
            
            for post in posts:
                platform = post.platform
                metrics = post.engagement_metrics or {}
                
                if platform not in platform_stats:
                    platform_stats[platform] = {
                        "post_count": 0,
                        "total_engagement": 0,
                        "total_reach": 0,
                        "posts": []
                    }
                
                platform_stats[platform]["post_count"] += 1
                platform_stats[platform]["posts"].append(post)
                
                # Calculate engagement for this platform
                platform_metrics = self.metric_mappings.get(platform, {})
                engagement_metrics = platform_metrics.get("engagement", [])
                reach_metrics = platform_metrics.get("reach", [])
                
                post_engagement = sum(metrics.get(metric, 0) for metric in engagement_metrics)
                post_reach = sum(metrics.get(metric, 0) for metric in reach_metrics)
                
                platform_stats[platform]["total_engagement"] += post_engagement
                platform_stats[platform]["total_reach"] += post_reach
                
                all_engagement.append(post_engagement)
                all_reach.append(post_reach)
            
            # Calculate overview stats
            report["overview"]["total_engagement"] = sum(all_engagement)
            report["overview"]["total_reach"] = sum(all_reach)
            report["overview"]["average_engagement_rate"] = (
                sum(all_engagement) / len(all_engagement) if all_engagement else 0
            )
            
            # Platform breakdown
            for platform, stats in platform_stats.items():
                report["platform_breakdown"][platform] = {
                    "post_count": stats["post_count"],
                    "total_engagement": stats["total_engagement"],
                    "total_reach": stats["total_reach"],
                    "average_engagement": stats["total_engagement"] / stats["post_count"] if stats["post_count"] > 0 else 0,
                    "average_reach": stats["total_reach"] / stats["post_count"] if stats["post_count"] > 0 else 0
                }
                
                report["overview"]["platforms"][platform] = stats["post_count"]
            
            # Top performing posts
            posts_with_engagement = []
            for post in posts:
                metrics = post.engagement_metrics or {}
                platform_metrics = self.metric_mappings.get(post.platform, {})
                engagement_metrics = platform_metrics.get("engagement", [])
                
                total_engagement = sum(metrics.get(metric, 0) for metric in engagement_metrics)
                
                posts_with_engagement.append({
                    "post_id": post.id,
                    "platform": post.platform,
                    "content": post.content[:100] + "..." if len(post.content) > 100 else post.content,
                    "posted_time": post.posted_time.isoformat() if post.posted_time else None,
                    "engagement": total_engagement,
                    "metrics": metrics
                })
            
            # Sort by engagement and get top 10
            posts_with_engagement.sort(key=lambda x: x["engagement"], reverse=True)
            report["top_performing_posts"] = posts_with_engagement[:10]
            
            # Best posting times analysis
            posting_times = {}
            for post in posts:
                if post.posted_time:
                    hour = post.posted_time.hour
                    day_of_week = post.posted_time.weekday()  # 0 = Monday
                    
                    if hour not in posting_times:
                        posting_times[hour] = {"posts": 0, "total_engagement": 0}
                    
                    metrics = post.engagement_metrics or {}
                    platform_metrics = self.metric_mappings.get(post.platform, {})
                    engagement_metrics = platform_metrics.get("engagement", [])
                    post_engagement = sum(metrics.get(metric, 0) for metric in engagement_metrics)
                    
                    posting_times[hour]["posts"] += 1
                    posting_times[hour]["total_engagement"] += post_engagement
            
            # Calculate average engagement by hour
            best_hours = []
            for hour, data in posting_times.items():
                avg_engagement = data["total_engagement"] / data["posts"] if data["posts"] > 0 else 0
                best_hours.append({
                    "hour": hour,
                    "average_engagement": avg_engagement,
                    "post_count": data["posts"]
                })
            
            best_hours.sort(key=lambda x: x["average_engagement"], reverse=True)
            report["best_posting_times"] = best_hours[:5]
            
            # Content performance by hashtags
            hashtag_performance = {}
            for post in posts:
                hashtags = post.hashtags or []
                metrics = post.engagement_metrics or {}
                platform_metrics = self.metric_mappings.get(post.platform, {})
                engagement_metrics = platform_metrics.get("engagement", [])
                post_engagement = sum(metrics.get(metric, 0) for metric in engagement_metrics)
                
                for hashtag in hashtags:
                    if hashtag not in hashtag_performance:
                        hashtag_performance[hashtag] = {"posts": 0, "total_engagement": 0}
                    
                    hashtag_performance[hashtag]["posts"] += 1
                    hashtag_performance[hashtag]["total_engagement"] += post_engagement
            
            # Get top performing hashtags
            top_hashtags = []
            for hashtag, data in hashtag_performance.items():
                avg_engagement = data["total_engagement"] / data["posts"] if data["posts"] > 0 else 0
                top_hashtags.append({
                    "hashtag": hashtag,
                    "average_engagement": avg_engagement,
                    "post_count": data["posts"],
                    "total_engagement": data["total_engagement"]
                })
            
            top_hashtags.sort(key=lambda x: x["average_engagement"], reverse=True)
            report["content_performance"]["top_hashtags"] = top_hashtags[:10]
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating aggregated report: {str(e)}")
            return {}
    
    async def get_engagement_trends(self, account_id: Optional[int] = None, days: int = 30) -> Dict[str, Any]:
        """Get engagement trends over time"""
        try:
            db = next(get_db())
            
            # Build query
            query = db.query(Analytics).filter(
                Analytics.recorded_at >= datetime.utcnow() - timedelta(days=days)
            )
            
            if account_id:
                # Join with Post to filter by account
                query = query.join(Post).filter(Post.account_id == account_id)
            
            analytics_records = query.all()
            
            # Group by date and metric
            daily_metrics = {}
            for record in analytics_records:
                date_key = record.recorded_at.date().isoformat()
                
                if date_key not in daily_metrics:
                    daily_metrics[date_key] = {}
                
                if record.metric_name not in daily_metrics[date_key]:
                    daily_metrics[date_key][record.metric_name] = 0
                
                daily_metrics[date_key][record.metric_name] += record.metric_value
            
            # Convert to trend format
            trends = []
            for date_key in sorted(daily_metrics.keys()):
                trend_point = {
                    "date": date_key,
                    "metrics": daily_metrics[date_key]
                }
                trends.append(trend_point)
            
            return {
                "success": True,
                "trends": trends,
                "period_days": days
            }
            
        except Exception as e:
            logger.error(f"Error getting engagement trends: {str(e)}")
            return {"success": False, "error": str(e)}
        finally:
            db.close()
    
    async def get_competitor_analysis(self, competitor_handles: List[str], platform: str) -> Dict[str, Any]:
        """Analyze competitor performance (placeholder for future implementation)"""
        try:
            # This would require additional API access and competitor data collection
            # For now, return a placeholder structure
            
            return {
                "success": True,
                "message": "Competitor analysis feature coming soon",
                "competitors": competitor_handles,
                "platform": platform,
                "note": "This feature requires additional API permissions and data collection setup"
            }
            
        except Exception as e:
            logger.error(f"Error in competitor analysis: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def export_analytics_data(self, format: str = "json", **filters) -> Dict[str, Any]:
        """Export analytics data in various formats"""
        try:
            # Generate report with filters
            report = await self.generate_analytics_report(**filters)
            
            if not report.get("success"):
                return report
            
            if format.lower() == "json":
                return {
                    "success": True,
                    "format": "json",
                    "data": report.get("report", {}),
                    "exported_at": datetime.utcnow().isoformat()
                }
            elif format.lower() == "csv":
                # Convert to CSV format (simplified)
                csv_data = self._convert_to_csv(report.get("report", {}))
                return {
                    "success": True,
                    "format": "csv",
                    "data": csv_data,
                    "exported_at": datetime.utcnow().isoformat()
                }
            else:
                return {"success": False, "error": f"Unsupported format: {format}"}
                
        except Exception as e:
            logger.error(f"Error exporting analytics data: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _convert_to_csv(self, report_data: Dict[str, Any]) -> str:
        """Convert report data to CSV format"""
        try:
            import csv
            import io
            
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Write overview data
            writer.writerow(["Section", "Metric", "Value"])
            
            overview = report_data.get("overview", {})
            for key, value in overview.items():
                if isinstance(value, dict):
                    for sub_key, sub_value in value.items():
                        writer.writerow(["Overview", f"{key}_{sub_key}", sub_value])
                else:
                    writer.writerow(["Overview", key, value])
            
            # Write platform breakdown
            platform_breakdown = report_data.get("platform_breakdown", {})
            for platform, metrics in platform_breakdown.items():
                for metric, value in metrics.items():
                    writer.writerow(["Platform", f"{platform}_{metric}", value])
            
            return output.getvalue()
            
        except Exception as e:
            logger.error(f"Error converting to CSV: {str(e)}")
            return "Error generating CSV data"
