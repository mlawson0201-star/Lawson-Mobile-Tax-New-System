
'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Upload,
  Bot,
  Download,
  Send
} from 'lucide-react';

interface AuditDefenseRequest {
  noticeType: string;
  clientId: string;
  taxReturnId: string;
  noticeContent: string;
  noticeDate: string;
}

interface DefenseResponse {
  status: string;
  result?: any;
  automationConfidence?: number;
}

export default function AuditDefenseInterface() {
  const [step, setStep] = useState<'input' | 'processing' | 'results'>('input');
  const [request, setRequest] = useState<AuditDefenseRequest>({
    noticeType: '',
    clientId: '',
    taxReturnId: '',
    noticeContent: '',
    noticeDate: ''
  });
  const [response, setResponse] = useState<DefenseResponse | null>(null);
  const [progress, setProgress] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const noticeTypes = [
    { value: 'cp2000', label: 'CP2000 - Underreported Income' },
    { value: 'cp3219a', label: 'CP3219A - Statutory Notice of Deficiency' },
    { value: 'cp161', label: 'CP161 - Balance Due Notice' },
    { value: 'cp503', label: 'CP503 - Second Balance Due Notice' },
    { value: 'audit_letter', label: 'Audit Examination Letter' },
    { value: 'correspondence', label: 'General IRS Correspondence' },
    { value: 'other', label: 'Other Notice Type' }
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      // In a real implementation, you'd extract text from the uploaded notice
      setRequest(prev => ({
        ...prev,
        noticeContent: `[Uploaded file: ${file.name}] - Content would be extracted automatically`
      }));
    }
  };

  const processAuditDefense = async () => {
    setStep('processing');
    setProgress(0);

    try {
      const response = await fetch('/api/automation/audit-defense', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let partialRead = '';

      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined };
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        let lines = partialRead.split('\n');
        partialRead = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.status === 'processing') {
                setProgress(prev => Math.min(prev + 10, 90));
              } else if (parsed.status === 'completed') {
                setResponse(parsed);
                setProgress(100);
                setStep('results');
                return;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Audit defense processing error:', error);
      setStep('input');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <Shield className="h-12 w-12 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Automated Audit Defense</h1>
        <p className="text-lg text-gray-600 mt-2">
          AI-powered IRS notice analysis and response generation
        </p>
      </div>

      {step === 'input' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-8"
        >
          <h2 className="text-xl font-semibold text-gray-900 mb-6">IRS Notice Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notice Type
              </label>
              <select
                value={request.noticeType}
                onChange={(e) => setRequest(prev => ({ ...prev, noticeType: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Select Notice Type</option>
                {noticeTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notice Date
              </label>
              <input
                type="date"
                value={request.noticeDate}
                onChange={(e) => setRequest(prev => ({ ...prev, noticeDate: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Client ID
              </label>
              <input
                type="text"
                value={request.clientId}
                onChange={(e) => setRequest(prev => ({ ...prev, clientId: e.target.value }))}
                placeholder="Enter client ID"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tax Return ID (Optional)
              </label>
              <input
                type="text"
                value={request.taxReturnId}
                onChange={(e) => setRequest(prev => ({ ...prev, taxReturnId: e.target.value }))}
                placeholder="Enter tax return ID"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload IRS Notice (PDF/Image)
            </label>
            <div className="flex items-center justify-center w-full">
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-8 h-8 mb-4 text-gray-500" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500">PDF, PNG, JPG (MAX. 10MB)</p>
                </div>
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.png,.jpg,.jpeg"
                  onChange={handleFileUpload}
                />
              </label>
            </div>
            {uploadedFile && (
              <div className="mt-3 flex items-center space-x-2 text-sm text-green-600">
                <CheckCircle className="h-4 w-4" />
                <span>File uploaded: {uploadedFile.name}</span>
              </div>
            )}
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notice Content (or leave blank if uploaded file)
            </label>
            <textarea
              value={request.noticeContent}
              onChange={(e) => setRequest(prev => ({ ...prev, noticeContent: e.target.value }))}
              rows={6}
              placeholder="Paste or type the IRS notice content here..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="mt-8 flex justify-end">
            <button
              onClick={processAuditDefense}
              disabled={!request.noticeType || !request.clientId || (!request.noticeContent && !uploadedFile)}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Bot className="h-4 w-4" />
              <span>Generate Defense Strategy</span>
            </button>
          </div>
        </motion.div>
      )}

      {step === 'processing' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
          
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Processing IRS Notice
          </h2>
          
          <div className="max-w-md mx-auto">
            <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
              <span>Analyzing notice content...</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-blue-600 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          <div className="mt-6 space-y-2 text-sm text-gray-600">
            <div className="flex items-center justify-center space-x-2">
              <Clock className="h-4 w-4" />
              <span>Estimated time: 2-3 minutes</span>
            </div>
          </div>
        </motion.div>
      )}

      {step === 'results' && response && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Success Header */}
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div>
                <h2 className="text-xl font-semibold text-green-900">
                  Defense Strategy Generated Successfully
                </h2>
                <p className="text-green-700">
                  Confidence Level: {((response.automationConfidence || 0) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          </div>

          {/* Results Content */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <div className="space-y-6">
              {response.result && (
                <>
                  {/* Notice Analysis */}
                  {response.result.noticeAnalysis && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Notice Analysis</h3>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p><strong>Classification:</strong> {response.result.noticeAnalysis.classification}</p>
                        <p><strong>Severity:</strong> {response.result.noticeAnalysis.severity}</p>
                        <p><strong>Response Deadline:</strong> {response.result.noticeAnalysis.responseDeadline}</p>
                      </div>
                    </div>
                  )}

                  {/* Response Strategy */}
                  {response.result.responseStrategy && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Response Strategy</h3>
                      <div className="space-y-4">
                        {response.result.responseStrategy.steps?.map((step: any, index: number) => (
                          <div key={index} className="flex items-start space-x-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <p className="text-gray-700">{step}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Draft Response */}
                  {response.result.draftResponse && (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Draft Response Letter</h3>
                      <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-blue-500">
                        <pre className="whitespace-pre-wrap text-sm text-gray-700">
                          {response.result.draftResponse}
                        </pre>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-wrap gap-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="h-4 w-4" />
                <span>Download Response Package</span>
              </button>
              
              <button className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                <Send className="h-4 w-4" />
                <span>Submit to IRS</span>
              </button>
              
              <button 
                onClick={() => {
                  setStep('input');
                  setResponse(null);
                  setProgress(0);
                }}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Process Another Notice
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
