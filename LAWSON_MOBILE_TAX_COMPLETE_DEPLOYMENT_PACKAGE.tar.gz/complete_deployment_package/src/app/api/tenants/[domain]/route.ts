
import { NextResponse } from 'next/server';
import { getTenantByDomain } from '@/lib/tenant';

export async function GET(
  request: Request,
  { params }: { params: { domain: string } }
) {
  try {
    const { domain } = params;
    const tenant = await getTenantByDomain(domain);

    if (!tenant) {
      return NextResponse.json(
        { error: 'Tenant not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(tenant);
  } catch (error) {
    console.error('Error fetching tenant:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
