
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const audioFile = formData.get('audio') as File;
    const clientId = formData.get('clientId') as string;
    const documentType = formData.get('documentType') as string || 'general';
    const processingType = formData.get('processingType') as string || 'transcription';

    if (!audioFile || !clientId) {
      return NextResponse.json({ error: 'Audio file and client ID required' }, { status: 400 });
    }

    // Convert audio file to base64 for AI processing
    const arrayBuffer = await audioFile.arrayBuffer();
    const base64Audio = Buffer.from(arrayBuffer).toString('base64');

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{
          role: 'user',
          content: [{
            type: 'text',
            text: `You are an advanced AI tax assistant with voice processing capabilities. Process this audio file and extract tax-relevant information.

Processing Type: ${processingType}
Document Type: ${documentType}
Client ID: ${clientId}

Tasks to perform:
1. Speech-to-Text Conversion: Convert audio to accurate text transcript
2. Tax Information Extraction: Identify and extract tax-relevant data points
3. Document Classification: Classify the type of tax document or conversation
4. Data Structuring: Organize extracted information into structured format
5. Automation Actions: Suggest automated actions based on the content
6. Quality Assessment: Provide confidence scores for extracted data

For tax document discussions, extract:
- Income amounts and sources
- Deduction categories and amounts  
- Tax form requirements
- Filing deadlines mentioned
- Client questions and concerns
- Action items and follow-ups

For client interactions, extract:
- Client identification information
- Tax year being discussed
- Specific tax issues or questions
- Required documentation
- Next steps and deadlines

Format response as JSON with structured voice processing results.`
          }]
        }],
        stream: true,
        max_tokens: 4000,
        response_format: { type: "json_object" }
      }),
    });

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = '';
        let partialRead = '';

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            let lines = partialRead.split('\n');
            partialRead = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  try {
                    const finalResult = JSON.parse(buffer);
                    
                    // Save voice processing record
                    await prisma.voiceProcessing.create({
                      data: {
                        tenantId: session.user.tenantId,
                        clientId: clientId,
                        userId: session.user.id,
                        audioFileName: audioFile.name,
                        processingType: processingType,
                        transcriptionText: finalResult.transcript || '',
                        extractedData: finalResult.extractedTaxData || {},
                        confidenceScore: parseFloat(finalResult.overallConfidence || '0.8'),
                        automationActions: finalResult.suggestedActions || [],
                        processingStatus: 'completed',
                      },
                    });

                    const finalData = JSON.stringify({
                      status: 'completed',
                      result: finalResult,
                      processingMetrics: {
                        transcriptionLength: finalResult.transcript?.length || 0,
                        dataPointsExtracted: Object.keys(finalResult.extractedTaxData || {}).length,
                        automationActionsCount: finalResult.suggestedActions?.length || 0,
                        confidenceScore: finalResult.overallConfidence || 0.8
                      }
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                    return;
                  } catch (e) {
                    controller.error(e);
                    return;
                  }
                }
                try {
                  const parsed = JSON.parse(data);
                  buffer += parsed.choices?.[0]?.delta?.content || '';
                  const progressData = JSON.stringify({
                    status: 'processing',
                    message: 'Processing voice data and extracting tax information...'
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Voice processing stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Voice document processing error:', error);
    return NextResponse.json(
      { error: 'Failed to process voice document' },
      { status: 500 }
    );
  }
}
