
import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const signupSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  phone: z.string().optional(),
  tenantDomain: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, password, firstName, lastName, phone, tenantDomain } = signupSchema.parse(body);

    // Determine tenant
    let tenantId: string;
    if (tenantDomain) {
      const tenant = await prisma.tenant.findUnique({
        where: { domain: tenantDomain, active: true }
      });
      if (!tenant) {
        return NextResponse.json(
          { error: 'Invalid tenant domain' },
          { status: 400 }
        );
      }
      tenantId = tenant.id;
    } else {
      // Default to main platform
      const defaultTenant = await prisma.tenant.findUnique({
        where: { domain: 'lawsonmobiletax.com' }
      });
      if (!defaultTenant) {
        return NextResponse.json(
          { error: 'Default tenant not found' },
          { status: 500 }
        );
      }
      tenantId = defaultTenant.id;
    }

    // Check if user already exists
    const existingUser = await prisma.user.findFirst({
      where: {
        email,
        tenantId
      }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user
    const user = await prisma.user.create({
      data: {
        tenantId,
        cognitoUserId: `local-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        email,
        firstName,
        lastName,
        phone,
        role: 'client', // Default role
        profileData: {
          hashedPassword, // Store for testing purposes
        },
        preferences: {
          theme: 'light',
          emailNotifications: true,
          smsNotifications: true
        }
      },
      include: {
        tenant: true
      }
    });

    // Create client record if the user is a client
    if (user.role === 'client') {
      await prisma.client.create({
        data: {
          tenantId: user.tenantId,
          createdByUserId: user.id,
          email: user.email,
          phone: user.phone || '',
          firstName: user.firstName,
          lastName: user.lastName,
          personalInfo: {},
          clientStatus: 'active'
        }
      });
    }

    // Remove sensitive data from response
    const { profileData, ...userResponse } = user;

    return NextResponse.json({
      message: 'User created successfully',
      user: userResponse
    });

  } catch (error) {
    console.error('Signup error:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
