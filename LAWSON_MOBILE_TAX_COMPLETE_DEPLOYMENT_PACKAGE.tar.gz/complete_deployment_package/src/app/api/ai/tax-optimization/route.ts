
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { taxReturnId, scenario } = await request.json();

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID required' }, { status: 400 });
    }

    // Get comprehensive tax return data
    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: {
        client: true,
        deductionSuggestions: {
          where: { status: { in: ['accepted', 'pending'] } },
        },
        documents: {
          include: {
            ocrProcessing: true,
          },
        },
      },
    });

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
    }

    // Calculate current tax situation
    const currentTaxData = {
      formData: taxReturn.formData,
      income: (taxReturn.calculations as any)?.income || {},
      deductions: taxReturn.deductionSuggestions.reduce((acc, d) => {
        acc[d.deductionCategory] = (acc[d.deductionCategory] || 0) + parseFloat(d.deductionAmount.toString());
        return acc;
      }, {} as Record<string, number>),
      currentTaxLiability: (taxReturn.calculations as any)?.taxLiability || 0,
      refundAmount: taxReturn.refundAmount ? parseFloat(taxReturn.refundAmount.toString()) : 0,
    };

    // Create optimization analysis prompt
    const optimizationPrompt = `
      Analyze this tax situation and provide comprehensive optimization strategies:

      Current Tax Situation:
      ${JSON.stringify(currentTaxData, null, 2)}

      Client Profile:
      - Filing Status: ${taxReturn.client.filingStatus || 'single'}
      - Tax Year: ${taxReturn.taxYear}
      - Return Type: ${taxReturn.returnType}

      Analysis Scenario: ${scenario || 'comprehensive'}

      Provide a detailed JSON analysis with these optimization strategies:

      {
        "current_analysis": {
          "effective_tax_rate": number,
          "marginal_tax_rate": number,
          "total_tax_liability": number,
          "total_deductions": number,
          "taxable_income": number
        },
        "optimization_strategies": [
          {
            "type": "timing_strategy | deduction_maximization | credit_optimization | filing_status | retirement_planning",
            "strategy_name": "descriptive name",
            "current_situation": "what's happening now",
            "optimized_approach": "what should be done",
            "tax_savings": number,
            "implementation_steps": ["step 1", "step 2"],
            "timeline": "immediate | tax_year_end | next_year",
            "confidence": 0.0-1.0,
            "risk_level": "low | medium | high",
            "requirements": ["what's needed to implement"],
            "deadlines": ["important dates"],
            "irs_references": ["relevant publications"]
          }
        ],
        "what_if_scenarios": [
          {
            "scenario": "description",
            "changes": "what changes",
            "new_tax_liability": number,
            "savings": number,
            "feasibility": "easy | moderate | difficult"
          }
        ],
        "year_round_planning": [
          {
            "quarter": "Q1 | Q2 | Q3 | Q4",
            "actions": ["recommended actions"],
            "benefits": "expected benefits"
          }
        ],
        "audit_risk_assessment": {
          "current_risk": "low | medium | high",
          "risk_factors": ["factors that increase risk"],
          "mitigation_strategies": ["how to reduce risk"]
        }
      }

      Focus on legitimate, IRS-compliant strategies that maximize tax efficiency.
    `;

    const response = await fetch(`${process.env.ABACUSAI_BASE_URL || 'https://apps.abacus.ai'}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{ role: 'user', content: optimizationPrompt }],
        response_format: { type: "json_object" },
        max_tokens: 4000,
      }),
    });

    if (!response.ok) {
      throw new Error(`Tax optimization analysis failed: ${response.statusText}`);
    }

    const aiResult = await response.json();
    const optimizationAnalysis = JSON.parse(aiResult.choices[0].message.content);

    // Create optimization suggestions in database
    const optimizationPromises = optimizationAnalysis.optimization_strategies?.map(async (strategy: any) => {
      return prisma.taxOptimizationSuggestion.create({
        data: {
          tenantId: session.user.tenantId,
          taxReturnId,
          optimizationType: strategy.type,
          currentTaxLiability: parseFloat(optimizationAnalysis.current_analysis?.total_tax_liability || 0),
          optimizedTaxLiability: parseFloat(optimizationAnalysis.current_analysis?.total_tax_liability || 0) - parseFloat(strategy.tax_savings || 0),
          estimatedSavings: parseFloat(strategy.tax_savings || 0),
          optimizationStrategy: {
            strategy_name: strategy.strategy_name,
            current_situation: strategy.current_situation,
            optimized_approach: strategy.optimized_approach,
            timeline: (strategy as any).timeline,
            risk_level: strategy.risk_level,
            requirements: strategy.requirements,
            irs_references: strategy.irs_references,
          },
          implementationSteps: strategy.implementation_steps || [],
          confidenceScore: parseFloat(strategy.confidence || 0),
          validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // Valid for 1 year
        },
      });
    }) || [];

    const createdOptimizations = await Promise.all(optimizationPromises);

    // Calculate total potential savings
    const totalSavings = optimizationAnalysis.optimization_strategies?.reduce(
      (total: number, strategy: any) => total + parseFloat(strategy.tax_savings || 0),
      0
    ) || 0;

    // Store predictive analytics
    await prisma.predictiveAnalytics.create({
      data: {
        tenantId: session.user.tenantId,
        clientId: taxReturn.clientId,
        analytic_type: 'tax_optimization',
        predictionData: optimizationAnalysis,
        confidenceInterval: {
          min_savings: totalSavings * 0.7,
          max_savings: totalSavings * 1.2,
          confidence: 0.85,
        },
        forecastPeriod: 'current_tax_year',
        generatedAt: new Date(),
        validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
      },
    });

    return NextResponse.json({
      success: true,
      analysis: optimizationAnalysis,
      optimizationsCreated: createdOptimizations.length,
      totalPotentialSavings: totalSavings,
      summary: {
        current_tax_liability: optimizationAnalysis.current_analysis?.total_tax_liability,
        optimized_tax_liability: (optimizationAnalysis.current_analysis?.total_tax_liability || 0) - totalSavings,
        total_savings: totalSavings,
        strategies_count: createdOptimizations.length,
        high_confidence_strategies: createdOptimizations.filter(
          (opt: any) => parseFloat(opt.confidenceScore?.toString() || '0') > 0.8
        ).length,
      },
    });
  } catch (error: any) {
    console.error('Tax optimization error:', error);
    return NextResponse.json(
      { error: 'Tax optimization failed', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve optimization suggestions
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const taxReturnId = searchParams.get('taxReturnId');
    const status = searchParams.get('status') || undefined;

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID required' }, { status: 400 });
    }

    const optimizations = await prisma.taxOptimizationSuggestion.findMany({
      where: {
        tenantId: session.user.tenantId,
        taxReturnId,
        ...(status && { status }),
        validUntil: {
          gte: new Date(),
        },
      },
      orderBy: [
        { estimatedSavings: 'desc' },
        { confidenceScore: 'desc' },
      ],
    });

    const summary = {
      totalSuggestions: optimizations.length,
      totalPotentialSavings: optimizations.reduce((sum, opt) => 
        sum + parseFloat(opt.estimatedSavings.toString()), 0),
      byOptimizationType: optimizations.reduce((acc, opt) => {
        acc[opt.optimizationType] = (acc[opt.optimizationType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      implementationTimeline: optimizations.reduce((acc, opt) => {
        const timeline = opt.optimizationStrategy?.timeline || 'unknown';
        acc[timeline] = (acc[timeline] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
    };

    return NextResponse.json({
      success: true,
      optimizations,
      summary,
    });
  } catch (error: any) {
    console.error('Get optimizations error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve optimizations', details: error?.message },
      { status: 500 }
    );
  }
}
