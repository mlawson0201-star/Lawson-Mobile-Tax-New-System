"""
Financial Data Aggregation Service
Multi-provider financial data aggregation with Plaid alternatives
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import json
import aiohttp
from decimal import Decimal
import hashlib
import hmac
import base64

logger = logging.getLogger(__name__)

class AccountType(Enum):
    """Financial account types"""
    CHECKING = "checking"
    SAVINGS = "savings"
    CREDIT_CARD = "credit_card"
    INVESTMENT = "investment"
    RETIREMENT = "retirement"
    LOAN = "loan"
    MORTGAGE = "mortgage"
    BUSINESS = "business"
    CRYPTO = "crypto"

class TransactionCategory(Enum):
    """Transaction categories for tax purposes"""
    BUSINESS_EXPENSE = "business_expense"
    OFFICE_SUPPLIES = "office_supplies"
    TRAVEL = "travel"
    MEALS = "meals"
    UTILITIES = "utilities"
    RENT = "rent"
    INSURANCE = "insurance"
    PROFESSIONAL_SERVICES = "professional_services"
    MARKETING = "marketing"
    EQUIPMENT = "equipment"
    INCOME = "income"
    INVESTMENT_INCOME = "investment_income"
    PERSONAL = "personal"

@dataclass
class FinancialAccount:
    """Financial account information"""
    account_id: str
    institution_id: str
    institution_name: str
    account_type: AccountType
    account_name: str
    account_number_masked: str
    balance: Decimal
    currency: str
    last_updated: datetime
    provider: str
    metadata: Dict[str, Any]

@dataclass
class Transaction:
    """Financial transaction"""
    transaction_id: str
    account_id: str
    amount: Decimal
    currency: str
    date: datetime
    description: str
    merchant_name: Optional[str]
    category: List[str]
    tax_category: Optional[TransactionCategory]
    is_business: bool
    location: Optional[Dict[str, str]]
    metadata: Dict[str, Any]
    confidence_score: float

@dataclass
class InvestmentHolding:
    """Investment holding information"""
    holding_id: str
    account_id: str
    security_id: str
    symbol: str
    name: str
    quantity: Decimal
    price: Decimal
    value: Decimal
    cost_basis: Optional[Decimal]
    unrealized_gain_loss: Optional[Decimal]
    asset_class: str
    last_updated: datetime

class FinancialDataAggregator:
    """
    Multi-Provider Financial Data Aggregation Service
    
    Supports multiple providers:
    - Plaid (primary)
    - Yodlee (Envestnet)
    - Flinks (Canada)
    - TrueLayer (Europe)
    - Akoya (bank-owned)
    - Teller (high-quality US)
    - MX (clean data)
    - Finicity (Mastercard)
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.providers = self._initialize_providers()
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def connect_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str],
        provider: str = "auto"
    ) -> List[FinancialAccount]:
        """
        Connect user accounts from financial institution
        
        Args:
            user_id: User identifier
            institution_id: Financial institution ID
            credentials: Login credentials or tokens
            provider: Preferred provider or "auto" for best match
            
        Returns:
            List of connected accounts
        """
        try:
            # Auto-select provider if not specified
            if provider == "auto":
                provider = await self._select_best_provider(institution_id)
            
            # Connect accounts using selected provider
            if provider == "plaid":
                accounts = await self._connect_plaid_accounts(user_id, institution_id, credentials)
            elif provider == "yodlee":
                accounts = await self._connect_yodlee_accounts(user_id, institution_id, credentials)
            elif provider == "flinks":
                accounts = await self._connect_flinks_accounts(user_id, institution_id, credentials)
            elif provider == "truelayer":
                accounts = await self._connect_truelayer_accounts(user_id, institution_id, credentials)
            elif provider == "akoya":
                accounts = await self._connect_akoya_accounts(user_id, institution_id, credentials)
            elif provider == "teller":
                accounts = await self._connect_teller_accounts(user_id, institution_id, credentials)
            elif provider == "mx":
                accounts = await self._connect_mx_accounts(user_id, institution_id, credentials)
            elif provider == "finicity":
                accounts = await self._connect_finicity_accounts(user_id, institution_id, credentials)
            else:
                raise ValueError(f"Unsupported provider: {provider}")
            
            # Standardize account data
            standardized_accounts = [
                await self._standardize_account_data(account, provider)
                for account in accounts
            ]
            
            logger.info(f"Connected {len(standardized_accounts)} accounts for user {user_id} via {provider}")
            return standardized_accounts
            
        except Exception as e:
            logger.error(f"Error connecting accounts for user {user_id}: {str(e)}")
            raise
    
    async def fetch_transactions(
        self,
        account_ids: List[str],
        start_date: datetime,
        end_date: datetime,
        categorize_for_tax: bool = True
    ) -> List[Transaction]:
        """
        Fetch transactions from connected accounts
        
        Args:
            account_ids: List of account IDs to fetch from
            start_date: Start date for transaction history
            end_date: End date for transaction history
            categorize_for_tax: Whether to categorize transactions for tax purposes
            
        Returns:
            List of transactions
        """
        try:
            all_transactions = []
            
            # Group accounts by provider for efficient batch requests
            accounts_by_provider = await self._group_accounts_by_provider(account_ids)
            
            for provider, provider_account_ids in accounts_by_provider.items():
                if provider == "plaid":
                    transactions = await self._fetch_plaid_transactions(
                        provider_account_ids, start_date, end_date
                    )
                elif provider == "yodlee":
                    transactions = await self._fetch_yodlee_transactions(
                        provider_account_ids, start_date, end_date
                    )
                elif provider == "flinks":
                    transactions = await self._fetch_flinks_transactions(
                        provider_account_ids, start_date, end_date
                    )
                # Add other providers...
                else:
                    logger.warning(f"Transaction fetching not implemented for provider: {provider}")
                    continue
                
                # Standardize transaction data
                standardized_transactions = [
                    await self._standardize_transaction_data(tx, provider)
                    for tx in transactions
                ]
                
                all_transactions.extend(standardized_transactions)
            
            # Remove duplicates
            unique_transactions = await self._deduplicate_transactions(all_transactions)
            
            # Categorize for tax purposes if requested
            if categorize_for_tax:
                for transaction in unique_transactions:
                    transaction.tax_category = await self._categorize_for_tax(transaction)
                    transaction.is_business = await self._classify_business_transaction(transaction)
            
            logger.info(f"Fetched {len(unique_transactions)} transactions from {len(account_ids)} accounts")
            return unique_transactions
            
        except Exception as e:
            logger.error(f"Error fetching transactions: {str(e)}")
            raise
    
    async def fetch_investment_holdings(
        self,
        account_ids: List[str]
    ) -> List[InvestmentHolding]:
        """
        Fetch investment holdings from connected accounts
        
        Args:
            account_ids: List of investment account IDs
            
        Returns:
            List of investment holdings
        """
        try:
            all_holdings = []
            
            accounts_by_provider = await self._group_accounts_by_provider(account_ids)
            
            for provider, provider_account_ids in accounts_by_provider.items():
                if provider == "plaid":
                    holdings = await self._fetch_plaid_holdings(provider_account_ids)
                elif provider == "yodlee":
                    holdings = await self._fetch_yodlee_holdings(provider_account_ids)
                # Add other providers...
                else:
                    continue
                
                standardized_holdings = [
                    await self._standardize_holding_data(holding, provider)
                    for holding in holdings
                ]
                
                all_holdings.extend(standardized_holdings)
            
            logger.info(f"Fetched {len(all_holdings)} investment holdings")
            return all_holdings
            
        except Exception as e:
            logger.error(f"Error fetching investment holdings: {str(e)}")
            raise
    
    async def sync_account_balances(
        self,
        account_ids: List[str]
    ) -> Dict[str, Decimal]:
        """
        Sync current account balances
        
        Args:
            account_ids: List of account IDs to sync
            
        Returns:
            Dictionary mapping account ID to current balance
        """
        try:
            balances = {}
            
            accounts_by_provider = await self._group_accounts_by_provider(account_ids)
            
            for provider, provider_account_ids in accounts_by_provider.items():
                if provider == "plaid":
                    provider_balances = await self._sync_plaid_balances(provider_account_ids)
                elif provider == "yodlee":
                    provider_balances = await self._sync_yodlee_balances(provider_account_ids)
                # Add other providers...
                else:
                    continue
                
                balances.update(provider_balances)
            
            logger.info(f"Synced balances for {len(balances)} accounts")
            return balances
            
        except Exception as e:
            logger.error(f"Error syncing account balances: {str(e)}")
            raise
    
    async def categorize_transactions_for_tax(
        self,
        transactions: List[Transaction],
        business_rules: Optional[Dict[str, Any]] = None
    ) -> List[Transaction]:
        """
        Enhanced tax categorization using AI and business rules
        
        Args:
            transactions: List of transactions to categorize
            business_rules: Custom business categorization rules
            
        Returns:
            Transactions with updated tax categories
        """
        try:
            for transaction in transactions:
                # Apply business rules first
                if business_rules:
                    category = await self._apply_business_rules(transaction, business_rules)
                    if category:
                        transaction.tax_category = category
                        transaction.is_business = True
                        continue
                
                # Use AI categorization
                transaction.tax_category = await self._ai_categorize_transaction(transaction)
                transaction.is_business = await self._ai_classify_business_transaction(transaction)
            
            logger.info(f"Categorized {len(transactions)} transactions for tax purposes")
            return transactions
            
        except Exception as e:
            logger.error(f"Error categorizing transactions for tax: {str(e)}")
            raise
    
    # Provider-specific implementations
    
    async def _connect_plaid_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Plaid"""
        plaid_config = self.config.get("plaid", {})
        
        # Exchange public token for access token
        exchange_data = {
            "client_id": plaid_config["client_id"],
            "secret": plaid_config["secret"],
            "public_token": credentials["public_token"]
        }
        
        async with self.session.post(
            "https://production.plaid.com/link/token/exchange",
            json=exchange_data
        ) as response:
            exchange_result = await response.json()
            access_token = exchange_result["access_token"]
        
        # Fetch accounts
        accounts_data = {
            "client_id": plaid_config["client_id"],
            "secret": plaid_config["secret"],
            "access_token": access_token
        }
        
        async with self.session.post(
            "https://production.plaid.com/accounts/get",
            json=accounts_data
        ) as response:
            accounts_result = await response.json()
            return accounts_result["accounts"]
    
    async def _connect_yodlee_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Yodlee"""
        yodlee_config = self.config.get("yodlee", {})
        
        # Authenticate with Yodlee
        auth_token = await self._authenticate_yodlee()
        
        # Add provider account
        add_account_data = {
            "providerId": institution_id,
            "dataset": ["BASIC_AGG_DATA", "ADVANCE_AGG_DATA"],
            "credentialParam": [
                {"name": key, "value": value}
                for key, value in credentials.items()
            ]
        }
        
        headers = {"Authorization": f"Bearer {auth_token}"}
        
        async with self.session.post(
            f"{yodlee_config['base_url']}/providerAccounts",
            json=add_account_data,
            headers=headers
        ) as response:
            result = await response.json()
            
        # Fetch accounts
        async with self.session.get(
            f"{yodlee_config['base_url']}/accounts",
            headers=headers
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("account", [])
    
    async def _connect_flinks_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Flinks (Canada)"""
        flinks_config = self.config.get("flinks", {})
        
        # Authorize with institution
        auth_data = {
            "institution_id": institution_id,
            "username": credentials["username"],
            "password": credentials["password"]
        }
        
        headers = {
            "Authorization": f"Bearer {flinks_config['api_key']}",
            "Content-Type": "application/json"
        }
        
        async with self.session.post(
            f"{flinks_config['base_url']}/Authorize",
            json=auth_data,
            headers=headers
        ) as response:
            auth_result = await response.json()
            login_id = auth_result["LoginId"]
        
        # Get accounts
        async with self.session.get(
            f"{flinks_config['base_url']}/GetAccountsSummary",
            params={"RequestId": login_id},
            headers=headers
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("Accounts", [])
    
    async def _connect_truelayer_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via TrueLayer (Europe)"""
        truelayer_config = self.config.get("truelayer", {})
        
        # Use OAuth access token from credentials
        access_token = credentials["access_token"]
        
        headers = {"Authorization": f"Bearer {access_token}"}
        
        async with self.session.get(
            f"{truelayer_config['base_url']}/data/v1/accounts",
            headers=headers
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("results", [])
    
    async def _connect_akoya_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Akoya"""
        akoya_config = self.config.get("akoya", {})
        
        # Use OAuth access token
        access_token = credentials["access_token"]
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "x-akoya-interaction-id": f"user-{user_id}-{datetime.now().isoformat()}"
        }
        
        async with self.session.get(
            f"{akoya_config['base_url']}/accounts",
            headers=headers
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("accounts", [])
    
    async def _connect_teller_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Teller"""
        teller_config = self.config.get("teller", {})
        
        # Use enrollment ID from Teller Connect
        enrollment_id = credentials["enrollment_id"]
        
        auth = aiohttp.BasicAuth(
            teller_config["application_id"],
            teller_config["private_key"]
        )
        
        async with self.session.get(
            f"{teller_config['base_url']}/accounts",
            params={"enrollment_id": enrollment_id},
            auth=auth
        ) as response:
            accounts_result = await response.json()
            return accounts_result
    
    async def _connect_mx_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via MX"""
        mx_config = self.config.get("mx", {})
        
        # Create member (connection)
        member_data = {
            "member": {
                "institution_code": institution_id,
                "credentials": [
                    {"guid": key, "value": value}
                    for key, value in credentials.items()
                ]
            }
        }
        
        auth = aiohttp.BasicAuth(mx_config["client_id"], mx_config["api_key"])
        
        async with self.session.post(
            f"{mx_config['base_url']}/users/{user_id}/members",
            json=member_data,
            auth=auth
        ) as response:
            member_result = await response.json()
            member_guid = member_result["member"]["guid"]
        
        # Get accounts
        async with self.session.get(
            f"{mx_config['base_url']}/users/{user_id}/members/{member_guid}/accounts",
            auth=auth
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("accounts", [])
    
    async def _connect_finicity_accounts(
        self,
        user_id: str,
        institution_id: str,
        credentials: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Connect accounts via Finicity (Mastercard)"""
        finicity_config = self.config.get("finicity", {})
        
        # Get access token
        access_token = await self._authenticate_finicity()
        
        # Add account
        add_account_data = {
            "institutionId": institution_id,
            "credentials": [
                {"name": key, "value": value}
                for key, value in credentials.items()
            ]
        }
        
        headers = {
            "Finicity-App-Token": access_token,
            "Content-Type": "application/json"
        }
        
        async with self.session.post(
            f"{finicity_config['base_url']}/aggregation/v1/customers/{user_id}/institutions/{institution_id}/accounts/addall",
            json=add_account_data,
            headers=headers
        ) as response:
            result = await response.json()
        
        # Get accounts
        async with self.session.get(
            f"{finicity_config['base_url']}/aggregation/v1/customers/{user_id}/accounts",
            headers=headers
        ) as response:
            accounts_result = await response.json()
            return accounts_result.get("accounts", [])
    
    # Helper methods
    
    def _initialize_providers(self) -> Dict[str, Dict[str, Any]]:
        """Initialize provider configurations"""
        return {
            "plaid": self.config.get("plaid", {}),
            "yodlee": self.config.get("yodlee", {}),
            "flinks": self.config.get("flinks", {}),
            "truelayer": self.config.get("truelayer", {}),
            "akoya": self.config.get("akoya", {}),
            "teller": self.config.get("teller", {}),
            "mx": self.config.get("mx", {}),
            "finicity": self.config.get("finicity", {})
        }
    
    async def _select_best_provider(self, institution_id: str) -> str:
        """Select the best provider for a given institution"""
        # This would implement logic to select the best provider
        # based on institution coverage, reliability, and cost
        
        # For now, return a simple priority order
        provider_priority = ["akoya", "teller", "yodlee", "plaid", "mx", "finicity"]
        
        for provider in provider_priority:
            if provider in self.providers and self.providers[provider]:
                # Check if provider supports this institution
                if await self._provider_supports_institution(provider, institution_id):
                    return provider
        
        return "plaid"  # Default fallback
    
    async def _provider_supports_institution(self, provider: str, institution_id: str) -> bool:
        """Check if provider supports the given institution"""
        # This would implement actual institution support checking
        return True  # Placeholder
    
    async def _standardize_account_data(
        self,
        account_data: Dict[str, Any],
        provider: str
    ) -> FinancialAccount:
        """Standardize account data across providers"""
        # This would implement provider-specific data mapping
        # For now, return a placeholder
        return FinancialAccount(
            account_id=account_data.get("account_id", ""),
            institution_id=account_data.get("institution_id", ""),
            institution_name=account_data.get("institution_name", ""),
            account_type=AccountType.CHECKING,
            account_name=account_data.get("name", ""),
            account_number_masked=account_data.get("mask", ""),
            balance=Decimal(str(account_data.get("balance", 0))),
            currency="USD",
            last_updated=datetime.now(),
            provider=provider,
            metadata=account_data
        )
    
    async def _standardize_transaction_data(
        self,
        transaction_data: Dict[str, Any],
        provider: str
    ) -> Transaction:
        """Standardize transaction data across providers"""
        # This would implement provider-specific transaction mapping
        return Transaction(
            transaction_id=transaction_data.get("transaction_id", ""),
            account_id=transaction_data.get("account_id", ""),
            amount=Decimal(str(transaction_data.get("amount", 0))),
            currency="USD",
            date=datetime.now(),
            description=transaction_data.get("description", ""),
            merchant_name=transaction_data.get("merchant_name"),
            category=transaction_data.get("category", []),
            tax_category=None,
            is_business=False,
            location=transaction_data.get("location"),
            metadata=transaction_data,
            confidence_score=0.8
        )
    
    async def _standardize_holding_data(
        self,
        holding_data: Dict[str, Any],
        provider: str
    ) -> InvestmentHolding:
        """Standardize investment holding data across providers"""
        return InvestmentHolding(
            holding_id=holding_data.get("holding_id", ""),
            account_id=holding_data.get("account_id", ""),
            security_id=holding_data.get("security_id", ""),
            symbol=holding_data.get("symbol", ""),
            name=holding_data.get("name", ""),
            quantity=Decimal(str(holding_data.get("quantity", 0))),
            price=Decimal(str(holding_data.get("price", 0))),
            value=Decimal(str(holding_data.get("value", 0))),
            cost_basis=Decimal(str(holding_data.get("cost_basis", 0))) if holding_data.get("cost_basis") else None,
            unrealized_gain_loss=None,
            asset_class=holding_data.get("asset_class", ""),
            last_updated=datetime.now()
        )
    
    async def _group_accounts_by_provider(self, account_ids: List[str]) -> Dict[str, List[str]]:
        """Group account IDs by their provider"""
        # This would query the database to determine which provider each account uses
        # For now, return a placeholder grouping
        return {"plaid": account_ids}
    
    async def _deduplicate_transactions(self, transactions: List[Transaction]) -> List[Transaction]:
        """Remove duplicate transactions across providers"""
        seen = set()
        unique_transactions = []
        
        for transaction in transactions:
            # Create a hash based on amount, date, and description
            transaction_hash = hashlib.md5(
                f"{transaction.amount}{transaction.date.date()}{transaction.description}".encode()
            ).hexdigest()
            
            if transaction_hash not in seen:
                seen.add(transaction_hash)
                unique_transactions.append(transaction)
        
        return unique_transactions
    
    async def _categorize_for_tax(self, transaction: Transaction) -> Optional[TransactionCategory]:
        """Categorize transaction for tax purposes"""
        # This would implement sophisticated categorization logic
        # For now, return a simple mapping
        description_lower = transaction.description.lower()
        
        if any(keyword in description_lower for keyword in ["office", "supplies", "staples"]):
            return TransactionCategory.OFFICE_SUPPLIES
        elif any(keyword in description_lower for keyword in ["travel", "hotel", "airline"]):
            return TransactionCategory.TRAVEL
        elif any(keyword in description_lower for keyword in ["restaurant", "meal", "food"]):
            return TransactionCategory.MEALS
        
        return None
    
    async def _classify_business_transaction(self, transaction: Transaction) -> bool:
        """Classify if transaction is business-related"""
        # This would implement business classification logic
        return False  # Placeholder
    
    async def _authenticate_yodlee(self) -> str:
        """Authenticate with Yodlee and get access token"""
        # Implementation would go here
        return "yodlee_access_token"
    
    async def _authenticate_finicity(self) -> str:
        """Authenticate with Finicity and get access token"""
        # Implementation would go here
        return "finicity_access_token"
    
    # Placeholder methods for transaction and balance fetching
    async def _fetch_plaid_transactions(self, account_ids, start_date, end_date):
        return []
    
    async def _fetch_yodlee_transactions(self, account_ids, start_date, end_date):
        return []
    
    async def _fetch_flinks_transactions(self, account_ids, start_date, end_date):
        return []
    
    async def _fetch_plaid_holdings(self, account_ids):
        return []
    
    async def _fetch_yodlee_holdings(self, account_ids):
        return []
    
    async def _sync_plaid_balances(self, account_ids):
        return {}
    
    async def _sync_yodlee_balances(self, account_ids):
        return {}
    
    async def _apply_business_rules(self, transaction, business_rules):
        return None
    
    async def _ai_categorize_transaction(self, transaction):
        return None
    
    async def _ai_classify_business_transaction(self, transaction):
        return False
