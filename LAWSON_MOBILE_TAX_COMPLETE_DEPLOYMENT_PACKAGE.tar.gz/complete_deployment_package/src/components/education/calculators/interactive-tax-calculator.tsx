
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Calculator, DollarSign, TrendingUp, PieChart, 
  Info, Save, Share2, Download, RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { TaxCalculator, CalculatorInput, CalculatorResult } from '@/lib/types/education';
import { ClientProfile } from '@/lib/types/experience';

interface InteractiveTaxCalculatorProps {
  calculators: TaxCalculator[];
  clientProfile: ClientProfile;
  onSaveCalculation: (calculatorId: string, inputs: Record<string, any>, results: CalculatorResult[]) => void;
  onShareCalculation: (calculatorId: string, results: CalculatorResult[]) => void;
}

const TAX_BRACKETS_2024 = [
  { min: 0, max: 11000, rate: 0.10 },
  { min: 11000, max: 44725, rate: 0.12 },
  { min: 44725, max: 95375, rate: 0.22 },
  { min: 95375, max: 182050, rate: 0.24 },
  { min: 182050, max: 231250, rate: 0.32 },
  { min: 231250, max: 578125, rate: 0.35 },
  { min: 578125, max: Infinity, rate: 0.37 }
];

const STANDARD_DEDUCTIONS_2024 = {
  single: 13850,
  married_filing_jointly: 27700,
  married_filing_separately: 13850,
  head_of_household: 20800
};

export default function InteractiveTaxCalculator({
  calculators,
  clientProfile,
  onSaveCalculation,
  onShareCalculation
}: InteractiveTaxCalculatorProps) {
  const [selectedCalculator, setSelectedCalculator] = useState<TaxCalculator | null>(null);
  const [inputs, setInputs] = useState<Record<string, any>>({});
  const [results, setResults] = useState<CalculatorResult[]>([]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [savedCalculations, setSavedCalculations] = useState<any[]>([]);

  // Filter calculators based on client profile
  const recommendedCalculators = calculators.filter(calc => {
    switch (clientProfile.persona.type) {
      case 'small_business':
        return calc.type === 'business_deduction' || calc.type === 'self_employment';
      case 'investor':
        return calc.type === 'investment';
      case 'retiree':
        return calc.type === 'retirement';
      case 'freelancer':
        return calc.type === 'self_employment';
      default:
        return calc.type === 'income_tax';
    }
  });

  useEffect(() => {
    if (selectedCalculator) {
      // Initialize inputs with default values
      const defaultInputs: Record<string, any> = {};
      selectedCalculator.inputs.forEach(input => {
        defaultInputs[input.id] = input.type === 'boolean' ? false : '';
      });
      setInputs(defaultInputs);
      setResults([]);
    }
  }, [selectedCalculator]);

  const handleInputChange = (inputId: string, value: any) => {
    setInputs(prev => ({
      ...prev,
      [inputId]: value
    }));
  };

  const calculateResults = async () => {
    if (!selectedCalculator) return;

    setIsCalculating(true);
    
    // Simulate calculation delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    let calculatedResults: CalculatorResult[] = [];

    switch (selectedCalculator.type) {
      case 'income_tax':
        calculatedResults = calculateIncomeTax(inputs);
        break;
      case 'business_deduction':
        calculatedResults = calculateBusinessDeductions(inputs);
        break;
      case 'investment':
        calculatedResults = calculateInvestmentTax(inputs);
        break;
      case 'retirement':
        calculatedResults = calculateRetirementTax(inputs);
        break;
      case 'self_employment':
        calculatedResults = calculateSelfEmploymentTax(inputs);
        break;
      default:
        calculatedResults = [];
    }

    setResults(calculatedResults);
    setIsCalculating(false);
  };

  const calculateIncomeTax = (inputs: Record<string, any>): CalculatorResult[] => {
    const income = parseFloat(inputs.annual_income) || 0;
    const filingStatus = inputs.filing_status || 'single';
    const standardDeduction = STANDARD_DEDUCTIONS_2024[filingStatus as keyof typeof STANDARD_DEDUCTIONS_2024];
    const taxableIncome = Math.max(0, income - standardDeduction);
    
    let tax = 0;
    let remainingIncome = taxableIncome;
    
    for (const bracket of TAX_BRACKETS_2024) {
      if (remainingIncome <= 0) break;
      
      const taxableAtThisBracket = Math.min(remainingIncome, bracket.max - bracket.min);
      tax += taxableAtThisBracket * bracket.rate;
      remainingIncome -= taxableAtThisBracket;
    }

    const effectiveRate = income > 0 ? (tax / income) * 100 : 0;
    const marginalRate = getMarginalTaxRate(taxableIncome) * 100;
    const afterTaxIncome = income - tax;

    return [
      {
        id: 'gross_income',
        label: 'Gross Income',
        value: income,
        format: 'currency',
        description: 'Your total annual income before deductions'
      },
      {
        id: 'standard_deduction',
        label: 'Standard Deduction',
        value: standardDeduction,
        format: 'currency',
        description: `Standard deduction for ${filingStatus.replace('_', ' ')}`
      },
      {
        id: 'taxable_income',
        label: 'Taxable Income',
        value: taxableIncome,
        format: 'currency',
        description: 'Income subject to federal tax'
      },
      {
        id: 'federal_tax',
        label: 'Federal Tax Owed',
        value: tax,
        format: 'currency',
        description: 'Total federal income tax liability'
      },
      {
        id: 'effective_rate',
        label: 'Effective Tax Rate',
        value: effectiveRate,
        format: 'percentage',
        description: 'Percentage of total income paid in taxes'
      },
      {
        id: 'marginal_rate',
        label: 'Marginal Tax Rate',
        value: marginalRate,
        format: 'percentage',
        description: 'Tax rate on your last dollar of income'
      },
      {
        id: 'after_tax_income',
        label: 'After-Tax Income',
        value: afterTaxIncome,
        format: 'currency',
        description: 'Your income after federal taxes'
      }
    ];
  };

  const calculateBusinessDeductions = (inputs: Record<string, any>): CalculatorResult[] => {
    const revenue = parseFloat(inputs.business_revenue) || 0;
    const homeOfficeExpense = parseFloat(inputs.home_office_expense) || 0;
    const vehicleExpense = parseFloat(inputs.vehicle_expense) || 0;
    const equipmentExpense = parseFloat(inputs.equipment_expense) || 0;
    const travelExpense = parseFloat(inputs.travel_expense) || 0;
    const mealExpense = parseFloat(inputs.meal_expense) || 0;

    const totalDeductions = homeOfficeExpense + vehicleExpense + equipmentExpense + travelExpense + (mealExpense * 0.5);
    const taxableIncome = Math.max(0, revenue - totalDeductions);
    const taxSavings = totalDeductions * 0.24; // Assuming 24% tax bracket

    return [
      {
        id: 'business_revenue',
        label: 'Business Revenue',
        value: revenue,
        format: 'currency',
        description: 'Total business income for the year'
      },
      {
        id: 'total_deductions',
        label: 'Total Deductions',
        value: totalDeductions,
        format: 'currency',
        description: 'Sum of all eligible business deductions'
      },
      {
        id: 'taxable_business_income',
        label: 'Taxable Business Income',
        value: taxableIncome,
        format: 'currency',
        description: 'Business income after deductions'
      },
      {
        id: 'estimated_tax_savings',
        label: 'Estimated Tax Savings',
        value: taxSavings,
        format: 'currency',
        description: 'Approximate tax savings from deductions'
      },
      {
        id: 'deduction_breakdown',
        label: 'Deduction Breakdown',
        value: `Home Office: $${homeOfficeExpense.toLocaleString()}, Vehicle: $${vehicleExpense.toLocaleString()}, Equipment: $${equipmentExpense.toLocaleString()}`,
        format: 'text',
        description: 'Breakdown of major deduction categories'
      }
    ];
  };

  const calculateInvestmentTax = (inputs: Record<string, any>): CalculatorResult[] => {
    const shortTermGains = parseFloat(inputs.short_term_gains) || 0;
    const longTermGains = parseFloat(inputs.long_term_gains) || 0;
    const dividends = parseFloat(inputs.dividends) || 0;
    const capitalLosses = parseFloat(inputs.capital_losses) || 0;

    const netShortTerm = Math.max(0, shortTermGains - capitalLosses);
    const netLongTerm = Math.max(0, longTermGains);
    
    // Assuming 24% ordinary income rate and 15% long-term capital gains rate
    const shortTermTax = netShortTerm * 0.24;
    const longTermTax = netLongTerm * 0.15;
    const dividendTax = dividends * 0.15; // Qualified dividends
    const totalTax = shortTermTax + longTermTax + dividendTax;

    return [
      {
        id: 'short_term_gains',
        label: 'Short-Term Capital Gains',
        value: shortTermGains,
        format: 'currency',
        description: 'Gains from assets held less than one year'
      },
      {
        id: 'long_term_gains',
        label: 'Long-Term Capital Gains',
        value: longTermGains,
        format: 'currency',
        description: 'Gains from assets held more than one year'
      },
      {
        id: 'dividend_income',
        label: 'Dividend Income',
        value: dividends,
        format: 'currency',
        description: 'Income from dividend payments'
      },
      {
        id: 'capital_losses',
        label: 'Capital Losses',
        value: capitalLosses,
        format: 'currency',
        description: 'Losses that can offset gains'
      },
      {
        id: 'total_investment_tax',
        label: 'Total Investment Tax',
        value: totalTax,
        format: 'currency',
        description: 'Total tax owed on investment income'
      }
    ];
  };

  const calculateRetirementTax = (inputs: Record<string, any>): CalculatorResult[] => {
    const age = parseInt(inputs.age) || 65;
    const retirementBalance = parseFloat(inputs.retirement_balance) || 0;
    const socialSecurity = parseFloat(inputs.social_security) || 0;
    const otherIncome = parseFloat(inputs.other_income) || 0;

    // RMD calculation (simplified)
    const rmdRate = age >= 72 ? 1 / (108.7 - age) : 0;
    const requiredMinimumDistribution = retirementBalance * rmdRate;
    
    // Social Security taxation (simplified)
    const provisionalIncome = otherIncome + (socialSecurity * 0.5);
    let taxableSocialSecurity = 0;
    if (provisionalIncome > 44000) {
      taxableSocialSecurity = Math.min(socialSecurity * 0.85, socialSecurity * 0.5 + (provisionalIncome - 44000) * 0.85);
    } else if (provisionalIncome > 32000) {
      taxableSocialSecurity = Math.min(socialSecurity * 0.5, (provisionalIncome - 32000) * 0.5);
    }

    const totalTaxableIncome = requiredMinimumDistribution + taxableSocialSecurity + otherIncome;
    const estimatedTax = totalTaxableIncome * 0.22; // Simplified tax calculation

    return [
      {
        id: 'retirement_balance',
        label: 'Retirement Account Balance',
        value: retirementBalance,
        format: 'currency',
        description: 'Total balance in tax-deferred retirement accounts'
      },
      {
        id: 'rmd',
        label: 'Required Minimum Distribution',
        value: requiredMinimumDistribution,
        format: 'currency',
        description: age >= 72 ? 'Mandatory annual withdrawal' : 'Not required until age 72'
      },
      {
        id: 'social_security_income',
        label: 'Social Security Income',
        value: socialSecurity,
        format: 'currency',
        description: 'Annual Social Security benefits'
      },
      {
        id: 'taxable_social_security',
        label: 'Taxable Social Security',
        value: taxableSocialSecurity,
        format: 'currency',
        description: 'Portion of Social Security subject to tax'
      },
      {
        id: 'total_retirement_tax',
        label: 'Estimated Annual Tax',
        value: estimatedTax,
        format: 'currency',
        description: 'Estimated tax on retirement income'
      }
    ];
  };

  const calculateSelfEmploymentTax = (inputs: Record<string, any>): CalculatorResult[] => {
    const netEarnings = parseFloat(inputs.net_earnings) || 0;
    const quarterlyPayments = parseFloat(inputs.quarterly_payments) || 0;

    const selfEmploymentTax = netEarnings * 0.9235 * 0.153; // SE tax rate
    const incomeTax = netEarnings * 0.24; // Simplified income tax
    const totalTax = selfEmploymentTax + incomeTax;
    const quarterlyEstimate = totalTax / 4;
    const additionalOwed = Math.max(0, totalTax - quarterlyPayments);

    return [
      {
        id: 'net_earnings',
        label: 'Net Self-Employment Earnings',
        value: netEarnings,
        format: 'currency',
        description: 'Profit from self-employment activities'
      },
      {
        id: 'self_employment_tax',
        label: 'Self-Employment Tax',
        value: selfEmploymentTax,
        format: 'currency',
        description: 'Social Security and Medicare taxes (15.3%)'
      },
      {
        id: 'income_tax',
        label: 'Income Tax',
        value: incomeTax,
        format: 'currency',
        description: 'Federal income tax on self-employment income'
      },
      {
        id: 'total_tax_owed',
        label: 'Total Tax Owed',
        value: totalTax,
        format: 'currency',
        description: 'Combined self-employment and income tax'
      },
      {
        id: 'quarterly_estimate',
        label: 'Quarterly Payment Estimate',
        value: quarterlyEstimate,
        format: 'currency',
        description: 'Suggested quarterly estimated tax payment'
      },
      {
        id: 'additional_owed',
        label: 'Additional Amount Owed',
        value: additionalOwed,
        format: 'currency',
        description: 'Amount still owed after quarterly payments'
      }
    ];
  };

  const getMarginalTaxRate = (taxableIncome: number): number => {
    for (const bracket of TAX_BRACKETS_2024) {
      if (taxableIncome <= bracket.max) {
        return bracket.rate;
      }
    }
    return TAX_BRACKETS_2024[TAX_BRACKETS_2024.length - 1].rate;
  };

  const formatValue = (value: number | string, format: string): string => {
    if (typeof value === 'string') return value;
    
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD'
        }).format(value);
      case 'percentage':
        return `${value.toFixed(2)}%`;
      case 'number':
        return value.toLocaleString();
      default:
        return value.toString();
    }
  };

  const handleSave = () => {
    if (selectedCalculator && results.length > 0) {
      onSaveCalculation(selectedCalculator.id, inputs, results);
      setSavedCalculations(prev => [...prev, {
        id: Date.now(),
        calculatorId: selectedCalculator.id,
        calculatorName: selectedCalculator.name,
        inputs,
        results,
        savedAt: new Date()
      }]);
    }
  };

  const handleShare = () => {
    if (selectedCalculator && results.length > 0) {
      onShareCalculation(selectedCalculator.id, results);
    }
  };

  const renderInput = (input: CalculatorInput) => {
    const value = inputs[input.id] || '';

    switch (input.type) {
      case 'number':
        return (
          <Input
            type="number"
            value={value}
            onChange={(e) => handleInputChange(input.id, e.target.value)}
            placeholder={input.placeholder}
            min={input.min}
            max={input.max}
          />
        );
      case 'select':
        return (
          <Select value={value} onValueChange={(val) => handleInputChange(input.id, val)}>
            <SelectTrigger>
              <SelectValue placeholder={input.placeholder} />
            </SelectTrigger>
            <SelectContent>
              {input.options?.map(option => (
                <SelectItem key={option} value={option}>
                  {option.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={value}
              onChange={(e) => handleInputChange(input.id, e.target.checked)}
              className="rounded border-gray-300"
            />
            <span className="text-sm">Yes</span>
          </div>
        );
      default:
        return (
          <Input
            value={value}
            onChange={(e) => handleInputChange(input.id, e.target.value)}
            placeholder={input.placeholder}
          />
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Interactive Tax Calculators
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Get instant tax calculations and insights tailored to your specific situation
        </p>
      </div>

      <Tabs defaultValue="recommended">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="all">All Calculators</TabsTrigger>
          <TabsTrigger value="saved">Saved Calculations</TabsTrigger>
        </TabsList>

        <TabsContent value="recommended" className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Recommended for {clientProfile.persona.name}s
            </h3>
            <p className="text-gray-600">
              Calculators most relevant to your tax situation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedCalculators.map((calculator) => (
              <Card
                key={calculator.id}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedCalculator(calculator)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{calculator.name}</CardTitle>
                      <CardDescription className="mt-2">
                        {calculator.description}
                      </CardDescription>
                    </div>
                    <Calculator className="w-6 h-6 text-blue-600" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>{calculator.inputs.length} inputs</span>
                    <Badge variant="outline">
                      {calculator.type.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div className="mt-3">
                    <Button className="w-full">
                      Use Calculator
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="all" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {calculators.map((calculator) => (
              <Card
                key={calculator.id}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedCalculator(calculator)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{calculator.name}</CardTitle>
                      <CardDescription className="mt-2">
                        {calculator.description}
                      </CardDescription>
                    </div>
                    <Calculator className="w-6 h-6 text-blue-600" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                    <span>{calculator.inputs.length} inputs</span>
                    <span>{calculator.usageCount.toLocaleString()} uses</span>
                  </div>
                  <Badge variant="outline" className="mb-3">
                    {calculator.type.replace('_', ' ')}
                  </Badge>
                  <Button className="w-full">
                    Use Calculator
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="saved" className="space-y-6">
          {savedCalculations.length === 0 ? (
            <div className="text-center py-12">
              <Calculator className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No Saved Calculations
              </h3>
              <p className="text-gray-600">
                Use a calculator and save your results to see them here
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {savedCalculations.map((saved) => (
                <Card key={saved.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{saved.calculatorName}</CardTitle>
                        <CardDescription>
                          Saved on {new Date(saved.savedAt).toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const calculator = calculators.find(c => c.id === saved.calculatorId);
                          if (calculator) {
                            setSelectedCalculator(calculator);
                            setInputs(saved.inputs);
                            setResults(saved.results);
                          }
                        }}
                      >
                        View
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      {saved.results.slice(0, 4).map((result: CalculatorResult) => (
                        <div key={result.id}>
                          <p className="text-gray-600">{result.label}</p>
                          <p className="font-medium">{formatValue(result.value, result.format)}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Calculator Modal */}
      <AnimatePresence>
        {selectedCalculator && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedCalculator(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{selectedCalculator.name}</h3>
                    <p className="text-gray-600 mt-2">{selectedCalculator.description}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedCalculator(null)}>
                    ✕
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Input Section */}
                  <div className="space-y-6">
                    <h4 className="text-lg font-semibold text-gray-900">Calculator Inputs</h4>
                    <div className="space-y-4">
                      {selectedCalculator.inputs.map((input) => (
                        <div key={input.id} className="space-y-2">
                          <Label htmlFor={input.id} className="flex items-center space-x-2">
                            <span>{input.label}</span>
                            {input.required && <span className="text-red-500">*</span>}
                            {input.helpText && (
                              <div className="group relative">
                                <Info className="w-4 h-4 text-gray-400 cursor-help" />
                                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                                  {input.helpText}
                                </div>
                              </div>
                            )}
                          </Label>
                          {renderInput(input)}
                        </div>
                      ))}
                    </div>

                    <div className="flex space-x-3">
                      <Button
                        onClick={calculateResults}
                        disabled={isCalculating}
                        className="flex-1"
                      >
                        {isCalculating ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Calculating...
                          </>
                        ) : (
                          <>
                            <Calculator className="w-4 h-4 mr-2" />
                            Calculate
                          </>
                        )}
                      </Button>
                      {results.length > 0 && (
                        <>
                          <Button variant="outline" onClick={handleSave}>
                            <Save className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" onClick={handleShare}>
                            <Share2 className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Results Section */}
                  <div className="space-y-6">
                    <h4 className="text-lg font-semibold text-gray-900">Results</h4>
                    {results.length === 0 ? (
                      <div className="text-center py-12 bg-gray-50 rounded-lg">
                        <PieChart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">
                          Enter your information and click Calculate to see results
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {results.map((result) => (
                          <Card key={result.id} className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h5 className="font-medium text-gray-900">{result.label}</h5>
                                {result.description && (
                                  <p className="text-sm text-gray-600 mt-1">{result.description}</p>
                                )}
                              </div>
                              <div className="text-right">
                                <p className="text-lg font-bold text-blue-600">
                                  {formatValue(result.value, result.format)}
                                </p>
                              </div>
                            </div>
                          </Card>
                        ))}

                        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                          <h5 className="font-medium text-blue-900 mb-2">
                            💡 Tax Planning Tip
                          </h5>
                          <p className="text-sm text-blue-800">
                            These calculations are estimates based on current tax laws. 
                            Consider consulting with a tax professional for personalized advice.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
