
"""
Pinterest adapter using Pinterest API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class PinterestAdapter(BasePlatformAdapter):
    """Adapter for Pinterest using Pinterest API v5"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.access_token = credentials.get('access_token')
        self.app_id = credentials.get('app_id')
        self.app_secret = credentials.get('app_secret')
        self.base_url = "https://api.pinterest.com/v5"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            url = f"{self.base_url}/user_account"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                user_info = response.json()
                logger.info(f"Authenticated as: {user_info.get('username', 'Unknown')}")
                return True
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Create a Pin on Pinterest"""
        try:
            if not media_urls or len(media_urls) == 0:
                return {"success": False, "error": "Pinterest requires image content"}
            
            # Format description with hashtags
            description = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                description = f"{content}\n\n{hashtag_text}"
            
            # Pinterest allows up to 500 characters for descriptions
            description = self.validate_content_length(description, 500)
            
            url = f"{self.base_url}/pins"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            pin_data = {
                'link': kwargs.get('link', ''),  # Optional destination URL
                'title': kwargs.get('title', content[:100]),  # Pin title (up to 100 chars)
                'description': description,
                'board_id': kwargs.get('board_id'),  # Required: Pinterest board ID
                'media_source': {
                    'source_type': 'image_url',
                    'url': media_urls[0]  # Pinterest primarily uses images
                }
            }
            
            # Add alt text for accessibility
            if kwargs.get('alt_text'):
                pin_data['alt_text'] = kwargs['alt_text']
            
            # Add note (private note for the pinner)
            if kwargs.get('note'):
                pin_data['note'] = kwargs['note']
            
            response = requests.post(url, headers=headers, json=pin_data)
            
            if response.status_code == 201:
                result = response.json()
                return {
                    "success": True,
                    "post_id": result.get('id'),
                    "pin_url": result.get('url'),
                    "platform_response": result
                }
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('message', f'HTTP {response.status_code}')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            logger.error(f"Error creating Pinterest pin: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a Pinterest pin"""
        try:
            # Pinterest API doesn't support native scheduling
            # This would be handled by our internal scheduler
            
            return {
                "success": True,
                "message": "Pinterest pin scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "Pinterest API doesn't support native scheduling"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a Pinterest pin"""
        try:
            url = f"{self.base_url}/pins/{post_id}/analytics"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            # Get analytics for the last 30 days
            params = {
                'start_date': (datetime.now().replace(day=1)).strftime('%Y-%m-%d'),
                'end_date': datetime.now().strftime('%Y-%m-%d'),
                'metric_types': 'IMPRESSION,SAVE,PIN_CLICK,OUTBOUND_CLICK'
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                daily_metrics = result.get('daily_metrics', [])
                
                # Aggregate metrics
                total_impressions = sum(day.get('data_status') == 'READY' and 
                                      day.get('metrics', {}).get('IMPRESSION', 0) 
                                      for day in daily_metrics)
                total_saves = sum(day.get('data_status') == 'READY' and 
                                day.get('metrics', {}).get('SAVE', 0) 
                                for day in daily_metrics)
                total_clicks = sum(day.get('data_status') == 'READY' and 
                                 day.get('metrics', {}).get('PIN_CLICK', 0) 
                                 for day in daily_metrics)
                total_outbound_clicks = sum(day.get('data_status') == 'READY' and 
                                          day.get('metrics', {}).get('OUTBOUND_CLICK', 0) 
                                          for day in daily_metrics)
                
                analytics = {
                    "post_id": post_id,
                    "impressions": total_impressions,
                    "saves": total_saves,
                    "clicks": total_clicks,
                    "outbound_clicks": total_outbound_clicks,
                    "period": "30 days"
                }
                
                return {"success": True, "analytics": analytics}
            else:
                error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a Pinterest pin"""
        try:
            url = f"{self.base_url}/pins/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.delete(url, headers=headers)
            return response.status_code == 204
            
        except Exception as e:
            logger.error(f"Error deleting Pinterest pin: {str(e)}")
            return False
    
    async def get_boards(self) -> Dict[str, Any]:
        """Get user's Pinterest boards"""
        try:
            url = f"{self.base_url}/boards"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                boards = result.get('items', [])
                
                board_list = []
                for board in boards:
                    board_list.append({
                        'id': board.get('id'),
                        'name': board.get('name'),
                        'description': board.get('description'),
                        'pin_count': board.get('pin_count', 0),
                        'privacy': board.get('privacy')
                    })
                
                return {"success": True, "boards": board_list}
            else:
                error_msg = f"Failed to get boards: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def create_board(self, name: str, description: str = "", privacy: str = "PUBLIC") -> Dict[str, Any]:
        """Create a new Pinterest board"""
        try:
            url = f"{self.base_url}/boards"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            board_data = {
                'name': name,
                'description': description,
                'privacy': privacy  # PUBLIC or SECRET
            }
            
            response = requests.post(url, headers=headers, json=board_data)
            
            if response.status_code == 201:
                result = response.json()
                return {
                    "success": True,
                    "board_id": result.get('id'),
                    "board_name": result.get('name'),
                    "platform_response": result
                }
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('message', f'HTTP {response.status_code}')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
