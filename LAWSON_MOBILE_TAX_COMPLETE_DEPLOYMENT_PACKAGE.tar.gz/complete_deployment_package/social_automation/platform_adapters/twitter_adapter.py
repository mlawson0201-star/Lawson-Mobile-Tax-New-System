
"""
Twitter/X adapter using API v2
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class TwitterAdapter(BasePlatformAdapter):
    """Adapter for Twitter/X using API v2"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.bearer_token = credentials.get('bearer_token')
        self.access_token = credentials.get('access_token')
        self.access_token_secret = credentials.get('access_token_secret')
        self.api_key = credentials.get('api_key')
        self.api_secret = credentials.get('api_secret')
        self.base_url = "https://api.x.com/2"
        
    async def authenticate(self) -> bool:
        """Verify credentials"""
        try:
            url = f"{self.base_url}/users/me"
            headers = {
                'Authorization': f'Bearer {self.bearer_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                user_info = response.json()
                logger.info(f"Authenticated as: {user_info.get('data', {}).get('username')}")
                return True
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post a tweet"""
        try:
            # Format content with hashtags
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content} {hashtag_text}"
            
            # Validate content length (280 characters for Twitter)
            full_content = self.validate_content_length(full_content, 280)
            
            url = f"{self.base_url}/tweets"
            headers = {
                'Authorization': f'Bearer {self.bearer_token}',
                'Content-Type': 'application/json'
            }
            
            tweet_data = {
                'text': full_content
            }
            
            # Handle media if provided
            if media_urls and len(media_urls) > 0:
                # For Twitter API v2, we need to upload media first using v1.1 API
                # This is a simplified version - in production, implement proper media upload
                logger.warning("Media upload not fully implemented for Twitter API v2")
            
            # Handle reply settings
            reply_settings = kwargs.get('reply_settings', 'everyone')  # everyone, mentionedUsers, following
            if reply_settings != 'everyone':
                tweet_data['reply_settings'] = reply_settings
            
            response = requests.post(url, headers=headers, json=tweet_data)
            
            if response.status_code == 201:
                result = response.json()
                return {
                    "success": True,
                    "post_id": result.get('data', {}).get('id'),
                    "platform_response": result
                }
            else:
                error_data = response.json()
                error_msg = error_data.get('detail', 'Unknown error')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            logger.error(f"Error posting tweet: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a tweet (requires Twitter API Pro or Enterprise)"""
        try:
            # Note: Scheduled tweets require higher tier access
            # This is a placeholder implementation
            
            full_content = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                full_content = f"{content} {hashtag_text}"
            
            full_content = self.validate_content_length(full_content, 280)
            
            # For now, return a scheduled status - implement actual scheduling with higher tier API
            return {
                "success": True,
                "message": "Tweet scheduled (requires Pro/Enterprise API for actual scheduling)",
                "scheduled_time": scheduled_time.isoformat(),
                "content": full_content
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a specific tweet"""
        try:
            url = f"{self.base_url}/tweets/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.bearer_token}',
                'Content-Type': 'application/json'
            }
            
            params = {
                'tweet.fields': 'created_at,public_metrics,text',
                'expansions': 'author_id'
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                tweet_data = data.get('data', {})
                metrics = tweet_data.get('public_metrics', {})
                
                analytics = {
                    "post_id": post_id,
                    "retweets": metrics.get('retweet_count', 0),
                    "likes": metrics.get('like_count', 0),
                    "replies": metrics.get('reply_count', 0),
                    "quotes": metrics.get('quote_count', 0),
                    "bookmarks": metrics.get('bookmark_count', 0),
                    "impressions": metrics.get('impression_count', 0),
                    "created_at": tweet_data.get('created_at'),
                    "text": tweet_data.get('text', '')
                }
                
                return {"success": True, "analytics": analytics}
            else:
                error_msg = response.json().get('detail', 'Unknown error')
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a tweet"""
        try:
            url = f"{self.base_url}/tweets/{post_id}"
            headers = {
                'Authorization': f'Bearer {self.bearer_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.delete(url, headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            logger.error(f"Error deleting tweet: {str(e)}")
            return False
    
    async def post_thread(self, tweets: List[str], **kwargs) -> Dict[str, Any]:
        """Post a Twitter thread"""
        try:
            thread_results = []
            previous_tweet_id = None
            
            for i, tweet_content in enumerate(tweets):
                # Add thread numbering
                if len(tweets) > 1:
                    tweet_text = f"{tweet_content} ({i+1}/{len(tweets)})"
                else:
                    tweet_text = tweet_content
                
                tweet_text = self.validate_content_length(tweet_text, 280)
                
                url = f"{self.base_url}/tweets"
                headers = {
                    'Authorization': f'Bearer {self.bearer_token}',
                    'Content-Type': 'application/json'
                }
                
                tweet_data = {'text': tweet_text}
                
                # If this is a reply to previous tweet in thread
                if previous_tweet_id:
                    tweet_data['reply'] = {'in_reply_to_tweet_id': previous_tweet_id}
                
                response = requests.post(url, headers=headers, json=tweet_data)
                
                if response.status_code == 201:
                    result = response.json()
                    tweet_id = result.get('data', {}).get('id')
                    thread_results.append({
                        "tweet_id": tweet_id,
                        "text": tweet_text,
                        "success": True
                    })
                    previous_tweet_id = tweet_id
                else:
                    error_data = response.json()
                    thread_results.append({
                        "text": tweet_text,
                        "success": False,
                        "error": error_data.get('detail', 'Unknown error')
                    })
                    break  # Stop thread if one tweet fails
            
            return {
                "success": all(result["success"] for result in thread_results),
                "thread_results": thread_results,
                "thread_length": len(thread_results)
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
