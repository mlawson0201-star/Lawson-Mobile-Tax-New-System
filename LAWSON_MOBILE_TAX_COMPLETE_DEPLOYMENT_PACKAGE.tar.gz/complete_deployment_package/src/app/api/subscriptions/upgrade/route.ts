
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { planId, billingCycle, clientId } = await request.json();

    if (!planId || !clientId) {
      return NextResponse.json({ error: 'Plan ID and Client ID are required' }, { status: 400 });
    }

    // In a real implementation, this would:
    // 1. Create a payment intent with Stripe
    // 2. Update/create the subscription
    // 3. Handle prorations and billing

    // Mock successful upgrade
    const upgradeResponse = {
      success: true,
      message: 'Subscription upgrade successful',
      subscriptionId: 'upgraded-subscription-' + Date.now(),
      nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      prorationAmount: 0, // Would calculate actual proration
    };

    // Create notification about upgrade
    await prisma.pushNotification.create({
      data: {
        tenantId: session.user.tenantId,
        clientId,
        title: 'Subscription Upgraded Successfully',
        message: 'Your subscription has been upgraded and new features are now available.',
        notificationType: 'subscription_update',
        priority: 'normal',
        payload: {
          planId,
          upgradeDate: new Date().toISOString(),
        },
        deviceTokens: [`client_${clientId}_token`],
      },
    });

    return NextResponse.json(upgradeResponse);
  } catch (error: any) {
    console.error('Subscription upgrade error:', error);
    return NextResponse.json(
      { error: 'Failed to upgrade subscription', details: error?.message },
      { status: 500 }
    );
  }
}
