
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      businessType, 
      businessName, 
      state, 
      industry, 
      owners, 
      taxElection,
      planningNeeds
    } = await request.json();

    if (!businessType || !businessName || !state) {
      return NextResponse.json({ error: 'Business type, name, and state required' }, { status: 400 });
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{
          role: 'user',
          content: `You are an expert business formation specialist. Create a complete automated business formation plan with integrated tax planning.

Business Details:
- Type: ${businessType} (LLC, Corporation, Partnership, etc.)
- Name: ${businessName}
- State: ${state}
- Industry: ${industry}
- Owners: ${JSON.stringify(owners)}
- Tax Election: ${taxElection}
- Planning Needs: ${planningNeeds}

Generate a comprehensive business formation package including:

1. Entity Structure Analysis:
   - Recommended entity type with justification
   - Alternative structures comparison
   - Multi-state considerations

2. Formation Documents:
   - Articles of Incorporation/Organization template
   - Operating Agreement/Bylaws template
   - EIN application details

3. Tax Planning Integration:
   - Optimal tax election strategy
   - Quarterly tax payment setup
   - Deduction maximization plan
   - State tax considerations

4. Ongoing Compliance Calendar:
   - Filing deadlines by jurisdiction
   - Required annual reports
   - Tax return schedules
   - License renewal dates

5. Automation Workflow:
   - Document preparation checklist
   - State filing procedures
   - Bank account setup guidance
   - Insurance requirements

6. First-Year Tax Optimization:
   - Startup expense deductions
   - Equipment depreciation strategies
   - Home office deductions
   - Business expense categories

Format as JSON with structured formation plan.`
        }],
        stream: true,
        max_tokens: 5000,
        response_format: { type: "json_object" }
      }),
    });

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = '';
        let partialRead = '';

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            let lines = partialRead.split('\n');
            partialRead = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  try {
                    const finalResult = JSON.parse(buffer);
                    
                    // Save business formation record
                    await prisma.systemConfig.create({
                      data: {
                        tenantId: session.user.tenantId,
                        configKey: `business_formation_${Date.now()}`,
                        configValue: {
                          businessDetails: { businessType, businessName, state, industry, owners },
                          formationPlan: finalResult,
                          status: 'generated',
                          createdBy: session.user.id
                        },
                        configType: 'business_formation',
                        isActive: true,
                        updatedBy: session.user.id,
                      },
                    });

                    const finalData = JSON.stringify({
                      status: 'completed',
                      result: finalResult,
                      automationLevel: 'advanced',
                      nextSteps: finalResult.automationWorkflow || []
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                    return;
                  } catch (e) {
                    controller.error(e);
                    return;
                  }
                }
                try {
                  const parsed = JSON.parse(data);
                  buffer += parsed.choices?.[0]?.delta?.content || '';
                  const progressData = JSON.stringify({
                    status: 'processing',
                    message: 'Generating comprehensive business formation plan...'
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Business formation stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Business formation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate business formation plan' },
      { status: 500 }
    );
  }
}
