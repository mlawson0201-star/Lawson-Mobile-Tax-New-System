
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { stripe, createPaymentIntent } from '@/lib/stripe'
import { z } from 'zod'

const createPaymentSchema = z.object({
  taxReturnId: z.string().uuid(),
  amount: z.number().positive(),
  description: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.tenantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = createPaymentSchema.parse(body)

    // Get tax return and tenant info
    const taxReturn = await prisma.taxReturn.findFirst({
      where: {
        id: validatedData.taxReturnId,
        tenantId: session.user.tenantId,
      },
      include: {
        client: true,
        tenant: true,
      },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 })
    }

    // Calculate application fee (platform commission)
    const applicationFeeAmount = Math.round(validatedData.amount * 0.03) // 3% platform fee

    // Create Stripe payment intent
    const paymentIntent = await createPaymentIntent(
      validatedData.amount,
      'usd',
      taxReturn.tenant.stripeConnectAccountId || undefined,
      applicationFeeAmount
    )

    // Create payment record
    const payment = await prisma.payment.create({
      data: {
        tenantId: session.user.tenantId,
        taxReturnId: validatedData.taxReturnId,
        clientId: taxReturn.clientId,
        amount: validatedData.amount,
        currency: 'USD',
        status: 'PENDING',
        paymentMethod: 'STRIPE',
        stripePaymentIntentId: paymentIntent.id,
        description: validatedData.description,
      },
    })

    return NextResponse.json({
      payment,
      clientSecret: paymentIntent.client_secret,
    })
  } catch (error) {
    console.error('Error creating payment:', error)
    return NextResponse.json(
      { error: 'Failed to create payment' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.tenantId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const status = searchParams.get('status')

    const where = {
      tenantId: session.user.tenantId,
      ...(status && { status }),
    }

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          client: {
            select: {
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          taxReturn: {
            select: {
              taxYear: true,
              status: true,
            },
          },
        },
      }),
      prisma.payment.count({ where }),
    ])

    return NextResponse.json({
      payments,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching payments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch payments' },
      { status: 500 }
    )
  }
}
