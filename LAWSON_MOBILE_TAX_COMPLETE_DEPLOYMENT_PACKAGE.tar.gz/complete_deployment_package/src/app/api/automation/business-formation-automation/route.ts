
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const BusinessFormationRequestSchema = z.object({
  clientId: z.string(),
  entityType: z.enum(['LLC', 'Corporation', 'S-Corp', 'Partnership', 'Sole-Proprietorship']),
  stateOfFormation: z.string(),
  businessName: z.string(),
  businessPurpose: z.string(),
  formationData: z.record(z.any()),
  automatedCompliance: z.boolean().default(true),
  expeditedProcessing: z.boolean().default(false),
});

const ComplianceRequirementSchema = z.object({
  formationRequestId: z.string(),
  requirementType: z.enum(['annual_report', 'tax_filing', 'license_renewal', 'registered_agent', 'franchise_tax']),
  description: z.string(),
  dueDate: z.string(),
  frequency: z.enum(['annual', 'quarterly', 'monthly', 'one-time']),
  automated: z.boolean().default(true),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;

    if (action === 'initiate_formation') {
      return await initiateBusinessFormation(body);
    } else if (action === 'check_name_availability') {
      return await checkBusinessNameAvailability(body);
    } else if (action === 'generate_documents') {
      return await generateFormationDocuments(body);
    } else if (action === 'file_formation') {
      return await fileFormationDocuments(body);
    } else if (action === 'setup_compliance') {
      return await setupOngoingCompliance(body);
    } else if (action === 'get_ein') {
      return await obtainEIN(body);
    } else if (action === 'setup_banking') {
      return await setupBusinessBanking(body);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Business Formation Automation Error:', error);
    return NextResponse.json(
      { error: 'Business formation failed', details: error.message },
      { status: 500 }
    );
  }
}

async function initiateBusinessFormation(body: any) {
  const { clientId, entityType, stateOfFormation, businessName, businessPurpose, formationData, automatedCompliance, expeditedProcessing } = 
    BusinessFormationRequestSchema.parse(body);

  // Get client information
  const client = await prisma.client.findUnique({
    where: { id: clientId }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  // Check business name availability
  const nameAvailability = await checkNameAvailabilityInState(businessName, stateOfFormation);
  
  if (!nameAvailability.available) {
    return NextResponse.json({ 
      error: 'Business name not available', 
      suggestions: nameAvailability.suggestions 
    }, { status: 400 });
  }

  // Create business formation request
  const formationRequest = await prisma.businessFormationRequest.create({
    data: {
      tenantId: client.tenantId,
      clientId,
      entityType,
      stateOfFormation,
      businessName,
      businessPurpose,
      formationData: {
        ...formationData,
        expeditedProcessing,
        automatedCompliance,
        initiatedAt: new Date().toISOString(),
      },
      status: 'initiated',
    }
  });

  // Generate formation timeline
  const formationTimeline = generateFormationTimeline(entityType, stateOfFormation, expeditedProcessing);

  // Setup automated compliance schedule if requested
  let complianceSchedule = null;
  if (automatedCompliance) {
    complianceSchedule = await setupAutomatedComplianceSchedule(formationRequest.id, entityType, stateOfFormation);
  }

  // Generate required documents list
  const requiredDocuments = generateRequiredDocumentsList(entityType, stateOfFormation, formationData);

  // Calculate formation costs
  const costBreakdown = calculateFormationCosts(entityType, stateOfFormation, expeditedProcessing, automatedCompliance);

  // Create formation workflow
  const workflow = await createFormationWorkflow(formationRequest, formationTimeline);

  return NextResponse.json({
    success: true,
    formationRequest: {
      id: formationRequest.id,
      businessName,
      entityType,
      stateOfFormation,
      status: formationRequest.status,
    },
    timeline: formationTimeline,
    complianceSchedule,
    requiredDocuments,
    costBreakdown,
    workflow: {
      id: workflow.id,
      totalSteps: workflow.steps.length,
      estimatedCompletion: workflow.estimatedCompletion,
    },
    nextSteps: generateFormationNextSteps(formationRequest, workflow),
  });
}

async function checkBusinessNameAvailability(body: any) {
  const { businessName, stateOfFormation, entityType } = body;

  // Check name availability through state APIs or services
  const availability = await checkNameAvailabilityInState(businessName, stateOfFormation);

  // Generate alternative names if not available
  let alternatives = [];
  if (!availability.available) {
    alternatives = await generateAlternativeBusinessNames(businessName, entityType);
  }

  // Check trademark conflicts
  const trademarkCheck = await checkTrademarkConflicts(businessName);

  // Check domain availability
  const domainAvailability = await checkDomainAvailability(businessName);

  return NextResponse.json({
    businessName,
    stateOfFormation,
    available: availability.available,
    reason: availability.reason,
    alternatives,
    trademarkCheck,
    domainAvailability,
    recommendations: generateNameRecommendations(availability, trademarkCheck, domainAvailability),
  });
}

async function generateFormationDocuments(body: any) {
  const { formationRequestId } = body;

  const formationRequest = await prisma.businessFormationRequest.findUnique({
    where: { id: formationRequestId },
    include: { client: true }
  });

  if (!formationRequest) {
    return NextResponse.json({ error: 'Formation request not found' }, { status: 404 });
  }

  // Generate entity-specific documents
  const documents = await generateEntityDocuments(formationRequest);

  // Generate operating agreements/bylaws
  const governanceDocuments = await generateGovernanceDocuments(formationRequest);

  // Generate tax election documents
  const taxElections = await generateTaxElectionDocuments(formationRequest);

  // Generate compliance documents
  const complianceDocuments = await generateInitialComplianceDocuments(formationRequest);

  // Save generated documents
  const savedDocuments = await saveGeneratedDocuments(
    formationRequest, 
    [...documents, ...governanceDocuments, ...taxElections, ...complianceDocuments]
  );

  // Update formation request status
  await prisma.businessFormationRequest.update({
    where: { id: formationRequestId },
    data: {
      status: 'documents_generated',
      formationData: {
        ...formationRequest.formationData,
        documentsGenerated: true,
        documentsGeneratedAt: new Date().toISOString(),
      }
    }
  });

  return NextResponse.json({
    success: true,
    documents: {
      formation: documents.length,
      governance: governanceDocuments.length,
      taxElections: taxElections.length,
      compliance: complianceDocuments.length,
      total: savedDocuments.length,
    },
    generatedDocuments: savedDocuments.map(doc => ({
      id: doc.id,
      type: doc.documentType,
      filename: doc.filename,
      status: doc.status,
    })),
    readyForFiling: true,
    nextSteps: [
      'Review generated documents',
      'Obtain client signatures',
      'Submit formation documents to state',
      'Apply for EIN',
    ],
  });
}

async function fileFormationDocuments(body: any) {
  const { formationRequestId, clientApproval, expeditedFiling } = body;

  const formationRequest = await prisma.businessFormationRequest.findUnique({
    where: { id: formationRequestId },
    include: { 
      client: true,
      documents: true,
    }
  });

  if (!formationRequest) {
    return NextResponse.json({ error: 'Formation request not found' }, { status: 404 });
  }

  if (!clientApproval) {
    return NextResponse.json({ error: 'Client approval required for filing' }, { status: 400 });
  }

  // Submit documents to state filing system
  const filingResult = await submitToStateFilingSystem(formationRequest, expeditedFiling);

  // Update formation request with filing information
  await prisma.businessFormationRequest.update({
    where: { id: formationRequestId },
    data: {
      status: 'filed',
      formationData: {
        ...formationRequest.formationData,
        filingSubmitted: true,
        filingDate: new Date().toISOString(),
        filingConfirmation: filingResult.confirmationNumber,
        expeditedFiling,
      }
    }
  });

  // Setup monitoring for filing status
  const statusMonitoring = await setupFilingStatusMonitoring(formationRequest, filingResult);

  // Schedule post-filing tasks
  const postFilingTasks = await schedulePostFilingTasks(formationRequest);

  return NextResponse.json({
    success: true,
    filing: {
      confirmationNumber: filingResult.confirmationNumber,
      filingDate: new Date().toISOString(),
      expedited: expeditedFiling,
      estimatedApproval: filingResult.estimatedApprovalDate,
    },
    monitoring: {
      trackingId: statusMonitoring.trackingId,
      checkFrequency: statusMonitoring.frequency,
      notificationPreferences: statusMonitoring.notifications,
    },
    postFilingTasks: postFilingTasks.length,
    nextSteps: [
      'Monitor filing status',
      'Prepare for EIN application',
      'Setup business banking',
      'Begin compliance monitoring',
    ],
  });
}

async function setupOngoingCompliance(body: any) {
  const { formationRequestId, compliancePreferences } = body;

  const formationRequest = await prisma.businessFormationRequest.findUnique({
    where: { id: formationRequestId },
    include: { client: true }
  });

  if (!formationRequest) {
    return NextResponse.json({ error: 'Formation request not found' }, { status: 404 });
  }

  // Generate comprehensive compliance schedule
  const complianceSchedule = await generateComprehensiveComplianceSchedule(
    formationRequest, compliancePreferences
  );

  // Create compliance requirements in database
  const complianceRequirements = await Promise.all(
    complianceSchedule.map(requirement => 
      prisma.complianceRequirement.create({
        data: {
          formationRequestId: formationRequest.id,
          requirementType: requirement.type,
          description: requirement.description,
          dueDate: new Date(requirement.dueDate),
          frequency: requirement.frequency,
          automated: requirement.automated,
        }
      })
    )
  );

  // Setup automated compliance monitoring
  const monitoringSystem = await setupComplianceMonitoring(formationRequest, complianceRequirements);

  // Create compliance calendar
  const complianceCalendar = generateComplianceCalendar(complianceRequirements);

  // Setup automated notifications
  const notificationSchedule = await setupComplianceNotifications(formationRequest, complianceRequirements);

  return NextResponse.json({
    success: true,
    compliance: {
      totalRequirements: complianceRequirements.length,
      automatedRequirements: complianceRequirements.filter(r => r.automated).length,
      manualRequirements: complianceRequirements.filter(r => !r.automated).length,
    },
    schedule: complianceSchedule,
    monitoring: {
      systemId: monitoringSystem.id,
      automationLevel: monitoringSystem.automationLevel,
      coveragePercentage: monitoringSystem.coveragePercentage,
    },
    calendar: complianceCalendar,
    notifications: {
      scheduleId: notificationSchedule.id,
      notificationCount: notificationSchedule.notifications.length,
    },
    nextSteps: [
      'Review compliance calendar',
      'Configure notification preferences',
      'Setup automated payment methods',
      'Begin compliance monitoring',
    ],
  });
}

async function obtainEIN(body: any) {
  const { formationRequestId, einApplicationData } = body;

  const formationRequest = await prisma.businessFormationRequest.findUnique({
    where: { id: formationRequestId },
    include: { client: true }
  });

  if (!formationRequest) {
    return NextResponse.json({ error: 'Formation request not found' }, { status: 404 });
  }

  // Prepare EIN application
  const einApplication = await prepareEINApplication(formationRequest, einApplicationData);

  // Submit EIN application to IRS
  const einResult = await submitEINApplication(einApplication);

  // Update formation request with EIN
  await prisma.businessFormationRequest.update({
    where: { id: formationRequestId },
    data: {
      einNumber: einResult.ein,
      formationData: {
        ...formationRequest.formationData,
        einObtained: true,
        einObtainedAt: new Date().toISOString(),
        einApplicationId: einResult.applicationId,
      }
    }
  });

  // Setup tax account and compliance
  const taxAccountSetup = await setupBusinessTaxAccount(formationRequest, einResult.ein);

  // Generate tax compliance schedule
  const taxComplianceSchedule = await generateTaxComplianceSchedule(formationRequest, einResult.ein);

  return NextResponse.json({
    success: true,
    ein: {
      number: einResult.ein,
      applicationId: einResult.applicationId,
      issuedDate: new Date().toISOString(),
    },
    taxAccount: {
      setupComplete: taxAccountSetup.complete,
      accountId: taxAccountSetup.accountId,
      initialFilingRequirements: taxAccountSetup.filingRequirements,
    },
    taxCompliance: {
      scheduleId: taxComplianceSchedule.id,
      upcomingDeadlines: taxComplianceSchedule.upcomingDeadlines,
      automatedFilings: taxComplianceSchedule.automatedFilings,
    },
    nextSteps: [
      'Setup business banking with EIN',
      'Configure payroll if needed',
      'Setup tax compliance monitoring',
      'Begin business operations',
    ],
  });
}

async function setupBusinessBanking(body: any) {
  const { formationRequestId, bankingPreferences } = body;

  const formationRequest = await prisma.businessFormationRequest.findUnique({
    where: { id: formationRequestId },
    include: { client: true }
  });

  if (!formationRequest) {
    return NextResponse.json({ error: 'Formation request not found' }, { status: 404 });
  }

  if (!formationRequest.einNumber) {
    return NextResponse.json({ error: 'EIN required for business banking setup' }, { status: 400 });
  }

  // Find optimal banking partners
  const bankingOptions = await findOptimalBankingPartners(formationRequest, bankingPreferences);

  // Prepare banking application packages
  const applicationPackages = await prepareBankingApplications(formationRequest, bankingOptions);

  // Submit applications to selected banks
  const applicationResults = await submitBankingApplications(applicationPackages);

  // Setup banking integration and monitoring
  const bankingIntegration = await setupBankingIntegration(formationRequest, applicationResults);

  return NextResponse.json({
    success: true,
    banking: {
      optionsEvaluated: bankingOptions.length,
      applicationsSubmitted: applicationResults.length,
      approvedApplications: applicationResults.filter(r => r.status === 'approved').length,
    },
    recommendations: bankingOptions.slice(0, 3).map(option => ({
      bank: option.bankName,
      accountType: option.recommendedAccount,
      benefits: option.keyBenefits,
      fees: option.feeStructure,
    })),
    integration: {
      setupComplete: bankingIntegration.complete,
      connectedAccounts: bankingIntegration.connectedAccounts,
      automatedFeatures: bankingIntegration.automatedFeatures,
    },
    nextSteps: [
      'Complete banking account setup',
      'Configure automated bookkeeping',
      'Setup payment processing',
      'Begin business operations',
    ],
  });
}

// Helper functions for business formation automation
async function checkNameAvailabilityInState(businessName: string, state: string): Promise<any> {
  // This would integrate with state business registration APIs
  // For now, implementing a simplified check
  
  const unavailableNames = ['Test Corp', 'Sample LLC', 'Demo Inc'];
  const available = !unavailableNames.includes(businessName);
  
  return {
    available,
    reason: available ? null : 'Name already in use',
    suggestions: available ? [] : await generateAlternativeBusinessNames(businessName, 'LLC'),
  };
}

async function generateAlternativeBusinessNames(originalName: string, entityType: string): Promise<string[]> {
  const alternatives = [];
  const baseName = originalName.replace(/\s+(LLC|Corp|Inc|Co)$/i, '');
  
  // Generate variations
  alternatives.push(`${baseName} ${entityType}`);
  alternatives.push(`${baseName} Group ${entityType}`);
  alternatives.push(`${baseName} Solutions ${entityType}`);
  alternatives.push(`${baseName} Enterprises ${entityType}`);
  alternatives.push(`${baseName} Holdings ${entityType}`);
  
  return alternatives.slice(0, 5);
}

async function checkTrademarkConflicts(businessName: string): Promise<any> {
  // This would integrate with USPTO TESS database
  return {
    conflictsFound: false,
    similarMarks: [],
    riskLevel: 'low',
    recommendation: 'Proceed with name selection',
  };
}

async function checkDomainAvailability(businessName: string): Promise<any> {
  const domainName = businessName.toLowerCase().replace(/\s+/g, '').replace(/[^a-z0-9]/g, '');
  
  return {
    primaryDomain: `${domainName}.com`,
    available: true, // Simplified check
    alternatives: [
      `${domainName}.net`,
      `${domainName}.org`,
      `${domainName}llc.com`,
    ],
  };
}

function generateNameRecommendations(availability: any, trademarkCheck: any, domainAvailability: any): string[] {
  const recommendations = [];
  
  if (availability.available && !trademarkCheck.conflictsFound && domainAvailability.available) {
    recommendations.push('Excellent choice - name is available across all channels');
  }
  
  if (!availability.available) {
    recommendations.push('Consider alternative names provided');
  }
  
  if (trademarkCheck.conflictsFound) {
    recommendations.push('Review trademark conflicts before proceeding');
  }
  
  if (!domainAvailability.available) {
    recommendations.push('Consider alternative domain names for online presence');
  }
  
  return recommendations;
}

function generateFormationTimeline(entityType: string, state: string, expedited: boolean): any {
  const baseTimeline = {
    'LLC': { standard: 14, expedited: 3 },
    'Corporation': { standard: 21, expedited: 5 },
    'S-Corp': { standard: 28, expedited: 7 },
    'Partnership': { standard: 10, expedited: 2 },
  };
  
  const days = expedited ? 
    baseTimeline[entityType]?.expedited || 5 : 
    baseTimeline[entityType]?.standard || 14;
  
  const milestones = [
    { name: 'Document Generation', days: 1 },
    { name: 'Client Review & Approval', days: 2 },
    { name: 'State Filing Submission', days: 3 },
    { name: 'State Processing', days: days - 5 },
    { name: 'Approval & Certificate', days: days - 1 },
    { name: 'EIN Application', days: days + 1 },
    { name: 'Banking Setup', days: days + 7 },
  ];
  
  return {
    totalDays: days + 7,
    expedited,
    milestones,
    estimatedCompletion: new Date(Date.now() + (days + 7) * 24 * 60 * 60 * 1000),
  };
}

async function setupAutomatedComplianceSchedule(formationRequestId: string, entityType: string, state: string): Promise<any> {
  const complianceItems = generateComplianceItems(entityType, state);
  
  return {
    scheduleId: `compliance_${formationRequestId}`,
    totalItems: complianceItems.length,
    automatedItems: complianceItems.filter(item => item.automated).length,
    items: complianceItems,
  };
}

function generateComplianceItems(entityType: string, state: string): any[] {
  const items = [];
  
  // Annual report
  items.push({
    type: 'annual_report',
    description: `${entityType} Annual Report filing`,
    frequency: 'annual',
    dueDate: `${new Date().getFullYear() + 1}-03-15`,
    automated: true,
    fee: 50,
  });
  
  // Franchise tax
  if (['Corporation', 'LLC'].includes(entityType)) {
    items.push({
      type: 'franchise_tax',
      description: 'State franchise tax payment',
      frequency: 'annual',
      dueDate: `${new Date().getFullYear() + 1}-04-15`,
      automated: true,
      fee: 100,
    });
  }
  
  // Registered agent
  items.push({
    type: 'registered_agent',
    description: 'Registered agent service renewal',
    frequency: 'annual',
    dueDate: `${new Date().getFullYear() + 1}-01-01`,
    automated: true,
    fee: 199,
  });
  
  return items;
}

function generateRequiredDocumentsList(entityType: string, state: string, formationData: any): any[] {
  const documents = [];
  
  switch (entityType) {
    case 'LLC':
      documents.push(
        { type: 'articles_of_organization', required: true },
        { type: 'operating_agreement', required: false },
        { type: 'ein_application', required: true },
        { type: 'registered_agent_consent', required: true }
      );
      break;
    case 'Corporation':
      documents.push(
        { type: 'articles_of_incorporation', required: true },
        { type: 'corporate_bylaws', required: true },
        { type: 'board_resolutions', required: true },
        { type: 'stock_certificates', required: true },
        { type: 'ein_application', required: true }
      );
      break;
    case 'S-Corp':
      documents.push(
        { type: 'articles_of_incorporation', required: true },
        { type: 'corporate_bylaws', required: true },
        { type: 's_corp_election', required: true },
        { type: 'board_resolutions', required: true },
        { type: 'stock_certificates', required: true },
        { type: 'ein_application', required: true }
      );
      break;
  }
  
  return documents;
}

function calculateFormationCosts(entityType: string, state: string, expedited: boolean, automatedCompliance: boolean): any {
  const baseCosts = {
    'LLC': { state: 100, legal: 500 },
    'Corporation': { state: 150, legal: 750 },
    'S-Corp': { state: 150, legal: 900 },
    'Partnership': { state: 50, legal: 400 },
  };
  
  const costs = baseCosts[entityType] || { state: 100, legal: 500 };
  
  const breakdown = {
    stateFiling: costs.state,
    legalDocuments: costs.legal,
    registeredAgent: 199,
    expeditedProcessing: expedited ? 200 : 0,
    automatedCompliance: automatedCompliance ? 299 : 0,
    einApplication: 0, // Free through IRS
  };
  
  breakdown.total = Object.values(breakdown).reduce((sum, cost) => sum + cost, 0);
  
  return breakdown;
}

async function createFormationWorkflow(formationRequest: any, timeline: any): Promise<any> {
  const steps = [
    { name: 'Name Availability Check', status: 'completed', estimatedDays: 0 },
    { name: 'Document Generation', status: 'pending', estimatedDays: 1 },
    { name: 'Client Review', status: 'pending', estimatedDays: 2 },
    { name: 'State Filing', status: 'pending', estimatedDays: 3 },
    { name: 'EIN Application', status: 'pending', estimatedDays: timeline.totalDays - 5 },
    { name: 'Banking Setup', status: 'pending', estimatedDays: timeline.totalDays },
    { name: 'Compliance Setup', status: 'pending', estimatedDays: timeline.totalDays + 1 },
  ];
  
  return {
    id: `workflow_${formationRequest.id}`,
    steps,
    currentStep: 1,
    estimatedCompletion: timeline.estimatedCompletion,
  };
}

function generateFormationNextSteps(formationRequest: any, workflow: any): string[] {
  const nextSteps = [];
  
  const currentStep = workflow.steps.find(step => step.status === 'pending');
  if (currentStep) {
    nextSteps.push(`Complete: ${currentStep.name}`);
  }
  
  nextSteps.push('Review formation timeline and milestones');
  nextSteps.push('Prepare required documentation');
  nextSteps.push('Setup automated compliance monitoring');
  
  return nextSteps;
}

async function generateEntityDocuments(formationRequest: any): Promise<any[]> {
  const documents = [];
  
  switch (formationRequest.entityType) {
    case 'LLC':
      documents.push({
        type: 'articles_of_organization',
        filename: `${formationRequest.businessName}_Articles_of_Organization.pdf`,
        content: generateArticlesOfOrganization(formationRequest),
      });
      break;
    case 'Corporation':
    case 'S-Corp':
      documents.push({
        type: 'articles_of_incorporation',
        filename: `${formationRequest.businessName}_Articles_of_Incorporation.pdf`,
        content: generateArticlesOfIncorporation(formationRequest),
      });
      break;
  }
  
  return documents;
}

async function generateGovernanceDocuments(formationRequest: any): Promise<any[]> {
  const documents = [];
  
  switch (formationRequest.entityType) {
    case 'LLC':
      documents.push({
        type: 'operating_agreement',
        filename: `${formationRequest.businessName}_Operating_Agreement.pdf`,
        content: generateOperatingAgreement(formationRequest),
      });
      break;
    case 'Corporation':
    case 'S-Corp':
      documents.push({
        type: 'corporate_bylaws',
        filename: `${formationRequest.businessName}_Bylaws.pdf`,
        content: generateCorporateBylaws(formationRequest),
      });
      break;
  }
  
  return documents;
}

async function generateTaxElectionDocuments(formationRequest: any): Promise<any[]> {
  const documents = [];
  
  if (formationRequest.entityType === 'S-Corp') {
    documents.push({
      type: 's_corp_election',
      filename: `${formationRequest.businessName}_Form_2553.pdf`,
      content: generateSCorpElection(formationRequest),
    });
  }
  
  return documents;
}

async function generateInitialComplianceDocuments(formationRequest: any): Promise<any[]> {
  return [
    {
      type: 'compliance_checklist',
      filename: `${formationRequest.businessName}_Compliance_Checklist.pdf`,
      content: generateComplianceChecklist(formationRequest),
    },
    {
      type: 'registered_agent_agreement',
      filename: `${formationRequest.businessName}_Registered_Agent_Agreement.pdf`,
      content: generateRegisteredAgentAgreement(formationRequest),
    },
  ];
}

async function saveGeneratedDocuments(formationRequest: any, documents: any[]): Promise<any[]> {
  const savedDocuments = [];
  
  for (const doc of documents) {
    const savedDoc = await prisma.document.create({
      data: {
        tenantId: formationRequest.tenantId,
        clientId: formationRequest.clientId,
        uploadedByUserId: 'system', // System-generated
        documentType: doc.type,
        filename: doc.filename,
        s3Key: `formation_documents/${formationRequest.id}/${doc.filename}`,
        s3Bucket: 'lawson-tax-documents',
        fileSize: doc.content.length,
        mimeType: 'application/pdf',
        status: 'generated',
        extractedData: {
          generatedForFormation: true,
          formationRequestId: formationRequest.id,
          entityType: formationRequest.entityType,
        }
      }
    });
    savedDocuments.push(savedDoc);
  }
  
  return savedDocuments;
}

// Document generation functions (simplified implementations)
function generateArticlesOfOrganization(formationRequest: any): string {
  return `ARTICLES OF ORGANIZATION FOR ${formationRequest.businessName}
  
State of Formation: ${formationRequest.stateOfFormation}
Business Purpose: ${formationRequest.businessPurpose}
Registered Agent: [To be filled]
Management Structure: Member-managed
  
[Generated document content would be much more comprehensive]`;
}

function generateArticlesOfIncorporation(formationRequest: any): string {
  return `ARTICLES OF INCORPORATION FOR ${formationRequest.businessName}
  
State of Incorporation: ${formationRequest.stateOfFormation}
Business Purpose: ${formationRequest.businessPurpose}
Authorized Shares: 1,000 shares of common stock
Registered Agent: [To be filled]
  
[Generated document content would be much more comprehensive]`;
}

function generateOperatingAgreement(formationRequest: any): string {
  return `OPERATING AGREEMENT FOR ${formationRequest.businessName}
  
This Operating Agreement governs the operations of the LLC...
  
[Generated document content would be much more comprehensive]`;
}

function generateCorporateBylaws(formationRequest: any): string {
  return `BYLAWS OF ${formationRequest.businessName}
  
These Bylaws govern the internal operations of the Corporation...
  
[Generated document content would be much more comprehensive]`;
}

function generateSCorpElection(formationRequest: any): string {
  return `FORM 2553 - ELECTION BY A SMALL BUSINESS CORPORATION
  
Corporation Name: ${formationRequest.businessName}
EIN: [To be obtained]
Election Effective Date: [Formation date]
  
[Generated form would include all required IRS fields]`;
}

function generateComplianceChecklist(formationRequest: any): string {
  return `COMPLIANCE CHECKLIST FOR ${formationRequest.businessName}
  
Entity Type: ${formationRequest.entityType}
State: ${formationRequest.stateOfFormation}
  
Required Compliance Items:
- Annual Report Filing
- Franchise Tax Payment
- Registered Agent Maintenance
- Tax Return Filing
  
[Detailed compliance requirements would be listed]`;
}

function generateRegisteredAgentAgreement(formationRequest: any): string {
  return `REGISTERED AGENT AGREEMENT FOR ${formationRequest.businessName}
  
This agreement establishes registered agent services...
  
[Complete registered agent agreement terms]`;
}

// Additional helper functions for filing and compliance
async function submitToStateFilingSystem(formationRequest: any, expedited: boolean): Promise<any> {
  // This would integrate with state filing systems
  return {
    confirmationNumber: `CONF-${Date.now()}`,
    filingDate: new Date(),
    estimatedApprovalDate: new Date(Date.now() + (expedited ? 3 : 14) * 24 * 60 * 60 * 1000),
    filingFee: expedited ? 300 : 100,
  };
}

async function setupFilingStatusMonitoring(formationRequest: any, filingResult: any): Promise<any> {
  return {
    trackingId: `TRACK-${formationRequest.id}`,
    frequency: 'daily',
    notifications: ['email', 'in_app'],
    estimatedCompletion: filingResult.estimatedApprovalDate,
  };
}

async function schedulePostFilingTasks(formationRequest: any): Promise<any[]> {
  return [
    {
      task: 'EIN Application',
      scheduledDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
      automated: true,
    },
    {
      task: 'Banking Setup',
      scheduledDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      automated: false,
    },
    {
      task: 'Compliance Monitoring Setup',
      scheduledDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      automated: true,
    },
  ];
}

async function generateComprehensiveComplianceSchedule(formationRequest: any, preferences: any): Promise<any[]> {
  const schedule = [];
  const currentYear = new Date().getFullYear();
  
  // Annual requirements
  schedule.push({
    type: 'annual_report',
    description: 'Annual Report Filing',
    dueDate: `${currentYear + 1}-03-15`,
    frequency: 'annual',
    automated: true,
    estimatedCost: 50,
  });
  
  // Tax filings
  schedule.push({
    type: 'tax_filing',
    description: 'Business Tax Return Filing',
    dueDate: `${currentYear + 1}-03-15`,
    frequency: 'annual',
    automated: preferences?.automatedTaxFiling || false,
    estimatedCost: 0,
  });
  
  // Franchise tax
  if (['Corporation', 'LLC'].includes(formationRequest.entityType)) {
    schedule.push({
      type: 'franchise_tax',
      description: 'State Franchise Tax Payment',
      dueDate: `${currentYear + 1}-04-15`,
      frequency: 'annual',
      automated: true,
      estimatedCost: 100,
    });
  }
  
  return schedule;
}

async function setupComplianceMonitoring(formationRequest: any, requirements: any[]): Promise<any> {
  const automatedCount = requirements.filter(r => r.automated).length;
  const totalCount = requirements.length;
  
  return {
    id: `monitoring_${formationRequest.id}`,
    automationLevel: automatedCount / totalCount,
    coveragePercentage: (automatedCount / totalCount) * 100,
    monitoringFrequency: 'weekly',
    alertThresholds: {
      upcoming: 30, // days
      overdue: 1, // days
    },
  };
}

function generateComplianceCalendar(requirements: any[]): any {
  const calendar = {};
  
  for (const req of requirements) {
    const month = new Date(req.dueDate).getMonth() + 1;
    const monthKey = `${new Date(req.dueDate).getFullYear()}-${month.toString().padStart(2, '0')}`;
    
    if (!calendar[monthKey]) {
      calendar[monthKey] = [];
    }
    
    calendar[monthKey].push({
      type: req.requirementType,
      description: req.description,
      dueDate: req.dueDate,
      automated: req.automated,
    });
  }
  
  return calendar;
}

async function setupComplianceNotifications(formationRequest: any, requirements: any[]): Promise<any> {
  const notifications = [];
  
  for (const req of requirements) {
    // 30-day advance notice
    notifications.push({
      type: 'advance_notice',
      requirementId: req.id,
      scheduledDate: new Date(new Date(req.dueDate).getTime() - 30 * 24 * 60 * 60 * 1000),
      channel: 'email',
    });
    
    // 7-day reminder
    notifications.push({
      type: 'reminder',
      requirementId: req.id,
      scheduledDate: new Date(new Date(req.dueDate).getTime() - 7 * 24 * 60 * 60 * 1000),
      channel: 'email',
    });
  }
  
  return {
    id: `notifications_${formationRequest.id}`,
    notifications,
  };
}

// EIN and tax setup functions
async function prepareEINApplication(formationRequest: any, applicationData: any): Promise<any> {
  return {
    businessName: formationRequest.businessName,
    entityType: formationRequest.entityType,
    stateOfFormation: formationRequest.stateOfFormation,
    businessPurpose: formationRequest.businessPurpose,
    responsibleParty: applicationData.responsibleParty,
    businessAddress: applicationData.businessAddress,
    mailingAddress: applicationData.mailingAddress,
    startDate: applicationData.startDate || new Date(),
  };
}

async function submitEINApplication(application: any): Promise<any> {
  // This would integrate with IRS EIN application system
  return {
    ein: `12-${Math.floor(Math.random() * 9000000) + 1000000}`,
    applicationId: `EIN-${Date.now()}`,
    issuedDate: new Date(),
    status: 'approved',
  };
}

async function setupBusinessTaxAccount(formationRequest: any, ein: string): Promise<any> {
  return {
    complete: true,
    accountId: `TAX-${ein}`,
    filingRequirements: [
      'Annual business tax return',
      'Quarterly estimated payments (if applicable)',
      'Employment tax returns (if applicable)',
    ],
  };
}

async function generateTaxComplianceSchedule(formationRequest: any, ein: string): Promise<any> {
  const upcomingDeadlines = [];
  const currentYear = new Date().getFullYear();
  
  // Business tax return
  upcomingDeadlines.push({
    type: 'business_tax_return',
    description: `${formationRequest.entityType} Tax Return`,
    dueDate: `${currentYear + 1}-03-15`,
    form: formationRequest.entityType === 'Corporation' ? '1120' : '1065',
  });
  
  return {
    id: `tax_compliance_${ein}`,
    upcomingDeadlines,
    automatedFilings: ['Quarterly estimates', 'Annual returns'],
  };
}

// Banking setup functions
async function findOptimalBankingPartners(formationRequest: any, preferences: any): Promise<any[]> {
  // This would integrate with banking partner APIs
  return [
    {
      bankName: 'Business Bank Pro',
      recommendedAccount: 'Business Checking Plus',
      keyBenefits: ['No monthly fees', 'Free transactions', 'Online banking'],
      feeStructure: { monthly: 0, transactions: 0, overdraft: 35 },
      rating: 4.5,
    },
    {
      bankName: 'Enterprise Banking Solutions',
      recommendedAccount: 'Small Business Account',
      keyBenefits: ['Cash management', 'Credit line available', 'Merchant services'],
      feeStructure: { monthly: 15, transactions: 0.50, overdraft: 30 },
      rating: 4.2,
    },
  ];
}

async function prepareBankingApplications(formationRequest: any, bankingOptions: any[]): Promise<any[]> {
  return bankingOptions.map(option => ({
    bank: option.bankName,
    accountType: option.recommendedAccount,
    applicationData: {
      businessName: formationRequest.businessName,
      ein: formationRequest.einNumber,
      entityType: formationRequest.entityType,
      stateOfFormation: formationRequest.stateOfFormation,
    },
  }));
}

async function submitBankingApplications(applications: any[]): Promise<any[]> {
  return applications.map(app => ({
    bank: app.bank,
    applicationId: `BANK-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    status: 'approved', // Simplified for demo
    accountNumber: `****${Math.floor(Math.random() * 9000) + 1000}`,
  }));
}

async function setupBankingIntegration(formationRequest: any, applicationResults: any[]): Promise<any> {
  const approvedAccounts = applicationResults.filter(r => r.status === 'approved');
  
  return {
    complete: true,
    connectedAccounts: approvedAccounts.length,
    automatedFeatures: [
      'Transaction categorization',
      'Expense tracking',
      'Tax document preparation',
      'Compliance monitoring',
    ],
  };
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get('tenantId');
    const clientId = searchParams.get('clientId');
    const status = searchParams.get('status');

    if (!tenantId) {
      return NextResponse.json({ error: 'tenantId required' }, { status: 400 });
    }

    let whereClause: any = { tenantId };
    
    if (clientId) whereClause.clientId = clientId;
    if (status) whereClause.status = status;

    const formationRequests = await prisma.businessFormationRequest.findMany({
      where: whereClause,
      include: {
        client: {
          select: { firstName: true, lastName: true, email: true }
        },
        complianceRequirements: true,
      },
      orderBy: { createdAt: 'desc' }
    });

    const summary = {
      total: formationRequests.length,
      initiated: formationRequests.filter(r => r.status === 'initiated').length,
      filed: formationRequests.filter(r => r.status === 'filed').length,
      completed: formationRequests.filter(r => r.status === 'completed').length,
      entityTypes: {
        LLC: formationRequests.filter(r => r.entityType === 'LLC').length,
        Corporation: formationRequests.filter(r => r.entityType === 'Corporation').length,
        'S-Corp': formationRequests.filter(r => r.entityType === 'S-Corp').length,
        Partnership: formationRequests.filter(r => r.entityType === 'Partnership').length,
      },
      totalComplianceRequirements: formationRequests.reduce((sum, r) => sum + r.complianceRequirements.length, 0),
    };

    return NextResponse.json({
      formationRequests,
      summary,
    });

  } catch (error) {
    console.error('Get Business Formation Requests Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve formation requests' },
      { status: 500 }
    );
  }
}
