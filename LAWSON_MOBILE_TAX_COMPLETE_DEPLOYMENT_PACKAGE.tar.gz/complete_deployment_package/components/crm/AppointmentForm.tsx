
'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';

interface AppointmentFormProps {
  leadId?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export function AppointmentForm({ leadId, onSuccess, onCancel }: AppointmentFormProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startTime: '',
    endTime: '',
    location: '',
    meetingType: 'IN_PERSON',
    meetingUrl: '',
    reminderMinutes: 15,
    syncToGoHighLevel: true,
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        leadId,
        startTime: formData.startTime,
        endTime: formData.endTime,
      };

      const response = await fetch('/api/crm/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: 'Appointment Scheduled',
          description: 'Appointment has been scheduled successfully.',
        });
        onSuccess();
      } else {
        throw new Error(data.error || 'Failed to schedule appointment');
      }
    } catch (error) {
      console.error('Error scheduling appointment:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to schedule appointment',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Title *</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => handleInputChange('title', e.target.value)}
          required
        />
      </div>
      
      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
          rows={3}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="startTime">Start Time *</Label>
          <Input
            id="startTime"
            type="datetime-local"
            value={formData.startTime}
            onChange={(e) => handleInputChange('startTime', e.target.value)}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="endTime">End Time *</Label>
          <Input
            id="endTime"
            type="datetime-local"
            value={formData.endTime}
            onChange={(e) => handleInputChange('endTime', e.target.value)}
            required
          />
        </div>
      </div>
      
      <div>
        <Label htmlFor="meetingType">Meeting Type</Label>
        <Select value={formData.meetingType} onValueChange={(value) => handleInputChange('meetingType', value)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="IN_PERSON">In Person</SelectItem>
            <SelectItem value="PHONE">Phone Call</SelectItem>
            <SelectItem value="VIDEO">Video Call</SelectItem>
            <SelectItem value="ONLINE">Online Meeting</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {formData.meetingType === 'IN_PERSON' ? (
        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => handleInputChange('location', e.target.value)}
            placeholder="Enter meeting location"
          />
        </div>
      ) : (
        <div>
          <Label htmlFor="meetingUrl">Meeting URL</Label>
          <Input
            id="meetingUrl"
            type="url"
            value={formData.meetingUrl}
            onChange={(e) => handleInputChange('meetingUrl', e.target.value)}
            placeholder="Enter meeting URL (Zoom, Teams, etc.)"
          />
        </div>
      )}
      
      <div>
        <Label htmlFor="reminderMinutes">Reminder (minutes before)</Label>
        <Select 
          value={formData.reminderMinutes.toString()} 
          onValueChange={(value) => handleInputChange('reminderMinutes', parseInt(value))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0">No reminder</SelectItem>
            <SelectItem value="5">5 minutes</SelectItem>
            <SelectItem value="15">15 minutes</SelectItem>
            <SelectItem value="30">30 minutes</SelectItem>
            <SelectItem value="60">1 hour</SelectItem>
            <SelectItem value="1440">1 day</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex items-center space-x-2">
        <Switch
          id="syncToGoHighLevel"
          checked={formData.syncToGoHighLevel}
          onCheckedChange={(checked) => handleInputChange('syncToGoHighLevel', checked)}
        />
        <Label htmlFor="syncToGoHighLevel">Sync to GoHighLevel</Label>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Scheduling...' : 'Schedule Appointment'}
        </Button>
      </div>
    </form>
  );
}
