
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Star, Video, Image as ImageIcon, Plus, Edit, Trash2, 
  Eye, Share2, TrendingUp, Users, MessageSquare, Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import { Testimonial } from '@/lib/types/client-acquisition';

interface TestimonialManagerProps {
  testimonials: Testimonial[];
  onCreateTestimonial: (testimonial: Partial<Testimonial>) => void;
  onUpdateTestimonial: (id: string, updates: Partial<Testimonial>) => void;
  onDeleteTestimonial: (id: string) => void;
}

const TESTIMONIAL_CATEGORIES = [
  { value: 'general', label: 'General Experience' },
  { value: 'refund', label: 'Refund Success' },
  { value: 'support', label: 'Customer Support' },
  { value: 'ease_of_use', label: 'Ease of Use' },
  { value: 'business', label: 'Business Taxes' },
  { value: 'complex', label: 'Complex Returns' },
  { value: 'speed', label: 'Fast Processing' },
  { value: 'accuracy', label: 'Accuracy' }
];

const PERSONA_TYPES = [
  { value: 'w2_employee', label: 'W-2 Employee' },
  { value: 'small_business', label: 'Small Business Owner' },
  { value: 'investor', label: 'Investor' },
  { value: 'retiree', label: 'Retiree' },
  { value: 'freelancer', label: 'Freelancer' }
];

export default function TestimonialManager({ 
  testimonials, 
  onCreateTestimonial, 
  onUpdateTestimonial, 
  onDeleteTestimonial 
}: TestimonialManagerProps) {
  const [selectedTestimonial, setSelectedTestimonial] = useState<Testimonial | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    clientName: '',
    clientTitle: '',
    content: '',
    rating: 5,
    videoUrl: '',
    imageUrl: '',
    tags: [] as string[],
    category: 'general'
  });
  const [filterCategory, setFilterCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  const filteredTestimonials = testimonials.filter(testimonial => {
    const matchesCategory = filterCategory === 'all' || testimonial.tags.includes(filterCategory);
    const matchesSearch = testimonial.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         testimonial.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const testimonialData = {
      ...formData,
      id: selectedTestimonial?.id || `testimonial-${Date.now()}`,
      isVerified: true,
      createdAt: new Date()
    };

    if (selectedTestimonial) {
      onUpdateTestimonial(selectedTestimonial.id, testimonialData);
    } else {
      onCreateTestimonial(testimonialData);
    }

    confettiReward();
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      clientName: '',
      clientTitle: '',
      content: '',
      rating: 5,
      videoUrl: '',
      imageUrl: '',
      tags: [],
      category: 'general'
    });
    setSelectedTestimonial(null);
    setIsCreating(false);
  };

  const handleEdit = (testimonial: Testimonial) => {
    setSelectedTestimonial(testimonial);
    setFormData({
      clientName: testimonial.clientName,
      clientTitle: testimonial.clientTitle || '',
      content: testimonial.content,
      rating: testimonial.rating,
      videoUrl: testimonial.videoUrl || '',
      imageUrl: testimonial.imageUrl || '',
      tags: testimonial.tags,
      category: testimonial.tags[0] || 'general'
    });
    setIsCreating(true);
  };

  const generateTestimonialPreview = (testimonial: Testimonial) => {
    return (
      <div className="bg-white border rounded-lg p-6 shadow-sm">
        <div className="flex items-start space-x-4">
          {testimonial.imageUrl && (
            <img
              src={testimonial.imageUrl}
              alt={testimonial.clientName}
              className="w-12 h-12 rounded-full object-cover"
            />
          )}
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < testimonial.rating
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              {testimonial.isVerified && (
                <Badge variant="secondary" className="text-xs">
                  Verified
                </Badge>
              )}
            </div>
            <blockquote className="text-gray-700 mb-3 italic">
              "{testimonial.content}"
            </blockquote>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900">{testimonial.clientName}</p>
                {testimonial.clientTitle && (
                  <p className="text-sm text-gray-600">{testimonial.clientTitle}</p>
                )}
              </div>
              {testimonial.videoUrl && (
                <Button size="sm" variant="outline">
                  <Video className="w-4 h-4 mr-2" />
                  Watch Video
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const getAverageRating = () => {
    if (testimonials.length === 0) return 0;
    const sum = testimonials.reduce((acc, t) => acc + t.rating, 0);
    return (sum / testimonials.length).toFixed(1);
  };

  const getTopCategories = () => {
    const categoryCount: Record<string, number> = {};
    testimonials.forEach(t => {
      t.tags.forEach(tag => {
        categoryCount[tag] = (categoryCount[tag] || 0) + 1;
      });
    });
    return Object.entries(categoryCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Testimonial Manager</h2>
          <p className="text-gray-600 mt-2">
            Manage and showcase client testimonials and success stories
          </p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Testimonial
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Testimonials</p>
                <p className="text-2xl font-bold text-gray-900">{testimonials.length}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Average Rating</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold text-gray-900">{getAverageRating()}</p>
                  <Star className="w-5 h-5 text-yellow-400 fill-current" />
                </div>
              </div>
              <Award className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Video Testimonials</p>
                <p className="text-2xl font-bold text-gray-900">
                  {testimonials.filter(t => t.videoUrl).length}
                </p>
              </div>
              <Video className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Verified</p>
                <p className="text-2xl font-bold text-gray-900">
                  {testimonials.filter(t => t.isVerified).length}
                </p>
              </div>
              <Users className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input
            placeholder="Search testimonials..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {TESTIMONIAL_CATEGORIES.map(category => (
              <SelectItem key={category.value} value={category.value}>
                {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Testimonials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTestimonials.map((testimonial) => (
          <motion.div
            key={testimonial.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group"
          >
            <Card className="h-full hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < testimonial.rating
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    {testimonial.isVerified && (
                      <Badge variant="secondary" className="text-xs">
                        Verified
                      </Badge>
                    )}
                  </div>
                  <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(testimonial)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onDeleteTestimonial(testimonial.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <blockquote className="text-gray-700 text-sm italic line-clamp-4">
                  "{testimonial.content}"
                </blockquote>
                
                <div className="flex items-center space-x-3">
                  {testimonial.imageUrl && (
                    <img
                      src={testimonial.imageUrl}
                      alt={testimonial.clientName}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 truncate">
                      {testimonial.clientName}
                    </p>
                    {testimonial.clientTitle && (
                      <p className="text-sm text-gray-600 truncate">
                        {testimonial.clientTitle}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap gap-1">
                  {testimonial.tags.slice(0, 3).map(tag => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag.replace('_', ' ')}
                    </Badge>
                  ))}
                  {testimonial.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{testimonial.tags.length - 3}
                    </Badge>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex space-x-2">
                    {testimonial.videoUrl && (
                      <Badge variant="secondary" className="text-xs">
                        <Video className="w-3 h-3 mr-1" />
                        Video
                      </Badge>
                    )}
                    {testimonial.imageUrl && (
                      <Badge variant="secondary" className="text-xs">
                        <ImageIcon className="w-3 h-3 mr-1" />
                        Photo
                      </Badge>
                    )}
                  </div>
                  <Button size="sm" variant="outline">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Create/Edit Modal */}
      <AnimatePresence>
        {isCreating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => resetForm()}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-semibold">
                    {selectedTestimonial ? 'Edit Testimonial' : 'Add New Testimonial'}
                  </h3>
                  <Button variant="ghost" size="sm" onClick={resetForm}>
                    ✕
                  </Button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Client Name *
                      </label>
                      <Input
                        value={formData.clientName}
                        onChange={(e) => setFormData({...formData, clientName: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Client Title
                      </label>
                      <Input
                        value={formData.clientTitle}
                        onChange={(e) => setFormData({...formData, clientTitle: e.target.value})}
                        placeholder="e.g., Small Business Owner"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Testimonial Content *
                    </label>
                    <Textarea
                      value={formData.content}
                      onChange={(e) => setFormData({...formData, content: e.target.value})}
                      rows={4}
                      required
                      placeholder="Share the client's experience..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Rating
                      </label>
                      <Select 
                        value={formData.rating.toString()} 
                        onValueChange={(value) => setFormData({...formData, rating: parseInt(value)})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[5, 4, 3, 2, 1].map(rating => (
                            <SelectItem key={rating} value={rating.toString()}>
                              <div className="flex items-center space-x-2">
                                <span>{rating}</span>
                                <div className="flex space-x-1">
                                  {[...Array(rating)].map((_, i) => (
                                    <Star key={i} className="w-3 h-3 text-yellow-400 fill-current" />
                                  ))}
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Category
                      </label>
                      <Select 
                        value={formData.category} 
                        onValueChange={(value) => setFormData({...formData, category: value, tags: [value]})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {TESTIMONIAL_CATEGORIES.map(category => (
                            <SelectItem key={category.value} value={category.value}>
                              {category.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Video URL
                      </label>
                      <Input
                        value={formData.videoUrl}
                        onChange={(e) => setFormData({...formData, videoUrl: e.target.value})}
                        placeholder="https://..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Image URL
                      </label>
                      <Input
                        value={formData.imageUrl}
                        onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                        placeholder="https://..."
                      />
                    </div>
                  </div>

                  {/* Preview */}
                  {formData.clientName && formData.content && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Preview
                      </label>
                      {generateTestimonialPreview({
                        id: 'preview',
                        clientName: formData.clientName,
                        clientTitle: formData.clientTitle,
                        content: formData.content,
                        rating: formData.rating,
                        videoUrl: formData.videoUrl,
                        imageUrl: formData.imageUrl,
                        tags: formData.tags,
                        isVerified: true,
                        createdAt: new Date()
                      })}
                    </div>
                  )}

                  <div className="flex justify-end space-x-3 pt-4">
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {selectedTestimonial ? 'Update' : 'Create'} Testimonial
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <span id="confetti" />
    </div>
  );
}
