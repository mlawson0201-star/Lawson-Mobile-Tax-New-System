
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { 
  FileText, 
  Upload, 
  Clock, 
  CheckCircle, 
  DollarSign,
  AlertCircle,
  Plus,
  Download,
  Eye
} from 'lucide-react';
import { MetricCard } from '@/components/ui/metric-card';
import { formatCurrency, getStatusColor } from '@/lib/utils';

export function ClientDashboard() {
  const { data: session } = useSession() || {};
  const [taxReturns, setTaxReturns] = useState<any[]>([]);
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading client data
    const timer = setTimeout(() => {
      setTaxReturns([
        {
          id: '1',
          taxYear: '2024',
          status: 'in_progress',
          totalFee: 199.99,
          refundAmount: 2500.00,
          createdAt: new Date('2024-02-15'),
          completedAt: null
        },
        {
          id: '2',
          taxYear: '2023',
          status: 'completed',
          totalFee: 149.99,
          refundAmount: 1800.00,
          createdAt: new Date('2023-03-01'),
          completedAt: new Date('2023-03-05')
        }
      ]);
      
      setDocuments([
        {
          id: '1',
          filename: 'W2_2024_TechCorp.pdf',
          documentType: 'w2',
          status: 'processed',
          uploadedAt: new Date('2024-02-15')
        },
        {
          id: '2',
          filename: '1099_INT_BankOfAmerica.pdf',
          documentType: '1099_int',
          status: 'processed',
          uploadedAt: new Date('2024-02-16')
        },
        {
          id: '3',
          filename: 'Receipt_Charitable_Donation.pdf',
          documentType: 'other',
          status: 'pending',
          uploadedAt: new Date('2024-02-18')
        }
      ]);
      
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in_progress':
        return <Clock className="h-4 w-4 text-blue-500" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-400" />;
    }
  };

  const currentYearReturn = taxReturns.find(r => r.taxYear === '2024');

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="h-8 bg-gray-200 rounded w-64 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-96 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="h-6 bg-gray-200 rounded w-32 mb-4 animate-pulse"></div>
              <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          Welcome back, {session?.user?.name?.split(' ')[0]}!
        </h1>
        <p className="mt-2 text-gray-600">
          Track your tax return progress and manage your documents
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <MetricCard
          title="Current Tax Year"
          value="2024"
          icon={FileText}
          description={`Status: ${currentYearReturn?.status || 'Not Started'}`}
        />
        <MetricCard
          title="Estimated Refund"
          value={currentYearReturn?.refundAmount ? formatCurrency(currentYearReturn.refundAmount) : 'TBD'}
          icon={DollarSign}
          description="Based on current information"
        />
        <MetricCard
          title="Documents"
          value={documents.length}
          icon={Upload}
          description={`${documents.filter(d => d.status === 'processed').length} processed`}
        />
      </div>

      {/* Current Return Status */}
      {currentYearReturn && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg p-6 mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                2024 Tax Return Progress
              </h2>
              <div className="flex items-center mb-4">
                {getStatusIcon(currentYearReturn.status)}
                <span className={`ml-2 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(currentYearReturn.status)}`}>
                  {currentYearReturn.status === 'in_progress' ? 'In Progress' : currentYearReturn.status}
                </span>
              </div>
              <p className="text-gray-600 mb-4">
                Your tax return is currently being prepared. We'll notify you when it's ready for review.
              </p>
              <div className="flex space-x-4">
                <Link
                  href="/dashboard/tax-returns/2024"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View Return
                </Link>
                <Link
                  href="/dashboard/documents"
                  className="bg-white text-blue-600 border border-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors inline-flex items-center"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Documents
                </Link>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-900">
                {formatCurrency(currentYearReturn.refundAmount)}
              </div>
              <div className="text-sm text-gray-500">Estimated Refund</div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      {!currentYearReturn && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Get Started with Your 2024 Tax Return</h2>
          <p className="text-gray-600 mb-6">
            Ready to file your 2024 taxes? Our AI-powered system will guide you through the process step by step.
          </p>
          <div className="flex space-x-4">
            <Link
              href="/dashboard/tax-returns/new"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Start New Return
            </Link>
            <Link
              href="/dashboard/documents"
              className="bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors inline-flex items-center"
            >
              <Upload className="h-5 w-5 mr-2" />
              Upload Documents
            </Link>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Documents */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Recent Documents</h2>
              <Link
                href="/dashboard/documents"
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                View All
              </Link>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {documents.slice(0, 3).map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center">
                    <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900 truncate max-w-[200px]">
                        {doc.filename}
                      </p>
                      <p className="text-xs text-gray-500">
                        {doc.uploadedAt.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(doc.status)}`}>
                      {doc.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {documents.length === 0 && (
              <div className="text-center py-8">
                <Upload className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No documents uploaded yet</p>
              </div>
            )}
          </div>
        </div>

        {/* Tax Return History */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Tax Return History</h2>
              <Link
                href="/dashboard/tax-returns"
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                View All
              </Link>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {taxReturns.map((taxReturn) => (
                <div key={taxReturn.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center">
                    <div className="h-10 w-10 bg-green-100 rounded-lg flex items-center justify-center">
                      {getStatusIcon(taxReturn.status)}
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">
                        {taxReturn.taxYear} Tax Return
                      </p>
                      <p className="text-xs text-gray-500">
                        {taxReturn.completedAt ? 
                          `Completed ${taxReturn.completedAt.toLocaleDateString()}` :
                          `Started ${taxReturn.createdAt.toLocaleDateString()}`
                        }
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      {formatCurrency(taxReturn.refundAmount)}
                    </p>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(taxReturn.status)}`}>
                      {taxReturn.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {taxReturns.length === 0 && (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No tax returns yet</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Help Section */}
      <div className="mt-8 bg-gradient-to-r from-purple-50 to-pink-100 rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Need Help?</h2>
        <p className="text-gray-600 mb-4">
          Our support team is here to help you with your tax preparation questions.
        </p>
        <div className="flex space-x-4">
          <Link
            href="/dashboard/support"
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Contact Support
          </Link>
          <Link
            href="/dashboard/faq"
            className="bg-white text-purple-600 border border-purple-600 px-4 py-2 rounded-lg hover:bg-purple-50 transition-colors"
          >
            View FAQ
          </Link>
        </div>
      </div>
    </div>
  );
}
