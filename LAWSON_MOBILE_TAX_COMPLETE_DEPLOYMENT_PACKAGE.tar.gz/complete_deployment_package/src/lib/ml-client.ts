
/**
 * ML Services Client for Lawson Mobile Tax Platform
 * Handles communication with ML microservices
 */

import { z } from 'zod';

// Schemas for ML service requests/responses
export const DeductionPredictionRequestSchema = z.object({
  tax_return_id: z.string(),
  client_data: z.record(z.any()),
  document_data: z.array(z.record(z.any())),
  historical_data: z.record(z.any()).optional(),
});

export const DeductionPredictionResponseSchema = z.object({
  predictions: z.record(z.any()),
  confidence_scores: z.record(z.number()),
  total_potential_savings: z.number(),
  processing_time: z.number(),
});

export const AuditRiskAssessmentRequestSchema = z.object({
  tax_return_id: z.string(),
  return_data: z.record(z.any()),
  client_profile: z.record(z.any()),
  historical_audits: z.array(z.record(z.any())).optional(),
});

export const AuditRiskAssessmentResponseSchema = z.object({
  overall_risk_score: z.number(),
  risk_category: z.string(),
  risk_factors: z.array(z.record(z.any())),
  prevention_recommendations: z.array(z.string()),
  monitoring_required: z.boolean(),
});

export const VoiceProcessingRequestSchema = z.object({
  audio_file_path: z.string(),
  processing_type: z.string(),
  context: z.record(z.any()).optional(),
});

export const VoiceProcessingResponseSchema = z.object({
  transcript: z.string(),
  extracted_data: z.record(z.any()),
  confidence_scores: z.record(z.number()),
  action_items: z.array(z.string()),
});

export const TaxOptimizationRequestSchema = z.object({
  client_id: z.string(),
  entity_structure: z.record(z.any()),
  financial_data: z.record(z.any()),
  goals: z.array(z.string()),
});

export const TaxOptimizationResponseSchema = z.object({
  strategies: z.array(z.record(z.any())),
  projected_savings: z.record(z.number()),
  implementation_timeline: z.record(z.string()),
  complexity_scores: z.record(z.number()),
});

// Type definitions
export type DeductionPredictionRequest = z.infer<typeof DeductionPredictionRequestSchema>;
export type DeductionPredictionResponse = z.infer<typeof DeductionPredictionResponseSchema>;
export type AuditRiskAssessmentRequest = z.infer<typeof AuditRiskAssessmentRequestSchema>;
export type AuditRiskAssessmentResponse = z.infer<typeof AuditRiskAssessmentResponseSchema>;
export type VoiceProcessingRequest = z.infer<typeof VoiceProcessingRequestSchema>;
export type VoiceProcessingResponse = z.infer<typeof VoiceProcessingResponseSchema>;
export type TaxOptimizationRequest = z.infer<typeof TaxOptimizationRequestSchema>;
export type TaxOptimizationResponse = z.infer<typeof TaxOptimizationResponseSchema>;

class MLClient {
  private baseUrl: string;
  private apiKey?: string;

  constructor(baseUrl: string = process.env.ML_SERVICE_URL || 'http://localhost:8001', apiKey?: string) {
    this.baseUrl = baseUrl;
    this.apiKey = apiKey;
  }

  private async makeRequest<T>(endpoint: string, data?: any, method: string = 'POST'): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.apiKey) {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }

    const config: RequestInit = {
      method,
      headers,
    };

    if (data && method !== 'GET') {
      config.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ML Service Error (${response.status}): ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`ML Client Error for ${endpoint}:`, error);
      throw error;
    }
  }

  /**
   * Predict potential tax deductions using advanced ML models
   */
  async predictDeductions(request: DeductionPredictionRequest): Promise<DeductionPredictionResponse> {
    const validatedRequest = DeductionPredictionRequestSchema.parse(request);
    const response = await this.makeRequest<DeductionPredictionResponse>('/predict-deductions', validatedRequest);
    return DeductionPredictionResponseSchema.parse(response);
  }

  /**
   * Assess audit risk using machine learning models
   */
  async assessAuditRisk(request: AuditRiskAssessmentRequest): Promise<AuditRiskAssessmentResponse> {
    const validatedRequest = AuditRiskAssessmentRequestSchema.parse(request);
    const response = await this.makeRequest<AuditRiskAssessmentResponse>('/assess-audit-risk', validatedRequest);
    return AuditRiskAssessmentResponseSchema.parse(response);
  }

  /**
   * Process voice audio for tax information extraction
   */
  async processVoice(request: VoiceProcessingRequest): Promise<VoiceProcessingResponse> {
    const validatedRequest = VoiceProcessingRequestSchema.parse(request);
    const response = await this.makeRequest<VoiceProcessingResponse>('/process-voice', validatedRequest);
    return VoiceProcessingResponseSchema.parse(response);
  }

  /**
   * Upload voice file for processing
   */
  async uploadVoiceFile(file: File): Promise<{ file_path: string; filename: string; size: number; status: string }> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${this.baseUrl}/upload-voice`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Voice upload failed (${response.status}): ${errorText}`);
    }

    return await response.json();
  }

  /**
   * Optimize tax strategy for complex multi-entity scenarios
   */
  async optimizeTaxStrategy(request: TaxOptimizationRequest): Promise<TaxOptimizationResponse> {
    const validatedRequest = TaxOptimizationRequestSchema.parse(request);
    const response = await this.makeRequest<TaxOptimizationResponse>('/optimize-tax-strategy', validatedRequest);
    return TaxOptimizationResponseSchema.parse(response);
  }

  /**
   * Check ML service health
   */
  async healthCheck(): Promise<{ status: string; timestamp: string; services: Record<string, string> }> {
    return await this.makeRequest('/health', undefined, 'GET');
  }

  /**
   * Get status of all ML models
   */
  async getModelStatus(): Promise<{
    deduction_models: string[];
    audit_risk_model: string;
    voice_models: Record<string, string>;
    optimization_models: string[];
  }> {
    return await this.makeRequest('/models/status', undefined, 'GET');
  }
}

// Export singleton instance
export const mlClient = new MLClient();

// Utility functions for common ML operations
export class MLUtils {
  /**
   * Extract features from tax return data for ML processing
   */
  static extractTaxReturnFeatures(taxReturn: any, client: any): Record<string, any> {
    return {
      // Income features
      adjusted_gross_income: taxReturn.formData?.agi || 0,
      business_income: taxReturn.formData?.businessIncome || 0,
      investment_income: taxReturn.formData?.investmentIncome || 0,
      rental_income: taxReturn.formData?.rentalIncome || 0,
      
      // Deduction features
      total_deductions: taxReturn.formData?.totalDeductions || 0,
      charitable_deductions: taxReturn.formData?.charitableDeductions || 0,
      business_expenses: taxReturn.formData?.businessExpenses || 0,
      home_office_deduction: taxReturn.formData?.homeOfficeDeduction || 0,
      
      // Client features
      filing_status: taxReturn.formData?.filingStatus || 'single',
      dependents: taxReturn.formData?.dependents || 0,
      age: client.personalInfo?.age || 35,
      state: client.address?.state || 'CA',
      
      // Historical features
      previous_audits: client.auditHistory?.length || 0,
      years_as_client: client.yearsAsClient || 0,
      self_employed: client.personalInfo?.selfEmployed || false,
      cash_business: client.personalInfo?.cashBusiness || false,
    };
  }

  /**
   * Process document data for ML feature extraction
   */
  static processDocumentData(documents: any[]): any[] {
    return documents.map(doc => ({
      type: doc.documentType,
      confidence: doc.ocrConfidence || 0.8,
      extracted_data: doc.extractedData || {},
      amount: doc.extractedData?.amount || 0,
      date: doc.extractedData?.date,
      category: doc.extractedData?.category || 'other',
    }));
  }

  /**
   * Calculate confidence score for ML predictions
   */
  static calculateOverallConfidence(confidenceScores: Record<string, number>): number {
    const scores = Object.values(confidenceScores);
    if (scores.length === 0) return 0;
    
    // Weighted average with higher weight for higher scores
    const weightedSum = scores.reduce((sum, score) => sum + score * score, 0);
    const weightSum = scores.reduce((sum, score) => sum + score, 0);
    
    return weightSum > 0 ? weightedSum / weightSum : 0;
  }

  /**
   * Format ML results for display
   */
  static formatMLResults(results: any, type: 'deduction' | 'audit' | 'voice' | 'optimization'): any {
    switch (type) {
      case 'deduction':
        return {
          ...results,
          formatted_savings: new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
          }).format(results.total_potential_savings || 0),
          high_confidence_predictions: Object.entries(results.predictions || {})
            .filter(([_, pred]: [string, any]) => pred.confidence > 0.8)
            .reduce((acc, [key, pred]) => ({ ...acc, [key]: pred }), {}),
        };
        
      case 'audit':
        return {
          ...results,
          risk_level_color: this.getRiskLevelColor(results.risk_category),
          formatted_risk_score: `${Math.round((results.overall_risk_score || 0) * 100)}%`,
          priority_recommendations: results.prevention_recommendations?.slice(0, 3) || [],
        };
        
      case 'voice':
        return {
          ...results,
          summary: this.summarizeVoiceResults(results),
          key_points: this.extractKeyPoints(results.extracted_data || {}),
        };
        
      case 'optimization':
        return {
          ...results,
          top_strategies: results.strategies?.slice(0, 3) || [],
          total_projected_savings: Object.values(results.projected_savings || {})
            .reduce((sum: number, savings: any) => sum + (savings || 0), 0),
        };
        
      default:
        return results;
    }
  }

  private static getRiskLevelColor(riskCategory: string): string {
    const colors = {
      low: '#10B981',      // Green
      medium: '#F59E0B',   // Yellow
      high: '#EF4444',     // Red
      critical: '#DC2626'  // Dark Red
    };
    return colors[riskCategory as keyof typeof colors] || colors.medium;
  }

  private static summarizeVoiceResults(results: any): string {
    const transcript = results.transcript || '';
    const sentences = transcript.split('.').filter(s => s.trim().length > 0);
    
    if (sentences.length <= 2) return transcript;
    
    // Return first and last sentences as summary
    return `${sentences[0].trim()}. ... ${sentences[sentences.length - 1].trim()}.`;
  }

  private static extractKeyPoints(extractedData: Record<string, any>): string[] {
    const keyPoints: string[] = [];
    
    if (extractedData.amounts?.length > 0) {
      keyPoints.push(`${extractedData.amounts.length} monetary amounts identified`);
    }
    
    if (extractedData.dates?.length > 0) {
      keyPoints.push(`${extractedData.dates.length} dates mentioned`);
    }
    
    if (extractedData.tax_items?.length > 0) {
      keyPoints.push(`Tax items: ${extractedData.tax_items.join(', ')}`);
    }
    
    if (extractedData.action_items?.length > 0) {
      keyPoints.push(`${extractedData.action_items.length} action items identified`);
    }
    
    return keyPoints;
  }
}

export default MLClient;
