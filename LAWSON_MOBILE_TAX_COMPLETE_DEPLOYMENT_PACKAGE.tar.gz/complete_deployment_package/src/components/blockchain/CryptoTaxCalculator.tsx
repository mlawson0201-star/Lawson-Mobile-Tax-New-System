"use client";

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Bitcoin, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Calculator,
  FileText,
  Shield,
  Zap,
  Link,
  Eye,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  PieChart,
  BarChart3,
  Coins
} from 'lucide-react';

interface CryptoTransaction {
  id: string;
  timestamp: Date;
  type: 'buy' | 'sell' | 'trade' | 'mining' | 'staking' | 'defi' | 'nft';
  asset: string;
  quantity: number;
  price_usd: number;
  fee_usd: number;
  exchange: string;
  gain_loss?: number;
  holding_period?: number;
  is_long_term?: boolean;
}

interface TaxSummary {
  short_term_gain_loss: number;
  long_term_gain_loss: number;
  total_gain_loss: number;
  ordinary_income: number;
  total_proceeds: number;
  total_cost_basis: number;
  events_count: number;
}

interface WalletConnection {
  id: string;
  address: string;
  network: string;
  balance: number;
  connected: boolean;
  last_sync: Date;
}

export default function CryptoTaxCalculator() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedYear, setSelectedYear] = useState('2024');
  const [taxMethod, setTaxMethod] = useState('fifo');
  const [isCalculating, setIsCalculating] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  
  const [taxSummary, setTaxSummary] = useState<TaxSummary>({
    short_term_gain_loss: -2450.75,
    long_term_gain_loss: 8920.50,
    total_gain_loss: 6469.75,
    ordinary_income: 3200.00,
    total_proceeds: 45600.25,
    total_cost_basis: 39130.50,
    events_count: 127
  });

  const [transactions, setTransactions] = useState<CryptoTransaction[]>([
    {
      id: '1',
      timestamp: new Date('2024-03-15'),
      type: 'sell',
      asset: 'BTC',
      quantity: 0.5,
      price_usd: 65000,
      fee_usd: 25.50,
      exchange: 'Coinbase',
      gain_loss: 2450.75,
      holding_period: 180,
      is_long_term: false
    },
    {
      id: '2',
      timestamp: new Date('2024-02-10'),
      type: 'staking',
      asset: 'ETH',
      quantity: 0.1,
      price_usd: 2800,
      fee_usd: 0,
      exchange: 'Ethereum 2.0',
      gain_loss: 280.00,
      holding_period: 0,
      is_long_term: false
    },
    {
      id: '3',
      timestamp: new Date('2024-01-20'),
      type: 'defi',
      asset: 'UNI',
      quantity: 100,
      price_usd: 8.50,
      fee_usd: 15.75,
      exchange: 'Uniswap',
      gain_loss: -125.25,
      holding_period: 45,
      is_long_term: false
    }
  ]);

  const [connectedWallets, setConnectedWallets] = useState<WalletConnection[]>([
    {
      id: '1',
      address: '0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4',
      network: 'Ethereum',
      balance: 2.45,
      connected: true,
      last_sync: new Date(Date.now() - 1000 * 60 * 30)
    },
    {
      id: '2',
      address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
      network: 'Bitcoin',
      balance: 0.125,
      connected: true,
      last_sync: new Date(Date.now() - 1000 * 60 * 60 * 2)
    }
  ]);

  const [defiProtocols] = useState([
    { name: 'Uniswap', tvl: 1250.75, transactions: 15, yield_earned: 125.50 },
    { name: 'Compound', tvl: 850.25, transactions: 8, yield_earned: 89.25 },
    { name: 'Aave', tvl: 2100.00, transactions: 22, yield_earned: 245.75 }
  ]);

  const handleCalculateTaxes = async () => {
    setIsCalculating(true);
    
    // Simulate tax calculation
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Update with new calculations
    setTaxSummary(prev => ({
      ...prev,
      total_gain_loss: prev.total_gain_loss + Math.random() * 1000 - 500
    }));
    
    setIsCalculating(false);
  };

  const handleConnectWallet = async () => {
    if (!walletAddress.trim()) return;
    
    const newWallet: WalletConnection = {
      id: Date.now().toString(),
      address: walletAddress,
      network: 'Ethereum', // Auto-detect in real implementation
      balance: Math.random() * 10,
      connected: true,
      last_sync: new Date()
    };
    
    setConnectedWallets(prev => [...prev, newWallet]);
    setWalletAddress('');
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'buy': return 'bg-green-500';
      case 'sell': return 'bg-red-500';
      case 'trade': return 'bg-blue-500';
      case 'mining': return 'bg-yellow-500';
      case 'staking': return 'bg-purple-500';
      case 'defi': return 'bg-pink-500';
      case 'nft': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Bitcoin className="h-8 w-8 text-orange-500" />
            Crypto Tax Calculator
          </h1>
          <p className="text-muted-foreground mt-1">
            Advanced cryptocurrency tax calculation with DeFi and NFT support
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={taxMethod} onValueChange={setTaxMethod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="fifo">FIFO</SelectItem>
              <SelectItem value="lifo">LIFO</SelectItem>
              <SelectItem value="hifo">HIFO</SelectItem>
              <SelectItem value="specific">Specific ID</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleCalculateTaxes} disabled={isCalculating}>
            {isCalculating ? (
              <>
                <Calculator className="h-4 w-4 mr-2 animate-spin" />
                Calculating...
              </>
            ) : (
              <>
                <Calculator className="h-4 w-4 mr-2" />
                Calculate Taxes
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Tax Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Total Gain/Loss
                </p>
                <p className={`text-2xl font-bold ${
                  taxSummary.total_gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatCurrency(taxSummary.total_gain_loss)}
                </p>
              </div>
              {taxSummary.total_gain_loss >= 0 ? (
                <TrendingUp className="h-8 w-8 text-green-600" />
              ) : (
                <TrendingDown className="h-8 w-8 text-red-600" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Short-term Gains
                </p>
                <p className={`text-2xl font-bold ${
                  taxSummary.short_term_gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatCurrency(taxSummary.short_term_gain_loss)}
                </p>
              </div>
              <Zap className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Long-term Gains
                </p>
                <p className={`text-2xl font-bold ${
                  taxSummary.long_term_gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatCurrency(taxSummary.long_term_gain_loss)}
                </p>
              </div>
              <Shield className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Ordinary Income
                </p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(taxSummary.ordinary_income)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="wallets">Wallets</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="defi">DeFi</TabsTrigger>
          <TabsTrigger value="nft">NFTs</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Tax Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Tax Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Short-term Capital Gains</span>
                    <span className="font-medium text-red-600">
                      {formatCurrency(Math.abs(taxSummary.short_term_gain_loss))}
                    </span>
                  </div>
                  <Progress 
                    value={Math.abs(taxSummary.short_term_gain_loss) / (Math.abs(taxSummary.short_term_gain_loss) + taxSummary.long_term_gain_loss) * 100} 
                    className="h-2"
                  />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Long-term Capital Gains</span>
                    <span className="font-medium text-green-600">
                      {formatCurrency(taxSummary.long_term_gain_loss)}
                    </span>
                  </div>
                  <Progress 
                    value={taxSummary.long_term_gain_loss / (Math.abs(taxSummary.short_term_gain_loss) + taxSummary.long_term_gain_loss) * 100} 
                    className="h-2"
                  />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Ordinary Income (Staking/Mining)</span>
                    <span className="font-medium text-purple-600">
                      {formatCurrency(taxSummary.ordinary_income)}
                    </span>
                  </div>
                  <Progress 
                    value={taxSummary.ordinary_income / (taxSummary.ordinary_income + Math.abs(taxSummary.total_gain_loss)) * 100} 
                    className="h-2"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Transaction Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Total Transactions</span>
                    <span className="font-medium">{taxSummary.events_count}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Total Proceeds</span>
                    <span className="font-medium text-green-600">
                      {formatCurrency(taxSummary.total_proceeds)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Total Cost Basis</span>
                    <span className="font-medium text-blue-600">
                      {formatCurrency(taxSummary.total_cost_basis)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between pt-2 border-t">
                    <span className="text-sm font-medium">Net Gain/Loss</span>
                    <span className={`font-bold ${
                      taxSummary.total_gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(taxSummary.total_gain_loss)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>
                Latest cryptocurrency transactions processed for tax calculation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.slice(0, 5).map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge className={`${getTransactionTypeColor(tx.type)} text-white`}>
                        {tx.type.toUpperCase()}
                      </Badge>
                      <div>
                        <p className="font-medium">
                          {tx.quantity} {tx.asset}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {tx.timestamp.toLocaleDateString()} • {tx.exchange}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {formatCurrency(tx.price_usd * tx.quantity)}
                      </p>
                      {tx.gain_loss !== undefined && (
                        <p className={`text-sm ${
                          tx.gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {tx.gain_loss >= 0 ? '+' : ''}{formatCurrency(tx.gain_loss)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wallets" className="space-y-6">
          {/* Connect Wallet */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link className="h-5 w-5" />
                Connect Wallet
              </CardTitle>
              <CardDescription>
                Connect your crypto wallets to automatically import transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter wallet address (0x... or bc1...)"
                  value={walletAddress}
                  onChange={(e) => setWalletAddress(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleConnectWallet} disabled={!walletAddress.trim()}>
                  <Wallet className="h-4 w-4 mr-2" />
                  Connect
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Connected Wallets */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                Connected Wallets
              </CardTitle>
              <CardDescription>
                Manage your connected cryptocurrency wallets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {connectedWallets.map((wallet) => (
                  <div key={wallet.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        wallet.connected ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <div>
                        <p className="font-medium">{wallet.network}</p>
                        <p className="text-sm text-muted-foreground font-mono">
                          {formatAddress(wallet.address)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {wallet.balance.toFixed(4)} {wallet.network === 'Bitcoin' ? 'BTC' : 'ETH'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Synced {Math.floor((Date.now() - wallet.last_sync.getTime()) / (1000 * 60))}m ago
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Transaction History
              </CardTitle>
              <CardDescription>
                Complete history of cryptocurrency transactions for tax year {selectedYear}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <Badge className={`${getTransactionTypeColor(tx.type)} text-white`}>
                        {tx.type}
                      </Badge>
                      <div>
                        <p className="font-medium">
                          {tx.type === 'sell' ? 'Sold' : tx.type === 'buy' ? 'Bought' : 'Traded'} {tx.quantity} {tx.asset}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {tx.timestamp.toLocaleDateString()} • {tx.exchange}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="font-medium">
                        {formatCurrency(tx.price_usd * tx.quantity)}
                      </p>
                      {tx.gain_loss !== undefined && (
                        <div className="flex items-center gap-2">
                          <span className={`text-sm ${
                            tx.gain_loss >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {tx.gain_loss >= 0 ? '+' : ''}{formatCurrency(tx.gain_loss)}
                          </span>
                          {tx.is_long_term !== undefined && (
                            <Badge variant={tx.is_long_term ? 'default' : 'secondary'}>
                              {tx.is_long_term ? 'Long-term' : 'Short-term'}
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defi" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Coins className="h-5 w-5" />
                DeFi Protocol Activity
              </CardTitle>
              <CardDescription>
                Decentralized finance protocol interactions and yield farming
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {defiProtocols.map((protocol, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                        {protocol.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{protocol.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {protocol.transactions} transactions
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        TVL: {formatCurrency(protocol.tvl)}
                      </p>
                      <p className="text-sm text-green-600">
                        Yield: +{formatCurrency(protocol.yield_earned)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>DeFi Tax Notice:</strong> All DeFi transactions including swaps, liquidity provision, 
              and yield farming are taxable events. Ensure all protocols are properly tracked.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="nft" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                NFT Transactions
              </CardTitle>
              <CardDescription>
                Non-fungible token purchases, sales, and transfers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Eye className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No NFT Transactions Found</h3>
                <p className="text-muted-foreground mb-4">
                  Connect your wallets to automatically detect NFT transactions
                </p>
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Import NFT Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Tax Reports
              </CardTitle>
              <CardDescription>
                Generate and download tax reports for filing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    name: 'Form 8949',
                    description: 'Capital gains and losses report',
                    format: 'PDF',
                    icon: <FileText className="h-5 w-5" />
                  },
                  {
                    name: 'Schedule D',
                    description: 'Capital gains summary',
                    format: 'PDF',
                    icon: <FileText className="h-5 w-5" />
                  },
                  {
                    name: 'Transaction Report',
                    description: 'Complete transaction history',
                    format: 'CSV',
                    icon: <Download className="h-5 w-5" />
                  },
                  {
                    name: 'Tax Summary',
                    description: 'Overview of tax implications',
                    format: 'PDF',
                    icon: <Calculator className="h-5 w-5" />
                  }
                ].map((report, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center gap-3 mb-3">
                      {report.icon}
                      <div>
                        <h4 className="font-medium">{report.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {report.description}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{report.format}</Badge>
                      <Button size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
