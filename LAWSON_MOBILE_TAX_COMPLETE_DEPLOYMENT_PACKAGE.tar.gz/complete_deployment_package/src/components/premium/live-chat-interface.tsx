
'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MessageCircle,
  Send,
  Paperclip,
  Phone,
  Video,
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  Shield,
  Zap,
} from 'lucide-react';
import { useSession } from 'next-auth/react';

interface Message {
  id: string;
  senderId: string;
  senderType: 'client' | 'ea_cpa' | 'system';
  message: string;
  messageType: 'text' | 'file' | 'form' | 'link';
  attachments?: any[];
  isRead: boolean;
  createdAt: string;
}

interface ChatSession {
  id: string;
  status: 'waiting' | 'active' | 'completed' | 'abandoned';
  topic: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  waitTime?: number;
  chatDuration?: number;
  eaCpaUser?: {
    id: string;
    firstName: string;
    lastName: string;
    role: string;
  };
  satisfactionRating?: number;
  startedAt: string;
  connectedAt?: string;
  endedAt?: string;
}

interface LiveChatInterfaceProps {
  clientId: string;
  onChatEnd?: (rating: number) => void;
}

export function LiveChatInterface({ clientId, onChatEnd }: LiveChatInterfaceProps) {
  const { data: session } = useSession() || {};
  const [chatSession, setChatSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [rating, setRating] = useState(0);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    initiateChatSession();
  }, [clientId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (chatSession?.id) {
      const interval = setInterval(() => {
        fetchMessages();
      }, 2000); // Poll for new messages every 2 seconds

      return () => clearInterval(interval);
    }
  }, [chatSession?.id]);

  const initiateChatSession = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/premium/live-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clientId,
          topic: 'general',
          priority: 'normal',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setChatSession(data);
        
        // Start polling for session updates
        pollSessionStatus(data.sessionId);
      }
    } catch (error) {
      console.error('Error initiating chat:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const pollSessionStatus = async (sessionId: string) => {
    try {
      const response = await fetch(`/api/premium/live-chat?sessionId=${sessionId}`);
      if (response.ok) {
        const data = await response.json();
        setChatSession(data.session);
        setMessages(data.session.messages || []);
        setIsConnected(data.session.status === 'active');
      }
    } catch (error) {
      console.error('Error polling session status:', error);
    }
  };

  const fetchMessages = async () => {
    if (!chatSession?.id) return;

    try {
      const response = await fetch(`/api/premium/live-chat/${chatSession.id}/messages`);
      if (response.ok) {
        const data = await response.json();
        setMessages(data.messages || []);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !chatSession?.id) return;

    try {
      const response = await fetch(`/api/premium/live-chat/${chatSession.id}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: newMessage.trim(),
          messageType: 'text',
        }),
      });

      if (response.ok) {
        setNewMessage('');
        fetchMessages(); // Refresh messages
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !chatSession?.id) return;

    // In a real implementation, you would upload the file first
    // then send the message with file attachment
    try {
      const response = await fetch(`/api/premium/live-chat/${chatSession.id}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: `Sent a file: ${file.name}`,
          messageType: 'file',
          attachments: [{ name: file.name, size: file.size, type: file.type }],
        }),
      });

      if (response.ok) {
        fetchMessages();
      }
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  };

  const endChatWithRating = () => {
    setShowRating(true);
  };

  const submitRating = async () => {
    if (rating > 0) {
      // Submit rating to backend
      onChatEnd?.(rating);
      setShowRating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-96 flex items-center justify-center bg-white rounded-lg shadow-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Connecting you with a tax professional...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-96 bg-white rounded-lg shadow-lg flex flex-col overflow-hidden">
      {/* Chat Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5" />
              <span className="font-medium">Live Tax Support</span>
            </div>
            <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs ${
              isConnected ? 'bg-green-500/20' : 'bg-yellow-500/20'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-green-300' : 'bg-yellow-300'
              }`}></div>
              <span>{isConnected ? 'Connected' : 'Waiting'}</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {chatSession?.eaCpaUser && (
              <>
                <button className="p-1 hover:bg-white/20 rounded">
                  <Phone className="h-4 w-4" />
                </button>
                <button className="p-1 hover:bg-white/20 rounded">
                  <Video className="h-4 w-4" />
                </button>
              </>
            )}
            <button 
              onClick={endChatWithRating}
              className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-medium transition-colors"
            >
              End Chat
            </button>
          </div>
        </div>

        {chatSession?.eaCpaUser && (
          <div className="mt-2 flex items-center space-x-2 text-sm opacity-90">
            <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
              <User className="h-3 w-3" />
            </div>
            <span>
              {chatSession.eaCpaUser.firstName} {chatSession.eaCpaUser.lastName}
            </span>
            <div className="flex items-center space-x-1">
              <Shield className="h-3 w-3" />
              <span className="text-xs">Certified EA</span>
            </div>
          </div>
        )}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!isConnected && (
          <div className="text-center py-8">
            <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">You're in the queue</p>
            <p className="text-sm text-gray-500">
              Estimated wait time: {Math.max(1, Math.ceil((chatSession?.waitTime || 0) / 60))} minutes
            </p>
            <div className="mt-4 max-w-sm mx-auto">
              <div className="bg-blue-50 p-3 rounded-lg text-sm text-blue-800">
                <Zap className="h-4 w-4 inline mr-1" />
                While you wait, feel free to describe your tax question!
              </div>
            </div>
          </div>
        )}

        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              className={`flex ${message.senderType === 'client' ? 'justify-end' : 'justify-start'}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                message.senderType === 'client'
                  ? 'bg-blue-600 text-white'
                  : message.senderType === 'system'
                  ? 'bg-gray-100 text-gray-800 text-sm'
                  : 'bg-gray-200 text-gray-900'
              }`}>
                {message.senderType === 'ea_cpa' && (
                  <div className="flex items-center space-x-1 mb-1 text-xs text-gray-600">
                    <Shield className="h-3 w-3" />
                    <span>Tax Professional</span>
                  </div>
                )}
                <p className="text-sm">{message.message}</p>
                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-2">
                    {message.attachments.map((attachment, idx) => (
                      <div key={idx} className="flex items-center space-x-2 text-xs">
                        <Paperclip className="h-3 w-3" />
                        <span>{attachment.name}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="mt-1 text-xs opacity-70">
                  {new Date(message.createdAt).toLocaleTimeString()}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="border-t p-4">
        <div className="flex items-center space-x-2">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileUpload}
            className="hidden"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
          />
          
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <Paperclip className="h-5 w-5" />
          </button>
          
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Type your tax question..."
            className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          
          <button
            onClick={sendMessage}
            disabled={!newMessage.trim()}
            className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Rating Modal */}
      <AnimatePresence>
        {showRating && (
          <motion.div
            className="absolute inset-0 bg-black/50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-lg p-6 max-w-sm w-full"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Rate your experience</h3>
              <p className="text-gray-600 mb-6">How was your chat with our tax professional?</p>
              
              <div className="flex justify-center space-x-2 mb-6">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className={`p-1 transition-colors ${
                      star <= rating ? 'text-yellow-400' : 'text-gray-300'
                    }`}
                  >
                    <Star className="h-8 w-8 fill-current" />
                  </button>
                ))}
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowRating(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Skip
                </button>
                <button
                  onClick={submitRating}
                  disabled={rating === 0}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Submit
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
