
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

// Define public routes that don't require authentication
const publicRoutes = [
  '/',
  '/auth/signin',
  '/auth/signup',
  '/auth/error',
  '/api/auth',
  '/api/signup',
  '/api/webhooks',
  '/_next',
  '/favicon.ico',
  '/images',
];

// Define role-based route access
const roleRoutes = {
  super_admin: ['/admin', '/tenants', '/system'],
  tenant_admin: ['/dashboard', '/admin/tenant', '/clients', '/preparers', '/reports'],
  ea_cpa: ['/dashboard', '/review', '/clients', '/tax-returns', '/efile'],
  preparer: ['/dashboard', '/tax-returns', '/clients'],
  support: ['/dashboard', '/support', '/clients'],
  client: ['/dashboard', '/documents', '/returns', '/payments'],
};

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // Skip middleware for public routes and API routes
  if (publicRoutes.some(route => pathname.startsWith(route))) {
    return NextResponse.next();
  }

  try {
    // Get the token from the request
    const token = await getToken({
      req: request,
      secret: process.env.NEXTAUTH_SECRET,
    });

    // If no token and not a public route, redirect to signin
    if (!token) {
      const signInUrl = new URL('/auth/signin', request.url);
      signInUrl.searchParams.set('callbackUrl', request.url);
      return NextResponse.redirect(signInUrl);
    }

    // Check role-based access
    const userRole = token.role as keyof typeof roleRoutes;
    const allowedRoutes = roleRoutes[userRole] || [];
    
    // Super admin has access to everything
    if (userRole !== 'super_admin') {
      const hasAccess = allowedRoutes.some(route => pathname.startsWith(route));
      
      if (!hasAccess) {
        // Redirect to appropriate dashboard based on role
        const dashboardUrl = new URL('/dashboard', request.url);
        return NextResponse.redirect(dashboardUrl);
      }
    }

    // Add tenant context to headers for multi-tenant support
    const requestHeaders = new Headers(request.headers);
    requestHeaders.set('x-tenant-id', token.tenantId as string);
    requestHeaders.set('x-user-role', token.role as string);

    return NextResponse.next({
      request: {
        headers: requestHeaders,
      },
    });

  } catch (error) {
    console.error('Middleware error:', error);
    // On error, redirect to signin
    const signInUrl = new URL('/auth/signin', request.url);
    return NextResponse.redirect(signInUrl);
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
