
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { analysisType, clientId, forecastPeriod } = await request.json();

    if (!analysisType) {
      return NextResponse.json({ error: 'Analysis type required' }, { status: 400 });
    }

    // Gather historical data based on analysis type
    let historicalData = {};
    let analysisPrompt = '';

    switch (analysisType) {
      case 'client_retention':
        const clientData = await prisma.client.findMany({
          where: {
            tenantId: session.user.tenantId,
            ...(clientId && { id: clientId }),
          },
          include: {
            taxReturns: {
              orderBy: { createdAt: 'desc' },
              take: 5,
            },
            payments: {
              orderBy: { createdAt: 'desc' },
              take: 10,
            },
            liveChatSessions: true,
            clientReviews: true,
          },
        });

        historicalData = { clients: clientData };
        analysisPrompt = `
          Analyze client retention patterns and predict future retention:

          Client Data: ${JSON.stringify(clientData, null, 2)}

          Provide predictive analysis in JSON format:
          {
            "overall_retention_rate": number,
            "risk_segments": [
              {
                "segment": "high_risk | medium_risk | low_risk",
                "client_count": number,
                "characteristics": ["common traits"],
                "retention_probability": number,
                "recommended_actions": ["what to do"]
              }
            ],
            "retention_drivers": [
              {
                "factor": "service_quality | price | convenience",
                "impact": number,
                "correlation": number
              }
            ],
            "predictions": [
              {
                "period": "next_month | next_quarter | next_year",
                "expected_retention_rate": number,
                "confidence_interval": {"min": number, "max": number}
              }
            ],
            "improvement_opportunities": [
              {
                "opportunity": "description",
                "potential_impact": number,
                "implementation_effort": "low | medium | high"
              }
            ]
          }
        `;
        break;

      case 'revenue_forecast':
        const revenueData = await prisma.payment.findMany({
          where: {
            tenantId: session.user.tenantId,
            status: 'completed',
            createdAt: {
              gte: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000), // Last year
            },
          },
          include: {
            taxReturn: true,
          },
          orderBy: { createdAt: 'asc' },
        });

        const subscriptions = await prisma.subscriptionEnhanced.findMany({
          where: {
            tenantId: session.user.tenantId,
            status: { in: ['trial', 'active'] },
          },
        });

        historicalData = { revenue: revenueData, subscriptions };
        analysisPrompt = `
          Analyze revenue trends and forecast future revenue:

          Historical Revenue: ${JSON.stringify(revenueData, null, 2)}
          Active Subscriptions: ${JSON.stringify(subscriptions, null, 2)}

          Provide revenue forecast in JSON format:
          {
            "current_metrics": {
              "monthly_recurring_revenue": number,
              "average_client_value": number,
              "revenue_growth_rate": number,
              "seasonality_factor": number
            },
            "forecast": [
              {
                "period": "month_name or quarter",
                "predicted_revenue": number,
                "confidence": number,
                "contributing_factors": ["reasons for prediction"]
              }
            ],
            "revenue_drivers": [
              {
                "driver": "new_clients | retention | pricing | services",
                "current_contribution": number,
                "growth_potential": number
              }
            ],
            "scenarios": [
              {
                "scenario": "conservative | expected | optimistic",
                "annual_revenue": number,
                "assumptions": ["key assumptions"]
              }
            ]
          }
        `;
        break;

      case 'audit_risk':
        const auditRiskData = await prisma.taxReturn.findMany({
          where: {
            tenantId: session.user.tenantId,
            ...(clientId && { clientId }),
            status: { in: ['submitted', 'completed'] },
          },
          include: {
            deductionSuggestions: true,
            taxOptimizationSuggestions: true,
            client: true,
          },
        });

        historicalData = { taxReturns: auditRiskData };
        analysisPrompt = `
          Analyze audit risk factors and predict audit probability:

          Tax Return Data: ${JSON.stringify(auditRiskData, null, 2)}

          Provide audit risk analysis in JSON format:
          {
            "overall_audit_risk": {
              "risk_level": "low | medium | high",
              "probability": number,
              "confidence": number
            },
            "risk_factors": [
              {
                "factor": "income_level | deduction_ratio | filing_patterns",
                "risk_score": number,
                "description": "explanation"
              }
            ],
            "client_risk_profiles": [
              {
                "client_id": "string",
                "risk_level": "low | medium | high",
                "risk_score": number,
                "primary_risk_factors": ["factors"],
                "mitigation_strategies": ["recommendations"]
              }
            ],
            "trend_analysis": {
              "risk_trends": "increasing | stable | decreasing",
              "key_changes": ["notable changes"]
            }
          }
        `;
        break;

      case 'refund_timeline':
        const refundData = await prisma.taxReturn.findMany({
          where: {
            tenantId: session.user.tenantId,
            refundAmount: { gt: 0 },
            submittedAt: { not: null },
          },
          include: {
            eFileSubmissions: true,
          },
          orderBy: { submittedAt: 'desc' },
          take: 100,
        });

        historicalData = { refunds: refundData };
        analysisPrompt = `
          Analyze refund processing timelines and predict future timelines:

          Refund History: ${JSON.stringify(refundData, null, 2)}

          Provide refund timeline analysis in JSON format:
          {
            "average_processing_times": {
              "e_file_simple": number,
              "e_file_complex": number,
              "paper_filing": number
            },
            "timeline_predictions": [
              {
                "filing_type": "e_file | paper",
                "complexity": "simple | complex",
                "predicted_days": number,
                "confidence": number
              }
            ],
            "factors_affecting_timeline": [
              {
                "factor": "irs_processing_delays | return_complexity | errors",
                "impact_days": number,
                "frequency": number
              }
            ],
            "seasonal_patterns": [
              {
                "month": "month_name",
                "average_delay": number,
                "volume_factor": number
              }
            ]
          }
        `;
        break;

      default:
        return NextResponse.json({ error: 'Invalid analysis type' }, { status: 400 });
    }

    // Process with AI
    const response = await fetch(`${process.env.ABACUSAI_BASE_URL || 'https://apps.abacus.ai'}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{ role: 'user', content: analysisPrompt }],
        response_format: { type: "json_object" },
        max_tokens: 4000,
      }),
    });

    if (!response.ok) {
      throw new Error(`Predictive analysis failed: ${response.statusText}`);
    }

    const aiResult = await response.json();
    const predictionData = JSON.parse(aiResult.choices[0].message.content);

    // Calculate confidence interval
    const confidenceInterval = {
      confidence: 0.85,
      method: 'ai_analysis',
      data_points: Object.keys(historicalData).length,
    };

    // Store predictive analytics result
    const analyticsRecord = await prisma.predictiveAnalytics.create({
      data: {
        tenantId: session.user.tenantId,
        clientId: clientId || null,
        analytic_type: analysisType,
        predictionData,
        confidenceInterval,
        forecastPeriod: forecastPeriod || 'next_quarter',
        validUntil: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // Valid for 90 days
      },
    });

    return NextResponse.json({
      success: true,
      analyticsId: analyticsRecord.id,
      analysisType,
      predictionData,
      confidenceInterval,
      generatedAt: analyticsRecord.generatedAt,
      validUntil: analyticsRecord.validUntil,
    });
  } catch (error: any) {
    console.error('Predictive analytics error:', error);
    return NextResponse.json(
      { error: 'Predictive analysis failed', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve analytics
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const analysisType = searchParams.get('analysisType');
    const clientId = searchParams.get('clientId');

    const analytics = await prisma.predictiveAnalytics.findMany({
      where: {
        tenantId: session.user.tenantId,
        ...(analysisType && { analytic_type: analysisType }),
        ...(clientId && { clientId }),
        validUntil: {
          gte: new Date(),
        },
      },
      orderBy: { generatedAt: 'desc' },
    });

    return NextResponse.json({
      success: true,
      analytics,
      count: analytics.length,
    });
  } catch (error: any) {
    console.error('Get analytics error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve analytics', details: error?.message },
      { status: 500 }
    );
  }
}
