
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const taxReturnId = formData.get('taxReturnId') as string;
    const documentType = formData.get('documentType') as string;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    // Convert file to base64 for AI processing
    const arrayBuffer = await file.arrayBuffer();
    const base64String = Buffer.from(arrayBuffer).toString('base64');

    // Create processing record
    const ocrRecord = await prisma.oCRProcessing.create({
      data: {
        tenantId: session.user.tenantId,
        documentId: 'temp-id', // Will be updated after document creation
        imageUrl: `data:${file.type};base64,${base64String}`,
        formType: documentType,
        processingEngine: 'ai_llm',
        realTimeProcessed: true,
      },
    });

    // Process with AI
    const aiResponse = await fetch(`${process.env.ABACUSAI_BASE_URL || 'https://apps.abacus.ai'}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `Analyze this tax document and extract key information. Document type: ${documentType}. 
                Return a JSON response with:
                - formType: detected form type (W2, 1099, receipt, etc.)
                - extractedData: key-value pairs of important tax information
                - confidenceScore: your confidence in the extraction (0-1)
                - suggestedDeductions: any potential deductions based on this document
                - structuredData: organized financial data for tax processing
                
                Respond with clean JSON only, no markdown or code blocks.`
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:${file.type};base64,${base64String}`
                }
              }
            ]
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 3000,
      }),
    });

    if (!aiResponse.ok) {
      throw new Error(`AI processing failed: ${aiResponse.statusText}`);
    }

    const aiResult = await aiResponse.json();
    const extractedData = JSON.parse(aiResult.choices[0].message.content);

    // Update OCR record with results
    const updatedOcrRecord = await prisma.oCRProcessing.update({
      where: { id: ocrRecord.id },
      data: {
        extractedText: JSON.stringify(extractedData.extractedData),
        structuredData: extractedData.structuredData,
        formType: extractedData.formType,
        confidenceScore: extractedData.confidenceScore,
        validationStatus: extractedData.confidenceScore > 0.8 ? 'validated' : 'requires_review',
        processedAt: new Date(),
        processingTime: Date.now() - new Date(ocrRecord.createdAt).getTime(),
      },
    });

    // If deductions are suggested, create deduction suggestions
    if (extractedData.suggestedDeductions?.length > 0 && taxReturnId) {
      const aiModel = await prisma.aIModelData.findFirst({
        where: {
          tenantId: session.user.tenantId,
          modelType: 'deduction_discovery',
          isActive: true,
        },
        orderBy: { createdAt: 'desc' },
      });

      if (aiModel) {
        for (const deduction of extractedData.suggestedDeductions) {
          await prisma.deductionSuggestion.create({
            data: {
              tenantId: session.user.tenantId,
              taxReturnId,
              aiModelId: aiModel.id,
              deductionCategory: deduction?.category || 'general',
              deductionAmount: parseFloat(deduction?.amount || 0),
              confidenceScore: deduction?.confidence || 0.7,
              evidenceData: { documentId: ocrRecord.id, extractedData },
              justification: deduction?.justification || 'AI-suggested based on document analysis',
              potentialSavings: parseFloat(deduction?.savings || 0),
              riskLevel: deduction?.riskLevel || 'low',
            },
          });
        }
      }
    }

    return NextResponse.json({
      success: true,
      ocrRecord: updatedOcrRecord,
      extractedData,
      message: 'Document processed successfully',
    });
  } catch (error: any) {
    console.error('Document analysis error:', error);
    return NextResponse.json(
      { error: 'Document analysis failed', details: error?.message },
      { status: 500 }
    );
  }
}
