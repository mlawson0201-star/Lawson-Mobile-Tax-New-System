
import Stripe from 'stripe'

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is not set')
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2025-07-30.basil',
  typescript: true,
})

export const createConnectedAccount = async (tenantId: string, email: string) => {
  const account = await stripe.accounts.create({
    type: 'express',
    email,
    metadata: {
      tenantId,
    },
  })
  return account
}

export const createAccountLink = async (accountId: string, refreshUrl: string, returnUrl: string) => {
  const accountLink = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: refreshUrl,
    return_url: returnUrl,
    type: 'account_onboarding',
  })
  return accountLink
}

export const createPaymentIntent = async (
  amount: number,
  currency: string = 'usd',
  connectedAccountId?: string,
  applicationFeeAmount?: number
) => {
  const paymentIntentData: Stripe.PaymentIntentCreateParams = {
    amount,
    currency,
    automatic_payment_methods: {
      enabled: true,
    },
  }

  if (connectedAccountId) {
    paymentIntentData.transfer_data = {
      destination: connectedAccountId,
    }
  }

  if (applicationFeeAmount) {
    paymentIntentData.application_fee_amount = applicationFeeAmount
  }

  return await stripe.paymentIntents.create(paymentIntentData)
}
