
import { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@/lib/prisma';
import { GoHighLevelClient } from '@/lib/gohighlevel/client';
import { createSyncService } from '@/lib/gohighlevel/sync';
import { triggerLeadCreated, triggerLeadStatusChanged, triggerAppointmentBooked } from '@/lib/crm/automation';
import { LeadStatus, LeadSource, CommunicationType } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const signature = req.headers['x-ghl-signature'] as string;
    const payload = JSON.stringify(req.body);
    
    // Get tenant from location ID or other identifier
    const locationId = req.body.locationId || req.query.locationId;
    if (!locationId) {
      return res.status(400).json({ error: 'Location ID required' });
    }

    // Find tenant by location ID
    const settings = await prisma.gohighlevel_settings.findFirst({
      where: { location_id: locationId },
    });

    if (!settings) {
      return res.status(404).json({ error: 'Tenant not found for location' });
    }

    // Verify webhook signature if secret is configured
    if (settings.webhook_secret && signature) {
      const isValid = GoHighLevelClient.verifyWebhookSignature(
        payload,
        signature,
        settings.webhook_secret
      );

      if (!isValid) {
        return res.status(401).json({ error: 'Invalid webhook signature' });
      }
    }

    // Log webhook event
    const webhookEvent = await prisma.gohighlevel_webhook_events.create({
      data: {
        tenant_id: settings.tenant_id,
        event_type: req.body.type || 'unknown',
        event_data: req.body,
        signature,
        received_at: new Date(),
      },
    });

    // Process webhook event
    await processWebhookEvent(settings.tenant_id, req.body, webhookEvent.id);

    res.status(200).json({ message: 'Webhook processed successfully' });
  } catch (error) {
    console.error('Webhook processing error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}

async function processWebhookEvent(tenantId: string, eventData: any, webhookEventId: string) {
  try {
    const eventType = eventData.type;
    
    switch (eventType) {
      case 'ContactCreate':
      case 'ContactUpdate':
        await handleContactEvent(tenantId, eventData);
        break;
        
      case 'AppointmentCreate':
      case 'AppointmentUpdate':
        await handleAppointmentEvent(tenantId, eventData);
        break;
        
      case 'OpportunityCreate':
      case 'OpportunityUpdate':
      case 'OpportunityStatusUpdate':
        await handleOpportunityEvent(tenantId, eventData);
        break;
        
      case 'InboundMessage':
      case 'OutboundMessage':
        await handleMessageEvent(tenantId, eventData);
        break;
        
      default:
        console.log(`Unhandled webhook event type: ${eventType}`);
    }

    // Mark webhook as processed
    await prisma.gohighlevel_webhook_events.update({
      where: { id: webhookEventId },
      data: {
        processed: true,
        processed_at: new Date(),
        processing_result: { success: true },
      },
    });
  } catch (error) {
    console.error('Error processing webhook event:', error);
    
    // Mark webhook as failed
    await prisma.gohighlevel_webhook_events.update({
      where: { id: webhookEventId },
      data: {
        processed: true,
        processed_at: new Date(),
        processing_result: { success: false, error: error instanceof Error ? error.message : 'Unknown error' },
        error_message: error instanceof Error ? error.message : 'Unknown error',
      },
    });
  }
}

async function handleContactEvent(tenantId: string, eventData: any) {
  const contactData = eventData.contact || eventData;
  const contactId = contactData.id;
  
  if (!contactId || !contactData.email) {
    console.warn('Invalid contact data in webhook:', contactData);
    return;
  }

  // Check if lead already exists
  let existingLead = await prisma.crm_leads.findFirst({
    where: {
      tenant_id: tenantId,
      OR: [
        { gohighlevel_contact_id: contactId },
        { email: contactData.email },
      ],
    },
  });

  const leadData = {
    first_name: contactData.firstName || '',
    last_name: contactData.lastName || '',
    email: contactData.email,
    phone: contactData.phone || null,
    company: contactData.companyName || contactData.customFields?.company || null,
    source: mapLeadSource(contactData.source),
    gohighlevel_contact_id: contactId,
    tags: contactData.tags || [],
    custom_fields: contactData.customFields || {},
    updated_at: new Date(),
  };

  if (existingLead) {
    // Update existing lead
    const updatedLead = await prisma.crm_leads.update({
      where: { id: existingLead.id },
      data: leadData,
    });

    // Trigger automation for updates
    if (eventData.type === 'ContactUpdate') {
      await triggerLeadStatusChanged(tenantId, updatedLead.id, existingLead.status, updatedLead.status);
    }
  } else {
    // Create new lead
    const settings = await prisma.gohighlevel_settings.findUnique({
      where: { tenant_id: tenantId },
    });

    const newLead = await prisma.crm_leads.create({
      data: {
        ...leadData,
        tenant_id: tenantId,
        status: LeadStatus.NEW,
        pipeline_stage_id: settings?.default_pipeline_stage_id,
        created_at: new Date(),
      },
    });

    // Trigger automation for new leads
    await triggerLeadCreated(tenantId, newLead.id);
  }
}

async function handleAppointmentEvent(tenantId: string, eventData: any) {
  const appointmentData = eventData.appointment || eventData;
  const appointmentId = appointmentData.id;
  const contactId = appointmentData.contactId;

  if (!appointmentId || !contactId) {
    console.warn('Invalid appointment data in webhook:', appointmentData);
    return;
  }

  // Find the corresponding lead
  const lead = await prisma.crm_leads.findFirst({
    where: {
      tenant_id: tenantId,
      gohighlevel_contact_id: contactId,
    },
  });

  if (!lead) {
    console.warn(`No lead found for GoHighLevel contact ${contactId}`);
    return;
  }

  // Check if appointment already exists
  const existingAppointment = await prisma.crm_appointments.findFirst({
    where: {
      tenant_id: tenantId,
      gohighlevel_appointment_id: appointmentId,
    },
  });

  const appointmentDbData = {
    lead_id: lead.id,
    title: appointmentData.title || 'GoHighLevel Appointment',
    description: appointmentData.notes || null,
    start_time: new Date(appointmentData.startTime),
    end_time: new Date(appointmentData.endTime),
    status: appointmentData.appointmentStatus || 'SCHEDULED',
    gohighlevel_appointment_id: appointmentId,
    updated_at: new Date(),
  };

  if (existingAppointment) {
    await prisma.crm_appointments.update({
      where: { id: existingAppointment.id },
      data: appointmentDbData,
    });
  } else {
    const newAppointment = await prisma.crm_appointments.create({
      data: {
        ...appointmentDbData,
        tenant_id: tenantId,
        created_at: new Date(),
      },
    });

    // Trigger automation for new appointments
    await triggerAppointmentBooked(tenantId, newAppointment.id, lead.id);
  }
}

async function handleOpportunityEvent(tenantId: string, eventData: any) {
  const opportunityData = eventData.opportunity || eventData;
  const contactId = opportunityData.contactId;

  if (!contactId) {
    console.warn('Invalid opportunity data in webhook:', opportunityData);
    return;
  }

  // Find the corresponding lead
  const lead = await prisma.crm_leads.findFirst({
    where: {
      tenant_id: tenantId,
      gohighlevel_contact_id: contactId,
    },
  });

  if (!lead) {
    console.warn(`No lead found for GoHighLevel contact ${contactId}`);
    return;
  }

  // Update lead with opportunity data
  const updateData: any = {
    updated_at: new Date(),
  };

  if (opportunityData.monetaryValue) {
    updateData.estimated_value = parseFloat(opportunityData.monetaryValue);
  }

  if (opportunityData.status) {
    // Map GoHighLevel opportunity status to our lead status
    updateData.status = mapOpportunityStatus(opportunityData.status);
  }

  const oldStatus = lead.status;
  const updatedLead = await prisma.crm_leads.update({
    where: { id: lead.id },
    data: updateData,
  });

  // Trigger automation if status changed
  if (updateData.status && updateData.status !== oldStatus) {
    await triggerLeadStatusChanged(tenantId, lead.id, oldStatus, updateData.status);
  }
}

async function handleMessageEvent(tenantId: string, eventData: any) {
  const messageData = eventData.message || eventData;
  const contactId = messageData.contactId;

  if (!contactId) {
    console.warn('Invalid message data in webhook:', messageData);
    return;
  }

  // Find the corresponding lead
  const lead = await prisma.crm_leads.findFirst({
    where: {
      tenant_id: tenantId,
      gohighlevel_contact_id: contactId,
    },
  });

  if (!lead) {
    console.warn(`No lead found for GoHighLevel contact ${contactId}`);
    return;
  }

  // Log the communication
  await prisma.crm_communication_logs.create({
    data: {
      tenant_id: tenantId,
      lead_id: lead.id,
      type: messageData.type === 'SMS' ? CommunicationType.SMS : CommunicationType.EMAIL,
      subject: messageData.subject || null,
      content: messageData.body || messageData.message,
      direction: eventData.type === 'InboundMessage' ? 'INBOUND' : 'OUTBOUND',
      status: 'RECEIVED',
      gohighlevel_message_id: messageData.id,
      metadata: {
        source: 'gohighlevel_webhook',
        messageType: messageData.type,
      },
      created_at: new Date(),
    },
  });
}

function mapLeadSource(ghlSource?: string): LeadSource {
  if (!ghlSource) return LeadSource.GOHIGHLEVEL;

  const sourceMap: Record<string, LeadSource> = {
    'website': LeadSource.WEBSITE,
    'referral': LeadSource.REFERRAL,
    'social': LeadSource.SOCIAL_MEDIA,
    'facebook': LeadSource.FACEBOOK_ADS,
    'google': LeadSource.GOOGLE_ADS,
    'phone': LeadSource.PHONE,
    'email': LeadSource.EMAIL,
  };

  const normalizedSource = ghlSource.toLowerCase();
  return sourceMap[normalizedSource] || LeadSource.GOHIGHLEVEL;
}

function mapOpportunityStatus(ghlStatus: string): LeadStatus {
  const statusMap: Record<string, LeadStatus> = {
    'open': LeadStatus.NEW,
    'won': LeadStatus.WON,
    'lost': LeadStatus.LOST,
    'abandoned': LeadStatus.LOST,
  };

  return statusMap[ghlStatus.toLowerCase()] || LeadStatus.NEW;
}

// Disable body parser for webhook signature verification
export const config = {
  api: {
    bodyParser: {
      sizeLimit: '1mb',
    },
  },
};
