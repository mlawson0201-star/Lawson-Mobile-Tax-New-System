
import VoiceProcessingInterface from '@/components/automation/voice-processing-interface';

export const dynamic = 'force-dynamic';

export default function VoiceProcessingPage() {
  return (
    <div className="space-y-8">
      <VoiceProcessingInterface />
    </div>
  );
}
