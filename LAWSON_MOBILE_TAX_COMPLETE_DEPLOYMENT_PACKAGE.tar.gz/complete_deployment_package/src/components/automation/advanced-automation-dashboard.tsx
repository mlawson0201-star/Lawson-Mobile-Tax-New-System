
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Shield, 
  TrendingUp, 
  Mic, 
  Building, 
  Gavel,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Settings,
  Zap
} from 'lucide-react';

interface AutomationMetrics {
  overallAutomationLevel: number;
  returnsProcessed24h: number;
  auditDefensesHandled: number;
  businessFormationsCompleted: number;
  voiceProcessingAccuracy: number;
  averageProcessingTime: number;
  clientSatisfactionScore: number;
  errorReductionRate: number;
}

interface ActiveAutomationTask {
  id: string;
  type: string;
  clientName: string;
  progress: number;
  estimatedCompletion: string;
  priority: 'high' | 'medium' | 'low';
}

export default function AdvancedAutomationDashboard() {
  const [metrics, setMetrics] = useState<AutomationMetrics | null>(null);
  const [activeTasks, setActiveTasks] = useState<ActiveAutomationTask[]>([]);
  const [selectedView, setSelectedView] = useState<string>('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAutomationMetrics();
    fetchActiveTasks();
    
    const interval = setInterval(() => {
      fetchAutomationMetrics();
      fetchActiveTasks();
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const fetchAutomationMetrics = async () => {
    try {
      // Mock data - replace with actual API call
      const mockMetrics: AutomationMetrics = {
        overallAutomationLevel: 96.2,
        returnsProcessed24h: 247,
        auditDefensesHandled: 12,
        businessFormationsCompleted: 8,
        voiceProcessingAccuracy: 94.7,
        averageProcessingTime: 3.2,
        clientSatisfactionScore: 4.8,
        errorReductionRate: 87.3
      };
      
      setMetrics(mockMetrics);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching automation metrics:', error);
      setLoading(false);
    }
  };

  const fetchActiveTasks = async () => {
    try {
      // Mock data - replace with actual API call
      const mockTasks: ActiveAutomationTask[] = [
        {
          id: '1',
          type: 'Complex Return Processing',
          clientName: 'Johnson Enterprises',
          progress: 78,
          estimatedCompletion: '12 min',
          priority: 'high'
        },
        {
          id: '2',
          type: 'Audit Defense Generation',
          clientName: 'Sarah Mitchell',
          progress: 45,
          estimatedCompletion: '25 min',
          priority: 'medium'
        },
        {
          id: '3',
          type: 'Business Formation',
          clientName: 'Tech Startup LLC',
          progress: 92,
          estimatedCompletion: '5 min',
          priority: 'high'
        }
      ];
      
      setActiveTasks(mockTasks);
    } catch (error) {
      console.error('Error fetching active tasks:', error);
    }
  };

  const automationModules = [
    {
      id: 'deduction-engine',
      title: 'Advanced Deduction Engine',
      icon: Brain,
      description: 'AI-powered complex deduction analysis',
      status: 'active',
      performance: 97.2
    },
    {
      id: 'audit-defense',
      title: 'Automated Audit Defense',
      icon: Shield,
      description: 'Intelligent IRS correspondence handling',
      status: 'active',
      performance: 94.8
    },
    {
      id: 'predictive-planning',
      title: 'Predictive Tax Planning',
      icon: TrendingUp,
      description: 'Year-round optimization strategies',
      status: 'active',
      performance: 96.5
    },
    {
      id: 'voice-processing',
      title: 'Voice Document Processing',
      icon: Mic,
      description: 'Speech-to-text tax data extraction',
      status: 'active',
      performance: 94.7
    },
    {
      id: 'business-formation',
      title: 'Business Formation Automation',
      icon: Building,
      description: 'Complete entity setup with tax planning',
      status: 'active',
      performance: 98.1
    },
    {
      id: 'tax-court',
      title: 'Automated Tax Court Rep',
      icon: Gavel,
      description: 'Simple case representation',
      status: 'beta',
      performance: 89.3
    }
  ];

  const priorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-500 bg-red-50';
      case 'medium': return 'text-yellow-500 bg-yellow-50';
      case 'low': return 'text-green-500 bg-green-50';
      default: return 'text-gray-500 bg-gray-50';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advanced Automation Center</h1>
          <p className="text-gray-600">95%+ Automation • Next-Generation AI Tax Processing</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-2 bg-green-50 px-4 py-2 rounded-lg">
            <Zap className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">
              {metrics?.overallAutomationLevel}% Automated
            </span>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Returns Processed (24h)</p>
              <p className="text-2xl font-bold text-gray-900">{metrics?.returnsProcessed24h}</p>
            </div>
            <BarChart3 className="h-8 w-8 text-blue-500" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">96.2% Fully Automated</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Audit Defenses</p>
              <p className="text-2xl font-bold text-gray-900">{metrics?.auditDefensesHandled}</p>
            </div>
            <Shield className="h-8 w-8 text-green-500" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">94.8% Success Rate</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Processing Time</p>
              <p className="text-2xl font-bold text-gray-900">{metrics?.averageProcessingTime}m</p>
            </div>
            <Clock className="h-8 w-8 text-purple-500" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">87% Faster than Manual</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Client Satisfaction</p>
              <p className="text-2xl font-bold text-gray-900">{metrics?.clientSatisfactionScore}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-500" />
          </div>
          <div className="mt-4 flex items-center text-sm">
            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-green-600">98% Recommend Us</span>
          </div>
        </motion.div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'active-tasks', label: 'Active Tasks', icon: Clock },
            { id: 'modules', label: 'Automation Modules', icon: Settings },
            { id: 'performance', label: 'Performance', icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedView(tab.id)}
                className={`${
                  selectedView === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Content Area */}
      {selectedView === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Processing Tasks</h3>
              <div className="space-y-4">
                {activeTasks.map((task) => (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-900">{task.type}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${priorityColor(task.priority)}`}>
                          {task.priority}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{task.clientName}</p>
                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex-1 bg-gray-200 rounded-full h-2 mr-4">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${task.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500">{task.estimatedCompletion}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">System Health</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">AI Processing</span>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-600">Optimal</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Voice Recognition</span>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-600">94.7%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Database Performance</span>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-600">Excellent</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Achievements</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-green-500 rounded-full" />
                  <span className="text-sm text-gray-600">Processed 1,000th complex return</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-blue-500 rounded-full" />
                  <span className="text-sm text-gray-600">95% automation milestone reached</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="h-2 w-2 bg-purple-500 rounded-full" />
                  <span className="text-sm text-gray-600">Voice processing launched</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedView === 'modules' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {automationModules.map((module, index) => {
            const Icon = module.icon;
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${module.status === 'active' ? 'bg-green-100' : 'bg-yellow-100'}`}>
                      <Icon className={`h-5 w-5 ${module.status === 'active' ? 'text-green-600' : 'text-yellow-600'}`} />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-gray-900">{module.title}</h3>
                      <p className="text-xs text-gray-500">{module.description}</p>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    module.status === 'active' ? 'text-green-800 bg-green-100' : 'text-yellow-800 bg-yellow-100'
                  }`}>
                    {module.status}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Performance</span>
                    <span className="text-sm font-medium text-gray-900">{module.performance}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${module.performance}%` }}
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
