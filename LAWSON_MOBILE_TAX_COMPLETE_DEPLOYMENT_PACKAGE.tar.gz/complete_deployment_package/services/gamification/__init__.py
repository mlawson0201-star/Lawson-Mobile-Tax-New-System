
"""
Gamification Systems
Engagement mechanics and reward systems for user motivation
"""

from .progress_tracker import TaxProgressTracker
from .achievement_engine import AchievementBadgeEngine
from .leaderboard_manager import TaxSavingsLeaderboard
from .challenge_system import DailyChallengeSystem
from .referral_rewards import ReferralRewardSystem
from .competition_manager import SeasonalCompetitionManager
from .educational_games import TaxEducationGames
from .social_sharing import SocialAchievementSharing
from .loyalty_points import LoyaltyPointsSystem
from .streak_tracker import UsageStreakTracker

__version__ = "1.0.0"
__all__ = [
    "TaxProgressTracker",
    "AchievementBadgeEngine",
    "TaxSavingsLeaderboard",
    "DailyChallengeSystem",
    "ReferralRewardSystem",
    "SeasonalCompetitionManager",
    "TaxEducationGames",
    "SocialAchievementSharing",
    "LoyaltyPointsSystem",
    "UsageStreakTracker"
]
