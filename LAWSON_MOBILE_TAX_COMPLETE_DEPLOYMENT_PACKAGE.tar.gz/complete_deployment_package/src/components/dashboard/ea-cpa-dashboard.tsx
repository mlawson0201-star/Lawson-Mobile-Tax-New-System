
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { 
  UserCheck, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Eye,
  Edit,
  Send
} from 'lucide-react';
import { MetricCard } from '@/components/ui/metric-card';
import { getStatusColor } from '@/lib/utils';

export function EACPADashboard() {
  const { data: session } = useSession() || {};
  const [metrics, setMetrics] = useState({
    pendingReviews: 0,
    completedToday: 0,
    totalReviewed: 0,
    avgReviewTime: 0
  });
  
  const [reviewQueue, setReviewQueue] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading EA/CPA data
    const timer = setTimeout(() => {
      setMetrics({
        pendingReviews: 12,
        completedToday: 8,
        totalReviewed: 247,
        avgReviewTime: 25
      });
      
      setReviewQueue([
        {
          id: '1',
          clientName: 'Sarah Johnson',
          taxYear: '2024',
          returnType: '1040',
          priority: 'high',
          aiConfidence: 0.87,
          submittedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
          complexity: 'complex',
          issues: ['Schedule C validation needed', 'Deduction verification required']
        },
        {
          id: '2',
          clientName: 'Michael Davis',
          taxYear: '2024',
          returnType: '1040',
          priority: 'medium',
          aiConfidence: 0.91,
          submittedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
          complexity: 'standard',
          issues: ['Income verification']
        },
        {
          id: '3',
          clientName: 'Jennifer Wilson',
          taxYear: '2024',
          returnType: '1040',
          priority: 'medium',
          aiConfidence: 0.94,
          submittedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
          complexity: 'standard',
          issues: []
        }
      ]);
      
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.95) return 'text-green-600';
    if (confidence >= 0.85) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="h-8 bg-gray-200 rounded w-64 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-96 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="h-6 bg-gray-200 rounded w-32 mb-4 animate-pulse"></div>
              <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Review Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Review tax returns and ensure accuracy before filing
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Pending Reviews"
          value={metrics.pendingReviews}
          icon={UserCheck}
          description="Returns awaiting review"
          className="border-l-4 border-red-500"
        />
        <MetricCard
          title="Completed Today"
          value={metrics.completedToday}
          icon={CheckCircle}
          description="Returns reviewed today"
          className="border-l-4 border-green-500"
        />
        <MetricCard
          title="Total Reviewed"
          value={metrics.totalReviewed}
          icon={FileText}
          trend={{ value: 12.5, isPositive: true }}
          description="Returns reviewed this season"
        />
        <MetricCard
          title="Avg Review Time"
          value={`${metrics.avgReviewTime}min`}
          icon={Clock}
          trend={{ value: 8.3, isPositive: false }}
          description="Average time per review"
        />
      </div>

      {/* Priority Alert */}
      {reviewQueue.filter(r => r.priority === 'high').length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
            <div>
              <h3 className="text-sm font-medium text-red-800">
                High Priority Reviews Available
              </h3>
              <p className="text-sm text-red-600">
                {reviewQueue.filter(r => r.priority === 'high').length} returns require immediate attention
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Review Queue */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Review Queue</h2>
            <Link
              href="/dashboard/review"
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              View All
            </Link>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Priority
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  AI Confidence
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Complexity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Issues
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Submitted
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reviewQueue.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{item.clientName}</div>
                      <div className="text-sm text-gray-500">{item.taxYear} {item.returnType}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPriorityColor(item.priority)}`}>
                      {item.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${getConfidenceColor(item.aiConfidence)}`}>
                      {Math.round(item.aiConfidence * 100)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      item.complexity === 'complex' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {item.complexity}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {item.issues.length > 0 ? (
                      <div className="text-xs text-gray-600 max-w-xs">
                        {item.issues.slice(0, 2).map((issue: string, idx: number) => (
                          <div key={idx} className="truncate">{issue}</div>
                        ))}
                        {item.issues.length > 2 && (
                          <div className="text-gray-400">+{item.issues.length - 2} more</div>
                        )}
                      </div>
                    ) : (
                      <span className="text-sm text-green-600">No issues</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {Math.floor((Date.now() - item.submittedAt.getTime()) / (1000 * 60 * 60))}h ago
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-purple-600 hover:text-purple-900">
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Today's Goals */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Today's Progress</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Reviews Completed</span>
                <span>{metrics.completedToday}/15</span>
              </div>
              <div className="w-full bg-white rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${(metrics.completedToday / 15) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>High Priority Queue</span>
                <span>{reviewQueue.filter(r => r.priority === 'high').length}/3</span>
              </div>
              <div className="w-full bg-white rounded-full h-2">
                <div 
                  className="bg-red-500 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${(reviewQueue.filter(r => r.priority === 'high').length / 3) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Average Confidence Score</span>
              <span className="text-sm font-medium text-gray-900">91.2%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Returns with Issues</span>
              <span className="text-sm font-medium text-gray-900">
                {reviewQueue.filter(r => r.issues.length > 0).length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Complex Returns</span>
              <span className="text-sm font-medium text-gray-900">
                {reviewQueue.filter(r => r.complexity === 'complex').length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">E-file Ready</span>
              <span className="text-sm font-medium text-green-600">3</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
