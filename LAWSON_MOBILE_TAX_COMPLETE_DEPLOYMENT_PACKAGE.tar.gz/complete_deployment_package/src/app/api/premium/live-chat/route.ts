
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { clientId, topic, priority } = await request.json();

    if (!clientId) {
      return NextResponse.json({ error: 'Client ID is required' }, { status: 400 });
    }

    // Generate unique session token
    const sessionToken = crypto.randomUUID();

    // Find available EA/CPA
    const availableEAs = await prisma.user.findMany({
      where: {
        tenantId: session.user.tenantId,
        role: { in: ['ea_cpa'] },
        active: true,
      },
      include: {
        liveChatSessions: {
          where: {
            status: 'active',
          },
        },
      },
      orderBy: { lastLoginAt: 'desc' },
    });

    // Find EA with least active sessions
    const leastBusyEA = availableEAs.reduce((prev, current) => {
      return (prev.liveChatSessions.length < current.liveChatSessions.length) ? prev : current;
    }, availableEAs[0]);

    // Create chat session
    const chatSession = await prisma.liveChatSession.create({
      data: {
        tenantId: session.user.tenantId,
        clientId,
        eaCpaUserId: leastBusyEA?.id,
        sessionToken,
        topic: topic || 'general',
        priority: priority || 'normal',
        status: leastBusyEA ? 'waiting' : 'waiting',
      },
    });

    // Send initial system message
    await prisma.chatMessage.create({
      data: {
        sessionId: chatSession.id,
        senderId: 'system',
        senderType: 'system',
        message: `Chat session started. Topic: ${topic || 'general'}. ${leastBusyEA ? 'You will be connected with an EA/CPA shortly.' : 'All our tax professionals are currently busy. You will be connected to the next available representative.'}`,
        messageType: 'text',
      },
    });

    // Notify assigned EA/CPA
    if (leastBusyEA) {
      await prisma.pushNotification.create({
        data: {
          tenantId: session.user.tenantId,
          userId: leastBusyEA.id,
          title: 'New Live Chat Request',
          message: `Client chat request for topic: ${topic || 'general'}`,
          notificationType: 'chat_request',
          priority: priority || 'normal',
          payload: {
            sessionId: chatSession.id,
            sessionToken,
            clientId,
            topic,
          },
          deviceTokens: [`user_${leastBusyEA.id}_token`],
        },
      });
    }

    // Get client info for response
    const client = await prisma.client.findUnique({
      where: { id: clientId },
      select: { firstName: true, lastName: true, email: true },
    });

    return NextResponse.json({
      success: true,
      sessionId: chatSession.id,
      sessionToken,
      status: chatSession.status,
      assignedEA: leastBusyEA ? {
        id: leastBusyEA.id,
        name: `${leastBusyEA.firstName} ${leastBusyEA.lastName}`,
      } : null,
      estimatedWaitTime: leastBusyEA ? 0 : 300, // 5 minutes if no EA available
      client: {
        name: `${client?.firstName} ${client?.lastName}`,
        email: client?.email,
      },
    });

  } catch (error: any) {
    console.error('Live chat initiation error:', error);
    return NextResponse.json(
      { error: 'Failed to initiate live chat', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve chat session
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');
    const sessionToken = searchParams.get('sessionToken');

    if (!sessionId && !sessionToken) {
      return NextResponse.json({ error: 'Session ID or token required' }, { status: 400 });
    }

    const chatSession = await prisma.liveChatSession.findFirst({
      where: {
        tenantId: session.user.tenantId,
        ...(sessionId && { id: sessionId }),
        ...(sessionToken && { sessionToken }),
      },
      include: {
        client: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        eaCpaUser: {
          select: { id: true, firstName: true, lastName: true, role: true },
        },
        messages: {
          orderBy: { createdAt: 'asc' },
          take: 100, // Last 100 messages
        },
      },
    });

    if (!chatSession) {
      return NextResponse.json({ error: 'Chat session not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      session: chatSession,
    });

  } catch (error: any) {
    console.error('Get chat session error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve chat session', details: error?.message },
      { status: 500 }
    );
  }
}
