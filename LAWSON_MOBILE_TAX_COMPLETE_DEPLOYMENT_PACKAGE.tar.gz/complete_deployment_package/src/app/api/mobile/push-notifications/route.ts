
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      title,
      message,
      notificationType,
      targetUsers,
      targetClients,
      priority,
      scheduledFor,
      payload,
    } = await request.json();

    if (!title || !message || !notificationType) {
      return NextResponse.json({ error: 'Title, message, and type are required' }, { status: 400 });
    }

    // Get device tokens for targets
    let deviceTokens = [];

    if (targetUsers?.length > 0) {
      const users = await prisma.user.findMany({
        where: {
          id: { in: targetUsers },
          tenantId: session.user.tenantId,
        },
      });
      // In real implementation, you'd store device tokens in user preferences
      deviceTokens.push(...users.map(user => `user_${user.id}_token`));
    }

    if (targetClients?.length > 0) {
      const clients = await prisma.client.findMany({
        where: {
          id: { in: targetClients },
          tenantId: session.user.tenantId,
        },
      });
      deviceTokens.push(...clients.map(client => `client_${client.id}_token`));
    }

    // Create notification record
    const notification = await prisma.pushNotification.create({
      data: {
        tenantId: session.user.tenantId,
        userId: targetUsers?.length === 1 ? targetUsers[0] : null,
        clientId: targetClients?.length === 1 ? targetClients[0] : null,
        title,
        message,
        notificationType,
        priority: priority || 'normal',
        payload: payload || {},
        deviceTokens,
        scheduledFor: scheduledFor ? new Date(scheduledFor) : null,
      },
    });

    // Send immediate notification if not scheduled
    if (!scheduledFor) {
      try {
        // Mock push notification service (replace with actual FCM/APNS)
        const pushResult = await mockPushNotificationService({
          deviceTokens,
          title,
          message,
          data: payload,
        });

        await prisma.pushNotification.update({
          where: { id: notification.id },
          data: {
            sentAt: new Date(),
            deliveryStatus: pushResult,
          },
        });
      } catch (pushError) {
        console.error('Push notification sending failed:', pushError);
      }
    }

    return NextResponse.json({
      success: true,
      notificationId: notification.id,
      scheduled: !!scheduledFor,
      deviceCount: deviceTokens.length,
    });
  } catch (error: any) {
    console.error('Push notification error:', error);
    return NextResponse.json(
      { error: 'Failed to send notification', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to retrieve notification history
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '50');

    const notifications = await prisma.pushNotification.findMany({
      where: {
        tenantId: session.user.tenantId,
        ...(type && { notificationType: type }),
        ...(status === 'sent' && { sentAt: { not: null } }),
        ...(status === 'scheduled' && { sentAt: null, scheduledFor: { not: null } }),
        ...(status === 'pending' && { sentAt: null, scheduledFor: null }),
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    const stats = {
      total: notifications.length,
      sent: notifications.filter(n => n.sentAt).length,
      scheduled: notifications.filter(n => !n.sentAt && n.scheduledFor).length,
      pending: notifications.filter(n => !n.sentAt && !n.scheduledFor).length,
    };

    return NextResponse.json({
      success: true,
      notifications,
      stats,
    });
  } catch (error: any) {
    console.error('Get notifications error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve notifications', details: error?.message },
      { status: 500 }
    );
  }
}

// Mock push notification service (replace with actual implementation)
async function mockPushNotificationService({
  deviceTokens,
  title,
  message,
  data,
}: {
  deviceTokens: string[];
  title: string;
  message: string;
  data: any;
}) {
  // In a real implementation, this would integrate with Firebase Cloud Messaging (FCM)
  // or Apple Push Notification Service (APNS)
  
  const deliveryResults: Record<string, string> = {};
  
  for (const token of deviceTokens) {
    // Simulate delivery (90% success rate)
    const success = Math.random() > 0.1;
    deliveryResults[token] = success ? 'delivered' : 'failed';
  }
  
  return deliveryResults;
}
