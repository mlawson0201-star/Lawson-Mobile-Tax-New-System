
# Temporal Workflow Definitions
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. Workflow Architecture Overview

### 1.1 Temporal.io Integration
Temporal.io provides reliable workflow orchestration for complex business processes in the tax preparation platform. All workflows are designed to be:

- **Durable**: Survive system failures and restarts
- **Reliable**: Guaranteed execution with retry logic
- **Scalable**: Handle thousands of concurrent workflows
- **Observable**: Full visibility into workflow execution
- **Testable**: Deterministic execution for testing

### 1.2 Workflow Categories

```mermaid
graph TB
    subgraph "Client Workflows"
        LEAD[Lead Nurture Workflow]
        INTAKE[Intake Completion Workflow]
        ONBOARD[Client Onboarding Workflow]
    end
    
    subgraph "Tax Processing Workflows"
        DOC[Document Processing Workflow]
        TAX[Tax Preparation Workflow]
        REVIEW[Review & QA Workflow]
        EFILE[E-Filing Workflow]
    end
    
    subgraph "Financial Workflows"
        PAYMENT[Payment Processing Workflow]
        BANK[Bank Product Workflow]
        REVENUE[Revenue Share Workflow]
    end
    
    subgraph "Communication Workflows"
        NOTIFY[Notification Workflow]
        REMINDER[Reminder Workflow]
        UPSELL[Upsell Campaign Workflow]
    end
    
    subgraph "Administrative Workflows"
        TENANT[Tenant Provisioning Workflow]
        COMPLIANCE[Compliance Monitoring Workflow]
        BACKUP[Data Backup Workflow]
    end
```

---

## 2. Client Management Workflows

### 2.1 Lead Nurture Workflow

```typescript
import { proxyActivities, sleep, condition, defineSignal, defineQuery } from '@temporalio/workflow';
import type * as activities from '../activities';

const { sendEmail, sendSMS, updateLeadStatus, checkLeadEngagement } = proxyActivities<typeof activities>({
  startToCloseTimeout: '1 minute',
  retry: {
    initialInterval: '1s',
    maximumInterval: '1m',
    backoffCoefficient: 2,
    maximumAttempts: 3,
  },
});

// Signals for external events
export const leadEngagedSignal = defineSignal<[string]>('leadEngaged');
export const leadConvertedSignal = defineSignal<[string]>('leadConverted');
export const leadUnsubscribedSignal = defineSignal<[]>('leadUnsubscribed');

// Queries for workflow state
export const getLeadStatusQuery = defineQuery<string>('getLeadStatus');

export async function leadNurtureWorkflow(leadId: string): Promise<string> {
  let leadStatus = 'active';
  let engaged = false;
  let converted = false;
  let unsubscribed = false;
  
  // Set up signal handlers
  setHandler(leadEngagedSignal, (engagementType: string) => {
    engaged = true;
  });
  
  setHandler(leadConvertedSignal, (conversionType: string) => {
    converted = true;
    leadStatus = 'converted';
  });
  
  setHandler(leadUnsubscribedSignal, () => {
    unsubscribed = true;
    leadStatus = 'unsubscribed';
  });
  
  setHandler(getLeadStatusQuery, () => leadStatus);
  
  try {
    // Day 0: Welcome sequence
    await sendEmail(leadId, 'welcome_email', {
      template: 'lead_welcome',
      subject: 'Welcome to Lawson Mobile Tax!'
    });
    
    // Day 1: Tax refund estimator
    await sleep('1 day');
    if (unsubscribed || converted) return leadStatus;
    
    await sendEmail(leadId, 'refund_estimator', {
      template: 'refund_estimator',
      subject: 'Estimate Your Tax Refund in 2 Minutes'
    });
    
    // Day 3: Educational content
    await sleep('2 days');
    if (unsubscribed || converted) return leadStatus;
    
    await sendEmail(leadId, 'tax_tips', {
      template: 'tax_education',
      subject: 'Top 5 Tax Deductions You Might Be Missing'
    });
    
    // Day 7: Social proof and testimonials
    await sleep('4 days');
    if (unsubscribed || converted) return leadStatus;
    
    await sendEmail(leadId, 'testimonials', {
      template: 'social_proof',
      subject: 'See How We Helped Others Maximize Their Refunds'
    });
    
    // Day 10: Limited time offer
    await sleep('3 days');
    if (unsubscribed || converted) return leadStatus;
    
    await sendEmail(leadId, 'limited_offer', {
      template: 'special_offer',
      subject: 'Limited Time: $50 Off Your Tax Return'
    });
    
    // Day 14: Final reminder
    await sleep('4 days');
    if (unsubscribed || converted) return leadStatus;
    
    await sendEmail(leadId, 'final_reminder', {
      template: 'final_reminder',
      subject: 'Don\'t Miss Out - Tax Season is Here!'
    });
    
    // Check for engagement after sequence
    const engagement = await checkLeadEngagement(leadId);
    if (engagement.score < 3) {
      // Move to re-engagement campaign
      await sleep('7 days');
      if (!unsubscribed && !converted) {
        await sendEmail(leadId, 'reengagement', {
          template: 'win_back',
          subject: 'We Miss You - Here\'s What\'s New'
        });
      }
    }
    
    // Update final status
    await updateLeadStatus(leadId, leadStatus);
    return leadStatus;
    
  } catch (error) {
    await updateLeadStatus(leadId, 'error');
    throw error;
  }
}
```

### 2.2 Intake Completion Workflow

```typescript
export async function intakeCompletionWorkflow(clientId: string): Promise<string> {
  let intakeStatus = 'started';
  let completed = false;
  
  // Signal handlers
  setHandler(intakeCompletedSignal, () => {
    completed = true;
    intakeStatus = 'completed';
  });
  
  try {
    // Send welcome SMS
    await sendSMS(clientId, {
      message: 'Welcome to Lawson Mobile Tax! Let\'s get your tax return started. Complete your intake at: ${intakeUrl}'
    });
    
    // Day 1: First reminder
    await sleep('1 day');
    if (completed) return intakeStatus;
    
    await sendEmail(clientId, 'intake_reminder_1', {
      template: 'intake_reminder',
      subject: 'Complete Your Tax Return Setup - It Takes 5 Minutes'
    });
    
    // Day 3: Second reminder with incentive
    await sleep('2 days');
    if (completed) return intakeStatus;
    
    await sendEmail(clientId, 'intake_reminder_2', {
      template: 'intake_incentive',
      subject: 'Quick Reminder: Your Tax Return is Waiting'
    });
    
    // Day 7: Phone call attempt
    await sleep('4 days');
    if (completed) return intakeStatus;
    
    await schedulePhoneCall(clientId, {
      purpose: 'intake_assistance',
      priority: 'medium'
    });
    
    // Day 10: Final email reminder
    await sleep('3 days');
    if (completed) return intakeStatus;
    
    await sendEmail(clientId, 'intake_final', {
      template: 'intake_final_reminder',
      subject: 'Last Chance: Complete Your Tax Return Today'
    });
    
    // Day 14: Mark as abandoned
    await sleep('4 days');
    if (!completed) {
      intakeStatus = 'abandoned';
      await updateClientStatus(clientId, 'intake_abandoned');
    }
    
    return intakeStatus;
    
  } catch (error) {
    await updateClientStatus(clientId, 'intake_error');
    throw error;
  }
}
```

---

## 3. Tax Processing Workflows

### 3.1 Document Processing Workflow

```typescript
export async function documentProcessingWorkflow(documentId: string): Promise<DocumentProcessingResult> {
  let processingStatus = 'started';
  
  try {
    // Step 1: Validate document
    const validation = await validateDocument(documentId);
    if (!validation.valid) {
      throw new Error(`Document validation failed: ${validation.errors.join(', ')}`);
    }
    
    processingStatus = 'validated';
    
    // Step 2: OCR Processing
    const ocrResult = await processOCR(documentId, {
      confidence_threshold: 0.85,
      manual_review_threshold: 0.95
    });
    
    processingStatus = 'ocr_completed';
    
    // Step 3: Data extraction
    const extractedData = await extractTaxData(documentId, ocrResult);
    
    processingStatus = 'data_extracted';
    
    // Step 4: Confidence scoring
    const confidenceScore = await calculateConfidenceScore(extractedData);
    
    // Step 5: Determine if manual review needed
    if (confidenceScore < 0.95) {
      await createReviewTask(documentId, {
        priority: confidenceScore < 0.85 ? 'high' : 'medium',
        reason: 'low_confidence_score',
        confidence: confidenceScore
      });
      
      processingStatus = 'manual_review_required';
      
      // Wait for manual review completion
      await condition(() => manualReviewCompleted, '24 hours');
    }
    
    // Step 6: Update tax return with extracted data
    await updateTaxReturnData(documentId, extractedData);
    
    processingStatus = 'completed';
    
    // Step 7: Trigger tax calculation if all documents processed
    const allDocumentsProcessed = await checkAllDocumentsProcessed(documentId);
    if (allDocumentsProcessed) {
      await startChildWorkflow(taxCalculationWorkflow, {
        args: [getTaxReturnId(documentId)],
        workflowId: `tax-calc-${getTaxReturnId(documentId)}`
      });
    }
    
    return {
      status: processingStatus,
      confidenceScore,
      extractedData,
      manualReviewRequired: confidenceScore < 0.95
    };
    
  } catch (error) {
    processingStatus = 'failed';
    
    // Create error task for manual intervention
    await createErrorTask(documentId, {
      error: error.message,
      processingStep: processingStatus
    });
    
    throw error;
  }
}
```

### 3.2 Tax Preparation Workflow

```typescript
export async function taxPreparationWorkflow(taxReturnId: string): Promise<TaxPreparationResult> {
  let preparationStatus = 'started';
  let requiresHumanReview = false;
  
  try {
    // Step 1: Gather all documents and data
    const taxData = await gatherTaxData(taxReturnId);
    preparationStatus = 'data_gathered';
    
    // Step 2: AI-powered tax calculation
    const calculations = await calculateTaxes(taxData, {
      use_ai_reasoning: true,
      cross_validate: true
    });
    
    preparationStatus = 'calculations_completed';
    
    // Step 3: Validate calculations
    const validation = await validateCalculations(calculations, taxData);
    
    // Step 4: Determine if human review required
    const reviewCriteria = await evaluateReviewCriteria(taxData, calculations);
    requiresHumanReview = reviewCriteria.requiresReview;
    
    if (requiresHumanReview) {
      // Create review task
      await createReviewTask(taxReturnId, {
        type: 'tax_review',
        priority: reviewCriteria.priority,
        reasons: reviewCriteria.reasons,
        assignTo: reviewCriteria.suggestedReviewer
      });
      
      preparationStatus = 'pending_review';
      
      // Wait for human review
      await condition(() => humanReviewCompleted, '48 hours');
      
      // Get reviewed calculations
      const reviewedCalculations = await getReviewedCalculations(taxReturnId);
      calculations = reviewedCalculations;
    }
    
    // Step 5: Generate tax forms
    const taxForms = await generateTaxForms(taxReturnId, calculations);
    preparationStatus = 'forms_generated';
    
    // Step 6: Final validation
    const finalValidation = await performFinalValidation(taxForms);
    if (!finalValidation.valid) {
      throw new Error(`Final validation failed: ${finalValidation.errors.join(', ')}`);
    }
    
    // Step 7: Update return status
    await updateTaxReturnStatus(taxReturnId, 'ready_for_client_review');
    preparationStatus = 'completed';
    
    // Step 8: Notify client
    await sendClientNotification(taxReturnId, {
      type: 'return_ready',
      template: 'return_ready_for_review'
    });
    
    return {
      status: preparationStatus,
      calculations,
      taxForms,
      requiresHumanReview,
      totalFee: calculations.totalFee,
      refundAmount: calculations.refundAmount
    };
    
  } catch (error) {
    preparationStatus = 'failed';
    
    await updateTaxReturnStatus(taxReturnId, 'preparation_failed');
    await createErrorTask(taxReturnId, {
      error: error.message,
      step: preparationStatus
    });
    
    throw error;
  }
}
```

### 3.3 E-Filing Workflow

```typescript
export async function eFilingWorkflow(taxReturnId: string): Promise<EFilingResult> {
  let filingStatus = 'started';
  let submissionId: string;
  
  try {
    // Step 1: Pre-filing validation
    const preFilingCheck = await performPreFilingValidation(taxReturnId);
    if (!preFilingCheck.valid) {
      throw new Error(`Pre-filing validation failed: ${preFilingCheck.errors.join(', ')}`);
    }
    
    filingStatus = 'validated';
    
    // Step 2: Generate e-file package
    const eFilePackage = await generateEFilePackage(taxReturnId);
    filingStatus = 'package_generated';
    
    // Step 3: Submit to OLT
    const submission = await submitToOLT(eFilePackage);
    submissionId = submission.id;
    filingStatus = 'submitted';
    
    // Step 4: Monitor submission status
    let attempts = 0;
    const maxAttempts = 144; // 24 hours with 10-minute intervals
    
    while (attempts < maxAttempts) {
      await sleep('10 minutes');
      
      const status = await checkSubmissionStatus(submissionId);
      
      switch (status.status) {
        case 'accepted':
          filingStatus = 'accepted';
          await updateTaxReturnStatus(taxReturnId, 'filed_accepted');
          await sendClientNotification(taxReturnId, {
            type: 'return_accepted',
            template: 'efile_accepted'
          });
          
          // Start upsell workflow
          await startChildWorkflow(upsellWorkflow, {
            args: [taxReturnId],
            workflowId: `upsell-${taxReturnId}`
          });
          
          return {
            status: filingStatus,
            submissionId,
            acceptanceDate: status.acceptedAt,
            federalId: status.federalId,
            stateId: status.stateId
          };
          
        case 'rejected':
          filingStatus = 'rejected';
          
          // Handle rejection
          const rejectionDetails = await handleRejection(submissionId, status.rejectionCodes);
          
          if (rejectionDetails.canRetry) {
            // Create correction task
            await createCorrectionTask(taxReturnId, rejectionDetails);
            
            // Wait for corrections
            await condition(() => correctionsCompleted, '48 hours');
            
            // Retry submission
            const correctedPackage = await generateEFilePackage(taxReturnId);
            const retrySubmission = await submitToOLT(correctedPackage);
            submissionId = retrySubmission.id;
            filingStatus = 'resubmitted';
            
            // Reset attempt counter for retry
            attempts = 0;
          } else {
            throw new Error(`E-filing rejected with non-retryable errors: ${status.rejectionCodes.join(', ')}`);
          }
          break;
          
        case 'processing':
          // Continue monitoring
          attempts++;
          break;
          
        default:
          throw new Error(`Unknown submission status: ${status.status}`);
      }
    }
    
    // Timeout reached
    throw new Error('E-filing status check timeout reached');
    
  } catch (error) {
    filingStatus = 'failed';
    
    await updateTaxReturnStatus(taxReturnId, 'filing_failed');
    await createErrorTask(taxReturnId, {
      error: error.message,
      submissionId,
      step: filingStatus
    });
    
    throw error;
  }
}
```

---

## 4. Financial Workflows

### 4.1 Payment Processing Workflow

```typescript
export async function paymentProcessingWorkflow(paymentId: string): Promise<PaymentResult> {
  let paymentStatus = 'started';
  
  try {
    // Step 1: Validate payment request
    const payment = await getPaymentDetails(paymentId);
    const validation = await validatePaymentRequest(payment);
    
    if (!validation.valid) {
      throw new Error(`Payment validation failed: ${validation.errors.join(', ')}`);
    }
    
    paymentStatus = 'validated';
    
    // Step 2: Process payment with Stripe
    const stripeResult = await processStripePayment(payment);
    paymentStatus = 'processing';
    
    // Step 3: Handle payment result
    if (stripeResult.status === 'succeeded') {
      paymentStatus = 'succeeded';
      
      // Step 4: Calculate revenue split for white-label
      if (payment.tenantId) {
        const revenueShare = await calculateRevenueShare(payment);
        await processRevenueShare(revenueShare);
      }
      
      // Step 5: Update tax return status
      await updateTaxReturnStatus(payment.taxReturnId, 'paid');
      
      // Step 6: Send confirmation
      await sendPaymentConfirmation(payment.clientId, {
        amount: payment.amount,
        paymentMethod: payment.paymentMethod,
        receiptUrl: stripeResult.receiptUrl
      });
      
      // Step 7: Continue with tax preparation
      await startChildWorkflow(taxPreparationWorkflow, {
        args: [payment.taxReturnId],
        workflowId: `tax-prep-${payment.taxReturnId}`
      });
      
    } else if (stripeResult.status === 'requires_action') {
      paymentStatus = 'requires_action';
      
      // Wait for customer action
      await condition(() => customerActionCompleted, '1 hour');
      
      // Check final status
      const finalResult = await checkStripePaymentStatus(stripeResult.paymentIntentId);
      if (finalResult.status === 'succeeded') {
        paymentStatus = 'succeeded';
        // Continue with success flow...
      } else {
        paymentStatus = 'failed';
        throw new Error('Customer action failed or timed out');
      }
      
    } else {
      paymentStatus = 'failed';
      throw new Error(`Payment failed: ${stripeResult.failureReason}`);
    }
    
    return {
      status: paymentStatus,
      stripePaymentIntentId: stripeResult.paymentIntentId,
      amount: payment.amount,
      processedAt: new Date()
    };
    
  } catch (error) {
    paymentStatus = 'failed';
    
    await updatePaymentStatus(paymentId, 'failed');
    await sendPaymentFailureNotification(payment.clientId, {
      error: error.message,
      retryUrl: generateRetryUrl(paymentId)
    });
    
    throw error;
  }
}
```

### 4.2 Bank Product Workflow

```typescript
export async function bankProductWorkflow(applicationId: string): Promise<BankProductResult> {
  let applicationStatus = 'started';
  
  try {
    // Step 1: Get application details
    const application = await getBankProductApplication(applicationId);
    applicationStatus = 'retrieved';
    
    // Step 2: Eligibility check
    const eligibility = await checkEPSEligibility(application);
    if (!eligibility.eligible) {
      applicationStatus = 'ineligible';
      
      await updateApplicationStatus(applicationId, 'declined');
      await sendDeclinationNotification(application.clientId, {
        reasons: eligibility.reasons
      });
      
      return {
        status: applicationStatus,
        eligible: false,
        reasons: eligibility.reasons
      };
    }
    
    applicationStatus = 'eligible';
    
    // Step 3: Identity verification with Persona
    const identityVerification = await initiateIdentityVerification(application.clientId);
    applicationStatus = 'identity_verification_started';
    
    // Wait for identity verification completion
    await condition(() => identityVerificationCompleted, '24 hours');
    
    const verificationResult = await getIdentityVerificationResult(identityVerification.inquiryId);
    if (!verificationResult.passed) {
      applicationStatus = 'identity_verification_failed';
      
      await updateApplicationStatus(applicationId, 'declined');
      await sendDeclinationNotification(application.clientId, {
        reasons: ['Identity verification failed']
      });
      
      return {
        status: applicationStatus,
        identityVerified: false
      };
    }
    
    applicationStatus = 'identity_verified';
    
    // Step 4: Submit to EPS Financial
    const epsSubmission = await submitToEPS(application, verificationResult);
    applicationStatus = 'submitted_to_eps';
    
    // Step 5: Monitor EPS underwriting
    let underwritingAttempts = 0;
    const maxUnderwritingAttempts = 72; // 24 hours with 20-minute intervals
    
    while (underwritingAttempts < maxUnderwritingAttempts) {
      await sleep('20 minutes');
      
      const epsStatus = await checkEPSApplicationStatus(epsSubmission.applicationId);
      
      switch (epsStatus.status) {
        case 'approved':
          applicationStatus = 'approved';
          
          await updateApplicationStatus(applicationId, 'approved');
          await sendApprovalNotification(application.clientId, {
            amount: epsStatus.approvedAmount,
            terms: epsStatus.terms
          });
          
          // Wait for funding
          await condition(() => fundingCompleted, '2 hours');
          
          applicationStatus = 'funded';
          await sendFundingNotification(application.clientId, {
            amount: epsStatus.approvedAmount,
            accountInfo: epsStatus.fundingAccount
          });
          
          return {
            status: applicationStatus,
            approved: true,
            amount: epsStatus.approvedAmount,
            fundedAt: new Date()
          };
          
        case 'declined':
          applicationStatus = 'declined';
          
          await updateApplicationStatus(applicationId, 'declined');
          await sendDeclinationNotification(application.clientId, {
            reasons: epsStatus.declineReasons
          });
          
          return {
            status: applicationStatus,
            approved: false,
            reasons: epsStatus.declineReasons
          };
          
        case 'under_review':
          underwritingAttempts++;
          break;
          
        default:
          throw new Error(`Unknown EPS status: ${epsStatus.status}`);
      }
    }
    
    // Underwriting timeout
    throw new Error('EPS underwriting timeout reached');
    
  } catch (error) {
    applicationStatus = 'failed';
    
    await updateApplicationStatus(applicationId, 'error');
    await createErrorTask(applicationId, {
      error: error.message,
      step: applicationStatus
    });
    
    throw error;
  }
}
```

---

## 5. Communication Workflows

### 5.1 Notification Workflow

```typescript
export async function notificationWorkflow(notificationId: string): Promise<NotificationResult> {
  let deliveryStatus = 'started';
  
  try {
    // Step 1: Get notification details
    const notification = await getNotificationDetails(notificationId);
    deliveryStatus = 'retrieved';
    
    // Step 2: Check user preferences
    const preferences = await getUserNotificationPreferences(notification.userId);
    
    // Step 3: Determine delivery channels
    const channels = determineDeliveryChannels(notification.type, preferences);
    
    const deliveryResults: ChannelResult[] = [];
    
    // Step 4: Send via each channel
    for (const channel of channels) {
      try {
        let result: ChannelResult;
        
        switch (channel) {
          case 'email':
            result = await sendEmailNotification(notification);
            break;
          case 'sms':
            result = await sendSMSNotification(notification);
            break;
          case 'push':
            result = await sendPushNotification(notification);
            break;
          case 'in_app':
            result = await createInAppNotification(notification);
            break;
          default:
            throw new Error(`Unknown channel: ${channel}`);
        }
        
        deliveryResults.push(result);
        
      } catch (channelError) {
        deliveryResults.push({
          channel,
          status: 'failed',
          error: channelError.message
        });
      }
    }
    
    // Step 5: Update delivery status
    const overallStatus = deliveryResults.some(r => r.status === 'delivered') ? 'delivered' : 'failed';
    deliveryStatus = overallStatus;
    
    await updateNotificationStatus(notificationId, {
      status: deliveryStatus,
      deliveryResults,
      deliveredAt: overallStatus === 'delivered' ? new Date() : undefined
    });
    
    return {
      status: deliveryStatus,
      channels: deliveryResults
    };
    
  } catch (error) {
    deliveryStatus = 'failed';
    
    await updateNotificationStatus(notificationId, {
      status: 'failed',
      error: error.message
    });
    
    throw error;
  }
}
```

### 5.2 Reminder Workflow

```typescript
export async function reminderWorkflow(reminderId: string): Promise<ReminderResult> {
  try {
    const reminder = await getReminderDetails(reminderId);
    
    // Schedule reminders based on type
    switch (reminder.type) {
      case 'tax_deadline':
        return await taxDeadlineReminderFlow(reminder);
      case 'document_upload':
        return await documentUploadReminderFlow(reminder);
      case 'payment_due':
        return await paymentDueReminderFlow(reminder);
      case 'appointment':
        return await appointmentReminderFlow(reminder);
      default:
        throw new Error(`Unknown reminder type: ${reminder.type}`);
    }
    
  } catch (error) {
    await updateReminderStatus(reminderId, 'failed');
    throw error;
  }
}

async function taxDeadlineReminderFlow(reminder: Reminder): Promise<ReminderResult> {
  const deadlineDate = new Date(reminder.deadlineDate);
  const now = new Date();
  
  // 30 days before deadline
  const thirtyDaysBefore = new Date(deadlineDate);
  thirtyDaysBefore.setDate(thirtyDaysBefore.getDate() - 30);
  
  if (now < thirtyDaysBefore) {
    await sleep(thirtyDaysBefore.getTime() - now.getTime());
  }
  
  await sendNotification(reminder.userId, {
    type: 'tax_deadline_30_days',
    template: 'tax_deadline_reminder',
    data: { daysRemaining: 30, deadlineDate }
  });
  
  // 14 days before deadline
  await sleep('16 days');
  await sendNotification(reminder.userId, {
    type: 'tax_deadline_14_days',
    template: 'tax_deadline_urgent',
    data: { daysRemaining: 14, deadlineDate }
  });
  
  // 7 days before deadline
  await sleep('7 days');
  await sendNotification(reminder.userId, {
    type: 'tax_deadline_7_days',
    template: 'tax_deadline_critical',
    data: { daysRemaining: 7, deadlineDate }
  });
  
  // 1 day before deadline
  await sleep('6 days');
  await sendNotification(reminder.userId, {
    type: 'tax_deadline_1_day',
    template: 'tax_deadline_final',
    data: { daysRemaining: 1, deadlineDate }
  });
  
  return { status: 'completed', remindersSent: 4 };
}
```

---

## 6. Administrative Workflows

### 6.1 Tenant Provisioning Workflow

```typescript
export async function tenantProvisioningWorkflow(applicationId: string): Promise<TenantProvisioningResult> {
  let provisioningStatus = 'started';
  
  try {
    // Step 1: Get application details
    const application = await getTenantApplication(applicationId);
    provisioningStatus = 'application_retrieved';
    
    // Step 2: Background check
    const backgroundCheck = await performBackgroundCheck(application);
    if (!backgroundCheck.passed) {
      provisioningStatus = 'background_check_failed';
      
      await updateApplicationStatus(applicationId, 'rejected');
      await sendRejectionNotification(application.applicantEmail, {
        reasons: backgroundCheck.issues
      });
      
      return {
        status: provisioningStatus,
        approved: false,
        reasons: backgroundCheck.issues
      };
    }
    
    provisioningStatus = 'background_check_passed';
    
    // Step 3: Create Stripe Connect account
    const stripeAccount = await createStripeConnectAccount(application);
    provisioningStatus = 'stripe_account_created';
    
    // Step 4: Create tenant record
    const tenant = await createTenant({
      ...application,
      stripeConnectAccountId: stripeAccount.id,
      status: 'pending_onboarding'
    });
    
    provisioningStatus = 'tenant_created';
    
    // Step 5: Configure subdomain
    const subdomain = await configureSubdomain(tenant.domain);
    provisioningStatus = 'subdomain_configured';
    
    // Step 6: Deploy tenant instance
    const deployment = await deployTenantInstance(tenant.id);
    provisioningStatus = 'instance_deployed';
    
    // Step 7: Create admin user
    const adminUser = await createTenantAdmin(tenant.id, application);
    provisioningStatus = 'admin_user_created';
    
    // Step 8: Send onboarding instructions
    await sendOnboardingInstructions(application.applicantEmail, {
      tenantId: tenant.id,
      domain: tenant.domain,
      stripeOnboardingUrl: stripeAccount.onboardingUrl,
      adminCredentials: adminUser.credentials
    });
    
    provisioningStatus = 'onboarding_sent';
    
    // Step 9: Monitor onboarding completion
    await condition(() => onboardingCompleted, '7 days');
    
    // Step 10: Activate tenant
    await activateTenant(tenant.id);
    provisioningStatus = 'activated';
    
    // Step 11: Send welcome message
    await sendWelcomeMessage(application.applicantEmail, {
      tenantDomain: tenant.domain,
      supportResources: getSupportResources()
    });
    
    return {
      status: provisioningStatus,
      tenantId: tenant.id,
      domain: tenant.domain,
      stripeAccountId: stripeAccount.id
    };
    
  } catch (error) {
    provisioningStatus = 'failed';
    
    await updateApplicationStatus(applicationId, 'error');
    await createErrorTask(applicationId, {
      error: error.message,
      step: provisioningStatus
    });
    
    throw error;
  }
}
```

### 6.2 Compliance Monitoring Workflow

```typescript
export async function complianceMonitoringWorkflow(): Promise<ComplianceResult> {
  const monitoringResults: ComplianceCheck[] = [];
  
  try {
    // Daily compliance checks
    while (true) {
      // Check 1: Data retention compliance
      const retentionCheck = await checkDataRetentionCompliance();
      monitoringResults.push(retentionCheck);
      
      if (!retentionCheck.compliant) {
        await createComplianceAlert('data_retention', retentionCheck.issues);
      }
      
      // Check 2: Access control compliance
      const accessCheck = await checkAccessControlCompliance();
      monitoringResults.push(accessCheck);
      
      if (!accessCheck.compliant) {
        await createComplianceAlert('access_control', accessCheck.issues);
      }
      
      // Check 3: Encryption compliance
      const encryptionCheck = await checkEncryptionCompliance();
      monitoringResults.push(encryptionCheck);
      
      if (!encryptionCheck.compliant) {
        await createComplianceAlert('encryption', encryptionCheck.issues);
      }
      
      // Check 4: Audit log integrity
      const auditCheck = await checkAuditLogIntegrity();
      monitoringResults.push(auditCheck);
      
      if (!auditCheck.compliant) {
        await createComplianceAlert('audit_logs', auditCheck.issues);
      }
      
      // Check 5: Vendor compliance
      const vendorCheck = await checkVendorCompliance();
      monitoringResults.push(vendorCheck);
      
      if (!vendorCheck.compliant) {
        await createComplianceAlert('vendor_compliance', vendorCheck.issues);
      }
      
      // Generate daily compliance report
      await generateComplianceReport(monitoringResults);
      
      // Wait 24 hours for next check
      await sleep('24 hours');
      
      // Clear results for next iteration
      monitoringResults.length = 0;
    }
    
  } catch (error) {
    await createComplianceAlert('monitoring_failure', [error.message]);
    throw error;
  }
}
```

---

## 7. Workflow Testing

### 7.1 Test Framework Setup

```typescript
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker } from '@temporalio/worker';
import * as activities from '../activities';

describe('Tax Processing Workflows', () => {
  let testEnv: TestWorkflowEnvironment;
  
  beforeAll(async () => {
    testEnv = await TestWorkflowEnvironment.createTimeSkipping();
  });
  
  afterAll(async () => {
    await testEnv?.teardown();
  });
  
  beforeEach(async () => {
    const { client, nativeConnection } = testEnv;
    const worker = await Worker.create({
      connection: nativeConnection,
      taskQueue: 'test-task-queue',
      workflowsPath: require.resolve('../workflows'),
      activities,
    });
    
    await worker.runUntil(async () => {
      // Test setup
    });
  });
});
```

### 7.2 Workflow Test Examples

```typescript
describe('Document Processing Workflow', () => {
  it('should process document successfully with high confidence', async () => {
    const { client } = testEnv;
    
    // Mock activities
    const mockActivities = {
      validateDocument: jest.fn().mockResolvedValue({ valid: true }),
      processOCR: jest.fn().mockResolvedValue({ confidence: 0.98 }),
      extractTaxData: jest.fn().mockResolvedValue({ w2Data: {} }),
      calculateConfidenceScore: jest.fn().mockResolvedValue(0.98),
      updateTaxReturnData: jest.fn().mockResolvedValue(true),
      checkAllDocumentsProcessed: jest.fn().mockResolvedValue(true)
    };
    
    const result = await client.workflow.execute(documentProcessingWorkflow, {
      args: ['test-document-id'],
      workflowId: 'test-document-processing',
      taskQueue: 'test-task-queue',
    });
    
    expect(result.status).toBe('completed');
    expect(result.confidenceScore).toBe(0.98);
    expect(result.manualReviewRequired).toBe(false);
  });
  
  it('should require manual review for low confidence', async () => {
    const { client } = testEnv;
    
    // Mock low confidence scenario
    const mockActivities = {
      validateDocument: jest.fn().mockResolvedValue({ valid: true }),
      processOCR: jest.fn().mockResolvedValue({ confidence: 0.80 }),
      extractTaxData: jest.fn().mockResolvedValue({ w2Data: {} }),
      calculateConfidenceScore: jest.fn().mockResolvedValue(0.80),
      createReviewTask: jest.fn().mockResolvedValue(true)
    };
    
    const result = await client.workflow.execute(documentProcessingWorkflow, {
      args: ['test-document-id'],
      workflowId: 'test-document-processing-low-confidence',
      taskQueue: 'test-task-queue',
    });
    
    expect(result.status).toBe('manual_review_required');
    expect(result.confidenceScore).toBe(0.80);
    expect(result.manualReviewRequired).toBe(true);
  });
});
```

---

## 8. Workflow Monitoring and Observability

### 8.1 Workflow Metrics

```typescript
interface WorkflowMetrics {
  workflowType: string;
  status: 'running' | 'completed' | 'failed' | 'timed_out';
  duration: number;
  retryCount: number;
  activityFailures: number;
  customMetrics: Record<string, number>;
}

class WorkflowMonitoringService {
  async collectWorkflowMetrics(): Promise<WorkflowMetrics[]> {
    const workflows = await this.temporalClient.workflow.list({
      query: 'WorkflowType="TaxPreparationWorkflow" AND ExecutionStatus="Running"'
    });
    
    const metrics: WorkflowMetrics[] = [];
    
    for (const workflow of workflows) {
      const history = await this.temporalClient.workflow.getHistory({
        workflowId: workflow.workflowId,
        runId: workflow.runId
      });
      
      const metric = this.calculateMetrics(workflow, history);
      metrics.push(metric);
    }
    
    return metrics;
  }
  
  async createWorkflowDashboard(): Promise<Dashboard> {
    const metrics = await this.collectWorkflowMetrics();
    
    return {
      totalWorkflows: metrics.length,
      runningWorkflows: metrics.filter(m => m.status === 'running').length,
      completedWorkflows: metrics.filter(m => m.status === 'completed').length,
      failedWorkflows: metrics.filter(m => m.status === 'failed').length,
      averageDuration: this.calculateAverageDuration(metrics),
      topFailureReasons: this.getTopFailureReasons(metrics)
    };
  }
}
```

### 8.2 Workflow Alerting

```typescript
class WorkflowAlertingService {
  async monitorWorkflowHealth(): Promise<void> {
    // Monitor for stuck workflows
    const stuckWorkflows = await this.findStuckWorkflows();
    if (stuckWorkflows.length > 0) {
      await this.sendAlert('stuck_workflows', {
        count: stuckWorkflows.length,
        workflows: stuckWorkflows
      });
    }
    
    // Monitor for high failure rates
    const failureRate = await this.calculateFailureRate();
    if (failureRate > 0.05) { // 5% threshold
      await this.sendAlert('high_failure_rate', {
        rate: failureRate,
        threshold: 0.05
      });
    }
    
    // Monitor for SLA breaches
    const slaBreaches = await this.findSLABreaches();
    if (slaBreaches.length > 0) {
      await this.sendAlert('sla_breaches', {
        breaches: slaBreaches
      });
    }
  }
}
```

---

*Document Version: 1.0*
*Last Updated: August 22, 2025*
*Next Review: September 22, 2025*

---

## Appendices

### Appendix A: Workflow Configuration
[INSERT TEMPORAL CONFIGURATION DETAILS]

### Appendix B: Activity Implementations
[INSERT ACTIVITY FUNCTION SPECIFICATIONS]

### Appendix C: Error Handling Patterns
[INSERT ERROR HANDLING STRATEGIES]

### Appendix D: Performance Optimization
[INSERT WORKFLOW PERFORMANCE GUIDELINES]


