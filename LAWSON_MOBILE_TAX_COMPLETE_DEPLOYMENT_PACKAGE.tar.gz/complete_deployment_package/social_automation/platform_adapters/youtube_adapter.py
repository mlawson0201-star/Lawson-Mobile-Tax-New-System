
"""
YouTube adapter using YouTube Data API v3
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class YouTubeAdapter(BasePlatformAdapter):
    """Adapter for YouTube using Data API v3"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.api_key = credentials.get('api_key')
        self.access_token = credentials.get('access_token')
        self.client_id = credentials.get('client_id')
        self.client_secret = credentials.get('client_secret')
        self.base_url = "https://www.googleapis.com/youtube/v3"
        
    async def authenticate(self) -> bool:
        """Verify access token"""
        try:
            url = f"{self.base_url}/channels"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            params = {
                'part': 'snippet',
                'mine': 'true'
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                items = result.get('items', [])
                if items:
                    channel = items[0]
                    channel_title = channel.get('snippet', {}).get('title', 'Unknown')
                    logger.info(f"Authenticated as: {channel_title}")
                    return True
                else:
                    logger.error("No channel found for authenticated user")
                    return False
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Upload video to YouTube"""
        try:
            if not media_urls or len(media_urls) == 0:
                return {"success": False, "error": "YouTube requires video content"}
            
            video_url = media_urls[0]
            
            # Format description with hashtags
            description = content
            if hashtags:
                hashtag_text = self.format_hashtags(hashtags)
                description = f"{content}\n\n{hashtag_text}"
            
            # YouTube allows up to 5000 characters for descriptions
            description = self.validate_content_length(description, 5000)
            
            # Video metadata
            video_metadata = {
                'snippet': {
                    'title': kwargs.get('title', 'Untitled Video'),
                    'description': description,
                    'tags': hashtags or [],
                    'categoryId': kwargs.get('category_id', '22'),  # People & Blogs
                    'defaultLanguage': kwargs.get('language', 'en'),
                    'defaultAudioLanguage': kwargs.get('audio_language', 'en')
                },
                'status': {
                    'privacyStatus': kwargs.get('privacy_status', 'private'),  # private, unlisted, public
                    'embeddable': kwargs.get('embeddable', True),
                    'license': kwargs.get('license', 'youtube'),  # youtube or creativeCommon
                    'publicStatsViewable': kwargs.get('public_stats', True)
                }
            }
            
            # For actual video upload, we would need to:
            # 1. Download video from URL
            # 2. Use resumable upload protocol
            # 3. Upload video binary data
            
            # This is a placeholder implementation
            return {
                "success": True,
                "message": "YouTube video upload initiated (placeholder)",
                "video_metadata": video_metadata,
                "note": "Actual video upload requires binary data handling"
            }
            
        except Exception as e:
            logger.error(f"Error uploading to YouTube: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a YouTube video"""
        try:
            # YouTube supports scheduled publishing
            scheduled_timestamp = scheduled_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
            
            kwargs['privacy_status'] = 'private'  # Set to private initially
            kwargs['publish_at'] = scheduled_timestamp
            
            # Upload video first (would be implemented in post_content)
            upload_result = await self.post_content(content, media_urls, hashtags, **kwargs)
            
            if upload_result.get('success'):
                return {
                    "success": True,
                    "message": "YouTube video scheduled",
                    "scheduled_time": scheduled_time.isoformat(),
                    "upload_result": upload_result
                }
            else:
                return upload_result
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a YouTube video"""
        try:
            # Get video statistics
            url = f"{self.base_url}/videos"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            params = {
                'part': 'statistics,snippet',
                'id': post_id
            }
            
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                items = result.get('items', [])
                
                if items:
                    video = items[0]
                    stats = video.get('statistics', {})
                    snippet = video.get('snippet', {})
                    
                    analytics = {
                        "post_id": post_id,
                        "views": int(stats.get('viewCount', 0)),
                        "likes": int(stats.get('likeCount', 0)),
                        "comments": int(stats.get('commentCount', 0)),
                        "favorites": int(stats.get('favoriteCount', 0)),
                        "published_at": snippet.get('publishedAt'),
                        "title": snippet.get('title', ''),
                        "description": snippet.get('description', ''),
                        "duration": snippet.get('duration', '')
                    }
                    
                    return {"success": True, "analytics": analytics}
                else:
                    return {"success": False, "error": "Video not found"}
            else:
                error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a YouTube video"""
        try:
            url = f"{self.base_url}/videos"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            params = {'id': post_id}
            
            response = requests.delete(url, headers=headers, params=params)
            return response.status_code == 204
            
        except Exception as e:
            logger.error(f"Error deleting YouTube video: {str(e)}")
            return False
    
    async def create_community_post(self, content: str, **kwargs) -> Dict[str, Any]:
        """Create a YouTube Community post"""
        try:
            # YouTube Community posts are not available via public API
            # This would require YouTube Partner Program and special access
            
            return {
                "success": False,
                "error": "YouTube Community posts not available via public API",
                "note": "Requires YouTube Partner Program and special API access"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def create_short(self, content: str, media_urls: List[str] = None,
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Create a YouTube Short"""
        try:
            # YouTube Shorts are regular videos with specific requirements:
            # - Vertical aspect ratio (9:16)
            # - Duration under 60 seconds
            # - #Shorts hashtag
            
            if not hashtags:
                hashtags = []
            
            # Add #Shorts hashtag if not present
            if 'Shorts' not in [tag.replace('#', '') for tag in hashtags]:
                hashtags.append('Shorts')
            
            # Set specific parameters for Shorts
            kwargs['title'] = kwargs.get('title', 'YouTube Short')
            kwargs['category_id'] = '24'  # Entertainment category often used for Shorts
            
            # Use regular video upload with Shorts-specific metadata
            return await self.post_content(content, media_urls, hashtags, **kwargs)
            
        except Exception as e:
            return {"success": False, "error": str(e)}
