
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const WorkflowRuleSchema = z.object({
  tenantId: z.string(),
  ruleName: z.string(),
  ruleType: z.enum(['routing', 'escalation', 'automation', 'notification']),
  conditions: z.record(z.any()),
  actions: z.record(z.any()),
  priority: z.number().min(0).max(100).default(50),
  active: z.boolean().default(true),
});

const WorkflowExecutionSchema = z.object({
  ruleId: z.string().optional(),
  taxReturnId: z.string().optional(),
  triggerData: z.record(z.any()),
  triggerType: z.enum(['tax_return_created', 'document_uploaded', 'client_message', 'deadline_approaching', 'audit_risk_high']),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;

    if (action === 'create_rule') {
      return await createWorkflowRule(body);
    } else if (action === 'execute_workflow') {
      return await executeWorkflow(body);
    } else if (action === 'evaluate_triggers') {
      return await evaluateTriggers(body);
    } else if (action === 'optimize_routing') {
      return await optimizeRouting(body);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Intelligent Workflow Routing Error:', error);
    return NextResponse.json(
      { error: 'Workflow routing failed', details: error.message },
      { status: 500 }
    );
  }
}

async function createWorkflowRule(body: any) {
  const { tenantId, ruleName, ruleType, conditions, actions, priority, active } = 
    WorkflowRuleSchema.parse(body);

  // Validate rule conditions and actions
  const validationResult = validateRuleLogic(conditions, actions, ruleType);
  if (!validationResult.valid) {
    return NextResponse.json({ 
      error: 'Invalid rule logic', 
      details: validationResult.errors 
    }, { status: 400 });
  }

  // Create workflow rule
  const rule = await prisma.workflowRule.create({
    data: {
      tenantId,
      ruleName,
      ruleType,
      conditions,
      actions,
      priority,
      active,
    }
  });

  // Test rule with sample data
  const testResult = await testWorkflowRule(rule);

  return NextResponse.json({
    success: true,
    rule: {
      id: rule.id,
      name: rule.ruleName,
      type: rule.ruleType,
      priority: rule.priority,
      active: rule.active,
    },
    validation: validationResult,
    testResult,
  });
}

async function executeWorkflow(body: any) {
  const { ruleId, taxReturnId, triggerData, triggerType } = 
    WorkflowExecutionSchema.parse(body);

  let applicableRules = [];

  if (ruleId) {
    // Execute specific rule
    const rule = await prisma.workflowRule.findUnique({
      where: { id: ruleId }
    });
    if (rule && rule.active) {
      applicableRules = [rule];
    }
  } else {
    // Find applicable rules based on trigger
    applicableRules = await findApplicableRules(triggerType, triggerData);
  }

  const executionResults = [];

  for (const rule of applicableRules) {
    try {
      // Evaluate conditions
      const conditionsMet = evaluateConditions(rule.conditions, triggerData);
      
      if (conditionsMet) {
        // Execute actions
        const actionResults = await executeActions(rule.actions, triggerData, taxReturnId);
        
        // Record execution
        const execution = await prisma.workflowExecution.create({
          data: {
            ruleId: rule.id,
            taxReturnId,
            triggerData,
            executionResult: {
              conditionsMet: true,
              actionsExecuted: actionResults.length,
              results: actionResults,
              executedAt: new Date().toISOString(),
            },
            status: 'completed',
          }
        });

        executionResults.push({
          ruleId: rule.id,
          ruleName: rule.ruleName,
          executionId: execution.id,
          actionsExecuted: actionResults.length,
          results: actionResults,
        });
      }
    } catch (error) {
      // Record failed execution
      await prisma.workflowExecution.create({
        data: {
          ruleId: rule.id,
          taxReturnId,
          triggerData,
          executionResult: {
            error: error.message,
            executedAt: new Date().toISOString(),
          },
          status: 'failed',
        }
      });

      executionResults.push({
        ruleId: rule.id,
        ruleName: rule.ruleName,
        error: error.message,
      });
    }
  }

  return NextResponse.json({
    success: true,
    triggerType,
    rulesEvaluated: applicableRules.length,
    rulesExecuted: executionResults.filter(r => !r.error).length,
    executionResults,
  });
}

async function evaluateTriggers(body: any) {
  const { tenantId, evaluationType } = body;

  let triggers = [];

  switch (evaluationType) {
    case 'pending_deadlines':
      triggers = await evaluatePendingDeadlines(tenantId);
      break;
    case 'high_risk_returns':
      triggers = await evaluateHighRiskReturns(tenantId);
      break;
    case 'client_communications':
      triggers = await evaluateClientCommunications(tenantId);
      break;
    case 'document_processing':
      triggers = await evaluateDocumentProcessing(tenantId);
      break;
    case 'all':
      triggers = await evaluateAllTriggers(tenantId);
      break;
  }

  // Execute workflows for identified triggers
  const workflowExecutions = [];
  for (const trigger of triggers) {
    const execution = await executeWorkflow({
      triggerData: trigger.data,
      triggerType: trigger.type,
    });
    workflowExecutions.push(execution);
  }

  return NextResponse.json({
    success: true,
    evaluationType,
    triggersFound: triggers.length,
    workflowsExecuted: workflowExecutions.length,
    triggers,
    executionSummary: summarizeExecutions(workflowExecutions),
  });
}

async function optimizeRouting(body: any) {
  const { tenantId, optimizationType } = body;

  // Analyze current routing performance
  const performanceAnalysis = await analyzeRoutingPerformance(tenantId);

  // Generate optimization recommendations
  const recommendations = await generateRoutingOptimizations(performanceAnalysis);

  // Apply automatic optimizations if requested
  let appliedOptimizations = [];
  if (body.autoApply) {
    appliedOptimizations = await applyRoutingOptimizations(tenantId, recommendations);
  }

  return NextResponse.json({
    success: true,
    performanceAnalysis,
    recommendations,
    appliedOptimizations: appliedOptimizations.length,
    estimatedImprovements: calculateEstimatedImprovements(recommendations),
  });
}

// Helper functions
function validateRuleLogic(conditions: any, actions: any, ruleType: string): any {
  const errors = [];
  const warnings = [];

  // Validate conditions structure
  if (!conditions || Object.keys(conditions).length === 0) {
    errors.push('Rule must have at least one condition');
  }

  // Validate actions structure
  if (!actions || Object.keys(actions).length === 0) {
    errors.push('Rule must have at least one action');
  }

  // Validate rule type specific logic
  switch (ruleType) {
    case 'routing':
      if (!actions.assignTo && !actions.routeTo) {
        errors.push('Routing rules must specify assignTo or routeTo action');
      }
      break;
    case 'escalation':
      if (!actions.escalateTo && !actions.notifyManager) {
        errors.push('Escalation rules must specify escalateTo or notifyManager action');
      }
      break;
    case 'automation':
      if (!actions.autoProcess && !actions.executeFunction) {
        warnings.push('Automation rules should specify automated actions');
      }
      break;
  }

  // Validate condition operators
  for (const [field, condition] of Object.entries(conditions)) {
    if (typeof condition === 'object' && condition !== null) {
      const operators = Object.keys(condition);
      const validOperators = ['equals', 'not_equals', 'greater_than', 'less_than', 'contains', 'in', 'not_in'];
      
      for (const op of operators) {
        if (!validOperators.includes(op)) {
          errors.push(`Invalid operator '${op}' for condition '${field}'`);
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

async function testWorkflowRule(rule: any): Promise<any> {
  // Generate test data based on rule type
  const testData = generateTestData(rule.ruleType);
  
  // Test condition evaluation
  const conditionResult = evaluateConditions(rule.conditions, testData);
  
  // Test action simulation (without actually executing)
  const actionSimulation = simulateActions(rule.actions, testData);

  return {
    testData,
    conditionResult,
    actionSimulation,
    wouldExecute: conditionResult,
  };
}

async function findApplicableRules(triggerType: string, triggerData: any): Promise<any[]> {
  // Get all active rules for the tenant
  const tenantId = triggerData.tenantId;
  const rules = await prisma.workflowRule.findMany({
    where: {
      tenantId,
      active: true,
    },
    orderBy: { priority: 'desc' }
  });

  // Filter rules that could apply to this trigger type
  const applicableRules = rules.filter(rule => {
    return couldRuleApply(rule, triggerType, triggerData);
  });

  return applicableRules;
}

function evaluateConditions(conditions: any, data: any): boolean {
  for (const [field, condition] of Object.entries(conditions)) {
    if (!evaluateCondition(field, condition, data)) {
      return false; // All conditions must be true (AND logic)
    }
  }
  return true;
}

function evaluateCondition(field: string, condition: any, data: any): boolean {
  const fieldValue = getNestedValue(data, field);
  
  if (typeof condition === 'object' && condition !== null) {
    for (const [operator, expectedValue] of Object.entries(condition)) {
      switch (operator) {
        case 'equals':
          if (fieldValue !== expectedValue) return false;
          break;
        case 'not_equals':
          if (fieldValue === expectedValue) return false;
          break;
        case 'greater_than':
          if (!(fieldValue > expectedValue)) return false;
          break;
        case 'less_than':
          if (!(fieldValue < expectedValue)) return false;
          break;
        case 'contains':
          if (!String(fieldValue).includes(String(expectedValue))) return false;
          break;
        case 'in':
          if (!Array.isArray(expectedValue) || !expectedValue.includes(fieldValue)) return false;
          break;
        case 'not_in':
          if (Array.isArray(expectedValue) && expectedValue.includes(fieldValue)) return false;
          break;
        default:
          return false;
      }
    }
  } else {
    // Simple equality check
    if (fieldValue !== condition) return false;
  }
  
  return true;
}

async function executeActions(actions: any, triggerData: any, taxReturnId?: string): Promise<any[]> {
  const results = [];

  for (const [actionType, actionConfig] of Object.entries(actions)) {
    try {
      let result;
      
      switch (actionType) {
        case 'assignTo':
          result = await executeAssignAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'routeTo':
          result = await executeRouteAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'escalateTo':
          result = await executeEscalateAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'notifyManager':
          result = await executeNotifyManagerAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'autoProcess':
          result = await executeAutoProcessAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'createTask':
          result = await executeCreateTaskAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'sendNotification':
          result = await executeSendNotificationAction(actionConfig, triggerData, taxReturnId);
          break;
        case 'updateStatus':
          result = await executeUpdateStatusAction(actionConfig, triggerData, taxReturnId);
          break;
        default:
          result = { error: `Unknown action type: ${actionType}` };
      }

      results.push({
        actionType,
        result,
        success: !result.error,
      });
    } catch (error) {
      results.push({
        actionType,
        result: { error: error.message },
        success: false,
      });
    }
  }

  return results;
}

// Action execution functions
async function executeAssignAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const assigneeId = config.userId || config.assigneeId;
  
  if (taxReturnId) {
    await prisma.taxReturn.update({
      where: { id: taxReturnId },
      data: { assignedPreparerId: assigneeId }
    });
  }

  return {
    action: 'assign',
    assignedTo: assigneeId,
    taxReturnId,
  };
}

async function executeRouteAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const department = config.department;
  const priority = config.priority || 'medium';

  // Create routing task
  if (taxReturnId) {
    await prisma.reviewTask.create({
      data: {
        tenantId: triggerData.tenantId,
        taxReturnId,
        assignedToUserId: config.userId,
        taskType: 'routing',
        priority,
        status: 'pending',
        reviewCriteria: {
          department,
          routedBy: 'workflow_automation',
          routingReason: config.reason || 'Automated routing',
        }
      }
    });
  }

  return {
    action: 'route',
    department,
    priority,
    taxReturnId,
  };
}

async function executeEscalateAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const managerId = config.managerId;
  const reason = config.reason || 'Automated escalation';

  // Create escalation notification
  await prisma.notification.create({
    data: {
      tenantId: triggerData.tenantId,
      userId: managerId,
      type: 'escalation',
      channel: 'email',
      status: 'pending',
      subject: `Escalation Required: ${reason}`,
      content: `A tax return has been escalated for your review. Reason: ${reason}`,
      metadata: {
        taxReturnId,
        escalationReason: reason,
        originalTrigger: triggerData.triggerType,
      }
    }
  });

  return {
    action: 'escalate',
    escalatedTo: managerId,
    reason,
    taxReturnId,
  };
}

async function executeNotifyManagerAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const managerId = config.managerId;
  const message = config.message || 'Manager notification from workflow automation';

  await prisma.notification.create({
    data: {
      tenantId: triggerData.tenantId,
      userId: managerId,
      type: 'manager_notification',
      channel: 'in_app',
      status: 'pending',
      subject: 'Workflow Notification',
      content: message,
      metadata: {
        taxReturnId,
        triggerType: triggerData.triggerType,
        automated: true,
      }
    }
  });

  return {
    action: 'notify_manager',
    notifiedManager: managerId,
    message,
  };
}

async function executeAutoProcessAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const processType = config.processType;
  
  // Execute automated processing based on type
  switch (processType) {
    case 'document_ocr':
      return await executeDocumentOCR(config, taxReturnId);
    case 'deduction_analysis':
      return await executeDeductionAnalysis(config, taxReturnId);
    case 'risk_assessment':
      return await executeRiskAssessment(config, taxReturnId);
    default:
      return { error: `Unknown process type: ${processType}` };
  }
}

async function executeCreateTaskAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const task = await prisma.reviewTask.create({
    data: {
      tenantId: triggerData.tenantId,
      taxReturnId: taxReturnId || '',
      assignedToUserId: config.assigneeId,
      taskType: config.taskType || 'general',
      priority: config.priority || 'medium',
      status: 'pending',
      reviewCriteria: {
        title: config.title || 'Automated Task',
        description: config.description || 'Task created by workflow automation',
        dueDate: config.dueDate,
        automated: true,
      }
    }
  });

  return {
    action: 'create_task',
    taskId: task.id,
    assignedTo: config.assigneeId,
  };
}

async function executeSendNotificationAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const notification = await prisma.notification.create({
    data: {
      tenantId: triggerData.tenantId,
      userId: config.userId,
      clientId: config.clientId,
      type: config.notificationType || 'workflow_notification',
      channel: config.channel || 'in_app',
      status: 'pending',
      subject: config.subject || 'Workflow Notification',
      content: config.message || 'Notification from workflow automation',
      metadata: {
        taxReturnId,
        automated: true,
        triggerType: triggerData.triggerType,
      }
    }
  });

  return {
    action: 'send_notification',
    notificationId: notification.id,
    recipient: config.userId || config.clientId,
  };
}

async function executeUpdateStatusAction(config: any, triggerData: any, taxReturnId?: string): Promise<any> {
  const newStatus = config.status;
  const reason = config.reason || 'Automated status update';

  if (taxReturnId) {
    await prisma.taxReturn.update({
      where: { id: taxReturnId },
      data: {
        status: newStatus,
        reviewNotes: `${reason} (Automated)`,
      }
    });
  }

  return {
    action: 'update_status',
    newStatus,
    reason,
    taxReturnId,
  };
}

// Trigger evaluation functions
async function evaluatePendingDeadlines(tenantId: string): Promise<any[]> {
  const triggers = [];
  const upcomingDeadline = new Date();
  upcomingDeadline.setDate(upcomingDeadline.getDate() + 7); // 7 days from now

  // Check tax returns with approaching deadlines
  const taxReturns = await prisma.taxReturn.findMany({
    where: {
      tenantId,
      status: { in: ['draft', 'in_review'] },
      // Add deadline field check when available
    },
    include: { client: true }
  });

  for (const taxReturn of taxReturns) {
    // Simplified deadline check - would use actual deadline fields
    triggers.push({
      type: 'deadline_approaching',
      data: {
        tenantId,
        taxReturnId: taxReturn.id,
        clientId: taxReturn.clientId,
        deadline: '2024-04-15', // Tax deadline
        daysRemaining: 30,
      }
    });
  }

  return triggers;
}

async function evaluateHighRiskReturns(tenantId: string): Promise<any[]> {
  const triggers = [];

  // Get tax returns with high AI confidence scores indicating risk
  const highRiskReturns = await prisma.taxReturn.findMany({
    where: {
      tenantId,
      aiConfidenceScore: { lt: 0.7 },
      status: { in: ['draft', 'in_review'] },
    },
    include: { client: true }
  });

  for (const taxReturn of highRiskReturns) {
    triggers.push({
      type: 'audit_risk_high',
      data: {
        tenantId,
        taxReturnId: taxReturn.id,
        clientId: taxReturn.clientId,
        riskScore: taxReturn.aiConfidenceScore,
        riskFactors: ['low_ai_confidence'],
      }
    });
  }

  return triggers;
}

async function evaluateClientCommunications(tenantId: string): Promise<any[]> {
  const triggers = [];
  const recentDate = new Date();
  recentDate.setHours(recentDate.getHours() - 24); // Last 24 hours

  // Check for recent client messages that need responses
  const recentCommunications = await prisma.communicationLog.findMany({
    where: {
      tenantId,
      direction: 'inbound',
      occurredAt: { gte: recentDate },
    },
    include: { client: true }
  });

  for (const comm of recentCommunications) {
    triggers.push({
      type: 'client_message',
      data: {
        tenantId,
        clientId: comm.clientId,
        communicationType: comm.communicationType,
        urgency: comm.metadata?.urgency || 'medium',
        messageTime: comm.occurredAt,
      }
    });
  }

  return triggers;
}

async function evaluateDocumentProcessing(tenantId: string): Promise<any[]> {
  const triggers = [];

  // Check for documents that failed processing
  const failedDocuments = await prisma.document.findMany({
    where: {
      tenantId,
      status: 'failed',
    },
    include: { client: true }
  });

  for (const doc of failedDocuments) {
    triggers.push({
      type: 'document_processing_failed',
      data: {
        tenantId,
        documentId: doc.id,
        clientId: doc.clientId,
        documentType: doc.documentType,
        failureReason: doc.extractedData?.error || 'Unknown error',
      }
    });
  }

  return triggers;
}

async function evaluateAllTriggers(tenantId: string): Promise<any[]> {
  const allTriggers = [];
  
  const deadlineTriggers = await evaluatePendingDeadlines(tenantId);
  const riskTriggers = await evaluateHighRiskReturns(tenantId);
  const commTriggers = await evaluateClientCommunications(tenantId);
  const docTriggers = await evaluateDocumentProcessing(tenantId);

  allTriggers.push(...deadlineTriggers, ...riskTriggers, ...commTriggers, ...docTriggers);
  
  return allTriggers;
}

// Utility functions
function getNestedValue(obj: any, path: string): any {
  return path.split('.').reduce((current, key) => current?.[key], obj);
}

function couldRuleApply(rule: any, triggerType: string, triggerData: any): boolean {
  // Check if rule conditions could potentially match the trigger data
  const conditions = rule.conditions;
  
  // Simple heuristic: if the rule has conditions that reference fields in the trigger data
  for (const field of Object.keys(conditions)) {
    if (getNestedValue(triggerData, field) !== undefined) {
      return true;
    }
  }
  
  return false;
}

function generateTestData(ruleType: string): any {
  const baseData = {
    tenantId: 'test-tenant',
    taxReturnId: 'test-return',
    clientId: 'test-client',
    triggerType: 'test_trigger',
  };

  switch (ruleType) {
    case 'routing':
      return {
        ...baseData,
        returnType: '1040',
        complexity: 'medium',
        preparerWorkload: 5,
      };
    case 'escalation':
      return {
        ...baseData,
        riskScore: 0.8,
        daysOverdue: 3,
        clientTier: 'premium',
      };
    case 'automation':
      return {
        ...baseData,
        documentCount: 10,
        ocrConfidence: 0.95,
        allDocumentsProcessed: true,
      };
    default:
      return baseData;
  }
}

function simulateActions(actions: any, testData: any): any {
  const simulation = {};
  
  for (const [actionType, actionConfig] of Object.entries(actions)) {
    simulation[actionType] = {
      wouldExecute: true,
      config: actionConfig,
      estimatedResult: `Would execute ${actionType} with config: ${JSON.stringify(actionConfig)}`,
    };
  }
  
  return simulation;
}

function summarizeExecutions(executions: any[]): any {
  return {
    totalExecutions: executions.length,
    successfulExecutions: executions.filter(e => e.success).length,
    failedExecutions: executions.filter(e => !e.success).length,
    averageActionsPerExecution: executions.reduce((sum, e) => 
      sum + (e.rulesExecuted || 0), 0) / executions.length || 0,
  };
}

async function analyzeRoutingPerformance(tenantId: string): Promise<any> {
  // Analyze workflow execution history
  const recentExecutions = await prisma.workflowExecution.findMany({
    where: {
      rule: { tenantId },
      executedAt: {
        gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
      }
    },
    include: { rule: true }
  });

  const analysis = {
    totalExecutions: recentExecutions.length,
    successRate: recentExecutions.filter(e => e.status === 'completed').length / recentExecutions.length,
    averageExecutionTime: calculateAverageExecutionTime(recentExecutions),
    mostTriggeredRules: getMostTriggeredRules(recentExecutions),
    bottlenecks: identifyBottlenecks(recentExecutions),
  };

  return analysis;
}

async function generateRoutingOptimizations(analysis: any): Promise<any[]> {
  const recommendations = [];

  if (analysis.successRate < 0.9) {
    recommendations.push({
      type: 'improve_success_rate',
      description: 'Review and fix failing workflow rules',
      priority: 'high',
      estimatedImpact: 'Increase success rate by 10-15%',
    });
  }

  if (analysis.averageExecutionTime > 5000) { // 5 seconds
    recommendations.push({
      type: 'optimize_performance',
      description: 'Optimize slow-executing workflow rules',
      priority: 'medium',
      estimatedImpact: 'Reduce execution time by 30-50%',
    });
  }

  if (analysis.bottlenecks.length > 0) {
    recommendations.push({
      type: 'resolve_bottlenecks',
      description: 'Address identified workflow bottlenecks',
      priority: 'high',
      estimatedImpact: 'Improve overall workflow efficiency',
      bottlenecks: analysis.bottlenecks,
    });
  }

  return recommendations;
}

async function applyRoutingOptimizations(tenantId: string, recommendations: any[]): Promise<any[]> {
  const applied = [];

  for (const rec of recommendations) {
    if (rec.type === 'improve_success_rate') {
      // Automatically disable failing rules for review
      const failingRules = await prisma.workflowRule.updateMany({
        where: {
          tenantId,
          // Would add criteria for failing rules
        },
        data: { active: false }
      });
      
      applied.push({
        type: rec.type,
        action: 'Disabled failing rules for review',
        count: failingRules.count,
      });
    }
  }

  return applied;
}

function calculateEstimatedImprovements(recommendations: any[]): any {
  return {
    estimatedEfficiencyGain: '25-40%',
    estimatedTimeReduction: '2-3 hours per day',
    estimatedErrorReduction: '15-20%',
    implementationEffort: 'Medium',
  };
}

// Additional utility functions
function calculateAverageExecutionTime(executions: any[]): number {
  if (executions.length === 0) return 0;
  
  const totalTime = executions.reduce((sum, exec) => {
    const executionTime = exec.executionResult?.executionTime || 1000; // Default 1 second
    return sum + executionTime;
  }, 0);
  
  return totalTime / executions.length;
}

function getMostTriggeredRules(executions: any[]): any[] {
  const ruleCounts = {};
  
  for (const exec of executions) {
    const ruleId = exec.ruleId;
    ruleCounts[ruleId] = (ruleCounts[ruleId] || 0) + 1;
  }
  
  return Object.entries(ruleCounts)
    .sort(([,a], [,b]) => (b as number) - (a as number))
    .slice(0, 5)
    .map(([ruleId, count]) => ({ ruleId, count }));
}

function identifyBottlenecks(executions: any[]): any[] {
  const bottlenecks = [];
  
  // Identify rules with high failure rates
  const ruleStats = {};
  for (const exec of executions) {
    const ruleId = exec.ruleId;
    if (!ruleStats[ruleId]) {
      ruleStats[ruleId] = { total: 0, failed: 0 };
    }
    ruleStats[ruleId].total++;
    if (exec.status === 'failed') {
      ruleStats[ruleId].failed++;
    }
  }
  
  for (const [ruleId, stats] of Object.entries(ruleStats)) {
    const failureRate = (stats as any).failed / (stats as any).total;
    if (failureRate > 0.2) { // 20% failure rate
      bottlenecks.push({
        type: 'high_failure_rate',
        ruleId,
        failureRate,
        description: `Rule ${ruleId} has ${Math.round(failureRate * 100)}% failure rate`,
      });
    }
  }
  
  return bottlenecks;
}

// Automated processing functions
async function executeDocumentOCR(config: any, taxReturnId?: string): Promise<any> {
  // This would trigger OCR processing for documents
  return {
    processType: 'document_ocr',
    status: 'initiated',
    message: 'OCR processing initiated for pending documents',
  };
}

async function executeDeductionAnalysis(config: any, taxReturnId?: string): Promise<any> {
  // This would trigger ML deduction analysis
  return {
    processType: 'deduction_analysis',
    status: 'initiated',
    message: 'AI deduction analysis initiated',
  };
}

async function executeRiskAssessment(config: any, taxReturnId?: string): Promise<any> {
  // This would trigger risk assessment
  return {
    processType: 'risk_assessment',
    status: 'initiated',
    message: 'Audit risk assessment initiated',
  };
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get('tenantId');
    const ruleType = searchParams.get('ruleType');
    const active = searchParams.get('active');

    if (!tenantId) {
      return NextResponse.json({ error: 'tenantId required' }, { status: 400 });
    }

    let whereClause: any = { tenantId };
    
    if (ruleType) whereClause.ruleType = ruleType;
    if (active !== null) whereClause.active = active === 'true';

    const rules = await prisma.workflowRule.findMany({
      where: whereClause,
      orderBy: { priority: 'desc' }
    });

    const executions = await prisma.workflowExecution.findMany({
      where: {
        rule: { tenantId }
      },
      include: { rule: true },
      orderBy: { executedAt: 'desc' },
      take: 50
    });

    const summary = {
      totalRules: rules.length,
      activeRules: rules.filter(r => r.active).length,
      recentExecutions: executions.length,
      successRate: executions.filter(e => e.status === 'completed').length / executions.length || 0,
      ruleTypes: {
        routing: rules.filter(r => r.ruleType === 'routing').length,
        escalation: rules.filter(r => r.ruleType === 'escalation').length,
        automation: rules.filter(r => r.ruleType === 'automation').length,
        notification: rules.filter(r => r.ruleType === 'notification').length,
      }
    };

    return NextResponse.json({
      rules,
      executions,
      summary,
    });

  } catch (error) {
    console.error('Get Workflow Rules Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve workflow rules' },
      { status: 500 }
    );
  }
}
