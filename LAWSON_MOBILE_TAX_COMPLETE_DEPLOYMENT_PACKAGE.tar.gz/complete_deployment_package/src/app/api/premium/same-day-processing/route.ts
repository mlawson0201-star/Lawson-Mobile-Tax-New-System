
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { taxReturnId, priorityLevel, guaranteedHours } = await request.json();

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID is required' }, { status: 400 });
    }

    // Get tax return details
    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: { client: true },
    });

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
    }

    if (taxReturn.tenantId !== session.user.tenantId) {
      return NextResponse.json({ error: 'Unauthorized access to tax return' }, { status: 403 });
    }

    // Calculate premium fee based on priority level
    const feeStructure = {
      express: 49.99,    // 4-hour guarantee
      same_day: 29.99,   // 8-hour guarantee  
      rush: 19.99,       // 24-hour guarantee
    };

    const premiumFee = feeStructure[priorityLevel as keyof typeof feeStructure] || feeStructure.rush;
    
    // Calculate guaranteed deadline
    const hoursMap = {
      express: 4,
      same_day: 8,
      rush: 24,
    };

    const guaranteedDeadline = new Date(
      Date.now() + (guaranteedHours || hoursMap[priorityLevel as keyof typeof hoursMap] || 24) * 60 * 60 * 1000
    );

    // Find available preparers
    const availablePreparers = await prisma.user.findMany({
      where: {
        tenantId: session.user.tenantId,
        role: { in: ['preparer', 'ea_cpa'] },
        active: true,
      },
      orderBy: { lastLoginAt: 'desc' },
      take: 5,
    });

    // Assign to the most recently active preparer
    const assignedPreparer = availablePreparers[0];

    // Create same-day processing record
    const sameDayProcessing = await prisma.sameDayProcessing.create({
      data: {
        tenantId: session.user.tenantId,
        taxReturnId,
        clientId: taxReturn.clientId,
        premiumFee,
        guaranteedDeadline,
        currentStage: 'document_review',
        stageTimestamps: {
          started: new Date().toISOString(),
          document_review: new Date().toISOString(),
        },
        assignedPreparerId: assignedPreparer?.id,
        priorityLevel: priorityLevel || 'rush',
      },
    });

    // Update tax return status to expedited
    await prisma.taxReturn.update({
      where: { id: taxReturnId },
      data: {
        status: 'expedited',
      },
    });

    // Create notifications for assigned preparer
    if (assignedPreparer) {
      await prisma.pushNotification.create({
        data: {
          tenantId: session.user.tenantId,
          userId: assignedPreparer.id,
          title: `Urgent: ${priorityLevel.toUpperCase()} Processing Required`,
          message: `Tax return for ${taxReturn.client.firstName} ${taxReturn.client.lastName} needs ${priorityLevel} processing. Deadline: ${guaranteedDeadline.toLocaleString()}`,
          notificationType: 'urgent_assignment',
          priority: 'urgent',
          payload: {
            taxReturnId,
            sameDayProcessingId: sameDayProcessing.id,
            deadline: guaranteedDeadline.toISOString(),
          },
          deviceTokens: [`user_${assignedPreparer.id}_token`],
        },
      });

      // Also create in-app notification
      await prisma.notification.create({
        data: {
          tenantId: session.user.tenantId,
          userId: assignedPreparer.id,
          clientId: taxReturn.clientId,
          type: 'urgent_assignment',
          title: `${priorityLevel.toUpperCase()} Processing Assignment`,
          message: `You have been assigned a ${priorityLevel} processing task with deadline ${guaranteedDeadline.toLocaleString()}`,
          data: {
            taxReturnId,
            sameDayProcessingId: sameDayProcessing.id,
            priorityLevel,
            premiumFee,
          },
        },
      });
    }

    // Create client notification
    await prisma.pushNotification.create({
      data: {
        tenantId: session.user.tenantId,
        clientId: taxReturn.clientId,
        title: `${priorityLevel.charAt(0).toUpperCase() + priorityLevel.slice(1)} Processing Activated`,
        message: `Your tax return is now being processed with ${priorityLevel} priority. You'll receive updates as it progresses.`,
        notificationType: 'service_update',
        priority: 'high',
        payload: {
          taxReturnId,
          sameDayProcessingId: sameDayProcessing.id,
          guaranteedDeadline: guaranteedDeadline.toISOString(),
        },
        deviceTokens: [`client_${taxReturn.clientId}_token`],
      },
    });

    return NextResponse.json({
      success: true,
      sameDayProcessingId: sameDayProcessing.id,
      guaranteedDeadline,
      premiumFee,
      assignedPreparer: assignedPreparer ? {
        id: assignedPreparer.id,
        name: `${assignedPreparer.firstName} ${assignedPreparer.lastName}`,
        role: assignedPreparer.role,
      } : null,
      estimatedStages: [
        { stage: 'document_review', estimatedMinutes: 30 },
        { stage: 'ai_processing', estimatedMinutes: 15 },
        { stage: 'human_review', estimatedMinutes: 60 },
        { stage: 'final_review', estimatedMinutes: 30 },
        { stage: 'completed', estimatedMinutes: 0 },
      ],
    });

  } catch (error: any) {
    console.error('Same-day processing setup error:', error);
    return NextResponse.json(
      { error: 'Failed to setup same-day processing', details: error?.message },
      { status: 500 }
    );
  }
}

// GET endpoint to track same-day processing status
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const sameDayProcessingId = searchParams.get('id');
    const taxReturnId = searchParams.get('taxReturnId');

    if (!sameDayProcessingId && !taxReturnId) {
      return NextResponse.json({ error: 'Processing ID or Tax Return ID required' }, { status: 400 });
    }

    const processing = await prisma.sameDayProcessing.findFirst({
      where: {
        tenantId: session.user.tenantId,
        ...(sameDayProcessingId && { id: sameDayProcessingId }),
        ...(taxReturnId && { taxReturnId }),
      },
      include: {
        taxReturn: {
          include: {
            client: true,
          },
        },
      },
    });

    if (!processing) {
      return NextResponse.json({ error: 'Same-day processing not found' }, { status: 404 });
    }

    // Calculate progress and time remaining
    const now = new Date();
    const startTime = new Date(processing.createdAt);
    const deadline = new Date(processing.guaranteedDeadline);
    
    const totalTime = deadline.getTime() - startTime.getTime();
    const elapsedTime = now.getTime() - startTime.getTime();
    const timeRemaining = deadline.getTime() - now.getTime();
    
    const progressPercentage = Math.min(100, Math.max(0, (elapsedTime / totalTime) * 100));
    
    // Stage progress mapping
    const stageProgress = {
      document_review: 20,
      ai_processing: 40,
      human_review: 70,
      final_review: 90,
      completed: 100,
    };

    const currentProgress = stageProgress[processing.currentStage as keyof typeof stageProgress] || 0;

    return NextResponse.json({
      success: true,
      processing: {
        id: processing.id,
        currentStage: processing.currentStage,
        progress: currentProgress,
        timeRemaining: Math.max(0, timeRemaining),
        guaranteedDeadline: processing.guaranteedDeadline,
        slaMet: timeRemaining > 0,
        premiumFee: processing.premiumFee,
        priorityLevel: processing.priorityLevel,
        stageTimestamps: processing.stageTimestamps,
        client: {
          name: `${processing.taxReturn.client.firstName} ${processing.taxReturn.client.lastName}`,
          email: processing.taxReturn.client.email,
        },
      },
      timeline: {
        started: processing.createdAt,
        estimatedCompletion: processing.guaranteedDeadline,
        currentStageStarted: processing.stageTimestamps?.[processing.currentStage],
        progressPercentage: Math.round(progressPercentage),
      },
    });

  } catch (error: any) {
    console.error('Same-day processing status error:', error);
    return NextResponse.json(
      { error: 'Failed to get processing status', details: error?.message },
      { status: 500 }
    );
  }
}

// PUT endpoint to update processing stage
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { sameDayProcessingId, newStage, notes } = await request.json();

    if (!sameDayProcessingId || !newStage) {
      return NextResponse.json({ error: 'Processing ID and new stage are required' }, { status: 400 });
    }

    const processing = await prisma.sameDayProcessing.findUnique({
      where: { id: sameDayProcessingId },
      include: {
        taxReturn: {
          include: { client: true },
        },
      },
    });

    if (!processing) {
      return NextResponse.json({ error: 'Processing record not found' }, { status: 404 });
    }

    // Update stage and timestamps
    const updatedTimestamps = {
      ...processing.stageTimestamps,
      [newStage]: new Date().toISOString(),
    };

    const updatedProcessing = await prisma.sameDayProcessing.update({
      where: { id: sameDayProcessingId },
      data: {
        currentStage: newStage,
        stageTimestamps: updatedTimestamps,
        ...(newStage === 'completed' && {
          completedAt: new Date(),
          slaMet: new Date() <= new Date(processing.guaranteedDeadline),
          completionTime: Math.round((Date.now() - new Date(processing.createdAt).getTime()) / (1000 * 60)),
        }),
      },
    });

    // Send progress notification to client
    await prisma.pushNotification.create({
      data: {
        tenantId: session.user.tenantId,
        clientId: processing.clientId,
        title: 'Tax Return Progress Update',
        message: `Your ${processing.priorityLevel} processing has advanced to: ${newStage.replace('_', ' ')}`,
        notificationType: 'progress_update',
        priority: 'normal',
        payload: {
          sameDayProcessingId,
          currentStage: newStage,
          notes,
        },
        deviceTokens: [`client_${processing.clientId}_token`],
      },
    });

    // If completed, update tax return status
    if (newStage === 'completed') {
      await prisma.taxReturn.update({
        where: { id: processing.taxReturnId },
        data: {
          status: 'completed',
          completedAt: new Date(),
        },
      });
    }

    return NextResponse.json({
      success: true,
      processing: updatedProcessing,
      message: `Stage updated to ${newStage}`,
    });

  } catch (error: any) {
    console.error('Update processing stage error:', error);
    return NextResponse.json(
      { error: 'Failed to update processing stage', details: error?.message },
      { status: 500 }
    );
  }
}
