
"""
Premium Concierge Services
24/7 AI-powered concierge with white-glove client experience
"""

from .ai_concierge import AIConciergeEngine
from .professional_assignment import TaxProfessionalMatcher
from .video_consultation import VideoConsultationManager
from .priority_queue import PriorityProcessingQueue
from .calendar_manager import PersonalizedTaxCalendar
from .document_service import DocumentCollectionService
from .planning_scheduler import TaxPlanningScheduler
from .audit_support import AuditSupportService
from .advisory_service import YearRoundTaxAdvisory
from .executive_services import ExecutiveTaxServices

__version__ = "1.0.0"
__all__ = [
    "AIConciergeEngine",
    "TaxProfessionalMatcher",
    "VideoConsultationManager", 
    "PriorityProcessingQueue",
    "PersonalizedTaxCalendar",
    "DocumentCollectionService",
    "TaxPlanningScheduler",
    "AuditSupportService",
    "YearRoundTaxAdvisory",
    "ExecutiveTaxServices"
]
