
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import { createSyncService } from '@/lib/gohighlevel/sync';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;

  switch (req.method) {
    case 'POST':
      return handleSync(req, res, tenantId);
    case 'GET':
      return handleGetSyncStatus(req, res, tenantId);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleSync(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const { type = 'all' } = req.body;
    
    const syncService = createSyncService(tenantId);
    
    let result;
    switch (type) {
      case 'all':
        result = await syncService.syncAll();
        break;
      default:
        return res.status(400).json({ error: 'Invalid sync type' });
    }

    res.status(200).json({
      message: 'Sync completed',
      result,
    });
  } catch (error) {
    console.error('Sync error:', error);
    res.status(500).json({ 
      error: 'Sync failed',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}

async function handleGetSyncStatus(req: NextApiRequest, res: NextApiResponse, tenantId: string) {
  try {
    const { prisma } = await import('@/lib/prisma');
    
    const settings = await prisma.gohighlevel_settings.findUnique({
      where: { tenant_id: tenantId },
    });

    if (!settings) {
      return res.status(404).json({ error: 'GoHighLevel not configured' });
    }

    const syncStatus = {
      configured: !!settings.api_key,
      syncEnabled: settings.sync_enabled,
      lastSyncAt: settings.last_sync_at,
      syncContacts: settings.sync_contacts,
      syncAppointments: settings.sync_appointments,
      syncMessages: settings.sync_messages,
    };

    res.status(200).json({ syncStatus });
  } catch (error) {
    console.error('Error getting sync status:', error);
    res.status(500).json({ error: 'Failed to get sync status' });
  }
}
