
"""
Reddit adapter using Reddit API
"""
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
from . import BasePlatformAdapter

logger = logging.getLogger(__name__)

class RedditAdapter(BasePlatformAdapter):
    """Adapter for Reddit using Reddit API"""
    
    def __init__(self, credentials: Dict[str, str]):
        super().__init__(credentials)
        self.client_id = credentials.get('client_id')
        self.client_secret = credentials.get('client_secret')
        self.username = credentials.get('username')
        self.password = credentials.get('password')
        self.user_agent = credentials.get('user_agent', 'LawsonMobileTax/1.0')
        self.access_token = None
        self.base_url = "https://oauth.reddit.com"
        
    async def authenticate(self) -> bool:
        """Authenticate with Reddit using OAuth2"""
        try:
            # Get access token
            auth_url = "https://www.reddit.com/api/v1/access_token"
            
            auth_data = {
                'grant_type': 'password',
                'username': self.username,
                'password': self.password
            }
            
            headers = {
                'User-Agent': self.user_agent
            }
            
            response = requests.post(
                auth_url, 
                data=auth_data, 
                headers=headers,
                auth=(self.client_id, self.client_secret)
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data.get('access_token')
                
                # Verify token by getting user info
                user_url = f"{self.base_url}/api/v1/me"
                user_headers = {
                    'Authorization': f'Bearer {self.access_token}',
                    'User-Agent': self.user_agent
                }
                
                user_response = requests.get(user_url, headers=user_headers)
                
                if user_response.status_code == 200:
                    user_info = user_response.json()
                    logger.info(f"Authenticated as: {user_info.get('name', 'Unknown')}")
                    return True
                else:
                    logger.error(f"Token verification failed: {user_response.text}")
                    return False
            else:
                logger.error(f"Authentication failed: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post content to Reddit"""
        try:
            if not self.access_token:
                auth_success = await self.authenticate()
                if not auth_success:
                    return {"success": False, "error": "Authentication failed"}
            
            subreddit = kwargs.get('subreddit')
            if not subreddit:
                return {"success": False, "error": "Subreddit is required"}
            
            title = kwargs.get('title', content[:100])  # Reddit requires a title
            post_type = kwargs.get('post_type', 'text')  # text, link, or image
            
            url = f"{self.base_url}/api/submit"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': self.user_agent,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            # Format content (Reddit doesn't use hashtags the same way)
            full_content = content
            if hashtags:
                # Add hashtags as text at the end
                hashtag_text = " ".join([f"#{tag.strip('#')}" for tag in hashtags])
                full_content = f"{content}\n\n{hashtag_text}"
            
            post_data = {
                'sr': subreddit,
                'title': title,
                'kind': post_type,
                'api_type': 'json'
            }
            
            if post_type == 'text':
                post_data['text'] = full_content
            elif post_type == 'link':
                link_url = kwargs.get('url') or (media_urls[0] if media_urls else '')
                if not link_url:
                    return {"success": False, "error": "URL required for link posts"}
                post_data['url'] = link_url
            elif post_type == 'image':
                if not media_urls or len(media_urls) == 0:
                    return {"success": False, "error": "Image URL required for image posts"}
                post_data['url'] = media_urls[0]
            
            # Add flair if specified
            if kwargs.get('flair_id'):
                post_data['flair_id'] = kwargs['flair_id']
            if kwargs.get('flair_text'):
                post_data['flair_text'] = kwargs['flair_text']
            
            # Mark as NSFW if needed
            if kwargs.get('nsfw', False):
                post_data['nsfw'] = 'true'
            
            # Mark as spoiler if needed
            if kwargs.get('spoiler', False):
                post_data['spoiler'] = 'true'
            
            response = requests.post(url, headers=headers, data=post_data)
            
            if response.status_code == 200:
                result = response.json()
                
                # Check for errors in response
                if result.get('json', {}).get('errors'):
                    errors = result['json']['errors']
                    error_msg = '; '.join([error[1] for error in errors])
                    return {"success": False, "error": error_msg}
                
                # Get post data
                things = result.get('json', {}).get('data', {}).get('things', [])
                if things:
                    post_data = things[0].get('data', {})
                    return {
                        "success": True,
                        "post_id": post_data.get('name'),  # Reddit's full name (e.g., t3_abc123)
                        "post_url": f"https://reddit.com{post_data.get('permalink', '')}",
                        "platform_response": result
                    }
                else:
                    return {"success": False, "error": "No post data returned"}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
                
        except Exception as e:
            logger.error(f"Error posting to Reddit: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a Reddit post"""
        try:
            # Reddit API doesn't support native scheduling
            # This would be handled by our internal scheduler
            
            return {
                "success": True,
                "message": "Reddit post scheduled via internal scheduler",
                "scheduled_time": scheduled_time.isoformat(),
                "note": "Reddit API doesn't support native scheduling"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a Reddit post"""
        try:
            if not self.access_token:
                auth_success = await self.authenticate()
                if not auth_success:
                    return {"success": False, "error": "Authentication failed"}
            
            # Get post info
            url = f"{self.base_url}/api/info"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': self.user_agent
            }
            
            params = {'id': post_id}
            response = requests.get(url, headers=headers, params=params)
            
            if response.status_code == 200:
                result = response.json()
                children = result.get('data', {}).get('children', [])
                
                if children:
                    post_data = children[0].get('data', {})
                    
                    analytics = {
                        "post_id": post_id,
                        "upvotes": post_data.get('ups', 0),
                        "downvotes": post_data.get('downs', 0),
                        "score": post_data.get('score', 0),
                        "upvote_ratio": post_data.get('upvote_ratio', 0),
                        "comments": post_data.get('num_comments', 0),
                        "awards": len(post_data.get('all_awardings', [])),
                        "created_utc": post_data.get('created_utc'),
                        "title": post_data.get('title', ''),
                        "subreddit": post_data.get('subreddit', ''),
                        "permalink": post_data.get('permalink', '')
                    }
                    
                    return {"success": True, "analytics": analytics}
                else:
                    return {"success": False, "error": "Post not found"}
            else:
                error_msg = f"Failed to get analytics: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def delete_post(self, post_id: str) -> bool:
        """Delete a Reddit post"""
        try:
            if not self.access_token:
                auth_success = await self.authenticate()
                if not auth_success:
                    return False
            
            url = f"{self.base_url}/api/del"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': self.user_agent,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            data = {'id': post_id}
            response = requests.post(url, headers=headers, data=data)
            
            return response.status_code == 200
            
        except Exception as e:
            logger.error(f"Error deleting Reddit post: {str(e)}")
            return False
    
    async def post_comment(self, post_id: str, comment_text: str) -> Dict[str, Any]:
        """Post a comment on a Reddit post"""
        try:
            if not self.access_token:
                auth_success = await self.authenticate()
                if not auth_success:
                    return {"success": False, "error": "Authentication failed"}
            
            url = f"{self.base_url}/api/comment"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': self.user_agent,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            data = {
                'thing_id': post_id,
                'text': comment_text,
                'api_type': 'json'
            }
            
            response = requests.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                result = response.json()
                
                if result.get('json', {}).get('errors'):
                    errors = result['json']['errors']
                    error_msg = '; '.join([error[1] for error in errors])
                    return {"success": False, "error": error_msg}
                
                things = result.get('json', {}).get('data', {}).get('things', [])
                if things:
                    comment_data = things[0].get('data', {})
                    return {
                        "success": True,
                        "comment_id": comment_data.get('name'),
                        "permalink": comment_data.get('permalink', ''),
                        "platform_response": result
                    }
                else:
                    return {"success": False, "error": "No comment data returned"}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_subreddit_info(self, subreddit: str) -> Dict[str, Any]:
        """Get information about a subreddit"""
        try:
            if not self.access_token:
                auth_success = await self.authenticate()
                if not auth_success:
                    return {"success": False, "error": "Authentication failed"}
            
            url = f"{self.base_url}/r/{subreddit}/about"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': self.user_agent
            }
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                data = result.get('data', {})
                
                subreddit_info = {
                    "name": data.get('display_name', ''),
                    "title": data.get('title', ''),
                    "description": data.get('public_description', ''),
                    "subscribers": data.get('subscribers', 0),
                    "active_users": data.get('active_user_count', 0),
                    "created_utc": data.get('created_utc'),
                    "over18": data.get('over18', False),
                    "submission_type": data.get('submission_type', ''),
                    "allow_images": data.get('allow_images', False),
                    "allow_videos": data.get('allow_videos', False)
                }
                
                return {"success": True, "subreddit_info": subreddit_info}
            else:
                error_msg = f"Failed to get subreddit info: HTTP {response.status_code}"
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
