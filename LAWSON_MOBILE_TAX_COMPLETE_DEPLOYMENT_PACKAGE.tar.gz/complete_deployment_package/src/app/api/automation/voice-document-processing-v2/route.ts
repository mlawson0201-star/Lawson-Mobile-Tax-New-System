
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { mlClient } from '@/lib/ml-client';
import { z } from 'zod';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

const VoiceProcessingRequestSchema = z.object({
  clientId: z.string(),
  userId: z.string(),
  processingType: z.enum(['document_dictation', 'client_interview', 'tax_consultation', 'document_review']),
  audioFile: z.string().optional(), // Base64 encoded audio
  audioFileName: z.string().optional(),
  context: z.record(z.any()).optional(),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
});

const VoiceCommandRequestSchema = z.object({
  voiceJobId: z.string(),
  commandType: z.enum(['create_document', 'update_return', 'schedule_appointment', 'send_notification']),
  parameters: z.record(z.any()),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;

    if (action === 'process_audio') {
      return await processAudioFile(body);
    } else if (action === 'execute_command') {
      return await executeVoiceCommand(body);
    } else if (action === 'batch_process') {
      return await batchProcessAudio(body);
    } else if (action === 'real_time_process') {
      return await realTimeProcess(body);
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Voice Processing Error:', error);
    return NextResponse.json(
      { error: 'Voice processing failed', details: error.message },
      { status: 500 }
    );
  }
}

async function processAudioFile(body: any) {
  const { clientId, userId, processingType, audioFile, audioFileName, context, priority } = 
    VoiceProcessingRequestSchema.parse(body);

  // Get client and user information
  const client = await prisma.client.findUnique({
    where: { id: clientId },
    include: {
      taxReturns: {
        orderBy: { createdAt: 'desc' },
        take: 1
      }
    }
  });

  if (!client) {
    return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  }

  const user = await prisma.user.findUnique({
    where: { id: userId }
  });

  if (!user) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 });
  }

  // Save audio file if provided
  let audioFilePath = '';
  if (audioFile && audioFileName) {
    const uploadDir = '/tmp/voice_uploads';
    await mkdir(uploadDir, { recursive: true });
    
    audioFilePath = join(uploadDir, `${Date.now()}_${audioFileName}`);
    const audioBuffer = Buffer.from(audioFile, 'base64');
    await writeFile(audioFilePath, audioBuffer);
  }

  // Create voice processing job
  const voiceJob = await prisma.voiceProcessingJob.create({
    data: {
      tenantId: client.tenantId,
      clientId,
      userId,
      audioFilePath,
      processingType,
      status: 'queued',
    }
  });

  // Process with ML service
  try {
    const processingResult = await mlClient.processVoice({
      audio_file_path: audioFilePath,
      processing_type: processingType,
      context: {
        clientId,
        userId,
        clientName: `${client.firstName} ${client.lastName}`,
        currentTaxYear: client.taxReturns[0]?.taxYear || '2024',
        ...context,
      }
    });

    // Update job with results
    const updatedJob = await prisma.voiceProcessingJob.update({
      where: { id: voiceJob.id },
      data: {
        status: 'completed',
        transcript: processingResult.transcript,
        extractedData: processingResult.extracted_data,
        confidenceScores: processingResult.confidence_scores,
        completedAt: new Date(),
        processingDuration: Math.floor(Date.now() / 1000) - Math.floor(voiceJob.createdAt.getTime() / 1000),
      }
    });

    // Process extracted commands
    const commands = await processExtractedCommands(voiceJob.id, processingResult);

    // Generate follow-up actions
    const followUpActions = await generateFollowUpActions(
      processingResult, processingType, client, user
    );

    // Create notifications if needed
    await createVoiceProcessingNotifications(
      client, user, processingResult, followUpActions
    );

    // Update client interaction log
    await updateClientInteractionLog(client.id, processingResult, processingType);

    return NextResponse.json({
      success: true,
      voiceJob: {
        id: updatedJob.id,
        status: updatedJob.status,
        processingDuration: updatedJob.processingDuration,
      },
      results: {
        transcript: processingResult.transcript,
        extractedData: processingResult.extracted_data,
        confidenceScores: processingResult.confidence_scores,
        actionItems: processingResult.action_items,
      },
      commands: commands.length,
      followUpActions,
      qualityMetrics: calculateQualityMetrics(processingResult),
    });

  } catch (error) {
    // Update job with error status
    await prisma.voiceProcessingJob.update({
      where: { id: voiceJob.id },
      data: {
        status: 'failed',
        extractedData: { error: error.message },
        completedAt: new Date(),
      }
    });

    throw error;
  }
}

async function executeVoiceCommand(body: any) {
  const { voiceJobId, commandType, parameters } = VoiceCommandRequestSchema.parse(body);

  // Get voice job
  const voiceJob = await prisma.voiceProcessingJob.findUnique({
    where: { id: voiceJobId },
    include: {
      client: true,
      user: true,
    }
  });

  if (!voiceJob) {
    return NextResponse.json({ error: 'Voice job not found' }, { status: 404 });
  }

  // Create command record
  const command = await prisma.voiceCommand.create({
    data: {
      voiceJobId,
      commandType,
      commandText: generateCommandText(commandType, parameters),
      parameters,
      executed: false,
    }
  });

  // Execute command based on type
  let executionResult;
  try {
    switch (commandType) {
      case 'create_document':
        executionResult = await executeCreateDocument(parameters, voiceJob);
        break;
      case 'update_return':
        executionResult = await executeUpdateReturn(parameters, voiceJob);
        break;
      case 'schedule_appointment':
        executionResult = await executeScheduleAppointment(parameters, voiceJob);
        break;
      case 'send_notification':
        executionResult = await executeSendNotification(parameters, voiceJob);
        break;
      default:
        throw new Error(`Unknown command type: ${commandType}`);
    }

    // Update command with execution result
    await prisma.voiceCommand.update({
      where: { id: command.id },
      data: {
        executed: true,
        executionResult,
      }
    });

    return NextResponse.json({
      success: true,
      command: {
        id: command.id,
        type: commandType,
        executed: true,
      },
      result: executionResult,
    });

  } catch (error) {
    // Update command with error
    await prisma.voiceCommand.update({
      where: { id: command.id },
      data: {
        executed: false,
        executionResult: { error: error.message },
      }
    });

    return NextResponse.json({
      success: false,
      error: error.message,
      command: {
        id: command.id,
        type: commandType,
        executed: false,
      }
    });
  }
}

async function batchProcessAudio(body: any) {
  const { audioFiles, processingType, clientId, userId } = body;

  const results = [];
  const errors = [];

  for (const audioFile of audioFiles) {
    try {
      const result = await processAudioFile({
        clientId,
        userId,
        processingType,
        audioFile: audioFile.data,
        audioFileName: audioFile.name,
        priority: 'medium',
      });
      results.push(result);
    } catch (error) {
      errors.push({
        fileName: audioFile.name,
        error: error.message,
      });
    }
  }

  return NextResponse.json({
    success: true,
    processed: results.length,
    errors: errors.length,
    results,
    errors,
    summary: generateBatchProcessingSummary(results),
  });
}

async function realTimeProcess(body: any) {
  const { audioChunk, sessionId, processingType, clientId, userId } = body;

  // This would handle real-time streaming audio processing
  // For now, implementing a simplified version

  const partialResult = await processAudioChunk(audioChunk, sessionId);

  return NextResponse.json({
    success: true,
    sessionId,
    partialTranscript: partialResult.transcript,
    confidence: partialResult.confidence,
    extractedItems: partialResult.extractedItems,
    isComplete: partialResult.isComplete,
  });
}

// Helper functions
async function processExtractedCommands(voiceJobId: string, processingResult: any): Promise<any[]> {
  const commands = [];
  const extractedData = processingResult.extracted_data;

  // Analyze extracted data for actionable commands
  if (extractedData.amounts && extractedData.amounts.length > 0) {
    commands.push({
      type: 'update_return',
      parameters: {
        amounts: extractedData.amounts,
        category: extractedData.tax_items?.[0] || 'income',
      }
    });
  }

  if (extractedData.action_items && extractedData.action_items.length > 0) {
    for (const actionItem of extractedData.action_items) {
      if (actionItem.toLowerCase().includes('schedule')) {
        commands.push({
          type: 'schedule_appointment',
          parameters: {
            description: actionItem,
            suggestedDate: extractedData.dates?.[0],
          }
        });
      } else if (actionItem.toLowerCase().includes('document')) {
        commands.push({
          type: 'create_document',
          parameters: {
            documentType: 'note',
            content: actionItem,
          }
        });
      }
    }
  }

  // Save commands to database
  const savedCommands = [];
  for (const cmd of commands) {
    const savedCommand = await prisma.voiceCommand.create({
      data: {
        voiceJobId,
        commandType: cmd.type,
        commandText: generateCommandText(cmd.type, cmd.parameters),
        parameters: cmd.parameters,
        executed: false,
      }
    });
    savedCommands.push(savedCommand);
  }

  return savedCommands;
}

async function generateFollowUpActions(
  processingResult: any, 
  processingType: string, 
  client: any, 
  user: any
): Promise<string[]> {
  const actions = [];

  switch (processingType) {
    case 'document_dictation':
      if (processingResult.extracted_data.amounts?.length > 0) {
        actions.push('Review and verify extracted monetary amounts');
        actions.push('Categorize amounts for proper tax form placement');
      }
      if (processingResult.confidence_scores.overall < 0.8) {
        actions.push('Manual review recommended due to low confidence score');
      }
      break;

    case 'client_interview':
      if (processingResult.extracted_data.questions?.length > 0) {
        actions.push('Follow up on client questions identified');
      }
      if (processingResult.extracted_data.concerns?.length > 0) {
        actions.push('Address client concerns in next communication');
      }
      actions.push('Update client profile with interview insights');
      break;

    case 'tax_consultation':
      if (processingResult.extracted_data.topics_discussed?.length > 0) {
        actions.push('Document consultation topics in client file');
      }
      if (processingResult.extracted_data.follow_up_items?.length > 0) {
        actions.push('Schedule follow-up for identified action items');
      }
      break;

    case 'document_review':
      actions.push('Verify document accuracy against voice notes');
      actions.push('Update document status based on review');
      break;
  }

  // Add general follow-up actions
  actions.push('Update client communication log');
  actions.push('Set reminders for any deadlines mentioned');

  return actions;
}

async function createVoiceProcessingNotifications(
  client: any, 
  user: any, 
  processingResult: any, 
  followUpActions: string[]
): Promise<void> {
  // Create notification for user about completed processing
  await prisma.notification.create({
    data: {
      tenantId: client.tenantId,
      userId: user.id,
      type: 'voice_processing_complete',
      channel: 'in_app',
      status: 'pending',
      subject: 'Voice Processing Complete',
      content: `Voice processing completed for ${client.firstName} ${client.lastName}. ${followUpActions.length} follow-up actions identified.`,
      metadata: {
        clientId: client.id,
        processingType: processingResult.processing_type,
        confidence: processingResult.confidence_scores?.overall || 0,
        actionCount: followUpActions.length,
      }
    }
  });

  // Create high-priority notification if confidence is low
  if (processingResult.confidence_scores?.overall < 0.7) {
    await prisma.notification.create({
      data: {
        tenantId: client.tenantId,
        userId: user.id,
        type: 'voice_processing_review_needed',
        channel: 'email',
        status: 'pending',
        subject: 'Voice Processing Review Required',
        content: `Voice processing for ${client.firstName} ${client.lastName} requires manual review due to low confidence score (${Math.round((processingResult.confidence_scores?.overall || 0) * 100)}%).`,
        metadata: {
          clientId: client.id,
          priority: 'high',
          confidence: processingResult.confidence_scores?.overall || 0,
        }
      }
    });
  }
}

async function updateClientInteractionLog(
  clientId: string, 
  processingResult: any, 
  processingType: string
): Promise<void> {
  await prisma.communicationLog.create({
    data: {
      tenantId: (await prisma.client.findUnique({ where: { id: clientId } }))?.tenantId || '',
      clientId,
      communicationType: 'voice_processing',
      direction: 'inbound',
      channel: 'voice',
      content: processingResult.transcript || 'Voice processing completed',
      metadata: {
        processingType,
        extractedData: processingResult.extracted_data,
        confidence: processingResult.confidence_scores,
        actionItems: processingResult.action_items,
      }
    }
  });
}

function calculateQualityMetrics(processingResult: any): any {
  const confidence = processingResult.confidence_scores?.overall || 0;
  const transcriptLength = processingResult.transcript?.length || 0;
  const extractedItemsCount = Object.keys(processingResult.extracted_data || {}).length;

  return {
    overallQuality: confidence > 0.8 ? 'high' : confidence > 0.6 ? 'medium' : 'low',
    transcriptionAccuracy: confidence,
    dataExtractionCompleteness: extractedItemsCount > 3 ? 'comprehensive' : extractedItemsCount > 1 ? 'partial' : 'minimal',
    transcriptLength,
    processingComplexity: transcriptLength > 1000 ? 'high' : transcriptLength > 300 ? 'medium' : 'low',
    recommendedActions: generateQualityRecommendations(confidence, extractedItemsCount),
  };
}

function generateQualityRecommendations(confidence: number, extractedItemsCount: number): string[] {
  const recommendations = [];

  if (confidence < 0.7) {
    recommendations.push('Consider re-recording with better audio quality');
    recommendations.push('Manual review and correction recommended');
  }

  if (extractedItemsCount < 2) {
    recommendations.push('Provide more structured information in voice recordings');
    recommendations.push('Use clear enunciation for numbers and technical terms');
  }

  if (confidence > 0.9 && extractedItemsCount > 5) {
    recommendations.push('Excellent quality - suitable for automated processing');
  }

  return recommendations;
}

function generateCommandText(commandType: string, parameters: any): string {
  switch (commandType) {
    case 'create_document':
      return `Create ${parameters.documentType || 'document'}: ${parameters.content || 'No content'}`;
    case 'update_return':
      return `Update tax return with ${parameters.amounts?.length || 0} amounts in ${parameters.category || 'unknown'} category`;
    case 'schedule_appointment':
      return `Schedule appointment: ${parameters.description || 'No description'}`;
    case 'send_notification':
      return `Send notification: ${parameters.message || 'No message'}`;
    default:
      return `Execute ${commandType} command`;
  }
}

async function executeCreateDocument(parameters: any, voiceJob: any): Promise<any> {
  const documentType = parameters.documentType || 'note';
  const content = parameters.content || '';

  // Create document in the system
  const document = await prisma.document.create({
    data: {
      tenantId: voiceJob.client.tenantId,
      clientId: voiceJob.clientId,
      uploadedByUserId: voiceJob.userId,
      documentType,
      filename: `voice_generated_${documentType}_${Date.now()}.txt`,
      s3Key: `voice_documents/${voiceJob.id}/${documentType}.txt`,
      s3Bucket: 'lawson-tax-documents',
      fileSize: content.length,
      mimeType: 'text/plain',
      status: 'processed',
      extractedData: {
        content,
        generatedFromVoice: true,
        voiceJobId: voiceJob.id,
      }
    }
  });

  return {
    success: true,
    documentId: document.id,
    documentType,
    filename: document.filename,
  };
}

async function executeUpdateReturn(parameters: any, voiceJob: any): Promise<any> {
  const amounts = parameters.amounts || [];
  const category = parameters.category || 'income';

  // Get the most recent tax return for the client
  const taxReturn = await prisma.taxReturn.findFirst({
    where: { clientId: voiceJob.clientId },
    orderBy: { createdAt: 'desc' }
  });

  if (!taxReturn) {
    throw new Error('No tax return found for client');
  }

  // Update tax return with voice-extracted data
  const updatedFormData = {
    ...taxReturn.formData,
    voiceUpdates: {
      ...(taxReturn.formData as any)?.voiceUpdates || {},
      [category]: amounts,
      lastVoiceUpdate: new Date().toISOString(),
      voiceJobId: voiceJob.id,
    }
  };

  const updatedReturn = await prisma.taxReturn.update({
    where: { id: taxReturn.id },
    data: {
      formData: updatedFormData,
      requiresHumanReview: true, // Flag for review since it's voice-generated
      reviewNotes: `Updated via voice processing: ${amounts.length} ${category} amounts added`,
    }
  });

  return {
    success: true,
    taxReturnId: updatedReturn.id,
    updatedCategory: category,
    amountsAdded: amounts.length,
  };
}

async function executeScheduleAppointment(parameters: any, voiceJob: any): Promise<any> {
  const description = parameters.description || 'Voice-scheduled appointment';
  const suggestedDate = parameters.suggestedDate;

  // Create appointment booking
  const appointment = await prisma.appointmentBooking.create({
    data: {
      tenantId: voiceJob.client.tenantId,
      clientId: voiceJob.clientId,
      eaCpaUserId: voiceJob.userId,
      appointmentType: 'consultation',
      status: 'requested',
      notes: description,
      requestedDateTime: suggestedDate ? new Date(suggestedDate) : null,
      metadata: {
        generatedFromVoice: true,
        voiceJobId: voiceJob.id,
        originalTranscript: parameters.originalText,
      }
    }
  });

  return {
    success: true,
    appointmentId: appointment.id,
    status: 'requested',
    description,
  };
}

async function executeSendNotification(parameters: any, voiceJob: any): Promise<any> {
  const message = parameters.message || 'Voice-generated notification';
  const recipient = parameters.recipient || 'client';

  let userId = null;
  let clientId = null;

  if (recipient === 'client') {
    clientId = voiceJob.clientId;
  } else {
    userId = voiceJob.userId;
  }

  const notification = await prisma.notification.create({
    data: {
      tenantId: voiceJob.client.tenantId,
      userId,
      clientId,
      type: 'voice_generated',
      channel: 'in_app',
      status: 'pending',
      subject: 'Voice-Generated Notification',
      content: message,
      metadata: {
        generatedFromVoice: true,
        voiceJobId: voiceJob.id,
        recipient,
      }
    }
  });

  return {
    success: true,
    notificationId: notification.id,
    recipient,
    message,
  };
}

function generateBatchProcessingSummary(results: any[]): any {
  const totalFiles = results.length;
  const successfulProcessing = results.filter(r => r.success).length;
  const averageConfidence = results.reduce((sum, r) => 
    sum + (r.results?.confidenceScores?.overall || 0), 0) / totalFiles;
  
  const totalActionItems = results.reduce((sum, r) => 
    sum + (r.results?.actionItems?.length || 0), 0);

  return {
    totalFiles,
    successfulProcessing,
    successRate: (successfulProcessing / totalFiles) * 100,
    averageConfidence,
    totalActionItems,
    averageProcessingTime: results.reduce((sum, r) => 
      sum + (r.voiceJob?.processingDuration || 0), 0) / totalFiles,
  };
}

async function processAudioChunk(audioChunk: string, sessionId: string): Promise<any> {
  // This would implement real-time streaming processing
  // For now, returning a mock response
  
  return {
    transcript: 'Partial transcript from audio chunk...',
    confidence: 0.85,
    extractedItems: ['amount: $1,500', 'category: business expense'],
    isComplete: false,
  };
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get('tenantId');
    const clientId = searchParams.get('clientId');
    const status = searchParams.get('status');
    const processingType = searchParams.get('processingType');

    if (!tenantId) {
      return NextResponse.json({ error: 'tenantId required' }, { status: 400 });
    }

    let whereClause: any = { tenantId };
    
    if (clientId) whereClause.clientId = clientId;
    if (status) whereClause.status = status;
    if (processingType) whereClause.processingType = processingType;

    const voiceJobs = await prisma.voiceProcessingJob.findMany({
      where: whereClause,
      include: {
        client: {
          select: { firstName: true, lastName: true, email: true }
        },
        user: {
          select: { firstName: true, lastName: true, email: true }
        },
        commands: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    const summary = {
      total: voiceJobs.length,
      completed: voiceJobs.filter(j => j.status === 'completed').length,
      failed: voiceJobs.filter(j => j.status === 'failed').length,
      queued: voiceJobs.filter(j => j.status === 'queued').length,
      averageProcessingTime: voiceJobs
        .filter(j => j.processingDuration)
        .reduce((sum, j) => sum + (j.processingDuration || 0), 0) / 
        voiceJobs.filter(j => j.processingDuration).length || 0,
      totalCommands: voiceJobs.reduce((sum, j) => sum + j.commands.length, 0),
    };

    return NextResponse.json({
      voiceJobs,
      summary,
    });

  } catch (error) {
    console.error('Get Voice Processing Jobs Error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve voice processing jobs' },
      { status: 500 }
    );
  }
}
