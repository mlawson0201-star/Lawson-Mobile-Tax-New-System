
"""
Platform adapters for social media automation
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class BasePlatformAdapter(ABC):
    """Base class for all social media platform adapters"""
    
    def __init__(self, credentials: Dict[str, str]):
        self.credentials = credentials
        self.platform_name = self.__class__.__name__.lower().replace('adapter', '')
        
    @abstractmethod
    async def authenticate(self) -> bool:
        """Authenticate with the platform"""
        pass
    
    @abstractmethod
    async def post_content(self, content: str, media_urls: List[str] = None, 
                          hashtags: List[str] = None, **kwargs) -> Dict[str, Any]:
        """Post content to the platform"""
        pass
    
    @abstractmethod
    async def schedule_post(self, content: str, scheduled_time: datetime,
                           media_urls: List[str] = None, hashtags: List[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """Schedule a post for later"""
        pass
    
    @abstractmethod
    async def get_post_analytics(self, post_id: str) -> Dict[str, Any]:
        """Get analytics for a specific post"""
        pass
    
    @abstractmethod
    async def delete_post(self, post_id: str) -> bool:
        """Delete a post"""
        pass
    
    def format_hashtags(self, hashtags: List[str]) -> str:
        """Format hashtags for the platform"""
        if not hashtags:
            return ""
        return " ".join([f"#{tag.strip('#')}" for tag in hashtags])
    
    def validate_content_length(self, content: str, max_length: int) -> str:
        """Validate and truncate content if necessary"""
        if len(content) <= max_length:
            return content
        return content[:max_length-3] + "..."
    
    async def refresh_token(self) -> bool:
        """Refresh access token if needed"""
        # Default implementation - override in platform-specific adapters
        return True

class PlatformAdapterFactory:
    """Factory for creating platform adapters"""
    
    _adapters = {}
    
    @classmethod
    def register_adapter(cls, platform: str, adapter_class):
        """Register a platform adapter"""
        cls._adapters[platform] = adapter_class
    
    @classmethod
    def create_adapter(cls, platform: str, credentials: Dict[str, str]) -> BasePlatformAdapter:
        """Create a platform adapter instance"""
        if platform not in cls._adapters:
            raise ValueError(f"Unsupported platform: {platform}")
        
        adapter_class = cls._adapters[platform]
        return adapter_class(credentials)
    
    @classmethod
    def get_supported_platforms(cls) -> List[str]:
        """Get list of supported platforms"""
        return list(cls._adapters.keys())

# Import and register all adapters
from .facebook_adapter import FacebookAdapter
from .twitter_adapter import TwitterAdapter
from .linkedin_adapter import LinkedInAdapter
from .tiktok_adapter import TikTokAdapter
from .youtube_adapter import YouTubeAdapter
from .pinterest_adapter import PinterestAdapter
from .snapchat_adapter import SnapchatAdapter
from .reddit_adapter import RedditAdapter
from .google_my_business_adapter import GoogleMyBusinessAdapter

# Register adapters
PlatformAdapterFactory.register_adapter("facebook", FacebookAdapter)
PlatformAdapterFactory.register_adapter("instagram", FacebookAdapter)  # Instagram uses Facebook Graph API
PlatformAdapterFactory.register_adapter("twitter", TwitterAdapter)
PlatformAdapterFactory.register_adapter("linkedin", LinkedInAdapter)
PlatformAdapterFactory.register_adapter("tiktok", TikTokAdapter)
PlatformAdapterFactory.register_adapter("youtube", YouTubeAdapter)
PlatformAdapterFactory.register_adapter("pinterest", PinterestAdapter)
PlatformAdapterFactory.register_adapter("snapchat", SnapchatAdapter)
PlatformAdapterFactory.register_adapter("reddit", RedditAdapter)
PlatformAdapterFactory.register_adapter("google_my_business", GoogleMyBusinessAdapter)
