
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, ArrowRight, ArrowLeft, User, FileText, 
  Settings, Shield, Sparkles, Clock, Target, Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useReward } from 'react-rewards';
import { OnboardingStep, ClientProfile } from '@/lib/types/experience';
import { ClientPersona } from '@/lib/types/client-acquisition';

interface WhiteGloveOnboardingProps {
  steps: OnboardingStep[];
  personas: ClientPersona[];
  onComplete: (profile: Partial<ClientProfile>) => void;
  onStepComplete: (stepId: string, data: any) => void;
  onSkipStep: (stepId: string) => void;
}

const STEP_ICONS = {
  welcome: Sparkles,
  profile: User,
  documents: FileText,
  preferences: Settings,
  verification: Shield,
  completion: Award
};

const PERSONA_BENEFITS = {
  w2_employee: [
    'Simplified tax filing process',
    'Maximum refund optimization',
    'Deduction discovery tools',
    'Year-round tax planning'
  ],
  small_business: [
    'Business expense tracking',
    'Quarterly tax planning',
    'Entity structure advice',
    'Audit protection services'
  ],
  investor: [
    'Capital gains optimization',
    'Tax loss harvesting',
    'Portfolio tax planning',
    'Investment strategy advice'
  ],
  retiree: [
    'RMD planning assistance',
    'Social Security optimization',
    'Healthcare deduction guidance',
    'Estate planning coordination'
  ],
  freelancer: [
    'Self-employment tax guidance',
    'Expense categorization help',
    'Quarterly payment planning',
    'Business deduction optimization'
  ]
};

export default function WhiteGloveOnboarding({
  steps,
  personas,
  onComplete,
  onStepComplete,
  onSkipStep
}: WhiteGloveOnboardingProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [stepData, setStepData] = useState<Record<string, any>>({});
  const [isTransitioning, setIsTransitioning] = useState(false);
  const { reward: confettiReward } = useReward('confetti', 'confetti');

  const currentStep = steps[currentStepIndex];
  const progress = ((currentStepIndex + 1) / steps.length) * 100;

  const handleNext = async () => {
    if (currentStep) {
      onStepComplete(currentStep.id, stepData[currentStep.id] || {});
      
      if (currentStepIndex === steps.length - 1) {
        // Final step - complete onboarding
        confettiReward();
        onComplete(buildClientProfile());
        return;
      }
    }

    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
      setIsTransitioning(false);
    }, 300);
  };

  const handlePrevious = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentStepIndex(prev => Math.max(prev - 1, 0));
      setIsTransitioning(false);
    }, 300);
  };

  const handleSkip = () => {
    if (currentStep && !currentStep.isRequired) {
      onSkipStep(currentStep.id);
      handleNext();
    }
  };

  const updateStepData = (stepId: string, data: any) => {
    setStepData(prev => ({
      ...prev,
      [stepId]: { ...prev[stepId], ...data }
    }));
  };

  const buildClientProfile = (): Partial<ClientProfile> => {
    const profileData = stepData.profile || {};
    const preferencesData = stepData.preferences || {};
    
    return {
      persona: personas.find(p => p.id === profileData.personaId) || personas[0],
      financialGoals: profileData.financialGoals || [],
      riskTolerance: profileData.riskTolerance || 'moderate',
      lifeStage: profileData.lifeStage || 'young_professional',
      taxComplexity: profileData.taxComplexity || 'simple',
      preferredCommunication: preferencesData.communicationChannel || 'email',
      communicationFrequency: preferencesData.frequency || 'monthly',
      timezone: preferencesData.timezone || 'America/New_York',
      completionScore: 85 // Base completion score
    };
  };

  const renderStepContent = () => {
    if (!currentStep) return null;

    const IconComponent = STEP_ICONS[currentStep.type as keyof typeof STEP_ICONS] || User;

    switch (currentStep.type) {
      case 'welcome':
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
              <IconComponent className="w-10 h-10 text-blue-600" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Welcome to Lawson Mobile Tax!
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                We're excited to help you with your taxes. This quick setup will personalize 
                your experience and ensure you get the maximum refund possible.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="text-center p-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Personalized Experience</h3>
                <p className="text-sm text-gray-600">
                  Tailored recommendations based on your unique situation
                </p>
              </div>
              <div className="text-center p-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Maximum Security</h3>
                <p className="text-sm text-gray-600">
                  Bank-level encryption and security for all your data
                </p>
              </div>
              <div className="text-center p-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Expert Support</h3>
                <p className="text-sm text-gray-600">
                  Professional tax experts available when you need them
                </p>
              </div>
            </div>
          </div>
        );

      case 'profile':
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <IconComponent className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Tell Us About Yourself
              </h2>
              <p className="text-gray-600">
                This helps us personalize your tax experience
              </p>
            </div>

            <div className="space-y-6">
              <div>
                <Label className="text-base font-medium mb-4 block">
                  Which best describes your tax situation?
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {personas.map((persona) => (
                    <Card
                      key={persona.id}
                      className={`cursor-pointer transition-all duration-200 ${
                        stepData.profile?.personaId === persona.id
                          ? 'ring-2 ring-blue-500 bg-blue-50'
                          : 'hover:shadow-lg'
                      }`}
                      onClick={() => updateStepData('profile', { personaId: persona.id })}
                    >
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-2">{persona.name}</h3>
                        <p className="text-sm text-gray-600 mb-3">{persona.description}</p>
                        <div className="space-y-1">
                          {PERSONA_BENEFITS[persona.type as keyof typeof PERSONA_BENEFITS]?.slice(0, 2).map((benefit, index) => (
                            <div key={index} className="flex items-center text-xs text-gray-500">
                              <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                              {benefit}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {stepData.profile?.personaId && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="lifeStage">Life Stage</Label>
                      <Select
                        value={stepData.profile?.lifeStage || ''}
                        onValueChange={(value) => updateStepData('profile', { lifeStage: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your life stage" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="student">Student</SelectItem>
                          <SelectItem value="young_professional">Young Professional</SelectItem>
                          <SelectItem value="family">Family</SelectItem>
                          <SelectItem value="pre_retirement">Pre-Retirement</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="taxComplexity">Tax Complexity</Label>
                      <Select
                        value={stepData.profile?.taxComplexity || ''}
                        onValueChange={(value) => updateStepData('profile', { taxComplexity: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="How complex are your taxes?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="simple">Simple (W-2, basic deductions)</SelectItem>
                          <SelectItem value="moderate">Moderate (Multiple income sources)</SelectItem>
                          <SelectItem value="complex">Complex (Business, investments, etc.)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="financialGoals">Financial Goals (Select all that apply)</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                      {[
                        'Maximize refund',
                        'Minimize tax liability',
                        'Retirement planning',
                        'Home ownership',
                        'Education savings',
                        'Business growth',
                        'Investment optimization',
                        'Debt reduction',
                        'Emergency fund'
                      ].map((goal) => (
                        <div key={goal} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={goal}
                            checked={stepData.profile?.financialGoals?.includes(goal) || false}
                            onChange={(e) => {
                              const currentGoals = stepData.profile?.financialGoals || [];
                              const newGoals = e.target.checked
                                ? [...currentGoals, goal]
                                : currentGoals.filter((g: string) => g !== goal);
                              updateStepData('profile', { financialGoals: newGoals });
                            }}
                            className="rounded border-gray-300"
                          />
                          <Label htmlFor={goal} className="text-sm">{goal}</Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        );

      case 'preferences':
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <IconComponent className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Communication Preferences
              </h2>
              <p className="text-gray-600">
                How would you like us to keep you informed?
              </p>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="communicationChannel">Preferred Communication Method</Label>
                  <Select
                    value={stepData.preferences?.communicationChannel || ''}
                    onValueChange={(value) => updateStepData('preferences', { communicationChannel: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="How should we contact you?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="sms">Text Message</SelectItem>
                      <SelectItem value="phone">Phone Call</SelectItem>
                      <SelectItem value="app">In-App Notifications</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="frequency">Communication Frequency</Label>
                  <Select
                    value={stepData.preferences?.frequency || ''}
                    onValueChange={(value) => updateStepData('preferences', { frequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="How often?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly updates</SelectItem>
                      <SelectItem value="monthly">Monthly summaries</SelectItem>
                      <SelectItem value="quarterly">Quarterly check-ins</SelectItem>
                      <SelectItem value="as_needed">Only when needed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="timezone">Time Zone</Label>
                <Select
                  value={stepData.preferences?.timezone || ''}
                  onValueChange={(value) => updateStepData('preferences', { timezone: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your time zone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/New_York">Eastern Time</SelectItem>
                    <SelectItem value="America/Chicago">Central Time</SelectItem>
                    <SelectItem value="America/Denver">Mountain Time</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                    <SelectItem value="America/Anchorage">Alaska Time</SelectItem>
                    <SelectItem value="Pacific/Honolulu">Hawaii Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-blue-50 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">
                  📧 What You'll Receive
                </h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Tax deadline reminders</li>
                  <li>• Personalized tax tips and strategies</li>
                  <li>• Document upload reminders</li>
                  <li>• Refund status updates</li>
                  <li>• Educational content tailored to your situation</li>
                </ul>
              </div>
            </div>
          </div>
        );

      case 'completion':
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <IconComponent className="w-10 h-10 text-green-600" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Welcome to Your Personalized Tax Experience!
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                You're all set! We've customized your dashboard and recommendations 
                based on your preferences. Let's get started on maximizing your tax savings.
              </p>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 mb-4">What's Next?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-white rounded-lg">
                  <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">Upload Documents</h4>
                  <p className="text-sm text-gray-600">Start by uploading your tax documents</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg">
                  <Target className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">Explore Tools</h4>
                  <p className="text-sm text-gray-600">Use our calculators and planning tools</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg">
                  <User className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">Get Expert Help</h4>
                  <p className="text-sm text-gray-600">Schedule a call with our tax professionals</p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <IconComponent className="w-8 h-8 text-gray-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {currentStep.title}
            </h2>
            <p className="text-gray-600">{currentStep.description}</p>
          </div>
        );
    }
  };

  const canProceed = () => {
    if (!currentStep) return false;
    
    switch (currentStep.type) {
      case 'profile':
        return stepData.profile?.personaId && stepData.profile?.lifeStage && stepData.profile?.taxComplexity;
      case 'preferences':
        return stepData.preferences?.communicationChannel && stepData.preferences?.frequency;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Account Setup</h1>
            <Badge variant="outline">
              Step {currentStepIndex + 1} of {steps.length}
            </Badge>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-sm text-gray-600 mt-2">
            <span>Getting started</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
        </div>

        {/* Step Content */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              {!isTransitioning && (
                <motion.div
                  key={currentStepIndex}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {renderStepContent()}
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStepIndex === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <div className="flex space-x-3">
            {currentStep && !currentStep.isRequired && currentStepIndex < steps.length - 1 && (
              <Button variant="ghost" onClick={handleSkip}>
                Skip for now
              </Button>
            )}
            
            <Button
              onClick={handleNext}
              disabled={!canProceed()}
              className="min-w-32"
            >
              {currentStepIndex === steps.length - 1 ? 'Complete Setup' : 'Continue'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>

        {/* Estimated Time */}
        {currentStep && (
          <div className="text-center mt-6">
            <div className="flex items-center justify-center text-sm text-gray-600">
              <Clock className="w-4 h-4 mr-2" />
              <span>Estimated time: {currentStep.estimatedTime} minutes</span>
            </div>
          </div>
        )}
      </div>

      <span id="confetti" />
    </div>
  );
}
