
import cron from 'node-cron';
import { enqueueJob } from './queue';
import { prisma } from '@/lib/prisma';

export class JobScheduler {
  private scheduledJobs: Map<string, cron.ScheduledTask> = new Map();

  constructor() {
    this.setupDefaultSchedules();
  }

  private setupDefaultSchedules() {
    // Daily analytics snapshot generation
    this.schedule('analytics-snapshot', '0 2 * * *', async () => {
      const tenants = await prisma.tenant.findMany({
        where: { active: true },
        select: { id: true },
      });

      for (const tenant of tenants) {
        await enqueueJob('analytics.snapshot.generate', {}, {
          tenantId: tenant.id,
          priority: 1,
        });
      }
    });

    // Hourly GoHighLevel sync for active tenants
    this.schedule('gohighlevel-sync', '0 * * * *', async () => {
      const activeSettings = await prisma.gohighlevel_settings.findMany({
        where: { sync_enabled: true },
        select: { tenant_id: true },
      });

      for (const setting of activeSettings) {
        await enqueueJob('ghl.sync.all', {}, {
          tenantId: setting.tenant_id,
          priority: 2,
        });
      }
    });

    // Task reminders - every 15 minutes
    this.schedule('task-reminders', '*/15 * * * *', async () => {
      const now = new Date();
      const reminderTime = new Date(now.getTime() + 15 * 60 * 1000); // 15 minutes from now

      const tasksWithReminders = await prisma.crm_tasks.findMany({
        where: {
          reminder_at: {
            gte: now,
            lte: reminderTime,
          },
          status: { not: 'COMPLETED' },
        },
        select: { id: true, tenant_id: true },
      });

      for (const task of tasksWithReminders) {
        await enqueueJob('crm.task.reminder', { taskId: task.id }, {
          tenantId: task.tenant_id,
          priority: 3,
        });
      }
    });

    // Appointment reminders - every 5 minutes
    this.schedule('appointment-reminders', '*/5 * * * *', async () => {
      const now = new Date();
      const reminderWindow = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour from now

      const upcomingAppointments = await prisma.crm_appointments.findMany({
        where: {
          start_time: {
            gte: now,
            lte: reminderWindow,
          },
          reminder_sent: false,
          status: 'SCHEDULED',
        },
        select: { id: true, tenant_id: true, start_time: true },
      });

      for (const appointment of upcomingAppointments) {
        const reminderDelay = appointment.start_time.getTime() - now.getTime() - (15 * 60 * 1000); // 15 minutes before
        
        if (reminderDelay > 0) {
          await enqueueJob('crm.appointment.reminder', { appointmentId: appointment.id }, {
            tenantId: appointment.tenant_id,
            priority: 4,
            delay: reminderDelay,
          });

          // Mark reminder as scheduled
          await prisma.crm_appointments.update({
            where: { id: appointment.id },
            data: { reminder_sent: true },
          });
        }
      }
    });

    // Cleanup old webhook events - daily at 3 AM
    this.schedule('cleanup-webhooks', '0 3 * * *', async () => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      await prisma.gohighlevel_webhook_events.deleteMany({
        where: {
          received_at: { lt: thirtyDaysAgo },
          processed: true,
        },
      });
    });

    // Cleanup completed jobs - daily at 4 AM
    this.schedule('cleanup-jobs', '0 4 * * *', async () => {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      await prisma.job_queue.deleteMany({
        where: {
          status: 'COMPLETED',
          completed_at: { lt: sevenDaysAgo },
        },
      });
    });

    // Lead scoring update - every 6 hours
    this.schedule('lead-scoring', '0 */6 * * *', async () => {
      const tenants = await prisma.tenant.findMany({
        where: { active: true },
        select: { id: true },
      });

      for (const tenant of tenants) {
        await enqueueJob('crm.lead.update_scores', {}, {
          tenantId: tenant.id,
          priority: 2,
        });
      }
    });
  }

  schedule(name: string, cronExpression: string, task: () => Promise<void>) {
    if (this.scheduledJobs.has(name)) {
      this.unschedule(name);
    }

    const scheduledTask = cron.schedule(cronExpression, async () => {
      try {
        console.log(`[Scheduler] Running scheduled job: ${name}`);
        await task();
        console.log(`[Scheduler] Completed scheduled job: ${name}`);
      } catch (error) {
        console.error(`[Scheduler] Error in scheduled job ${name}:`, error);
      }
    }, {
      scheduled: false,
    });

    this.scheduledJobs.set(name, scheduledTask);
    scheduledTask.start();
    
    console.log(`[Scheduler] Scheduled job: ${name} with cron: ${cronExpression}`);
  }

  unschedule(name: string) {
    const job = this.scheduledJobs.get(name);
    if (job) {
      job.stop();
      this.scheduledJobs.delete(name);
      console.log(`[Scheduler] Unscheduled job: ${name}`);
    }
  }

  start() {
    console.log('[Scheduler] Starting job scheduler');
    for (const [name, job] of this.scheduledJobs) {
      job.start();
      console.log(`[Scheduler] Started job: ${name}`);
    }
  }

  stop() {
    console.log('[Scheduler] Stopping job scheduler');
    for (const [name, job] of this.scheduledJobs) {
      job.stop();
      console.log(`[Scheduler] Stopped job: ${name}`);
    }
  }

  getScheduledJobs(): string[] {
    return Array.from(this.scheduledJobs.keys());
  }
}

// Global scheduler instance
export const jobScheduler = new JobScheduler();

// Helper functions
export function startScheduler() {
  jobScheduler.start();
}

export function stopScheduler() {
  jobScheduler.stop();
}

export function scheduleJob(name: string, cronExpression: string, task: () => Promise<void>) {
  jobScheduler.schedule(name, cronExpression, task);
}

export function unscheduleJob(name: string) {
  jobScheduler.unschedule(name);
}
