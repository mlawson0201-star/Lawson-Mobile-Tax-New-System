
import AuditDefenseInterface from '@/components/automation/audit-defense-interface';

export const dynamic = 'force-dynamic';

export default function AuditDefensePage() {
  return (
    <div className="space-y-8">
      <AuditDefenseInterface />
    </div>
  );
}
