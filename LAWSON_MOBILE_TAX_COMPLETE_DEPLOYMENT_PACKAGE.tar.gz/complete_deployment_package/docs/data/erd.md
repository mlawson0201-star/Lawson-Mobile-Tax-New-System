
# Entity Relationship Diagram (ERD)
## Lawson Mobile Tax + Formality Tax Platform

---

## 1. Database Schema Overview

### 1.1 Multi-Tenant Data Architecture
The platform uses a multi-tenant architecture with row-level security (RLS) to ensure complete data isolation between tenants while maintaining operational efficiency.

### 1.2 Core Entity Relationships

```mermaid
erDiagram
    %% Core Tenant Management
    TENANT {
        uuid id PK
        string name
        string domain
        string legal_name
        string ein
        jsonb branding_config
        jsonb settings
        string subscription_tier
        decimal revenue_share_rate
        string stripe_connect_account_id
        boolean active
        timestamp created_at
        timestamp updated_at
    }
    
    %% User Management
    USER {
        uuid id PK
        uuid tenant_id FK
        string cognito_user_id
        string email
        string phone
        string first_name
        string last_name
        string role
        jsonb profile_data
        jsonb preferences
        boolean active
        timestamp last_login_at
        timestamp created_at
        timestamp updated_at
    }
    
    ROLE {
        uuid id PK
        uuid tenant_id FK
        string name
        string description
        jsonb permissions
        boolean system_role
        timestamp created_at
        timestamp updated_at
    }
    
    USER_ROLE {
        uuid id PK
        uuid user_id FK
        uuid role_id FK
        timestamp assigned_at
        uuid assigned_by FK
    }
    
    %% Client Management
    CLIENT {
        uuid id PK
        uuid tenant_id FK
        uuid created_by_user_id FK
        string email
        string phone
        string first_name
        string last_name
        string ssn_encrypted
        date date_of_birth
        jsonb address
        string filing_status
        jsonb personal_info
        string client_status
        decimal lifetime_value
        timestamp created_at
        timestamp updated_at
    }
    
    %% Tax Return Management
    TAX_RETURN {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid assigned_preparer_id FK
        string tax_year
        string return_type
        string status
        decimal total_fee
        decimal refund_amount
        jsonb form_data
        jsonb calculations
        decimal ai_confidence_score
        boolean requires_human_review
        string review_notes
        timestamp submitted_at
        timestamp completed_at
        timestamp created_at
        timestamp updated_at
    }
    
    TAX_FORM {
        uuid id PK
        uuid tax_return_id FK
        string form_type
        string form_name
        jsonb form_data
        jsonb validations
        decimal confidence_score
        string status
        timestamp created_at
        timestamp updated_at
    }
    
    %% Document Management
    DOCUMENT {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid tax_return_id FK
        uuid uploaded_by_user_id FK
        string document_type
        string filename
        string s3_key
        string s3_bucket
        integer file_size
        string mime_type
        string status
        jsonb ocr_results
        decimal ocr_confidence
        jsonb extracted_data
        timestamp processed_at
        timestamp created_at
        timestamp updated_at
    }
    
    DOCUMENT_EXTRACTION {
        uuid id PK
        uuid document_id FK
        string field_name
        string field_value
        decimal confidence_score
        jsonb validation_results
        boolean manually_verified
        uuid verified_by_user_id FK
        timestamp verified_at
        timestamp created_at
    }
    
    %% Payment Management
    PAYMENT {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid tax_return_id FK
        string stripe_payment_intent_id
        decimal amount
        decimal platform_fee
        decimal reseller_amount
        string currency
        string status
        string payment_method
        jsonb payment_metadata
        timestamp processed_at
        timestamp created_at
        timestamp updated_at
    }
    
    INVOICE {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid tax_return_id FK
        string invoice_number
        decimal subtotal
        decimal tax_amount
        decimal total_amount
        string status
        jsonb line_items
        timestamp due_date
        timestamp paid_at
        timestamp created_at
        timestamp updated_at
    }
    
    %% Bank Products & Financial Services
    BANK_PRODUCT {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid tax_return_id FK
        string product_type
        string provider
        decimal amount
        decimal apr
        decimal fee
        string status
        jsonb terms
        jsonb disclosures
        string eps_application_id
        timestamp approved_at
        timestamp funded_at
        timestamp created_at
        timestamp updated_at
    }
    
    IDENTITY_VERIFICATION {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        string persona_inquiry_id
        string verification_type
        string status
        jsonb verification_data
        jsonb document_images
        boolean liveness_check_passed
        jsonb risk_assessment
        timestamp completed_at
        timestamp created_at
        timestamp updated_at
    }
    
    %% E-Filing Management
    EFILE_SUBMISSION {
        uuid id PK
        uuid tenant_id FK
        uuid tax_return_id FK
        string olt_submission_id
        string federal_submission_id
        string state_submission_id
        string status
        jsonb submission_data
        jsonb acknowledgment_data
        jsonb rejection_data
        integer retry_count
        timestamp submitted_at
        timestamp accepted_at
        timestamp rejected_at
        timestamp created_at
        timestamp updated_at
    }
    
    EFILE_STATUS_HISTORY {
        uuid id PK
        uuid efile_submission_id FK
        string previous_status
        string new_status
        string reason
        jsonb details
        timestamp changed_at
    }
    
    %% Review & Quality Assurance
    REVIEW_TASK {
        uuid id PK
        uuid tenant_id FK
        uuid tax_return_id FK
        uuid assigned_to_user_id FK
        string task_type
        string priority
        string status
        jsonb review_criteria
        jsonb review_results
        string notes
        timestamp assigned_at
        timestamp completed_at
        timestamp created_at
        timestamp updated_at
    }
    
    QUALITY_CHECK {
        uuid id PK
        uuid tax_return_id FK
        uuid performed_by_user_id FK
        string check_type
        string status
        jsonb check_results
        jsonb issues_found
        string resolution_notes
        timestamp performed_at
        timestamp created_at
    }
    
    %% Communication & Notifications
    NOTIFICATION {
        uuid id PK
        uuid tenant_id FK
        uuid user_id FK
        uuid client_id FK
        string type
        string channel
        string status
        string subject
        text content
        jsonb metadata
        timestamp scheduled_at
        timestamp sent_at
        timestamp delivered_at
        timestamp created_at
    }
    
    COMMUNICATION_LOG {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        uuid user_id FK
        string communication_type
        string direction
        string channel
        text content
        jsonb metadata
        timestamp occurred_at
        timestamp created_at
    }
    
    %% Marketing & Lead Management
    LEAD {
        uuid id PK
        uuid tenant_id FK
        string email
        string phone
        string first_name
        string last_name
        string source
        string campaign
        jsonb utm_data
        string status
        decimal estimated_refund
        jsonb qualification_data
        timestamp converted_at
        timestamp created_at
        timestamp updated_at
    }
    
    MARKETING_CAMPAIGN {
        uuid id PK
        uuid tenant_id FK
        string name
        string type
        string channel
        jsonb configuration
        string status
        decimal budget
        decimal spent
        integer leads_generated
        integer conversions
        timestamp started_at
        timestamp ended_at
        timestamp created_at
        timestamp updated_at
    }
    
    %% Subscription & Billing
    SUBSCRIPTION {
        uuid id PK
        uuid tenant_id FK
        string stripe_subscription_id
        string plan_type
        string status
        decimal monthly_fee
        decimal per_return_fee
        decimal payment_processing_fee
        integer included_returns
        integer used_returns
        timestamp current_period_start
        timestamp current_period_end
        timestamp created_at
        timestamp updated_at
    }
    
    USAGE_METRIC {
        uuid id PK
        uuid tenant_id FK
        uuid subscription_id FK
        string metric_type
        integer quantity
        decimal unit_price
        decimal total_amount
        date usage_date
        timestamp created_at
    }
    
    %% Revenue & Payouts
    PAYOUT {
        uuid id PK
        uuid tenant_id FK
        string stripe_transfer_id
        decimal amount
        string currency
        string status
        jsonb payout_details
        date period_start
        date period_end
        timestamp processed_at
        timestamp created_at
    }
    
    REVENUE_SHARE {
        uuid id PK
        uuid tenant_id FK
        uuid payment_id FK
        uuid payout_id FK
        decimal gross_amount
        decimal platform_fee
        decimal reseller_amount
        decimal platform_percentage
        timestamp calculated_at
        timestamp created_at
    }
    
    %% Audit & Compliance
    AUDIT_LOG {
        uuid id PK
        uuid tenant_id FK
        uuid user_id FK
        string action
        string resource_type
        uuid resource_id
        jsonb old_values
        jsonb new_values
        inet ip_address
        text user_agent
        jsonb additional_data
        timestamp created_at
    }
    
    CONSENT_RECORD {
        uuid id PK
        uuid tenant_id FK
        uuid client_id FK
        string consent_type
        string version
        boolean granted
        jsonb consent_data
        inet ip_address
        text user_agent
        timestamp granted_at
        timestamp revoked_at
        timestamp created_at
    }
    
    %% System Configuration
    SYSTEM_CONFIG {
        uuid id PK
        uuid tenant_id FK
        string config_key
        jsonb config_value
        string description
        boolean is_sensitive
        timestamp updated_at
        uuid updated_by FK
        timestamp created_at
    }
    
    %% Relationships
    TENANT ||--o{ USER : "has"
    TENANT ||--o{ CLIENT : "serves"
    TENANT ||--o{ TAX_RETURN : "processes"
    TENANT ||--o{ SUBSCRIPTION : "subscribes_to"
    TENANT ||--o{ ROLE : "defines"
    
    USER ||--o{ USER_ROLE : "assigned"
    ROLE ||--o{ USER_ROLE : "grants"
    USER ||--o{ CLIENT : "created_by"
    USER ||--o{ TAX_RETURN : "assigned_to"
    USER ||--o{ REVIEW_TASK : "assigned_to"
    
    CLIENT ||--o{ TAX_RETURN : "owns"
    CLIENT ||--o{ DOCUMENT : "uploads"
    CLIENT ||--o{ PAYMENT : "makes"
    CLIENT ||--o{ BANK_PRODUCT : "applies_for"
    CLIENT ||--o{ IDENTITY_VERIFICATION : "undergoes"
    
    TAX_RETURN ||--o{ TAX_FORM : "contains"
    TAX_RETURN ||--o{ DOCUMENT : "supports"
    TAX_RETURN ||--o{ PAYMENT : "requires"
    TAX_RETURN ||--o{ EFILE_SUBMISSION : "submitted_as"
    TAX_RETURN ||--o{ REVIEW_TASK : "requires"
    TAX_RETURN ||--o{ QUALITY_CHECK : "undergoes"
    
    DOCUMENT ||--o{ DOCUMENT_EXTRACTION : "extracts"
    
    PAYMENT ||--o{ INVOICE : "settles"
    PAYMENT ||--o{ REVENUE_SHARE : "generates"
    
    EFILE_SUBMISSION ||--o{ EFILE_STATUS_HISTORY : "tracks"
    
    SUBSCRIPTION ||--o{ USAGE_METRIC : "measures"
    SUBSCRIPTION ||--o{ PAYOUT : "generates"
    
    PAYOUT ||--o{ REVENUE_SHARE : "includes"
    
    LEAD ||--o{ CLIENT : "converts_to"
    MARKETING_CAMPAIGN ||--o{ LEAD : "generates"
```

---

## 2. Table Specifications

### 2.1 Core Tables

#### 2.1.1 Tenant Management

```sql
-- Tenant table with white-label configuration
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(255) UNIQUE NOT NULL,
    legal_name VARCHAR(255) NOT NULL,
    ein VARCHAR(20),
    branding_config JSONB DEFAULT '{}',
    settings JSONB DEFAULT '{}',
    subscription_tier VARCHAR(50) DEFAULT 'basic',
    revenue_share_rate DECIMAL(5,4) DEFAULT 0.30,
    stripe_connect_account_id VARCHAR(255),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_revenue_share CHECK (revenue_share_rate >= 0 AND revenue_share_rate <= 1),
    CONSTRAINT valid_subscription_tier CHECK (subscription_tier IN ('basic', 'professional', 'enterprise'))
);

-- Indexes for performance
CREATE INDEX idx_tenants_domain ON tenants (domain);
CREATE INDEX idx_tenants_active ON tenants (active) WHERE active = true;
CREATE INDEX idx_tenants_stripe_account ON tenants (stripe_connect_account_id);
```

#### 2.1.2 User Management with RBAC

```sql
-- Users table with tenant isolation
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    cognito_user_id VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'client',
    profile_data JSONB DEFAULT '{}',
    preferences JSONB DEFAULT '{}',
    active BOOLEAN DEFAULT true,
    last_login_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_role CHECK (role IN ('super_admin', 'tenant_admin', 'preparer', 'ea', 'cpa', 'client', 'support')),
    UNIQUE(tenant_id, email)
);

-- Row Level Security for multi-tenancy
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON users
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Indexes
CREATE INDEX idx_users_tenant_email ON users (tenant_id, email);
CREATE INDEX idx_users_cognito_id ON users (cognito_user_id);
CREATE INDEX idx_users_role ON users (tenant_id, role);
```

#### 2.1.3 Tax Return Management

```sql
-- Tax returns with comprehensive tracking
CREATE TABLE tax_returns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    assigned_preparer_id UUID REFERENCES users(id),
    tax_year VARCHAR(4) NOT NULL,
    return_type VARCHAR(50) DEFAULT '1040',
    status VARCHAR(50) DEFAULT 'draft',
    total_fee DECIMAL(10,2) DEFAULT 0,
    refund_amount DECIMAL(10,2),
    form_data JSONB DEFAULT '{}',
    calculations JSONB DEFAULT '{}',
    ai_confidence_score DECIMAL(5,4),
    requires_human_review BOOLEAN DEFAULT false,
    review_notes TEXT,
    submitted_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_tax_year CHECK (tax_year ~ '^\d{4}$'),
    CONSTRAINT valid_status CHECK (status IN (
        'draft', 'documents_pending', 'in_progress', 'review_required', 
        'client_review', 'ready_to_file', 'filed', 'accepted', 'rejected', 'completed'
    )),
    CONSTRAINT valid_confidence CHECK (ai_confidence_score IS NULL OR (ai_confidence_score >= 0 AND ai_confidence_score <= 1))
);

-- Enable RLS
ALTER TABLE tax_returns ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON tax_returns
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Performance indexes
CREATE INDEX idx_tax_returns_tenant_status ON tax_returns (tenant_id, status);
CREATE INDEX idx_tax_returns_client ON tax_returns (client_id, tax_year DESC);
CREATE INDEX idx_tax_returns_preparer ON tax_returns (assigned_preparer_id, status);
CREATE INDEX idx_tax_returns_review ON tax_returns (tenant_id, requires_human_review) 
    WHERE requires_human_review = true;
```

#### 2.1.4 Document Processing

```sql
-- Documents with OCR results
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    tax_return_id UUID REFERENCES tax_returns(id) ON DELETE CASCADE,
    uploaded_by_user_id UUID NOT NULL REFERENCES users(id),
    document_type VARCHAR(50) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    s3_key VARCHAR(500) NOT NULL,
    s3_bucket VARCHAR(100) NOT NULL,
    file_size INTEGER NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'uploaded',
    ocr_results JSONB,
    ocr_confidence DECIMAL(5,4),
    extracted_data JSONB DEFAULT '{}',
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_document_type CHECK (document_type IN (
        'w2', '1099_nec', '1099_int', '1099_div', '1099_b', '1099_k', 
        '1098', '1095_a', 'k1', 'other'
    )),
    CONSTRAINT valid_status CHECK (status IN (
        'uploaded', 'processing', 'processed', 'failed', 'verified'
    )),
    CONSTRAINT valid_file_size CHECK (file_size > 0 AND file_size <= 50000000) -- 50MB limit
);

-- Enable RLS
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON documents
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Indexes
CREATE INDEX idx_documents_client_type ON documents (client_id, document_type);
CREATE INDEX idx_documents_return ON documents (tax_return_id, status);
CREATE INDEX idx_documents_processing ON documents (status, created_at) 
    WHERE status IN ('uploaded', 'processing');
```

### 2.2 Financial Tables

#### 2.2.1 Payment Processing

```sql
-- Payments with Stripe integration
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    tax_return_id UUID REFERENCES tax_returns(id) ON DELETE CASCADE,
    stripe_payment_intent_id VARCHAR(255) UNIQUE,
    amount DECIMAL(10,2) NOT NULL,
    platform_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    reseller_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) DEFAULT 'USD',
    status VARCHAR(50) DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_metadata JSONB DEFAULT '{}',
    processed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_amount CHECK (amount > 0),
    CONSTRAINT valid_status CHECK (status IN (
        'pending', 'processing', 'succeeded', 'failed', 'canceled', 'refunded'
    )),
    CONSTRAINT valid_currency CHECK (currency IN ('USD')),
    CONSTRAINT valid_fee_calculation CHECK (platform_fee + reseller_amount <= amount)
);

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON payments
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Indexes
CREATE INDEX idx_payments_tenant_status ON payments (tenant_id, status);
CREATE INDEX idx_payments_stripe_intent ON payments (stripe_payment_intent_id);
CREATE INDEX idx_payments_client ON payments (client_id, created_at DESC);
```

#### 2.2.2 Bank Products (EPS Integration)

```sql
-- Bank products and refund advances
CREATE TABLE bank_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    tax_return_id UUID NOT NULL REFERENCES tax_returns(id) ON DELETE CASCADE,
    product_type VARCHAR(50) NOT NULL,
    provider VARCHAR(50) DEFAULT 'eps_financial',
    amount DECIMAL(10,2) NOT NULL,
    apr DECIMAL(5,4),
    fee DECIMAL(10,2) DEFAULT 0,
    status VARCHAR(50) DEFAULT 'pending',
    terms JSONB DEFAULT '{}',
    disclosures JSONB DEFAULT '{}',
    eps_application_id VARCHAR(255),
    approved_at TIMESTAMP WITH TIME ZONE,
    funded_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_product_type CHECK (product_type IN (
        'refund_advance', 'refund_transfer', 'tax_refund_loan'
    )),
    CONSTRAINT valid_amount CHECK (amount > 0 AND amount <= 7000),
    CONSTRAINT valid_status CHECK (status IN (
        'pending', 'under_review', 'approved', 'funded', 'declined', 'canceled'
    ))
);

-- Enable RLS
ALTER TABLE bank_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON bank_products
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Indexes
CREATE INDEX idx_bank_products_client ON bank_products (client_id, status);
CREATE INDEX idx_bank_products_eps_id ON bank_products (eps_application_id);
CREATE INDEX idx_bank_products_status ON bank_products (tenant_id, status, created_at);
```

### 2.3 Analytics and Tracking Tables

#### 2.3.1 Event Tracking

```sql
-- Event tracking for analytics
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
    session_id VARCHAR(255),
    event_name VARCHAR(100) NOT NULL,
    event_properties JSONB DEFAULT '{}',
    user_properties JSONB DEFAULT '{}',
    page_url TEXT,
    referrer TEXT,
    utm_source VARCHAR(100),
    utm_medium VARCHAR(100),
    utm_campaign VARCHAR(100),
    utm_content VARCHAR(100),
    utm_term VARCHAR(100),
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_event_name CHECK (event_name ~ '^[a-z_]+$')
);

-- Partitioning by month for performance
CREATE TABLE events_2025_01 PARTITION OF events
FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');

-- Indexes
CREATE INDEX idx_events_tenant_name ON events (tenant_id, event_name, created_at);
CREATE INDEX idx_events_user ON events (user_id, created_at);
CREATE INDEX idx_events_session ON events (session_id, created_at);
```

#### 2.3.2 KPI Metrics

```sql
-- Pre-calculated KPI metrics for dashboard performance
CREATE TABLE kpi_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(15,4) NOT NULL,
    metric_metadata JSONB DEFAULT '{}',
    period_type VARCHAR(20) NOT NULL, -- daily, weekly, monthly
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_period_type CHECK (period_type IN ('daily', 'weekly', 'monthly', 'quarterly', 'yearly')),
    UNIQUE(tenant_id, metric_name, period_type, period_start)
);

-- Enable RLS
ALTER TABLE kpi_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON kpi_metrics
    USING (tenant_id = current_setting('app.current_tenant')::uuid);

-- Indexes
CREATE INDEX idx_kpi_metrics_tenant_name ON kpi_metrics (tenant_id, metric_name, period_start DESC);
CREATE INDEX idx_kpi_metrics_period ON kpi_metrics (period_type, period_start);
```

---

## 3. Data Relationships and Constraints

### 3.1 Foreign Key Relationships

```sql
-- Core relationship constraints
ALTER TABLE users ADD CONSTRAINT fk_users_tenant 
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;

ALTER TABLE clients ADD CONSTRAINT fk_clients_tenant 
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;

ALTER TABLE tax_returns ADD CONSTRAINT fk_tax_returns_client 
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE;

ALTER TABLE tax_returns ADD CONSTRAINT fk_tax_returns_preparer 
    FOREIGN KEY (assigned_preparer_id) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE documents ADD CONSTRAINT fk_documents_tax_return 
    FOREIGN KEY (tax_return_id) REFERENCES tax_returns(id) ON DELETE CASCADE;

ALTER TABLE payments ADD CONSTRAINT fk_payments_tax_return 
    FOREIGN KEY (tax_return_id) REFERENCES tax_returns(id) ON DELETE CASCADE;

-- Ensure referential integrity across tenants
ALTER TABLE tax_returns ADD CONSTRAINT fk_tax_returns_tenant_client
    FOREIGN KEY (tenant_id, client_id) REFERENCES clients(tenant_id, id);

ALTER TABLE documents ADD CONSTRAINT fk_documents_tenant_client
    FOREIGN KEY (tenant_id, client_id) REFERENCES clients(tenant_id, id);
```

### 3.2 Business Logic Constraints

```sql
-- Ensure tax returns can only be assigned to preparers within the same tenant
ALTER TABLE tax_returns ADD CONSTRAINT check_preparer_tenant
    CHECK (
        assigned_preparer_id IS NULL OR 
        EXISTS (
            SELECT 1 FROM users 
            WHERE id = assigned_preparer_id 
            AND tenant_id = tax_returns.tenant_id
            AND role IN ('preparer', 'ea', 'cpa', 'tenant_admin')
        )
    );

-- Ensure payment amounts are consistent with tax return fees
ALTER TABLE payments ADD CONSTRAINT check_payment_amount
    CHECK (
        tax_return_id IS NULL OR
        EXISTS (
            SELECT 1 FROM tax_returns 
            WHERE id = payments.tax_return_id 
            AND total_fee = payments.amount
        )
    );

-- Ensure bank products are only for eligible returns
ALTER TABLE bank_products ADD CONSTRAINT check_bank_product_eligibility
    CHECK (
        EXISTS (
            SELECT 1 FROM tax_returns 
            WHERE id = bank_products.tax_return_id 
            AND refund_amount > 0
            AND refund_amount >= bank_products.amount
        )
    );
```

---

## 4. Indexing Strategy

### 4.1 Performance Indexes

```sql
-- Multi-column indexes for common query patterns
CREATE INDEX idx_tax_returns_tenant_status_year ON tax_returns (tenant_id, status, tax_year);
CREATE INDEX idx_documents_client_type_status ON documents (client_id, document_type, status);
CREATE INDEX idx_payments_tenant_date ON payments (tenant_id, created_at DESC) WHERE status = 'succeeded';

-- Partial indexes for specific use cases
CREATE INDEX idx_tax_returns_review_queue ON tax_returns (tenant_id, created_at) 
    WHERE requires_human_review = true AND status = 'review_required';

CREATE INDEX idx_documents_processing_queue ON documents (created_at) 
    WHERE status IN ('uploaded', 'processing');

CREATE INDEX idx_bank_products_pending ON bank_products (tenant_id, created_at) 
    WHERE status = 'pending';

-- Covering indexes for dashboard queries
CREATE INDEX idx_tax_returns_dashboard_covering ON tax_returns (tenant_id, status, created_at) 
    INCLUDE (total_fee, refund_amount, ai_confidence_score);

CREATE INDEX idx_payments_revenue_covering ON payments (tenant_id, created_at) 
    INCLUDE (amount, platform_fee, reseller_amount) 
    WHERE status = 'succeeded';
```

### 4.2 Full-Text Search Indexes

```sql
-- Full-text search for clients
ALTER TABLE clients ADD COLUMN search_vector tsvector;

CREATE INDEX idx_clients_search ON clients USING gin(search_vector);

-- Update search vector on changes
CREATE OR REPLACE FUNCTION update_client_search_vector()
RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('english', 
        COALESCE(NEW.first_name, '') || ' ' ||
        COALESCE(NEW.last_name, '') || ' ' ||
        COALESCE(NEW.email, '') || ' ' ||
        COALESCE(NEW.phone, '')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_client_search_vector
    BEFORE INSERT OR UPDATE ON clients
    FOR EACH ROW EXECUTE FUNCTION update_client_search_vector();
```

---

## 5. Data Partitioning Strategy

### 5.1 Time-Based Partitioning

```sql
-- Partition audit logs by month
CREATE TABLE audit_logs (
    id UUID DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    user_id UUID,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    additional_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- Create monthly partitions
CREATE TABLE audit_logs_2025_01 PARTITION OF audit_logs
FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');

CREATE TABLE audit_logs_2025_02 PARTITION OF audit_logs
FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');

-- Auto-create partitions function
CREATE OR REPLACE FUNCTION create_monthly_partition(table_name text, start_date date)
RETURNS void AS $$
DECLARE
    partition_name text;
    end_date date;
BEGIN
    partition_name := table_name || '_' || to_char(start_date, 'YYYY_MM');
    end_date := start_date + interval '1 month';
    
    EXECUTE format('CREATE TABLE %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)',
        partition_name, table_name, start_date, end_date);
END;
$$ LANGUAGE plpgsql;
```

### 5.2 Tenant-Based Partitioning (Future Consideration)

```sql
-- For very large deployments, consider tenant-based partitioning
-- This is a future optimization when tenant count grows significantly

CREATE TABLE tax_returns_large_tenants (
    LIKE tax_returns INCLUDING ALL
) PARTITION BY LIST (tenant_id);

-- Create partitions for large tenants
CREATE TABLE tax_returns_tenant_001 PARTITION OF tax_returns_large_tenants
FOR VALUES IN ('tenant-uuid-001');

CREATE TABLE tax_returns_tenant_002 PARTITION OF tax_returns_large_tenants
FOR VALUES IN ('tenant-uuid-002');

-- Default partition for smaller tenants
CREATE TABLE tax_returns_small_tenants PARTITION OF tax_returns_large_tenants
DEFAULT;
```

---

## 6. Data Migration and Seeding

### 6.1 Initial Data Setup

```sql
-- Create default system roles
INSERT INTO roles (id, tenant_id, name, description, permissions, system_role) VALUES
(gen_random_uuid(), NULL, 'super_admin', 'System Administrator', 
 '{"all": true}', true),
(gen_random_uuid(), NULL, 'tenant_admin', 'Tenant Administrator', 
 '{"tenant_management": true, "user_management": true, "client_management": true}', true),
(gen_random_uuid(), NULL, 'preparer', 'Tax Preparer', 
 '{"tax_preparation": true, "client_view": true, "document_access": true}', true),
(gen_random_uuid(), NULL, 'ea', 'Enrolled Agent', 
 '{"tax_preparation": true, "review_returns": true, "client_management": true}', true),
(gen_random_uuid(), NULL, 'client', 'Client', 
 '{"own_returns": true, "document_upload": true}', true);

-- Create default system configuration
INSERT INTO system_config (tenant_id, config_key, config_value, description) VALUES
(NULL, 'ai_confidence_threshold', '0.98', 'Minimum AI confidence for auto-processing'),
(NULL, 'max_file_size', '52428800', 'Maximum file upload size in bytes (50MB)'),
(NULL, 'supported_file_types', '["pdf", "jpg", "jpeg", "png", "tiff"]', 'Supported document file types'),
(NULL, 'tax_season_start', '2025-01-15', 'Tax season start date'),
(NULL, 'tax_season_end', '2025-04-15', 'Tax season end date');
```

### 6.2 Sample Data for Development

```sql
-- Create sample tenant for development
INSERT INTO tenants (id, name, domain, legal_name, ein, active) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Demo Tax Firm', 'demo.formalitytax.com', 
 'Demo Tax Firm LLC', '12-3456789', true);

-- Create sample users
INSERT INTO users (tenant_id, cognito_user_id, email, first_name, last_name, role) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'demo-admin-001', 'admin@demo.com', 
 'Demo', 'Admin', 'tenant_admin'),
('550e8400-e29b-41d4-a716-446655440000', 'demo-preparer-001', 'preparer@demo.com', 
 'Demo', 'Preparer', 'preparer'),
('550e8400-e29b-41d4-a716-446655440000', 'demo-client-001', 'client@demo.com', 
 'Demo', 'Client', 'client');

-- Create sample client
INSERT INTO clients (tenant_id, created_by_user_id, email, first_name, last_name, 
                    filing_status, client_status) VALUES
('550e8400-e29b-41d4-a716-446655440000', 
 (SELECT id FROM users WHERE email = 'admin@demo.com'),
 'john.doe@example.com', 'John', 'Doe', 'single', 'active');
```

---

## 7. Data Backup and Recovery

### 7.1 Backup Strategy

```sql
-- Create backup configuration table
CREATE TABLE backup_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_name VARCHAR(100) NOT NULL,
    backup_type VARCHAR(50) NOT NULL, -- full, incremental, differential
    schedule_cron VARCHAR(100) NOT NULL,
    retention_days INTEGER NOT NULL,
    s3_bucket VARCHAR(100) NOT NULL,
    encryption_key_id VARCHAR(255),
    last_run_at TIMESTAMP WITH TIME ZONE,
    last_status VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_backup_type CHECK (backup_type IN ('full', 'incremental', 'differential'))
);

-- Insert default backup jobs
INSERT INTO backup_jobs (job_name, backup_type, schedule_cron, retention_days, s3_bucket) VALUES
('daily_full_backup', 'full', '0 2 * * *', 30, 'lawson-tax-backups'),
('hourly_incremental', 'incremental', '0 * * * *', 7, 'lawson-tax-backups');
```

### 7.2 Point-in-Time Recovery Setup

```sql
-- Enable point-in-time recovery tracking
CREATE TABLE recovery_points (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recovery_point_name VARCHAR(100) NOT NULL,
    recovery_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    backup_location VARCHAR(500) NOT NULL,
    database_size_bytes BIGINT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Function to create recovery point
CREATE OR REPLACE FUNCTION create_recovery_point(point_name text)
RETURNS uuid AS $$
DECLARE
    recovery_id uuid;
BEGIN
    INSERT INTO recovery_points (recovery_point_name, recovery_timestamp, backup_location)
    VALUES (point_name, NOW(), 's3://lawson-tax-backups/recovery-points/' || point_name)
    RETURNING id INTO recovery_id;
    
    RETURN recovery_id;
END;
$$ LANGUAGE plpgsql;
```

---

## 8. Data Privacy and Compliance

### 8.1 PII Encryption

```sql
-- Create encryption functions for PII data
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Function to encrypt SSN
CREATE OR REPLACE FUNCTION encrypt_ssn(ssn text)
RETURNS text AS $$
BEGIN
    RETURN encode(pgp_sym_encrypt(ssn, current_setting('app.encryption_key')), 'base64');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to decrypt SSN
CREATE OR REPLACE FUNCTION decrypt_ssn(encrypted_ssn text)
RETURNS text AS $$
BEGIN
    RETURN pgp_sym_decrypt(decode(encrypted_ssn, 'base64'), current_setting('app.encryption_key'));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update clients table to use encrypted SSN
ALTER TABLE clients ALTER COLUMN ssn_encrypted TYPE text;

-- Create trigger to auto-encrypt SSN on insert/update
CREATE OR REPLACE FUNCTION encrypt_client_pii()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.ssn_encrypted IS NOT NULL AND NEW.ssn_encrypted != OLD.ssn_encrypted THEN
        NEW.ssn_encrypted := encrypt_ssn(NEW.ssn_encrypted);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_encrypt_client_pii
    BEFORE INSERT OR UPDATE ON clients
    FOR EACH ROW EXECUTE FUNCTION encrypt_client_pii();
```

### 8.2 Data Retention Policies

```sql
-- Create data retention policy table
CREATE TABLE data_retention_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name VARCHAR(100) NOT NULL,
    retention_period_days INTEGER NOT NULL,
    deletion_criteria JSONB NOT NULL,
    last_cleanup_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert retention policies
INSERT INTO data_retention_policies (table_name, retention_period_days, deletion_criteria) VALUES
('audit_logs', 2555, '{"condition": "created_at < NOW() - INTERVAL ''7 years''"}'), -- 7 years for tax records
('events', 1095, '{"condition": "created_at < NOW() - INTERVAL ''3 years''"}'), -- 3 years for analytics
('notifications', 365, '{"condition": "created_at < NOW() - INTERVAL ''1 year'' AND status = ''delivered''"}');

-- Cleanup function
CREATE OR REPLACE FUNCTION cleanup_old_data()
RETURNS void AS $$
DECLARE
    policy RECORD;
    deleted_count INTEGER;
BEGIN
    FOR policy IN SELECT * FROM data_retention_policies LOOP
        EXECUTE format('DELETE FROM %I WHERE %s', 
            policy.table_name, 
            policy.deletion_criteria->>'condition');
        
        GET DIAGNOSTICS deleted_count = ROW_COUNT;
        
        UPDATE data_retention_policies 
        SET last_cleanup_at = NOW() 
        WHERE id = policy.id;
        
        RAISE NOTICE 'Cleaned up % rows from %', deleted_count, policy.table_name;
    END LOOP;
END;
$$ LANGUAGE plpgsql;
```

---

## 9. Performance Monitoring

### 9.1 Query Performance Tracking

```sql
-- Create query performance tracking
CREATE TABLE query_performance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    query_hash VARCHAR(64) NOT NULL,
    query_text TEXT NOT NULL,
    execution_time_ms INTEGER NOT NULL,
    rows_returned INTEGER,
    tenant_id UUID,
    user_id UUID,
    executed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    INDEX idx_query_performance_hash (query_hash),
    INDEX idx_query_performance_time (execution_time_ms DESC),
    INDEX idx_query_performance_tenant (tenant_id, executed_at)
);

-- Function to log slow queries
CREATE OR REPLACE FUNCTION log_slow_query(
    p_query_text text,
    p_execution_time integer,
    p_rows_returned integer DEFAULT NULL,
    p_tenant_id uuid DEFAULT NULL,
    p_user_id uuid DEFAULT NULL
)
RETURNS void AS $$
BEGIN
    IF p_execution_time > 1000 THEN -- Log queries slower than 1 second
        INSERT INTO query_performance (
            query_hash, query_text, execution_time_ms, 
            rows_returned, tenant_id, user_id
        ) VALUES (
            md5(p_query_text), p_query_text, p_execution_time,
            p_rows_returned, p_tenant_id, p_user_id
        );
    END IF;
END;
$$ LANGUAGE plpgsql;
```

### 9.2 Database Health Monitoring

```sql
-- Create database health metrics table
CREATE TABLE db_health_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(15,4) NOT NULL,
    metric_unit VARCHAR(20),
    threshold_warning DECIMAL(15,4),
    threshold_critical DECIMAL(15,4),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Function to collect database metrics
CREATE OR REPLACE FUNCTION collect_db_metrics()
RETURNS void AS $$
BEGIN
    -- Connection count
    INSERT INTO db_health_metrics (metric_name, metric_value, metric_unit, threshold_warning, threshold_critical)
    SELECT 'active_connections', count(*), 'connections', 80, 95
    FROM pg_stat_activity WHERE state = 'active';
    
    -- Database size
    INSERT INTO db_health_metrics (metric_name, metric_value, metric_unit, threshold_warning, threshold_critical)
    SELECT 'database_size_gb', pg_database_size(current_database()) / 1024.0^3, 'GB', 100, 150;
    
    -- Cache hit ratio
    INSERT INTO db_health_metrics (metric_name, metric_value, metric_unit, threshold_warning, threshold_critical)
    SELECT 'cache_hit_ratio', 
           round((sum(blks_hit) * 100.0 / sum(blks_hit + blks_read))::numeric, 2),
           'percent', 95, 90
    FROM pg_stat_database;
END;
$$ LANGUAGE plpgsql;
```

---

*Document Version: 1.0*
*Last Updated: August 22, 2025*
*Next Review: September 22, 2025*

---

## Appendices

### Appendix A: Complete Table Creation Scripts
[INSERT COMPLETE DDL SCRIPTS]

### Appendix B: Sample Data Sets
[INSERT SAMPLE DATA FOR TESTING]

### Appendix C: Migration Scripts
[INSERT DATABASE MIGRATION PROCEDURES]

### Appendix D: Performance Tuning Queries
[INSERT PERFORMANCE OPTIMIZATION QUERIES]

