
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  User, 
  Mail, 
  Phone, 
  Building, 
  Calendar, 
  CheckCircle, 
  Clock, 
  MessageSquare,
  Edit,
  Trash2,
  Plus,
  ExternalLink
} from 'lucide-react';
import { LeadForm } from './LeadForm';
import { TaskForm } from './TaskForm';
import { AppointmentForm } from './AppointmentForm';
import { CommunicationLog } from './CommunicationLog';
import { useToast } from '@/components/ui/use-toast';

interface LeadDetailsProps {
  lead: any;
  onUpdate: (lead: any) => void;
  onDelete: (leadId: string) => void;
  onClose: () => void;
}

export function LeadDetails({ lead, onUpdate, onDelete, onClose }: LeadDetailsProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [leadDetails, setLeadDetails] = useState(lead);
  const [tasks, setTasks] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [communications, setCommunications] = useState([]);

  useEffect(() => {
    fetchLeadDetails();
  }, [lead.id]);

  const fetchLeadDetails = async () => {
    try {
      const response = await fetch(`/api/crm/leads/${lead.id}`);
      if (response.ok) {
        const data = await response.json();
        setLeadDetails(data.lead);
        setTasks(data.lead.tasks || []);
        setAppointments(data.lead.appointments || []);
        setCommunications(data.lead.communication_logs || []);
      }
    } catch (error) {
      console.error('Error fetching lead details:', error);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this lead? This action cannot be undone.')) {
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/crm/leads/${lead.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast({
          title: 'Lead Deleted',
          description: 'The lead has been deleted successfully.',
        });
        onDelete(lead.id);
      } else {
        throw new Error('Failed to delete lead');
      }
    } catch (error) {
      console.error('Error deleting lead:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete lead',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLeadUpdated = (updatedLead: any) => {
    setLeadDetails(updatedLead);
    onUpdate(updatedLead);
    setShowEditForm(false);
  };

  const getStatusColor = (status: string) => {
    const colors = {
      NEW: 'bg-blue-100 text-blue-800',
      CONTACTED: 'bg-yellow-100 text-yellow-800',
      QUALIFIED: 'bg-green-100 text-green-800',
      PROPOSAL_SENT: 'bg-purple-100 text-purple-800',
      NEGOTIATING: 'bg-orange-100 text-orange-800',
      WON: 'bg-green-100 text-green-800',
      LOST: 'bg-red-100 text-red-800',
      NURTURING: 'bg-gray-100 text-gray-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div className="flex items-center space-x-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="text-lg">
              {leadDetails.first_name[0]}{leadDetails.last_name[0]}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-2xl font-bold">
              {leadDetails.first_name} {leadDetails.last_name}
            </h2>
            <p className="text-muted-foreground">{leadDetails.email}</p>
            {leadDetails.company && (
              <p className="text-sm text-muted-foreground">{leadDetails.company}</p>
            )}
            <div className="flex items-center space-x-2 mt-2">
              <Badge className={getStatusColor(leadDetails.status)}>
                {leadDetails.status.replace('_', ' ')}
              </Badge>
              {leadDetails.pipeline_stage && (
                <Badge variant="outline" style={{ borderColor: leadDetails.pipeline_stage.color }}>
                  {leadDetails.pipeline_stage.name}
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setShowEditForm(true)}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="destructive" onClick={handleDelete} disabled={loading}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Lead Score</p>
                <p className="text-2xl font-bold">{leadDetails.lead_score || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Communications</p>
                <p className="text-2xl font-bold">{communications.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Open Tasks</p>
                <p className="text-2xl font-bold">{tasks.filter((t: any) => t.status !== 'COMPLETED').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Appointments</p>
                <p className="text-2xl font-bold">{appointments.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Information */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="communications">Communications</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{leadDetails.email}</span>
                </div>
                {leadDetails.phone && (
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{leadDetails.phone}</span>
                  </div>
                )}
                {leadDetails.company && (
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span>{leadDetails.company}</span>
                  </div>
                )}
                {leadDetails.job_title && (
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>{leadDetails.job_title}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lead Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium">Source</p>
                  <p className="text-sm text-muted-foreground">{leadDetails.source.replace('_', ' ')}</p>
                </div>
                {leadDetails.estimated_value && (
                  <div>
                    <p className="text-sm font-medium">Estimated Value</p>
                    <p className="text-sm text-muted-foreground">${leadDetails.estimated_value.toLocaleString()}</p>
                  </div>
                )}
                {leadDetails.expected_close_date && (
                  <div>
                    <p className="text-sm font-medium">Expected Close Date</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(leadDetails.expected_close_date).toLocaleDateString()}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium">Created</p>
                  <p className="text-sm text-muted-foreground">{formatDate(leadDetails.created_at)}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {leadDetails.tags && leadDetails.tags.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {leadDetails.tags.map((tag: string) => (
                    <Badge key={tag} variant="secondary">{tag}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {leadDetails.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{leadDetails.notes}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Tasks</h3>
            <Button onClick={() => setShowTaskForm(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Task
            </Button>
          </div>
          
          <div className="space-y-2">
            {tasks.map((task: any) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{task.title}</h4>
                      {task.description && (
                        <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                      )}
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant={task.status === 'COMPLETED' ? 'default' : 'secondary'}>
                          {task.status}
                        </Badge>
                        <Badge variant="outline">{task.priority}</Badge>
                        {task.due_date && (
                          <span className="text-xs text-muted-foreground">
                            Due: {new Date(task.due_date).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    {task.assigned_user && (
                      <div className="text-sm text-muted-foreground">
                        {task.assigned_user.firstName} {task.assigned_user.lastName}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {tasks.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">No tasks found. Create a task to get started.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="appointments" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Appointments</h3>
            <Button onClick={() => setShowAppointmentForm(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Schedule Appointment
            </Button>
          </div>
          
          <div className="space-y-2">
            {appointments.map((appointment: any) => (
              <Card key={appointment.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{appointment.title}</h4>
                      {appointment.description && (
                        <p className="text-sm text-muted-foreground mt-1">{appointment.description}</p>
                      )}
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge>{appointment.status}</Badge>
                        <span className="text-sm text-muted-foreground">
                          {formatDate(appointment.start_time)}
                        </span>
                        {appointment.location && (
                          <span className="text-sm text-muted-foreground">
                            📍 {appointment.location}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {appointments.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">No appointments scheduled.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="communications" className="space-y-4">
          <CommunicationLog leadId={leadDetails.id} communications={communications} />
        </TabsContent>
      </Tabs>

      {/* Edit Lead Dialog */}
      <Dialog open={showEditForm} onOpenChange={setShowEditForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Lead</DialogTitle>
            <DialogDescription>
              Update the lead's information
            </DialogDescription>
          </DialogHeader>
          <LeadForm
            lead={leadDetails}
            onSuccess={handleLeadUpdated}
            onCancel={() => setShowEditForm(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Task Form Dialog */}
      <Dialog open={showTaskForm} onOpenChange={setShowTaskForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Task</DialogTitle>
            <DialogDescription>
              Create a new task for this lead
            </DialogDescription>
          </DialogHeader>
          <TaskForm
            leadId={leadDetails.id}
            onSuccess={() => {
              setShowTaskForm(false);
              fetchLeadDetails();
            }}
            onCancel={() => setShowTaskForm(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Appointment Form Dialog */}
      <Dialog open={showAppointmentForm} onOpenChange={setShowAppointmentForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Appointment</DialogTitle>
            <DialogDescription>
              Schedule a new appointment with this lead
            </DialogDescription>
          </DialogHeader>
          <AppointmentForm
            leadId={leadDetails.id}
            onSuccess={() => {
              setShowAppointmentForm(false);
              fetchLeadDetails();
            }}
            onCancel={() => setShowAppointmentForm(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
