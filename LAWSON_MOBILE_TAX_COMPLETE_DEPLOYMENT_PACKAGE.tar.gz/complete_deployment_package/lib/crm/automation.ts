
import { prisma } from '@/lib/prisma';
import { createGoHighLevelClient } from '@/lib/gohighlevel/client';
import { createSyncService } from '@/lib/gohighlevel/sync';
import { AutomationTrigger, AutomationAction, LeadStatus, CommunicationType, TaskStatus, TaskPriority } from '@prisma/client';

export interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  triggerType: AutomationTrigger;
  triggerConditions: Record<string, any>;
  actions: AutomationActionConfig[];
  isActive: boolean;
}

export interface AutomationActionConfig {
  type: AutomationAction;
  config: Record<string, any>;
  delay?: number; // delay in minutes
}

export interface TriggerContext {
  tenantId: string;
  leadId?: string;
  userId?: string;
  triggerData: Record<string, any>;
  timestamp: Date;
}

export class CRMAutomationEngine {
  private tenantId: string;

  constructor(tenantId: string) {
    this.tenantId = tenantId;
  }

  async processTrigger(trigger: AutomationTrigger, context: TriggerContext): Promise<void> {
    try {
      // Find all active automation rules for this trigger
      const rules = await prisma.crm_automation_rules.findMany({
        where: {
          tenant_id: this.tenantId,
          trigger_type: trigger,
          is_active: true,
        },
      });

      for (const rule of rules) {
        try {
          // Check if trigger conditions are met
          if (await this.evaluateConditions(rule.trigger_conditions as Record<string, any>, context)) {
            await this.executeRule(rule, context);
          }
        } catch (error) {
          console.error(`Error executing automation rule ${rule.id}:`, error);
          await this.logExecution(rule.id, context, 'ERROR', error instanceof Error ? error.message : 'Unknown error');
        }
      }
    } catch (error) {
      console.error('Error processing automation trigger:', error);
    }
  }

  private async evaluateConditions(conditions: Record<string, any>, context: TriggerContext): Promise<boolean> {
    if (!conditions || Object.keys(conditions).length === 0) {
      return true; // No conditions means always execute
    }

    try {
      // Get lead data if needed
      let lead = null;
      if (context.leadId) {
        lead = await prisma.crm_leads.findUnique({
          where: { id: context.leadId },
        });
      }

      // Evaluate each condition
      for (const [key, value] of Object.entries(conditions)) {
        switch (key) {
          case 'leadStatus':
            if (lead && lead.status !== value) return false;
            break;
          case 'leadSource':
            if (lead && lead.source !== value) return false;
            break;
          case 'leadScore':
            if (lead && !this.evaluateNumericCondition(lead.lead_score || 0, value)) return false;
            break;
          case 'tags':
            if (lead && !this.evaluateTagCondition(lead.tags || [], value)) return false;
            break;
          case 'customField':
            if (lead && !this.evaluateCustomFieldCondition(lead.custom_fields as Record<string, any>, value)) return false;
            break;
          case 'daysSinceCreated':
            if (lead && !this.evaluateDateCondition(lead.created_at, value)) return false;
            break;
          default:
            // Check trigger data
            if (context.triggerData[key] !== value) return false;
        }
      }

      return true;
    } catch (error) {
      console.error('Error evaluating conditions:', error);
      return false;
    }
  }

  private evaluateNumericCondition(actual: number, condition: any): boolean {
    if (typeof condition === 'number') {
      return actual === condition;
    }
    if (typeof condition === 'object') {
      if (condition.gt !== undefined && actual <= condition.gt) return false;
      if (condition.gte !== undefined && actual < condition.gte) return false;
      if (condition.lt !== undefined && actual >= condition.lt) return false;
      if (condition.lte !== undefined && actual > condition.lte) return false;
      if (condition.eq !== undefined && actual !== condition.eq) return false;
    }
    return true;
  }

  private evaluateTagCondition(actualTags: string[], condition: any): boolean {
    if (typeof condition === 'string') {
      return actualTags.includes(condition);
    }
    if (Array.isArray(condition)) {
      return condition.some(tag => actualTags.includes(tag));
    }
    if (typeof condition === 'object') {
      if (condition.includes) {
        return Array.isArray(condition.includes) 
          ? condition.includes.every((tag: string) => actualTags.includes(tag))
          : actualTags.includes(condition.includes);
      }
      if (condition.excludes) {
        return Array.isArray(condition.excludes)
          ? !condition.excludes.some((tag: string) => actualTags.includes(tag))
          : !actualTags.includes(condition.excludes);
      }
    }
    return true;
  }

  private evaluateCustomFieldCondition(customFields: Record<string, any>, condition: any): boolean {
    const { field, value, operator = 'equals' } = condition;
    const actualValue = customFields[field];

    switch (operator) {
      case 'equals':
        return actualValue === value;
      case 'not_equals':
        return actualValue !== value;
      case 'contains':
        return typeof actualValue === 'string' && actualValue.includes(value);
      case 'exists':
        return actualValue !== undefined && actualValue !== null;
      case 'not_exists':
        return actualValue === undefined || actualValue === null;
      default:
        return false;
    }
  }

  private evaluateDateCondition(date: Date, condition: any): boolean {
    const now = new Date();
    const daysDiff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (typeof condition === 'number') {
      return daysDiff === condition;
    }
    if (typeof condition === 'object') {
      if (condition.gt !== undefined && daysDiff <= condition.gt) return false;
      if (condition.gte !== undefined && daysDiff < condition.gte) return false;
      if (condition.lt !== undefined && daysDiff >= condition.lt) return false;
      if (condition.lte !== undefined && daysDiff > condition.lte) return false;
    }
    return true;
  }

  private async executeRule(rule: any, context: TriggerContext): Promise<void> {
    const actions = rule.actions as AutomationActionConfig[];
    
    for (const action of actions) {
      try {
        // Apply delay if specified
        if (action.delay && action.delay > 0) {
          // In production, this should be handled by a job queue
          await this.delay(action.delay * 60 * 1000);
        }

        await this.executeAction(action, context);
      } catch (error) {
        console.error(`Error executing action ${action.type}:`, error);
        throw error;
      }
    }

    // Update rule execution count
    await prisma.crm_automation_rules.update({
      where: { id: rule.id },
      data: {
        execution_count: { increment: 1 },
        last_executed_at: new Date(),
      },
    });

    await this.logExecution(rule.id, context, 'SUCCESS');
  }

  private async executeAction(action: AutomationActionConfig, context: TriggerContext): Promise<void> {
    switch (action.type) {
      case AutomationAction.SEND_EMAIL:
        await this.sendEmail(action.config, context);
        break;
      case AutomationAction.SEND_SMS:
        await this.sendSMS(action.config, context);
        break;
      case AutomationAction.CREATE_TASK:
        await this.createTask(action.config, context);
        break;
      case AutomationAction.UPDATE_LEAD_STATUS:
        await this.updateLeadStatus(action.config, context);
        break;
      case AutomationAction.SCHEDULE_FOLLOW_UP:
        await this.scheduleFollowUp(action.config, context);
        break;
      case AutomationAction.ASSIGN_TO_USER:
        await this.assignToUser(action.config, context);
        break;
      case AutomationAction.ADD_TAG:
        await this.addTag(action.config, context);
        break;
      case AutomationAction.WEBHOOK_CALL:
        await this.callWebhook(action.config, context);
        break;
      default:
        console.warn(`Unknown automation action: ${action.type}`);
    }
  }

  private async sendEmail(config: any, context: TriggerContext): Promise<void> {
    if (!context.leadId) return;

    const lead = await prisma.crm_leads.findUnique({
      where: { id: context.leadId },
    });

    if (!lead) return;

    // Use GoHighLevel to send email if configured
    const client = await createGoHighLevelClient(this.tenantId);
    if (client && lead.gohighlevel_contact_id) {
      await client.sendEmail({
        contactId: lead.gohighlevel_contact_id,
        type: 'Email',
        subject: this.replacePlaceholders(config.subject, lead, context),
        message: this.replacePlaceholders(config.message, lead, context),
        templateId: config.templateId,
      });
    }

    // Log communication
    await prisma.crm_communication_logs.create({
      data: {
        tenant_id: this.tenantId,
        lead_id: context.leadId,
        type: CommunicationType.EMAIL,
        subject: config.subject,
        content: config.message,
        direction: 'OUTBOUND',
        status: 'SENT',
        metadata: { automationTriggered: true, ruleId: config.ruleId },
      },
    });
  }

  private async sendSMS(config: any, context: TriggerContext): Promise<void> {
    if (!context.leadId) return;

    const lead = await prisma.crm_leads.findUnique({
      where: { id: context.leadId },
    });

    if (!lead || !lead.phone) return;

    // Use GoHighLevel to send SMS if configured
    const client = await createGoHighLevelClient(this.tenantId);
    if (client && lead.gohighlevel_contact_id) {
      await client.sendSMS({
        contactId: lead.gohighlevel_contact_id,
        type: 'SMS',
        message: this.replacePlaceholders(config.message, lead, context),
      });
    }

    // Log communication
    await prisma.crm_communication_logs.create({
      data: {
        tenant_id: this.tenantId,
        lead_id: context.leadId,
        type: CommunicationType.SMS,
        content: config.message,
        direction: 'OUTBOUND',
        status: 'SENT',
        metadata: { automationTriggered: true, ruleId: config.ruleId },
      },
    });
  }

  private async createTask(config: any, context: TriggerContext): Promise<void> {
    await prisma.crm_tasks.create({
      data: {
        tenant_id: this.tenantId,
        lead_id: context.leadId,
        assigned_to: config.assignedTo || context.userId,
        title: this.replacePlaceholders(config.title, null, context),
        description: config.description ? this.replacePlaceholders(config.description, null, context) : null,
        priority: config.priority || TaskPriority.MEDIUM,
        due_date: config.dueDate ? new Date(config.dueDate) : null,
        tags: config.tags || [],
        metadata: { automationTriggered: true },
      },
    });
  }

  private async updateLeadStatus(config: any, context: TriggerContext): Promise<void> {
    if (!context.leadId) return;

    await prisma.crm_leads.update({
      where: { id: context.leadId },
      data: {
        status: config.status as LeadStatus,
        pipeline_stage_id: config.pipelineStageId,
        updated_at: new Date(),
      },
    });

    // Sync with GoHighLevel
    const syncService = createSyncService(this.tenantId);
    await syncService.updateGoHighLevelContact(context.leadId);
  }

  private async scheduleFollowUp(config: any, context: TriggerContext): Promise<void> {
    const followUpDate = new Date();
    followUpDate.setDate(followUpDate.getDate() + (config.daysFromNow || 1));

    await prisma.crm_tasks.create({
      data: {
        tenant_id: this.tenantId,
        lead_id: context.leadId,
        assigned_to: config.assignedTo || context.userId,
        title: config.title || 'Follow up with lead',
        description: config.description,
        priority: TaskPriority.MEDIUM,
        due_date: followUpDate,
        tags: ['follow-up', 'automation'],
        metadata: { automationTriggered: true, followUpType: config.type },
      },
    });
  }

  private async assignToUser(config: any, context: TriggerContext): Promise<void> {
    if (!context.leadId) return;

    await prisma.crm_leads.update({
      where: { id: context.leadId },
      data: {
        assigned_to: config.userId,
        updated_at: new Date(),
      },
    });
  }

  private async addTag(config: any, context: TriggerContext): Promise<void> {
    if (!context.leadId) return;

    const lead = await prisma.crm_leads.findUnique({
      where: { id: context.leadId },
    });

    if (!lead) return;

    const currentTags = lead.tags || [];
    const newTags = Array.isArray(config.tags) ? config.tags : [config.tags];
    const updatedTags = [...new Set([...currentTags, ...newTags])];

    await prisma.crm_leads.update({
      where: { id: context.leadId },
      data: {
        tags: updatedTags,
        updated_at: new Date(),
      },
    });

    // Sync with GoHighLevel
    const syncService = createSyncService(this.tenantId);
    await syncService.updateGoHighLevelContact(context.leadId);
  }

  private async callWebhook(config: any, context: TriggerContext): Promise<void> {
    const axios = require('axios');
    
    const payload = {
      trigger: context.triggerData,
      leadId: context.leadId,
      tenantId: this.tenantId,
      timestamp: context.timestamp,
      ...config.payload,
    };

    await axios.post(config.url, payload, {
      headers: {
        'Content-Type': 'application/json',
        ...config.headers,
      },
      timeout: 10000,
    });
  }

  private replacePlaceholders(template: string, lead: any, context: TriggerContext): string {
    if (!template) return '';

    let result = template;

    // Replace lead placeholders
    if (lead) {
      result = result.replace(/\{\{lead\.firstName\}\}/g, lead.first_name || '');
      result = result.replace(/\{\{lead\.lastName\}\}/g, lead.last_name || '');
      result = result.replace(/\{\{lead\.email\}\}/g, lead.email || '');
      result = result.replace(/\{\{lead\.phone\}\}/g, lead.phone || '');
      result = result.replace(/\{\{lead\.company\}\}/g, lead.company || '');
      result = result.replace(/\{\{lead\.status\}\}/g, lead.status || '');
    }

    // Replace context placeholders
    result = result.replace(/\{\{date\}\}/g, new Date().toLocaleDateString());
    result = result.replace(/\{\{time\}\}/g, new Date().toLocaleTimeString());

    return result;
  }

  private async logExecution(ruleId: string, context: TriggerContext, status: string, errorMessage?: string): Promise<void> {
    await prisma.crm_automation_executions.create({
      data: {
        tenant_id: this.tenantId,
        rule_id: ruleId,
        lead_id: context.leadId,
        trigger_data: context.triggerData,
        status,
        error_message: errorMessage,
        executed_at: new Date(),
      },
    });
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Trigger functions for common events
export async function triggerLeadCreated(tenantId: string, leadId: string): Promise<void> {
  const engine = new CRMAutomationEngine(tenantId);
  await engine.processTrigger(AutomationTrigger.LEAD_CREATED, {
    tenantId,
    leadId,
    triggerData: { event: 'lead_created' },
    timestamp: new Date(),
  });
}

export async function triggerLeadStatusChanged(tenantId: string, leadId: string, oldStatus: string, newStatus: string): Promise<void> {
  const engine = new CRMAutomationEngine(tenantId);
  await engine.processTrigger(AutomationTrigger.LEAD_STATUS_CHANGED, {
    tenantId,
    leadId,
    triggerData: { event: 'lead_status_changed', oldStatus, newStatus },
    timestamp: new Date(),
  });
}

export async function triggerTaskCompleted(tenantId: string, taskId: string, leadId?: string): Promise<void> {
  const engine = new CRMAutomationEngine(tenantId);
  await engine.processTrigger(AutomationTrigger.TASK_COMPLETED, {
    tenantId,
    leadId,
    triggerData: { event: 'task_completed', taskId },
    timestamp: new Date(),
  });
}

export async function triggerAppointmentBooked(tenantId: string, appointmentId: string, leadId?: string): Promise<void> {
  const engine = new CRMAutomationEngine(tenantId);
  await engine.processTrigger(AutomationTrigger.APPOINTMENT_BOOKED, {
    tenantId,
    leadId,
    triggerData: { event: 'appointment_booked', appointmentId },
    timestamp: new Date(),
  });
}
