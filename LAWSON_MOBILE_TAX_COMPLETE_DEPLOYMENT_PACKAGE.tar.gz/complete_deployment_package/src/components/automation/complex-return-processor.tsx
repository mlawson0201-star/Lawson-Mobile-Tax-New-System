
'use client';

import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Upload, 
  Bot, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Building,
  Globe,
  Coins,
  Home,
  Users,
  Download,
  Clock,
  BarChart3
} from 'lucide-react';

interface ComplexReturnData {
  taxReturnId: string;
  returnComplexity: 'medium' | 'high' | 'very_high';
  schedules: string[];
  businessEntities: any[];
  internationalItems: any[];
  cryptoActivities: any[];
  realEstateTransactions: any[];
  partnershipInterests: any[];
}

interface ProcessingResult {
  status: string;
  result?: any;
  processingMetrics?: {
    automationLevel: number;
    formsProcessed: number;
    deductionsFound: number;
    qualityScore: number;
    requiresHumanReview: boolean;
  };
}

export default function ComplexReturnProcessor() {
  const [step, setStep] = useState<'input' | 'processing' | 'results'>('input');
  const [returnData, setReturnData] = useState<ComplexReturnData>({
    taxReturnId: '',
    returnComplexity: 'high',
    schedules: [],
    businessEntities: [],
    internationalItems: [],
    cryptoActivities: [],
    realEstateTransactions: [],
    partnershipInterests: []
  });
  const [result, setResult] = useState<ProcessingResult | null>(null);
  const [progress, setProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  const complexityLevels = [
    { value: 'medium', label: 'Medium Complexity', description: 'Multiple income sources, standard deductions' },
    { value: 'high', label: 'High Complexity', description: 'Business income, rental properties, investments' },
    { value: 'very_high', label: 'Very High Complexity', description: 'Multi-entity, international, complex structures' }
  ];

  const availableSchedules = [
    'Schedule A - Itemized Deductions',
    'Schedule B - Interest and Dividends',
    'Schedule C - Business Income/Loss',
    'Schedule D - Capital Gains/Losses',
    'Schedule E - Rental/Royalty Income',
    'Schedule F - Farm Income/Loss',
    'Schedule H - Household Employment',
    'Schedule K-1 - Partnership/S-Corp',
    'Schedule R - Credit for Elderly',
    'Schedule SE - Self-Employment Tax',
    'Form 8825 - Rental Real Estate',
    'Form 8949 - Capital Gains Detail',
    'Form 4562 - Depreciation',
    'Form 8582 - Passive Activity Losses'
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const toggleSchedule = (schedule: string) => {
    setReturnData(prev => ({
      ...prev,
      schedules: prev.schedules.includes(schedule)
        ? prev.schedules.filter(s => s !== schedule)
        : [...prev.schedules, schedule]
    }));
  };

  const processComplexReturn = async () => {
    setStep('processing');
    setProgress(0);

    try {
      const response = await fetch('/api/automation/complex-return-processing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(returnData),
      });

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let partialRead = '';

      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined };
        if (done) break;

        partialRead += decoder.decode(value, { stream: true });
        let lines = partialRead.split('\n');
        partialRead = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const parsed = JSON.parse(data);
              if (parsed.status === 'processing') {
                setProgress(prev => Math.min(prev + 15, 90));
              } else if (parsed.status === 'completed') {
                setResult(parsed);
                setProgress(100);
                setStep('results');
                return;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Complex return processing error:', error);
      setStep('input');
    }
  };

  const addComplexElement = (type: keyof ComplexReturnData, element: any) => {
    setReturnData(prev => ({
      ...prev,
      [type]: [...(prev[type] as any[]), element]
    }));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <FileText className="h-12 w-12 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Complex Return Processor</h1>
        <p className="text-lg text-gray-600 mt-2">
          95% Automation for Complex Tax Returns • K-1s, Rental Properties, Multi-Entity
        </p>
      </div>

      {step === 'input' && (
        <div className="space-y-8">
          {/* Tax Return Identification */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Tax Return Information</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tax Return ID
                </label>
                <input
                  type="text"
                  value={returnData.taxReturnId}
                  onChange={(e) => setReturnData(prev => ({ ...prev, taxReturnId: e.target.value }))}
                  placeholder="Enter tax return ID"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Complexity Level
                </label>
                <select
                  value={returnData.returnComplexity}
                  onChange={(e) => setReturnData(prev => ({ ...prev, returnComplexity: e.target.value as any }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {complexityLevels.map((level) => (
                    <option key={level.value} value={level.value}>
                      {level.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Required Schedules */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Required Tax Schedules & Forms</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableSchedules.map((schedule) => (
                <motion.div
                  key={schedule}
                  whileHover={{ scale: 1.02 }}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    returnData.schedules.includes(schedule)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => toggleSchedule(schedule)}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                      returnData.schedules.includes(schedule)
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                    }`}>
                      {returnData.schedules.includes(schedule) && (
                        <CheckCircle className="w-3 h-3 text-white" />
                      )}
                    </div>
                    <span className="text-sm text-gray-900">{schedule}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Complex Elements */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Business Entities */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Building className="h-6 w-6 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900">Business Entities</h3>
              </div>
              
              <div className="space-y-4">
                <button
                  onClick={() => addComplexElement('businessEntities', {
                    type: 'partnership',
                    name: 'New Partnership',
                    k1Forms: 1
                  })}
                  className="w-full p-3 border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                >
                  + Add Business Entity
                </button>
                
                {returnData.businessEntities.length > 0 && (
                  <div className="text-sm text-green-600">
                    {returnData.businessEntities.length} entities added
                  </div>
                )}
              </div>
            </div>

            {/* International Items */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Globe className="h-6 w-6 text-green-600" />
                <h3 className="text-lg font-semibold text-gray-900">International Items</h3>
              </div>
              
              <div className="space-y-4">
                <button
                  onClick={() => addComplexElement('internationalItems', {
                    type: 'foreign_account',
                    country: 'Unknown',
                    reportingForm: 'FBAR'
                  })}
                  className="w-full p-3 border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                >
                  + Add International Item
                </button>
                
                {returnData.internationalItems.length > 0 && (
                  <div className="text-sm text-green-600">
                    {returnData.internationalItems.length} items added
                  </div>
                )}
              </div>
            </div>

            {/* Crypto Activities */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Coins className="h-6 w-6 text-yellow-600" />
                <h3 className="text-lg font-semibold text-gray-900">Crypto Activities</h3>
              </div>
              
              <div className="space-y-4">
                <button
                  onClick={() => addComplexElement('cryptoActivities', {
                    type: 'trading',
                    platform: 'Various',
                    transactions: 0
                  })}
                  className="w-full p-3 border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                >
                  + Add Crypto Activity
                </button>
                
                {returnData.cryptoActivities.length > 0 && (
                  <div className="text-sm text-green-600">
                    {returnData.cryptoActivities.length} activities added
                  </div>
                )}
              </div>
            </div>

            {/* Real Estate */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Home className="h-6 w-6 text-purple-600" />
                <h3 className="text-lg font-semibold text-gray-900">Real Estate</h3>
              </div>
              
              <div className="space-y-4">
                <button
                  onClick={() => addComplexElement('realEstateTransactions', {
                    type: 'rental_property',
                    address: 'Property Address',
                    income: 0
                  })}
                  className="w-full p-3 border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors"
                >
                  + Add Real Estate
                </button>
                
                {returnData.realEstateTransactions.length > 0 && (
                  <div className="text-sm text-green-600">
                    {returnData.realEstateTransactions.length} properties added
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Document Upload */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Supporting Documents</h2>
            
            <div className="flex items-center justify-center w-full">
              <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-10 h-10 mb-3 text-gray-400" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> tax documents
                  </p>
                  <p className="text-xs text-gray-500">K-1s, 1099s, W-2s, receipts (PDF, JPG, PNG)</p>
                </div>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {uploadedFiles.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Uploaded Files:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-800 truncate">{file.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Process Button */}
          <div className="text-center">
            <button
              onClick={processComplexReturn}
              disabled={!returnData.taxReturnId || returnData.schedules.length === 0}
              className="flex items-center space-x-3 px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-lg font-semibold mx-auto"
            >
              <Bot className="h-6 w-6" />
              <span>Process Complex Return</span>
              <TrendingUp className="h-6 w-6" />
            </button>
          </div>
        </div>
      )}

      {step === 'processing' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
          </div>
          
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            Processing Complex Tax Return
          </h2>
          
          <div className="max-w-md mx-auto mb-6">
            <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
              <span>Advanced AI Analysis...</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <motion.div
                className="bg-blue-600 h-3 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-center justify-center space-x-2">
              <Clock className="h-4 w-4" />
              <span>Estimated time: 5-8 minutes</span>
            </div>
            <p>Processing {returnData.schedules.length} schedules with 95%+ automation</p>
          </div>
        </motion.div>
      )}

      {step === 'results' && result && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Success Header */}
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-10 w-10 text-green-600" />
              <div>
                <h2 className="text-2xl font-semibold text-green-900">
                  Complex Return Processed Successfully
                </h2>
                <p className="text-green-700">
                  Automation Level: {result.processingMetrics?.automationLevel || 95}% • 
                  Quality Score: {((result.processingMetrics?.qualityScore || 0.95) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          </div>

          {/* Processing Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
              <BarChart3 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {result.processingMetrics?.automationLevel || 95}%
              </div>
              <div className="text-sm text-gray-600">Automation Level</div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
              <FileText className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {result.processingMetrics?.formsProcessed || 0}
              </div>
              <div className="text-sm text-gray-600">Forms Processed</div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
              <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {result.processingMetrics?.deductionsFound || 0}
              </div>
              <div className="text-sm text-gray-600">Deductions Found</div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
              {result.processingMetrics?.requiresHumanReview ? (
                <AlertTriangle className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              ) : (
                <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
              )}
              <div className="text-2xl font-bold text-gray-900">
                {result.processingMetrics?.requiresHumanReview ? 'Review' : 'Ready'}
              </div>
              <div className="text-sm text-gray-600">Status</div>
            </div>
          </div>

          {/* Results Content */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Processing Results</h3>
            
            {result.result && (
              <div className="space-y-6">
                {/* Summary */}
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-3">Processing Summary</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-blue-700 font-medium">Schedules:</span>
                      <div className="text-blue-600">{returnData.schedules.length} processed</div>
                    </div>
                    <div>
                      <span className="text-blue-700 font-medium">Entities:</span>
                      <div className="text-blue-600">{returnData.businessEntities.length} analyzed</div>
                    </div>
                    <div>
                      <span className="text-blue-700 font-medium">International:</span>
                      <div className="text-blue-600">{returnData.internationalItems.length} items</div>
                    </div>
                    <div>
                      <span className="text-blue-700 font-medium">Properties:</span>
                      <div className="text-blue-600">{returnData.realEstateTransactions.length} processed</div>
                    </div>
                  </div>
                </div>

                {/* Quality Assurance */}
                {result.result.qualityAssurance && (
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-4">Quality Assurance Results</h4>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                        {JSON.stringify(result.result.qualityAssurance, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="mt-8 flex flex-wrap gap-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="h-4 w-4" />
                <span>Download Complete Return</span>
              </button>
              
              {result.processingMetrics?.requiresHumanReview && (
                <button className="flex items-center space-x-2 px-6 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
                  <Users className="h-4 w-4" />
                  <span>Request Human Review</span>
                </button>
              )}
              
              <button className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                <CheckCircle className="h-4 w-4" />
                <span>Submit for E-Filing</span>
              </button>
              
              <button 
                onClick={() => {
                  setStep('input');
                  setResult(null);
                  setProgress(0);
                }}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Process Another Return
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
