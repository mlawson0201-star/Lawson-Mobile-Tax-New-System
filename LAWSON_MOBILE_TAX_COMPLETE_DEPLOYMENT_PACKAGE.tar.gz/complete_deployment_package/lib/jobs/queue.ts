
import { prisma } from '@/lib/prisma';

export interface Job {
  id: string;
  type: string;
  payload: Record<string, any>;
  priority: number;
  attempts: number;
  maxAttempts: number;
  scheduledAt: Date;
  createdAt: Date;
}

export interface JobProcessor {
  (payload: Record<string, any>): Promise<void>;
}

export class JobQueue {
  private processors: Map<string, JobProcessor> = new Map();
  private isProcessing = false;
  private processingInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.setupProcessors();
  }

  private setupProcessors() {
    // CRM Automation Jobs
    this.registerProcessor('crm.automation.execute', this.processAutomationJob);
    this.registerProcessor('crm.lead.sync_to_ghl', this.processSyncLeadJob);
    this.registerProcessor('crm.communication.send_email', this.processSendEmailJob);
    this.registerProcessor('crm.communication.send_sms', this.processSendSMSJob);
    this.registerProcessor('crm.task.reminder', this.processTaskReminderJob);
    this.registerProcessor('crm.appointment.reminder', this.processAppointmentReminderJob);
    this.registerProcessor('ghl.webhook.process', this.processWebhookJob);
    this.registerProcessor('analytics.snapshot.generate', this.processAnalyticsSnapshotJob);
  }

  registerProcessor(jobType: string, processor: JobProcessor) {
    this.processors.set(jobType, processor);
  }

  async enqueue(
    jobType: string,
    payload: Record<string, any>,
    options: {
      priority?: number;
      delay?: number; // delay in milliseconds
      maxAttempts?: number;
      tenantId: string;
    }
  ): Promise<string> {
    const scheduledAt = new Date();
    if (options.delay) {
      scheduledAt.setTime(scheduledAt.getTime() + options.delay);
    }

    const job = await prisma.job_queue.create({
      data: {
        type: jobType,
        payload,
        priority: options.priority || 0,
        max_attempts: options.maxAttempts || 3,
        scheduled_at: scheduledAt,
        tenant_id: options.tenantId,
        status: 'PENDING',
      },
    });

    // Start processing if not already running
    if (!this.isProcessing) {
      this.startProcessing();
    }

    return job.id;
  }

  startProcessing() {
    if (this.isProcessing) return;

    this.isProcessing = true;
    this.processingInterval = setInterval(async () => {
      await this.processJobs();
    }, 5000); // Process jobs every 5 seconds

    console.log('Job queue processing started');
  }

  stopProcessing() {
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
      this.processingInterval = null;
    }
    this.isProcessing = false;
    console.log('Job queue processing stopped');
  }

  private async processJobs() {
    try {
      // Get pending jobs ordered by priority and scheduled time
      const jobs = await prisma.job_queue.findMany({
        where: {
          status: 'PENDING',
          scheduled_at: { lte: new Date() },
          attempts: { lt: prisma.job_queue.fields.max_attempts },
        },
        orderBy: [
          { priority: 'desc' },
          { scheduled_at: 'asc' },
        ],
        take: 10, // Process up to 10 jobs at a time
      });

      for (const job of jobs) {
        await this.processJob(job);
      }
    } catch (error) {
      console.error('Error processing jobs:', error);
    }
  }

  private async processJob(job: any) {
    const processor = this.processors.get(job.type);
    if (!processor) {
      console.warn(`No processor found for job type: ${job.type}`);
      await this.markJobFailed(job.id, 'No processor found');
      return;
    }

    try {
      // Mark job as processing
      await prisma.job_queue.update({
        where: { id: job.id },
        data: {
          status: 'PROCESSING',
          started_at: new Date(),
          attempts: { increment: 1 },
        },
      });

      // Process the job
      await processor(job.payload);

      // Mark job as completed
      await prisma.job_queue.update({
        where: { id: job.id },
        data: {
          status: 'COMPLETED',
          completed_at: new Date(),
        },
      });

      console.log(`Job ${job.id} (${job.type}) completed successfully`);
    } catch (error) {
      console.error(`Job ${job.id} (${job.type}) failed:`, error);

      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Check if we should retry
      if (job.attempts + 1 >= job.max_attempts) {
        await this.markJobFailed(job.id, errorMessage);
      } else {
        // Schedule retry with exponential backoff
        const retryDelay = Math.pow(2, job.attempts) * 60 * 1000; // 1min, 2min, 4min, etc.
        const retryAt = new Date();
        retryAt.setTime(retryAt.getTime() + retryDelay);

        await prisma.job_queue.update({
          where: { id: job.id },
          data: {
            status: 'PENDING',
            scheduled_at: retryAt,
            error_message: errorMessage,
          },
        });
      }
    }
  }

  private async markJobFailed(jobId: string, errorMessage: string) {
    await prisma.job_queue.update({
      where: { id: jobId },
      data: {
        status: 'FAILED',
        error_message: errorMessage,
        failed_at: new Date(),
      },
    });
  }

  // Job Processors
  private async processAutomationJob(payload: any): Promise<void> {
    const { CRMAutomationEngine } = await import('@/lib/crm/automation');
    const { tenantId, trigger, context } = payload;
    
    const engine = new CRMAutomationEngine(tenantId);
    await engine.processTrigger(trigger, context);
  }

  private async processSyncLeadJob(payload: any): Promise<void> {
    const { createSyncService } = await import('@/lib/gohighlevel/sync');
    const { tenantId, leadId } = payload;
    
    const syncService = createSyncService(tenantId);
    await syncService.pushLeadToGoHighLevel(leadId);
  }

  private async processSendEmailJob(payload: any): Promise<void> {
    const { createGoHighLevelClient } = await import('@/lib/gohighlevel/client');
    const { tenantId, contactId, subject, message, templateId } = payload;
    
    const client = await createGoHighLevelClient(tenantId);
    if (client) {
      await client.sendEmail({
        contactId,
        type: 'Email',
        subject,
        message,
        templateId,
      });
    }
  }

  private async processSendSMSJob(payload: any): Promise<void> {
    const { createGoHighLevelClient } = await import('@/lib/gohighlevel/client');
    const { tenantId, contactId, message } = payload;
    
    const client = await createGoHighLevelClient(tenantId);
    if (client) {
      await client.sendSMS({
        contactId,
        type: 'SMS',
        message,
      });
    }
  }

  private async processTaskReminderJob(payload: any): Promise<void> {
    const { tenantId, taskId } = payload;
    
    const task = await prisma.crm_tasks.findUnique({
      where: { id: taskId },
      include: {
        assigned_user: true,
        lead: true,
      },
    });

    if (!task || !task.assigned_user) return;

    // Send reminder notification (implement your notification system here)
    console.log(`Task reminder: ${task.title} is due for ${task.assigned_user.firstName}`);
  }

  private async processAppointmentReminderJob(payload: any): Promise<void> {
    const { tenantId, appointmentId } = payload;
    
    const appointment = await prisma.crm_appointments.findUnique({
      where: { id: appointmentId },
      include: {
        lead: true,
        user: true,
      },
    });

    if (!appointment) return;

    // Send reminder notification
    console.log(`Appointment reminder: ${appointment.title} at ${appointment.start_time}`);
  }

  private async processWebhookJob(payload: any): Promise<void> {
    // Process webhook events that were queued for later processing
    const { tenantId, eventData, webhookEventId } = payload;
    
    // Re-process the webhook event
    // This would call the same processing logic as the webhook handler
    console.log(`Processing queued webhook event: ${eventData.type}`);
  }

  private async processAnalyticsSnapshotJob(payload: any): Promise<void> {
    const { createAnalyticsService } = await import('@/lib/crm/analytics');
    const { tenantId } = payload;
    
    const analyticsService = createAnalyticsService(tenantId);
    await analyticsService.generateAnalyticsSnapshot();
  }
}

// Global job queue instance
export const jobQueue = new JobQueue();

// Helper functions
export async function enqueueJob(
  jobType: string,
  payload: Record<string, any>,
  options: {
    priority?: number;
    delay?: number;
    maxAttempts?: number;
    tenantId: string;
  }
): Promise<string> {
  return jobQueue.enqueue(jobType, payload, options);
}

export function startJobProcessing() {
  jobQueue.startProcessing();
}

export function stopJobProcessing() {
  jobQueue.stopProcessing();
}
