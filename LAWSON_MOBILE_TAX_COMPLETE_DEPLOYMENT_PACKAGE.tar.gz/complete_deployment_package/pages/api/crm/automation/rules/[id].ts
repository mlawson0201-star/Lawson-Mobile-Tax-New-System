
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;
  const ruleId = req.query.id as string;

  switch (req.method) {
    case 'GET':
      return handleGetRule(req, res, tenantId, ruleId);
    case 'PUT':
      return handleUpdateRule(req, res, tenantId, ruleId);
    case 'DELETE':
      return handleDeleteRule(req, res, tenantId, ruleId);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetRule(req: NextApiRequest, res: NextApiResponse, tenantId: string, ruleId: string) {
  try {
    const rule = await prisma.crm_automation_rules.findFirst({
      where: { id: ruleId, tenant_id: tenantId },
      include: {
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        executions: {
          orderBy: { executed_at: 'desc' },
          take: 10,
          include: {
            lead: {
              select: { id: true, first_name: true, last_name: true, email: true },
            },
          },
        },
        _count: {
          select: { executions: true },
        },
      },
    });

    if (!rule) {
      return res.status(404).json({ error: 'Automation rule not found' });
    }

    res.status(200).json({ rule });
  } catch (error) {
    console.error('Error fetching automation rule:', error);
    res.status(500).json({ error: 'Failed to fetch automation rule' });
  }
}

async function handleUpdateRule(req: NextApiRequest, res: NextApiResponse, tenantId: string, ruleId: string) {
  try {
    const existingRule = await prisma.crm_automation_rules.findFirst({
      where: { id: ruleId, tenant_id: tenantId },
    });

    if (!existingRule) {
      return res.status(404).json({ error: 'Automation rule not found' });
    }

    const {
      name,
      description,
      triggerConditions,
      actions,
      isActive,
    } = req.body;

    const updateData: any = {};
    
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (triggerConditions !== undefined) updateData.trigger_conditions = triggerConditions;
    if (actions !== undefined) updateData.actions = actions;
    if (isActive !== undefined) updateData.is_active = isActive;

    updateData.updated_at = new Date();

    const updatedRule = await prisma.crm_automation_rules.update({
      where: { id: ruleId },
      data: updateData,
      include: {
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        _count: {
          select: { executions: true },
        },
      },
    });

    res.status(200).json({ rule: updatedRule });
  } catch (error) {
    console.error('Error updating automation rule:', error);
    res.status(500).json({ error: 'Failed to update automation rule' });
  }
}

async function handleDeleteRule(req: NextApiRequest, res: NextApiResponse, tenantId: string, ruleId: string) {
  try {
    const rule = await prisma.crm_automation_rules.findFirst({
      where: { id: ruleId, tenant_id: tenantId },
    });

    if (!rule) {
      return res.status(404).json({ error: 'Automation rule not found' });
    }

    await prisma.crm_automation_rules.delete({
      where: { id: ruleId },
    });

    res.status(200).json({ message: 'Automation rule deleted successfully' });
  } catch (error) {
    console.error('Error deleting automation rule:', error);
    res.status(500).json({ error: 'Failed to delete automation rule' });
  }
}
