
import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import { prisma } from '@/lib/prisma';
import { triggerTaskCompleted } from '@/lib/crm/automation';
import { TaskStatus } from '@prisma/client';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.tenantId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const tenantId = session.user.tenantId;
  const taskId = req.query.id as string;

  switch (req.method) {
    case 'GET':
      return handleGetTask(req, res, tenantId, taskId);
    case 'PUT':
      return handleUpdateTask(req, res, tenantId, taskId);
    case 'DELETE':
      return handleDeleteTask(req, res, tenantId, taskId);
    default:
      return res.status(405).json({ error: 'Method not allowed' });
  }
}

async function handleGetTask(req: NextApiRequest, res: NextApiResponse, tenantId: string, taskId: string) {
  try {
    const task = await prisma.crm_tasks.findFirst({
      where: { id: taskId, tenant_id: tenantId },
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        lead: {
          select: { id: true, first_name: true, last_name: true, email: true, company: true },
        },
      },
    });

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    res.status(200).json({ task });
  } catch (error) {
    console.error('Error fetching task:', error);
    res.status(500).json({ error: 'Failed to fetch task' });
  }
}

async function handleUpdateTask(req: NextApiRequest, res: NextApiResponse, tenantId: string, taskId: string) {
  try {
    const existingTask = await prisma.crm_tasks.findFirst({
      where: { id: taskId, tenant_id: tenantId },
    });

    if (!existingTask) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const {
      title,
      description,
      status,
      priority,
      dueDate,
      reminderAt,
      tags,
    } = req.body;

    const updateData: any = {};
    
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (status !== undefined) updateData.status = status;
    if (priority !== undefined) updateData.priority = priority;
    if (dueDate !== undefined) updateData.due_date = dueDate ? new Date(dueDate) : null;
    if (reminderAt !== undefined) updateData.reminder_at = reminderAt ? new Date(reminderAt) : null;
    if (tags !== undefined) updateData.tags = tags;

    // Set completion time if status is being changed to completed
    if (status === TaskStatus.COMPLETED && existingTask.status !== TaskStatus.COMPLETED) {
      updateData.completed_at = new Date();
    }

    updateData.updated_at = new Date();

    const updatedTask = await prisma.crm_tasks.update({
      where: { id: taskId },
      data: updateData,
      include: {
        assigned_user: {
          select: { id: true, firstName: true, lastName: true, email: true },
        },
        created_user: {
          select: { id: true, firstName: true, lastName: true },
        },
        lead: {
          select: { id: true, first_name: true, last_name: true, email: true },
        },
      },
    });

    // Trigger automation if task was completed
    if (status === TaskStatus.COMPLETED && existingTask.status !== TaskStatus.COMPLETED) {
      try {
        await triggerTaskCompleted(tenantId, taskId, existingTask.lead_id || undefined);
      } catch (error) {
        console.error('Error triggering task completed automation:', error);
      }
    }

    res.status(200).json({ task: updatedTask });
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
}

async function handleDeleteTask(req: NextApiRequest, res: NextApiResponse, tenantId: string, taskId: string) {
  try {
    const task = await prisma.crm_tasks.findFirst({
      where: { id: taskId, tenant_id: tenantId },
    });

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    await prisma.crm_tasks.delete({
      where: { id: taskId },
    });

    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ error: 'Failed to delete task' });
  }
}
