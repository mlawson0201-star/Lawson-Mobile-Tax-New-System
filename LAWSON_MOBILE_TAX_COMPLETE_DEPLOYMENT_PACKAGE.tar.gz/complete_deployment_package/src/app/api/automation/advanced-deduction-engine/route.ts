
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      taxReturnId, 
      complexScenarios, 
      businessExpenses, 
      multiStateData,
      internationalTransactions,
      cryptoActivity,
      rentalProperties
    } = await request.json();

    if (!taxReturnId) {
      return NextResponse.json({ error: 'Tax return ID required' }, { status: 400 });
    }

    // Get comprehensive tax return data
    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: {
        client: true,
        documents: {
          include: {
            ocrProcessing: true,
          },
        },
        deductionSuggestions: true,
        taxOptimizationSuggestions: true,
      },
    });

    if (!taxReturn) {
      return NextResponse.json({ error: 'Tax return not found' }, { status: 404 });
    }

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: [{
          role: 'user',
          content: `You are an advanced AI tax specialist with expertise in complex deductions and business expenses. Analyze this comprehensive tax scenario and discover all possible deductions using advanced algorithms.

Tax Year: ${taxReturn.taxYear}
Return Type: ${taxReturn.returnType}
Filing Status: ${(taxReturn.formData as any)?.filingStatus}

Client Profile: ${taxReturn.client.firstName} ${taxReturn.client.lastName}
Business Activity: ${JSON.stringify(businessExpenses || {})}

Complex Scenarios:
${JSON.stringify(complexScenarios || {})}

Multi-State Data:
${JSON.stringify(multiStateData || {})}

International Transactions:
${JSON.stringify(internationalTransactions || {})}

Crypto Activity:
${JSON.stringify(cryptoActivity || {})}

Rental Properties:
${JSON.stringify(rentalProperties || {})}

Existing Documents: ${taxReturn.documents.length} documents processed
Current Deductions: ${taxReturn.deductionSuggestions.length} already identified

Perform advanced deduction analysis including:

1. Complex Business Deductions:
   - Advanced depreciation strategies (179, bonus, MACRS)
   - Section 199A deductions optimization
   - R&D expense treatment
   - Interest limitation rules (163(j))
   - Business entertainment (pre/post 2018 rules)

2. Multi-State Tax Optimization:
   - Apportionment strategies
   - State-specific deductions
   - Nexus optimization
   - Sales tax vs income tax elections

3. International Tax Considerations:
   - Foreign tax credit optimization
   - GILTI/FDII calculations
   - Transfer pricing implications
   - Treaty benefits

4. Crypto Tax Optimization:
   - Like-kind exchange analysis (pre-2018)
   - Staking and DeFi deductions
   - Mining expense optimization
   - Loss harvesting strategies

5. Advanced Individual Strategies:
   - Bunching strategies for itemized deductions
   - Roth conversion ladders
   - Tax-loss harvesting
   - Estate planning deductions

6. Risk Assessment:
   - Audit probability for each deduction
   - Documentation requirements
   - Aggressive vs conservative positions

Format response as JSON with detailed deduction recommendations.`
        }],
        stream: true,
        max_tokens: 5000,
        response_format: { type: "json_object" }
      }),
    });

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = '';
        let partialRead = '';

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            let lines = partialRead.split('\n');
            partialRead = lines.pop() || '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  try {
                    const finalResult = JSON.parse(buffer);
                    
                    // Save advanced deduction suggestions
                    if (finalResult.deductionRecommendations) {
                      for (const deduction of finalResult.deductionRecommendations) {
                        await prisma.deductionSuggestion.create({
                          data: {
                            tenantId: session.user.tenantId,
                            taxReturnId: taxReturnId,
                            deductionCategory: deduction.category || 'advanced',
                            deductionAmount: parseFloat(deduction.amount || '0'),
                            description: deduction.description || '',
                            confidenceScore: parseFloat(deduction.confidenceScore || '0.8'),
                            riskLevel: deduction.riskLevel || 'medium',
                            requiredDocumentation: deduction.documentation || [],
                            automaticallyDetected: true,
                            detectionMethod: 'advanced_ai_engine',
                            taxCode: deduction.taxCode || '',
                            auditRisk: parseFloat(deduction.auditRisk || '0.1'),
                            status: 'pending',
                          },
                        });
                      }
                    }

                    const finalData = JSON.stringify({
                      status: 'completed',
                      result: finalResult,
                      totalNewDeductions: finalResult.deductionRecommendations?.length || 0,
                      estimatedAdditionalSavings: finalResult.totalEstimatedSavings || 0,
                      automationLevel: 'advanced'
                    });
                    controller.enqueue(encoder.encode(`data: ${finalData}\n\n`));
                    return;
                  } catch (e) {
                    controller.error(e);
                    return;
                  }
                }
                try {
                  const parsed = JSON.parse(data);
                  buffer += parsed.choices?.[0]?.delta?.content || '';
                  const progressData = JSON.stringify({
                    status: 'processing',
                    message: 'Running advanced deduction algorithms...'
                  });
                  controller.enqueue(encoder.encode(`data: ${progressData}\n\n`));
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Advanced deduction engine stream error:', error);
          controller.error(error);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Advanced deduction engine error:', error);
    return NextResponse.json(
      { error: 'Failed to run advanced deduction analysis' },
      { status: 500 }
    );
  }
}
