
'use client';

import { useSession } from 'next-auth/react';
import { MobileInterface } from '@/components/mobile/mobile-interface';
import { redirect } from 'next/navigation';
// Force dynamic rendering
export const dynamic = 'force-dynamic';

export default function MobileDashboardPage() {
  const { data: session, status } = useSession() || {};
  
  if (status === 'loading') {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Loading...</div>;
  }
  
  if (!session?.user) {
    redirect('/auth/signin');
  }

  const handleVoiceUpload = async (audioBlob: Blob) => {
    const formData = new FormData();
    formData.append('audioFile', audioBlob, 'voice-note.wav');
    formData.append('language', 'en-US');
    formData.append('context', 'tax_info');

    try {
      const response = await fetch('/api/mobile/voice-processing', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Voice processing result:', result);
        // Handle successful voice processing
      }
    } catch (error) {
      console.error('Voice upload error:', error);
    }
  };

  const handleDocumentCapture = async (imageFile: File) => {
    const formData = new FormData();
    formData.append('file', imageFile);
    formData.append('documentType', 'general');

    try {
      const response = await fetch('/api/ai/document-analysis', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Document analysis result:', result);
        // Handle successful document analysis
      }
    } catch (error) {
      console.error('Document capture error:', error);
    }
  };

  const handleStartChat = async () => {
    // Navigate to live chat or initialize chat session
    window.location.href = '/dashboard/live-chat';
  };

  return (
    <div className="h-screen bg-gray-50">
      <MobileInterface
        user={session.user}
        onVoiceUpload={handleVoiceUpload}
        onDocumentCapture={handleDocumentCapture}
        onStartChat={handleStartChat}
      />
    </div>
  );
}
