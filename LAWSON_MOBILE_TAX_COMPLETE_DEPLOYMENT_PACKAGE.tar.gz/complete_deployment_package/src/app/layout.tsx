
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';
import { getCurrentTenant } from '@/lib/tenant';

const inter = Inter({ subsets: ['latin'] });

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const tenant = await getCurrentTenant();
  
  return {
    title: tenant?.name || 'Lawson Mobile Tax',
    description: 'AI-powered tax preparation platform with white-label capabilities',
    keywords: ['tax preparation', 'AI tax', 'white label', 'tax software'],
    authors: [{ name: 'Lawson Mobile Tax' }],
    viewport: 'width=device-width, initial-scale=1',
  };
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const tenant = await getCurrentTenant();
  
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {tenant?.brandingConfig?.favicon && (
          <link rel="icon" href={tenant.brandingConfig.favicon} />
        )}
        <style dangerouslySetInnerHTML={{
          __html: `
            :root {
              --primary-color: ${tenant?.brandingConfig?.primaryColor || '#2563eb'};
              --secondary-color: ${tenant?.brandingConfig?.secondaryColor || '#1e40af'};
            }
          `
        }} />
      </head>
      <body className={inter.className} suppressHydrationWarning>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
